import type { UpdateChannel } from './updateVersion';

export const UPDATE_CHANNEL_STORAGE_KEY = 'jiraautoUpdateChannel';
export const UPDATE_CHANNEL_CHANGED_EVENT = 'jiraautoUpdateChannelChanged';

export const normalizeUpdateChannel = (value: unknown): UpdateChannel =>
  value === 'beta' ? 'beta' : 'stable';

export const loadUpdateChannel = (): UpdateChannel =>
  normalizeUpdateChannel(localStorage.getItem(UPDATE_CHANNEL_STORAGE_KEY));

export const saveUpdateChannel = (channel: UpdateChannel) => {
  localStorage.setItem(UPDATE_CHANNEL_STORAGE_KEY, channel);
  window.dispatchEvent(new CustomEvent<UpdateChannel>(UPDATE_CHANNEL_CHANGED_EVENT, {
    detail: channel,
  }));
};

