import { AlertTriangle, CalendarCheck2, ExternalLink, RefreshCw } from 'lucide-react';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useFloatingWidgetLayout } from '../hooks/useFloatingWidgetLayout';
import {
  CHECKAUTO_WIDGET_SETTINGS_CHANGED_EVENT,
  loadCheckautoWidgetSettings,
  parseCheckautoWidgetResponse,
} from '../utils/checkautoWidget';
import type {
  CheckautoWidgetItem,
  CheckautoWidgetResponse,
  CheckautoWidgetSettings,
} from '../utils/checkautoWidget';

const API_BASE = 'http://localhost:8000/api';
const SEVERITY_ORDER = { need: 0, wait: 1, normal: 2 } as const;

const readError = async (response: Response) => {
  const payload: unknown = await response.json().catch(() => null);
  if (payload && typeof payload === 'object' && 'detail' in payload) {
    const detail = (payload as { detail?: unknown }).detail;
    if (typeof detail === 'string') return detail;
    if (detail && typeof detail === 'object' && 'message' in detail) {
      const message = (detail as { message?: unknown }).message;
      if (typeof message === 'string') return message;
    }
  }
  return 'checkauto 데이터를 불러오지 못했습니다.';
};

const dueTime = (item: CheckautoWidgetItem) => {
  if (!item.due_date) return Number.POSITIVE_INFINITY;
  const parsed = new Date(`${item.due_date}T00:00:00`).getTime();
  return Number.isFinite(parsed) ? parsed : Number.POSITIVE_INFINITY;
};

const formatDate = (value: string | null) => {
  if (!value) return '-';
  const parts = value.split('-');
  return parts.length === 3 ? `${Number(parts[1])}.${Number(parts[2])}` : value;
};

export default function CheckautoFloatingWidget() {
  const [settings, setSettings] = useState<CheckautoWidgetSettings>(loadCheckautoWidgetSettings);
  const [data, setData] = useState<CheckautoWidgetResponse | null>(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [currentTime, setCurrentTime] = useState<number | null>(null);
  const requestRef = useRef<{ id: number; controller: AbortController } | null>(null);
  const requestIdRef = useRef(0);
  const { ref: layoutRef, ...layout } = useFloatingWidgetLayout(
    'checkauto', settings.placement, settings.enabled, 'double',
  );

  useEffect(() => {
    const sync = () => setSettings(loadCheckautoWidgetSettings());
    window.addEventListener(CHECKAUTO_WIDGET_SETTINGS_CHANGED_EVENT, sync);
    window.addEventListener('storage', sync);
    return () => {
      window.removeEventListener(CHECKAUTO_WIDGET_SETTINGS_CHANGED_EVENT, sync);
      window.removeEventListener('storage', sync);
    };
  }, []);

  useEffect(() => {
    const timer = window.setInterval(() => setCurrentTime(Date.now()), 30_000);
    return () => window.clearInterval(timer);
  }, []);

  const load = useCallback(async () => {
    if (!settings.enabled || requestRef.current) return;
    const id = ++requestIdRef.current;
    const controller = new AbortController();
    requestRef.current = { id, controller };
    setLoading(true);
    try {
      // 후보를 넉넉히 받아 클라이언트에서 severity와 기한 기준을 일관되게 적용한다.
      const params = new URLSearchParams({ limit: '50' });
      const response = await fetch(`${API_BASE}/checkauto/widget?${params}`, { signal: controller.signal });
      if (!response.ok) throw new Error(await readError(response));
      const parsed = parseCheckautoWidgetResponse(await response.json());
      setData(parsed);
      setCurrentTime(Date.now());
      setError('');
    } catch (reason) {
      if ((reason as Error).name !== 'AbortError') {
        setError(reason instanceof Error ? reason.message : 'checkauto 데이터를 불러오지 못했습니다.');
      }
    } finally {
      if (requestRef.current?.id === id) {
        requestRef.current = null;
        setLoading(false);
      }
    }
  }, [settings.enabled]);

  useEffect(() => {
    if (!settings.enabled) return;
    const initialTimer = window.setTimeout(() => void load(), 0);
    const refreshTimer = window.setInterval(() => void load(), settings.refreshSeconds * 1000);
    return () => {
      window.clearTimeout(initialTimer);
      window.clearInterval(refreshTimer);
      requestRef.current?.controller.abort();
      requestRef.current = null;
    };
  }, [load, settings.enabled, settings.refreshSeconds]);

  const importantItems = useMemo(() => (
    [...(data?.items || [])]
      .sort((left, right) => (
        SEVERITY_ORDER[left.severity] - SEVERITY_ORDER[right.severity]
        || dueTime(left) - dueTime(right)
        || left.solution_name.localeCompare(right.solution_name, 'ko')
      ))
      .slice(0, settings.itemLimit)
  ), [data?.items, settings.itemLimit]);

  if (!settings.enabled) return null;

  const generatedTime = data ? new Date(data.generated_at).getTime() : Number.NaN;
  const staleAfterMs = Math.max(300, settings.refreshSeconds * 3) * 1000;
  const stale = data !== null && (!Number.isFinite(generatedTime)
    || (currentTime !== null && currentTime - generatedTime > staleAfterMs));
  const empty = data !== null && data.summary.total === 0 && importantItems.length === 0;
  const openDashboard = () => {
    if (data?.dashboard_url) window.open(data.dashboard_url, '_blank', 'noopener,noreferrer');
  };

  return (
    <section
      ref={layoutRef}
      className={`checkauto-floating-widget floating-widget-responsive checkauto-placement-${settings.placement}`}
      data-floating-side={layout.side}
      data-floating-block={layout.block}
      data-floating-stacked={layout.stacked || undefined}
      hidden={layout.hidden}
      aria-hidden={layout.hidden || undefined}
      aria-label="checkauto 점검 현황"
      style={layout.style}
    >
      <header className="checkauto-header">
        <span><CalendarCheck2 size={18} /><strong>점검 현황</strong></span>
        <div className="checkauto-header-actions">
          {stale && <span className="checkauto-state-badge stale">오래된 데이터</span>}
          <button type="button" onClick={() => void load()} disabled={loading} title="새로고침">
            <RefreshCw size={15} className={loading ? 'spinning' : undefined} />
          </button>
          <button type="button" onClick={openDashboard} disabled={!data?.dashboard_url} title="checkauto 열기">
            <ExternalLink size={15} />
          </button>
        </div>
      </header>

      {data && (
        <div className="checkauto-total">
          <span>{data.target_month.replace('-', '년 ')}월</span>
          <strong>{data.summary.total}<small>건</small></strong>
        </div>
      )}

      {data && (
        <div className="checkauto-status-grid">
          <span><strong>{data.summary.planned}</strong>예정</span>
          <span><strong>{data.summary.contacted}</strong>협의 중</span>
          <span><strong>{data.summary.confirmed}</strong>확정</span>
          <span><strong>{data.summary.done}</strong>완료</span>
          <span><strong>{data.summary.carryover}</strong>이월</span>
        </div>
      )}

      {data && (
        <div className="checkauto-attention-grid">
          <span className="need"><strong>{data.summary.action_required}</strong>조치 필요</span>
          <span className="wait"><strong>{data.summary.waiting}</strong>대기</span>
          <span className="error"><strong>{data.summary.errors_7d}</strong>7일 오류</span>
        </div>
      )}

      {error && (
        <div className={`checkauto-warning ${data ? 'compact' : ''}`}>
          <AlertTriangle size={16} /><span>{error}{data ? ' 기존 데이터를 표시합니다.' : ''}</span>
        </div>
      )}
      {!data && !error && <div className="checkauto-empty">checkauto 점검 현황을 불러오는 중입니다.</div>}
      {empty && <div className="checkauto-empty">이번 달 점검 항목이 없습니다.</div>}

      {data && !empty && (
        <div className="checkauto-item-list">
          {importantItems.map(item => (
            <div className={`checkauto-item severity-${item.severity}`} key={String(item.cycle_id)}>
              <span className="checkauto-item-severity" aria-hidden="true" />
              <span className="checkauto-item-main">
                <strong>{item.solution_name}</strong>
                <small>{item.vendor || item.action || '상세 정보 없음'}</small>
              </span>
              <span className="checkauto-item-meta">
                <strong>{item.status_label}</strong>
                <small>{item.due_date ? `기한 ${formatDate(item.due_date)}` : item.action || '기한 없음'}</small>
              </span>
            </div>
          ))}
          {importantItems.length === 0 && <div className="checkauto-empty">표시할 중요 항목이 없습니다.</div>}
        </div>
      )}

      <footer className="checkauto-footer">
        <small>{data && Number.isFinite(generatedTime)
          ? `${new Date(generatedTime).toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit' })} 갱신`
          : '연결 대기 중'}</small>
        <button type="button" onClick={openDashboard} disabled={!data?.dashboard_url}>
          checkauto 열기 <ExternalLink size={13} />
        </button>
      </footer>
    </section>
  );
}
