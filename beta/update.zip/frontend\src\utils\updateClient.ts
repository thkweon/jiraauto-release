import { loadUpdateChannel } from './updateChannel';
import {
  compareSemVer,
  isValidSemVer,
  normalizeUpdateManifest,
  resolveTargetRelease,
  type UpdateChannel,
  type UpdateRelease,
} from './updateVersion';

const API_BASE = 'http://localhost:8000/api';
const REMOTE_VERSION_URL = 'https://raw.githubusercontent.com/thkweon/jiraauto-release/main/version.json';

export interface UpdateStatus {
  localVersion: string;
  installedChannel: UpdateChannel;
  selectedChannel: UpdateChannel;
  target?: UpdateRelease;
  updateAvailable: boolean;
  forcedUpdate: boolean;
  minRequiredVersion?: string;
}

export const fetchUpdateStatus = async (): Promise<UpdateStatus> => {
  const [localResponse, remoteResponse] = await Promise.all([
    fetch(`${API_BASE}/local-version`, { cache: 'no-store' }),
    fetch(`${REMOTE_VERSION_URL}?t=${Date.now()}`, { cache: 'no-store' }),
  ]);
  if (!localResponse.ok) throw new Error(`Local version check failed: ${localResponse.status}`);
  if (!remoteResponse.ok) throw new Error(`Remote version check failed: ${remoteResponse.status}`);

  const localData = await localResponse.json() as { version?: unknown; channel?: unknown };
  const localVersion = isValidSemVer(localData.version)
    ? localData.version.trim().replace(/^v/, '')
    : '0.0.0';
  const installedChannel: UpdateChannel = localData.channel === 'beta' ? 'beta' : 'stable';
  const selectedChannel = loadUpdateChannel();
  const manifest = normalizeUpdateManifest(await remoteResponse.json());
  const target = resolveTargetRelease(manifest, selectedChannel);
  const updateAvailable = Boolean(target && compareSemVer(target.version, localVersion) > 0);
  const forcedUpdate = Boolean(
    updateAvailable
      && manifest.minRequiredVersion
      && compareSemVer(localVersion, manifest.minRequiredVersion) < 0,
  );

  return {
    localVersion,
    installedChannel,
    selectedChannel,
    target,
    updateAvailable,
    forcedUpdate,
    minRequiredVersion: manifest.minRequiredVersion,
  };
};

export const triggerUpdate = async (channel: UpdateChannel, targetVersion: string) => {
  const response = await fetch(`${API_BASE}/trigger-update`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ channel, target_version: targetVersion }),
  });
  const data = await response.json().catch(() => ({})) as { detail?: string; version?: string };
  if (!response.ok) throw new Error(data.detail || `Update request failed: ${response.status}`);
  if (data.version && data.version !== targetVersion) {
    throw new Error('업데이트 확인 중 새 버전이 게시되었습니다. 다시 확인해 주세요.');
  }
  return data;
};

