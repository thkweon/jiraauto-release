export type CheckautoWidgetPlacement =
  | 'left-top-middle'
  | 'left-middle-bottom'
  | 'right-top-middle'
  | 'right-middle-bottom';

export type CheckautoSeverity = 'need' | 'wait' | 'normal';
export type CheckautoOccupiedPosition =
  | 'left-top'
  | 'left-middle'
  | 'left-bottom'
  | 'right-top'
  | 'right-middle'
  | 'right-bottom';

export interface CheckautoWidgetSettings {
  enabled: boolean;
  placement: CheckautoWidgetPlacement;
  refreshSeconds: 30 | 60 | 120 | 300 | 600;
  itemLimit: number;
}

export interface CheckautoWidgetSummary {
  total: number;
  planned: number;
  contacted: number;
  confirmed: number;
  done: number;
  carryover: number;
  action_required: number;
  waiting: number;
  errors_7d: number;
}

export interface CheckautoWidgetItem {
  cycle_id: number | string;
  solution_name: string;
  vendor: string;
  target_month: string;
  status: string;
  status_label: string;
  severity: CheckautoSeverity;
  action: string;
  due_date: string | null;
  confirmed_date: string | null;
}

export interface CheckautoWidgetResponse {
  schema_version: 1;
  generated_at: string;
  target_month: string;
  summary: CheckautoWidgetSummary;
  items: CheckautoWidgetItem[];
  dashboard_url: string | null;
}

export const CHECKAUTO_WIDGET_SETTINGS_STORAGE_KEY = 'jiraautoCheckautoWidgetSettings';
export const CHECKAUTO_WIDGET_SETTINGS_CHANGED_EVENT = 'checkautoWidgetSettingsChanged';
export const CHECKAUTO_WIDGET_PLACEMENTS: CheckautoWidgetPlacement[] = [
  'left-top-middle',
  'left-middle-bottom',
  'right-top-middle',
  'right-middle-bottom',
];

const DEFAULT_SETTINGS: CheckautoWidgetSettings = {
  enabled: false,
  placement: 'left-top-middle',
  refreshSeconds: 60,
  itemLimit: 5,
};

const isRecord = (value: unknown): value is Record<string, unknown> => (
  typeof value === 'object' && value !== null && !Array.isArray(value)
);

const safeString = (value: unknown, fallback = '') => typeof value === 'string' ? value : fallback;

const safeCount = (value: unknown) => {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? Math.max(0, Math.round(parsed)) : 0;
};

const nullableDate = (value: unknown) => typeof value === 'string' && value ? value : null;

const parseItem = (value: unknown): CheckautoWidgetItem | null => {
  if (!isRecord(value)) return null;
  const cycleId = value.cycle_id;
  const solutionName = safeString(value.solution_name).trim();
  if ((typeof cycleId !== 'number' && typeof cycleId !== 'string') || !solutionName) return null;
  const rawSeverity = safeString(value.severity).toLowerCase();
  const severity: CheckautoSeverity = rawSeverity === 'need' || rawSeverity === 'wait'
    ? rawSeverity
    : 'normal';
  return {
    cycle_id: cycleId,
    solution_name: solutionName,
    vendor: safeString(value.vendor),
    target_month: safeString(value.target_month),
    status: safeString(value.status),
    status_label: safeString(value.status_label, safeString(value.status, '상태 미확인')),
    severity,
    action: safeString(value.action),
    due_date: nullableDate(value.due_date),
    confirmed_date: nullableDate(value.confirmed_date),
  };
};

export const parseCheckautoWidgetResponse = (value: unknown): CheckautoWidgetResponse => {
  if (!isRecord(value) || value.schema_version !== 1) throw new Error('지원하지 않는 checkauto 응답입니다.');
  if (!isRecord(value.summary) || !Array.isArray(value.items)) throw new Error('checkauto 응답 형식이 올바르지 않습니다.');
  const generatedAt = safeString(value.generated_at);
  const targetMonth = safeString(value.target_month);
  if (!generatedAt || !targetMonth) throw new Error('checkauto 응답의 기준 시각 또는 대상 월이 없습니다.');
  const summary = value.summary;
  const dashboardUrl = safeString(value.dashboard_url);
  return {
    schema_version: 1,
    generated_at: generatedAt,
    target_month: targetMonth,
    summary: {
      total: safeCount(summary.total),
      planned: safeCount(summary.planned),
      contacted: safeCount(summary.contacted),
      confirmed: safeCount(summary.confirmed),
      done: safeCount(summary.done),
      carryover: safeCount(summary.carryover),
      action_required: safeCount(summary.action_required),
      waiting: safeCount(summary.waiting),
      errors_7d: safeCount(summary.errors_7d),
    },
    items: value.items.map(parseItem).filter((item): item is CheckautoWidgetItem => item !== null),
    dashboard_url: /^https?:\/\//i.test(dashboardUrl) ? dashboardUrl : null,
  };
};

export const getCheckautoOccupiedPositions = (
  placement: CheckautoWidgetPlacement,
): CheckautoOccupiedPosition[] => {
  const [side, first, second] = placement.split('-');
  return [
    `${side}-${first}` as CheckautoOccupiedPosition,
    `${side}-${second}` as CheckautoOccupiedPosition,
  ];
};

export const loadCheckautoWidgetSettings = (): CheckautoWidgetSettings => {
  try {
    const value = JSON.parse(localStorage.getItem(CHECKAUTO_WIDGET_SETTINGS_STORAGE_KEY) || '{}') as Partial<CheckautoWidgetSettings>;
    const refreshSeconds = Number(value.refreshSeconds);
    const itemLimit = Number(value.itemLimit);
    return {
      enabled: typeof value.enabled === 'boolean' ? value.enabled : DEFAULT_SETTINGS.enabled,
      placement: CHECKAUTO_WIDGET_PLACEMENTS.includes(value.placement as CheckautoWidgetPlacement)
        ? value.placement as CheckautoWidgetPlacement
        : DEFAULT_SETTINGS.placement,
      refreshSeconds: [30, 60, 120, 300, 600].includes(refreshSeconds)
        ? refreshSeconds as CheckautoWidgetSettings['refreshSeconds']
        : DEFAULT_SETTINGS.refreshSeconds,
      itemLimit: Number.isFinite(itemLimit)
        ? Math.min(10, Math.max(5, Math.round(itemLimit)))
        : DEFAULT_SETTINGS.itemLimit,
    };
  } catch {
    return DEFAULT_SETTINGS;
  }
};

export const saveCheckautoWidgetSettings = (settings: CheckautoWidgetSettings) => {
  localStorage.setItem(CHECKAUTO_WIDGET_SETTINGS_STORAGE_KEY, JSON.stringify(settings));
  window.dispatchEvent(new CustomEvent<CheckautoWidgetSettings>(
    CHECKAUTO_WIDGET_SETTINGS_CHANGED_EVENT,
    { detail: settings },
  ));
};
