@echo off
setlocal
chcp 65001 > nul
echo =========================================
echo Jira Dashboard Auto-Updater Bootstrap
echo =========================================

set "VERSION_URL=https://raw.githubusercontent.com/thkweon/jiraauto-release/main/version.json"
set "VERSION_FILE=version_remote.json"
set "UPDATER_FILE=remote_update_temp.bat"
set "UPDATE_CHANNEL=%~1"
set "EXPECTED_VERSION=%~2"
if /I not "%UPDATE_CHANNEL%"=="beta" set "UPDATE_CHANNEL=stable"

echo [1/5] Preparing downloader...
if exist "downloader.py" del "downloader.py"
(
echo import urllib.request, sys, ssl
echo ctx = ssl.create_default_context^(^)
echo ctx.check_hostname = False
echo ctx.verify_mode = ssl.CERT_NONE
echo proxy = urllib.request.ProxyHandler^(^)
echo opener = urllib.request.build_opener^(proxy, urllib.request.HTTPSHandler^(context=ctx^)^)
echo urllib.request.install_opener^(opener^)
echo try:
echo     urllib.request.urlretrieve^(sys.argv[1], sys.argv[2]^)
echo except Exception as e:
echo     print^("Download Error:", e^)
echo     sys.exit^(1^)
) > downloader.py

set "PYTHON_EXE="
if exist "backend\venv\Scripts\python.exe" set "PYTHON_EXE=backend\venv\Scripts\python.exe"
if "%PYTHON_EXE%"=="" (
    where python >nul 2>&1
    if not errorlevel 1 set "PYTHON_EXE=python"
)
if "%PYTHON_EXE%"=="" (
    echo [ERROR] Python is not available. Run run.bat first to rebuild the environment.
    timeout /t 15
    exit
)

echo [2/5] Downloading release metadata...
if exist "%VERSION_FILE%" del "%VERSION_FILE%"
"%PYTHON_EXE%" downloader.py "%VERSION_URL%" "%VERSION_FILE%"
if not exist "%VERSION_FILE%" (
    echo [ERROR] Failed to download version metadata.
    if exist "downloader.py" del "downloader.py"
    timeout /t 15
    exit
)

for /f "delims=" %%A in ('powershell -NoProfile -Command "if (Test-Path '%VERSION_FILE%') { (Get-Content '%VERSION_FILE%' -Raw | ConvertFrom-Json).updater_url }"') do set "UPDATER_URL=%%A"
for /f "delims=" %%B in ('powershell -NoProfile -Command "if (Test-Path '%VERSION_FILE%') { (Get-Content '%VERSION_FILE%' -Raw | ConvertFrom-Json).updater_sha256 }"') do set "EXPECTED_UPDATER_HASH=%%B"

if "%UPDATER_URL%"=="" (
    echo [ERROR] updater_url is missing from version metadata.
    if exist "downloader.py" del "downloader.py"
    timeout /t 15
    exit
)
if "%EXPECTED_UPDATER_HASH%"=="" (
    echo [ERROR] updater_sha256 is missing from version metadata.
    if exist "downloader.py" del "downloader.py"
    timeout /t 15
    exit
)

echo [3/5] Downloading latest updater...
if exist "%UPDATER_FILE%" del "%UPDATER_FILE%"
"%PYTHON_EXE%" downloader.py "%UPDATER_URL%" "%UPDATER_FILE%"
if not exist "%UPDATER_FILE%" (
    echo [ERROR] Failed to download latest updater.
    if exist "downloader.py" del "downloader.py"
    timeout /t 15
    exit
)

echo [4/5] Verifying updater integrity...
for /f "delims=" %%H in ('powershell -NoProfile -Command "(Get-FileHash '.\%UPDATER_FILE%' -Algorithm SHA256).Hash"') do set "ACTUAL_UPDATER_HASH=%%H"
if /I not "%EXPECTED_UPDATER_HASH%"=="%ACTUAL_UPDATER_HASH%" (
    echo [ERROR] Updater integrity check failed!
    echo Expected: %EXPECTED_UPDATER_HASH%
    echo Actual  : %ACTUAL_UPDATER_HASH%
    del "%UPDATER_FILE%"
    if exist "downloader.py" del "downloader.py"
    timeout /t 15
    exit
)

echo [5/5] Running latest updater...
call "%UPDATER_FILE%" "%UPDATE_CHANNEL%" "%EXPECTED_VERSION%"
set "UPDATER_EXIT=%ERRORLEVEL%"
if exist "%UPDATER_FILE%" del "%UPDATER_FILE%"
if exist "downloader.py" del "downloader.py"
exit /b %UPDATER_EXIT%
