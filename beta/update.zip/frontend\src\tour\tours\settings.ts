import type { TourDefinition } from '../types';

export const settingsTour: TourDefinition = {
  id: 'settings',
  version: 1,
  steps: [
    { target: '[data-tour="settings-page"]', title: '설정', description: '현황판, Jira 계정, 위젯, 라이선스와 업데이트 환경을 관리합니다.', side: 'top' },
    { target: '[data-tour="settings-tabs"]', title: '설정 카테고리', description: '일반 설정, JIRA 계정, 위젯과 JIRAAUTO 정보 탭을 선택할 수 있습니다.', side: 'bottom' },
    { target: '[data-tour="settings-general"]', title: '일반 설정', description: '안내 초기화, 현황판 갱신, 자동화와 AI 요약 기능을 설정합니다.', side: 'top' },
    { target: '[data-tour="settings-jira"]', title: 'JIRA 계정', description: '연결할 Jira 계정 슬롯과 인증 정보를 등록하고 연결을 확인합니다.', side: 'top' },
    { target: '[data-tour="settings-widgets"]', title: '위젯 설정', description: '화면에 표시할 위젯과 각 위젯의 위치 및 내용을 설정합니다.', side: 'top' },
    { target: '[data-tour="settings-product"]', title: '제품 정보', description: '라이선스 상태, 업데이트 채널과 로그 설정을 확인할 수 있습니다.', side: 'top' },
  ],
};
