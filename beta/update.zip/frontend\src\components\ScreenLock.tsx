import { useEffect, useRef, useState } from 'react';
import type { ReactNode } from 'react';
import { createPortal } from 'react-dom';
import { motion, useReducedMotion } from 'framer-motion';
import { LockKeyhole, LoaderCircle, UnlockKeyhole } from 'lucide-react';
import LockInput from './LockInput';
import { LOCK_EVENT, LOCK_NOW, methods } from '../utils/screenLock';
import { defaults, dropSession, getSession, handleReset, request, setSession } from '../utils/screenLockApi';
import type { Config } from '../utils/screenLockApi';
import './ScreenLock.css';

export function ScreenLockBoundary({ children }: { children: ReactNode }) {
  const reduceMotion = useReducedMotion();
  const [config, setConfig] = useState<Config | null>(null);
  const [locked, setLocked] = useState(true);
  const [error, setError] = useState('');
  const [secret, setSecret] = useState('');
  const [busy, setBusy] = useState(false);
  const [otpMode, setOtpMode] = useState(false);
  const [notice, setNotice] = useState('');
  const lastActivity = useRef(0);
  const awaySince = useRef<number | null>(null);
  const panel = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!locked) return;
    const previous = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => { document.body.style.overflow = previous; };
  }, [locked]);
  useEffect(() => {
    // Saving settings already required authentication, so it must not lock the screen again.
    // A valid unlock session (per tab, survives reload) also keeps the screen open.
    const load = async (keepUnlocked = false) => {
      try {
        // An unactivated installation has no application content to protect.
        const license = await fetch('http://localhost:8000/api/license/status').then(r => r.json());
        if (!license.licensed) { setConfig(defaults); setLocked(false); return; }
        const next = await request('/status', { session: getSession() }); setConfig({ ...defaults, ...next });
        // A session-restored page has had no input yet; count the reload itself as activity.
        lastActivity.current = Date.now(); awaySince.current = null;
        if (!keepUnlocked || !next.enabled) setLocked(Boolean(next.enabled) && !next.unlocked);
        setSecret(''); setError('');
      } catch (e) { setError(String(e)); }
    };
    const reload = () => void load();
    const settingsChanged = () => void load(true);
    const sync = (e: StorageEvent) => { if (e.key === LOCK_EVENT) void load(true); if (e.key === LOCK_NOW) { dropSession(); void load(); } if (e.key === 'screenLockReset') window.location.assign('/activation'); };
    void load(); window.addEventListener(LOCK_EVENT, settingsChanged); window.addEventListener('licenseChanged', reload); window.addEventListener('storage', sync);
    return () => { window.removeEventListener(LOCK_EVENT, settingsChanged); window.removeEventListener('licenseChanged', reload); window.removeEventListener('storage', sync); };
  }, []);
  useEffect(() => {
    if (!error || !config) return;
    const timer = window.setTimeout(() => setError(''), 4000);
    return () => window.clearTimeout(timer);
  }, [error, config]);
  useEffect(() => {
    if (!notice) return;
    const timer = window.setTimeout(() => setNotice(''), 8000);
    return () => window.clearTimeout(timer);
  }, [notice]);
  useEffect(() => {
    document.documentElement.dataset.screenLocked = String(locked);
    if (locked) { window.dispatchEvent(new Event('screenLocked')); panel.current?.focus(); }
    return () => { delete document.documentElement.dataset.screenLocked; };
  }, [locked]);
  useEffect(() => {
    document.documentElement.dataset.notificationsMuted = String(locked && !config?.notifyWhileLocked);
    return () => { delete document.documentElement.dataset.notificationsMuted; };
  }, [locked, config]);
  useEffect(() => {
    if (!config?.enabled) return;
    const lock = () => { dropSession(); setLocked(true); setSecret(''); localStorage.setItem(LOCK_NOW, String(Date.now())); };
    const check = () => {
      if (locked) return;
      const now = Date.now();
      if ((config.idleSeconds > 0 && now - lastActivity.current >= config.idleSeconds * 1000) || (config.blurSeconds >= 0 && awaySince.current !== null && now - awaySince.current >= config.blurSeconds * 1000)) lock();
    };
    const activity = () => { check(); if (!locked && document.hasFocus() && !document.hidden) lastActivity.current = Date.now(); };
    const visibility = () => {
      check();
      if (document.hidden || !document.hasFocus()) { if (awaySince.current === null) awaySince.current = Date.now(); check(); }
      else { awaySince.current = null; }
    };
    const inputs = ['pointerdown', 'pointermove', 'keydown', 'wheel', 'touchstart'];
    inputs.forEach(e => window.addEventListener(e, activity, { passive: true }));
    window.addEventListener('blur', visibility); window.addEventListener('focus', visibility); document.addEventListener('visibilitychange', visibility); window.addEventListener(LOCK_NOW, lock);
    const timer = window.setInterval(() => { if (!locked) check(); }, 500);
    return () => { inputs.forEach(e => window.removeEventListener(e, activity)); window.removeEventListener('blur', visibility); window.removeEventListener('focus', visibility); document.removeEventListener('visibilitychange', visibility); window.removeEventListener(LOCK_NOW, lock); window.clearInterval(timer); };
  }, [config, locked]);
  useEffect(() => {
    if (locked || !config?.enabled) return;
    const timer = window.setInterval(() => { const session = getSession(); if (session) void request('/touch', { session }).catch(() => {}); }, 45000);
    return () => window.clearInterval(timer);
  }, [locked, config]);
  const unlock = async (value = secret) => {
    if (busy || !value) return;
    setBusy(true); setError('');
    try { const result = await request('/verify', { secret: value }); if (result.reset) { handleReset(); return; } if (!result.ok) { setError(result.message); setSecret(''); return; } if (result.session) setSession(result.session); lastActivity.current = Date.now(); awaySince.current = null; setSecret(''); setLocked(false); }
    catch (e) { setError(String(e)); } finally { setBusy(false); }
  };
  // Recovery: the server disables the lock and discards the forgotten credential; OTP itself stays registered.
  const unlockOtp = async (code: string) => {
    if (busy || code.length !== 6) return;
    setBusy(true); setError('');
    try {
      const result = await request('/otp/unlock', { code });
      if (!result.ok) { setError(result.message); setSecret(''); return; }
      setConfig(c => ({ ...(c ?? defaults), enabled: false })); setSecret(''); setOtpMode(false); setLocked(false);
      localStorage.setItem(LOCK_EVENT, String(Date.now())); window.dispatchEvent(new Event(LOCK_EVENT));
      setNotice('OTP로 해제했습니다. 화면 잠금이 꺼지고 등록된 인증 수단이 삭제되었습니다. 설정에서 다시 등록하세요.');
    } catch (e) { setError(String(e)); } finally { setBusy(false); }
  };
  return <>
    <div inert={locked} aria-hidden={locked} style={locked ? { visibility: 'hidden', pointerEvents: 'none' } : undefined}>{children}</div>
    {locked && <div className="screen-lock-overlay" ref={panel} tabIndex={-1} role="dialog" aria-modal="true" aria-labelledby="screen-lock-title">
      <motion.form className="glass-panel settings-card screen-lock-card" initial={reduceMotion ? false : { opacity: 0, y: 18, scale: 0.98 }} animate={{ opacity: 1, y: 0, scale: 1 }} transition={{ duration: 0.25 }} onSubmit={e => { e.preventDefault(); if (otpMode) void unlockOtp(secret); else void unlock(); }}>
        <div className="lock-emblem"><LockKeyhole size={26} aria-hidden="true" /></div>
        <h1 id="screen-lock-title" className="settings-card-title">화면이 잠겼습니다</h1>
        {config?.enabled && otpMode ? <>
          <p className="settings-description">인증 앱의 6자리 OTP 코드를 입력하세요.</p>
          <div className="lock-unlock-input"><input className="glass-input settings-control lock-otp-code" aria-label="OTP 코드" inputMode="numeric" autoComplete="one-time-code" maxLength={6} placeholder="6자리 코드" autoFocus disabled={busy} value={secret} onChange={e => { const next = e.target.value.replace(/\D/g, ''); setSecret(next); if (next.length === 6) void unlockOtp(next); }} /></div>
          <button className="btn-premium settings-action lock-unlock-button" disabled={busy || secret.length !== 6} type="button" onClick={() => void unlockOtp(secret)}>{busy ? <LoaderCircle size={16} className="lock-spinner" /> : <UnlockKeyhole size={16} />}{busy ? '확인 중…' : 'OTP로 해제'}</button>
          <p className="settings-description lock-reset-notice">OTP로 해제하면 화면 잠금이 꺼지고 등록된 {methods[config.method]}가 삭제됩니다. 설정에서 다시 등록할 수 있습니다.</p>
          <button type="button" className="lock-link" disabled={busy} onClick={() => { setOtpMode(false); setSecret(''); setError(''); }}>{methods[config.method]}로 해제하기</button>
        </> : config?.enabled ? <>
          <p className="settings-description">{methods[config.method]}로 잠금을 해제하세요.</p>
          <div className="lock-unlock-input"><LockInput method={config.method} value={secret} onChange={setSecret} onComplete={value => void unlock(value)} showLines={config.showLines} disabled={busy} autoFocus label="잠금 해제 인증" /></div>
          <button className="btn-premium settings-action lock-unlock-button" disabled={busy || !secret} type="submit">{busy ? <LoaderCircle size={16} className="lock-spinner" /> : <UnlockKeyhole size={16} />}{busy ? '확인 중…' : '잠금 해제'}</button>
          {config.resetAfter > 0 && <p className="settings-description lock-reset-notice">연속 {config.resetAfter}회 실패하면 서버 기기 등록과 로컬 DB가 초기화됩니다.</p>}
          {config.otp && <button type="button" className="lock-link" disabled={busy} onClick={() => { setOtpMode(true); setSecret(''); setError(''); }}>인증 수단을 잊으셨나요? OTP로 해제</button>}
        </> : <p className="settings-description">잠금 설정 확인 중…</p>}
        {error && !config && <><p className="lock-feedback error" role="alert">{error}</p><button className="btn-secondary settings-action" type="button" onClick={() => window.location.reload()}>다시 연결</button></>}
      </motion.form>
      {error && config && <button type="button" role="alert" className="settings-toast" title="닫기" onClick={() => setError('')}>{error}</button>}
    </div>}
    {notice && createPortal(<button type="button" role="status" className="settings-toast" title="닫기" onClick={() => setNotice('')}>{notice}</button>, document.body)}
  </>;
}
