import type { TourDefinition } from '../types';

export const teamAnalyticsTour: TourDefinition = {
  id: 'team-analytics',
  version: 1,
  steps: [
    { target: '[data-tour="team-analytics-page"]', title: '팀 통계', description: '팀 업무의 규모, 완료율과 처리 흐름을 여러 지표로 확인하는 화면입니다.', side: 'top' },
    { target: '[data-tour="team-analytics-controls"]', title: '조회와 차트 설정', description: '조회 기간을 바꾸고 화면에 표시할 차트를 선택할 수 있습니다.', side: 'bottom' },
    { target: '[data-tour="team-analytics-kpi"]', title: '핵심 지표', description: '이슈 수, 완료율, 진행 중 업무와 평균 완료 소요일을 빠르게 확인합니다.', side: 'bottom' },
    { target: '[data-tour="team-analytics-charts"]', title: '업무 분석 차트', description: '상태, 담당자, 처리량, 노후화와 우선순위별 업무 분포를 비교할 수 있습니다.', side: 'top' },
  ],
};
