// @ts-nocheck
import React, { memo, useState, useEffect, useCallback, useRef } from 'react';
import { CheckCheck, Flag, Plus, RefreshCcw, Search, Sparkles, Star } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { MentionsInput, Mention } from 'react-mentions';
import '../App.css';
import { updateEndDateWithinRange, updateStartDateWithinRange } from '../utils/dateRange';
import { formatJiraInstanceName, type JiraDeploymentType } from '../utils/jiraInstance';
import { loadDashboardActivityTypes, type DashboardActivityType } from '../utils/dashboardActivity';
import { normalizeInstanceFilter, normalizeProjectFilter } from '../utils/dashboardFilters';
import { notificationsAllowed } from '../utils/screenLock';
import MarkdownPreview from '../components/MarkdownPreview';

// ---------------------------------------------------------
// 1. 타입 정의
// ---------------------------------------------------------
interface JiraPerson {
  name?: string;
  key?: string;
  accountId?: string;
  displayName?: string;
}

interface JiraIssue {
  key: string;
  instance_id: number;
  jiraauto_closed?: boolean;
  jiraauto_closed_at?: string;
  errorMessages?: string[];
  favorite_unavailable?: boolean;
  favorite_unavailable_reason?: string;
  fields: {
    summary: string;
    status: { id?: string; name: string; statusCategory?: { key?: string } };
    project: { key: string };
    issuetype: { name: string };
    priority?: { name?: string; iconUrl?: string };
    components?: { name: string }[];
    labels?: string[];
    assignee: JiraPerson | null;
    reporter: JiraPerson | null;
    creator?: JiraPerson | null;
    updated: string;
    created: string;
    timetracking?: {
      originalEstimate?: string;
      remainingEstimate?: string;
      timeSpent?: string;
    };
  };
}

interface JiraComment {
  id: string;
  author: JiraPerson;
  updateAuthor?: JiraPerson;
  body: string;
  displayBody?: string;
  renderedBody?: string;
  created: string;
  updated?: string;
}

interface JiraHistoryItem {
  id: string;
  author: JiraPerson;
  created: string;
  items: { field: string; fromString: string; toString: string; }[];
}

interface JiraLinkedIssue {
  key: string;
  fields?: {
    summary?: string;
    status?: { name?: string };
    issuetype?: { name?: string };
  };
}

interface JiraIssueLink {
  id: string;
  type?: { name?: string; inward?: string; outward?: string };
  inwardIssue?: JiraLinkedIssue;
  outwardIssue?: JiraLinkedIssue;
}

interface JiraIssueDetail extends JiraIssue {
  fields: JiraIssue['fields'] & {
    description: string;
    displayDescription?: string;
    issuelinks?: JiraIssueLink[];
    comment: { comments: JiraComment[] };
    priority: { name: string };
    components: { name: string }[];
    labels: string[];
    watchers: string[];
    created: string;
    updated: string;
  };
  changelog?: { histories: JiraHistoryItem[]; };
}

interface JiraTransition { id: string; name: string; to: { id?: string; name: string }; }
type JiraUser = JiraPerson;
interface JiraUserSuggestion { id: string; display: string; name?: string; key?: string; accountId?: string; }
interface JiraInstanceInfo { id: number; base_url: string; name: string; deployment_type: JiraDeploymentType; }
interface TimeTrackingSnapshot {
  timetracking: {
    originalEstimate?: string;
    remainingEstimate?: string;
    timeSpent?: string;
  };
  worklog?: { total?: number; worklogs?: WorklogEntry[] };
}

interface WorklogEntry {
  id: string;
  author: JiraPerson;
  timeSpent: string;
  timeSpentSeconds: number;
  started?: string;
  created?: string;
  updated?: string;
  comment: string;
  editable: boolean;
}

const priorityColor = (name?: string) => {
  const normalized = (name || '').trim().toLowerCase();
  if (['highest', 'blocker', 'critical', '긴급', '매우 높음'].some(value => normalized.includes(value))) return '#d32f2f';
  if (['high', 'major', '높음'].some(value => normalized.includes(value))) return '#f57c00';
  if (['medium', 'normal', '중간', '보통'].some(value => normalized.includes(value))) return '#f9a825';
  if (['lowest', 'trivial', '매우 낮음'].some(value => normalized.includes(value))) return '#78909c';
  if (['low', 'minor', '낮음'].some(value => normalized.includes(value))) return '#1976d2';
  return '#78909c';
};

const sameStringRecord = (left: Record<string, string>, right: Record<string, string>) => {
  const leftKeys = Object.keys(left);
  const rightKeys = Object.keys(right);
  return leftKeys.length === rightKeys.length && leftKeys.every(key => left[key] === right[key]);
};

const issueSnapshotSignature = (issues: JiraIssue[]) => issues
  .map(issue => [
    issue.instance_id,
    issue.key,
    issue.fields?.updated || '',
    issue.fields?.status?.name || '',
    issue.fields?.assignee?.accountId || issue.fields?.assignee?.key || issue.fields?.assignee?.name || '',
    issue.favorite_unavailable ? '1' : '0',
  ].join(':'))
  .sort()
  .join('|');
interface IssueCreateOption { id?: string; name: string; }
interface IssueCreateProjectMeta {
  instance_id: number;
  instance_name: string;
  base_url: string;
  project_key: string;
  issue_types: IssueCreateOption[];
  components: IssueCreateOption[];
  error?: string;
}

interface WorklogPayload {
  timeSpent: string;
  comment: string;
  started: string;
  adjustEstimate: 'auto' | 'new' | 'leave';
  newEstimate?: string;
}

interface DashboardIssueState {
  observed_updated_at: string;
  unread_updated_at?: string | null;
  read_updated_at?: string | null;
  jiraauto_closed_at?: string | null;
}

interface DashboardIssueStatePayload {
  states: Record<string, DashboardIssueState>;
  initialized_instance_ids: number[];
  migration_pending_instance_ids: number[];
  last_sync_at_by_instance: Record<string, string>;
}

interface DashboardIssueActivityPayload {
  categories: DashboardActivityType[];
  snapshot: Record<string, unknown>;
}

type UnknownRecord = Record<string, unknown>;

const asRecord = (value: unknown): UnknownRecord | null =>
  typeof value === 'object' && value !== null ? value as UnknownRecord : null;

const errorMessage = (error: unknown, fallback: string) =>
  error instanceof Error && error.message ? error.message : fallback;

const isAbortError = (error: unknown) =>
  error instanceof DOMException
    ? error.name === 'AbortError'
    : asRecord(error)?.name === 'AbortError';

const mentionsStyle = {
  control: { backgroundColor: 'var(--card-bg)', color: 'var(--text-primary)', fontSize: 14, lineHeight: 1.5, fontFamily: 'inherit' },
  '&multiLine': {
    control: { minHeight: 150, fontFamily: 'inherit' },
    highlighter: { padding: 12, border: '1px solid transparent', boxSizing: 'border-box' as const, color: 'var(--text-primary)' },
    input: { padding: 12, border: '1px solid rgba(127, 140, 141, 0.32)', borderRadius: 8, outline: 'none', boxSizing: 'border-box' as const, minHeight: 150, color: 'var(--text-primary)', caretColor: 'var(--text-primary)' },
  },
  suggestions: {
    list: { backgroundColor: 'var(--card-bg)', color: 'var(--text-primary)', border: '1px solid rgba(127, 140, 141, 0.32)', borderRadius: 8, boxShadow: '0 4px 15px rgba(0,0,0,0.15)', fontSize: 13, zIndex: 10000 },
    item: { padding: '8px 12px', borderBottom: '1px solid rgba(127, 140, 141, 0.18)', '&focused': { backgroundColor: 'rgba(9, 132, 227, 0.12)', color: 'var(--accent-color)' } },
  },
};

const API_BASE = 'http://localhost:8000/api';
const FAVORITES_STORAGE_KEY = 'jiraDashboardFavoriteIssueMap';
const UNREAD_UPDATES_STORAGE_KEY = 'jiraDashboardUnreadUpdatedIssueMap';
const TRACK_OWN_ACTIVITY_STORAGE_KEY = 'jiraDashboardTrackOwnActivity';
const DASHBOARD_PERSON_ROLE_STORAGE_KEY = 'jiraDashboardPersonRole';
const FAVORITE_SEARCH_QUERIES_STORAGE_KEY = 'jiraDashboardFavoriteSearchQueries';

type DashboardPersonRole = 'assignee' | 'reporter';
type IssueSearchField = 'ticket' | 'summary' | 'assignee' | 'reporter' | 'component' | 'label';

interface ParsedIssueSearchQuery {
  field: IssueSearchField;
  operator: '=' | '~';
  value: string;
  negated: boolean;
}

interface ParsedIssueSearchExpression {
  orGroups: ParsedIssueSearchQuery[][];
}

const ISSUE_SEARCH_FIELDS = [
  { token: '티켓번호', description: '티켓 키로 검색' },
  { token: '제목', description: '티켓 제목으로 검색' },
  { token: '담당자', description: '담당자 정보로 검색' },
  { token: '보고자', description: '보고자 정보로 검색' },
  { token: '컴포넌트', description: '컴포넌트 이름으로 검색' },
  { token: '레이블', description: '레이블 문자열로 검색' },
];

const ISSUE_SEARCH_OPERATORS = [
  { token: '=', description: '정확히 일치' },
  { token: '~', description: '문자열 포함' },
  { token: '!=', description: '정확히 일치하지 않음' },
  { token: '!~', description: '문자열을 포함하지 않음' },
];

const ISSUE_SEARCH_CONNECTORS = [
  { token: 'AND', description: '모든 조건을 만족' },
  { token: 'OR', description: '조건 중 하나를 만족' },
];

const loadDashboardPersonRole = (): DashboardPersonRole =>
  localStorage.getItem(DASHBOARD_PERSON_ROLE_STORAGE_KEY) === 'reporter' ? 'reporter' : 'assignee';

const parseIssueSearchQuery = (input: string): ParsedIssueSearchQuery | null => {
  const match = input.match(/^\s*(티켓번호|티켓|제목|담당자|보고자|컴포넌트|레이블)\s*(!?=|!~|~)\s*(.+?)\s*$/i);
  if (!match) return null;
  const fieldMap: Record<string, IssueSearchField> = {
    티켓번호: 'ticket',
    티켓: 'ticket',
    제목: 'summary',
    담당자: 'assignee',
    보고자: 'reporter',
    컴포넌트: 'component',
    레이블: 'label',
  };
  const operator = match[2];
  return {
    field: fieldMap[match[1]],
    operator: operator.endsWith('=') ? '=' : '~',
    value: match[3].trim().toLowerCase(),
    negated: operator.startsWith('!'),
  };
};

const parseIssueSearchExpression = (input: string): ParsedIssueSearchExpression | null => {
  const parts = input.trim().split(/\s+(AND|OR)\s+/i);
  if (!parts.length || parts.length % 2 === 0) return null;

  const orGroups: ParsedIssueSearchQuery[][] = [[]];
  for (let index = 0; index < parts.length; index += 2) {
    const query = parseIssueSearchQuery(parts[index]);
    if (!query) return null;
    if (index > 0 && parts[index - 1].toUpperCase() === 'OR') orGroups.push([]);
    orGroups[orGroups.length - 1].push(query);
  }
  return { orGroups };
};

const jiraPersonSearchValues = (person?: JiraPerson | null) => [
  person?.displayName,
  person?.name,
  person?.key,
  person?.accountId,
].filter((value): value is string => Boolean(value)).map(value => value.toLowerCase());

const normalizeFavoriteSearchQuery = (value: string) => value.trim().replace(/\s+/g, ' ').toLowerCase();

const loadFavoriteSearchQueries = (): string[] => {
  try {
    const parsed = JSON.parse(localStorage.getItem(FAVORITE_SEARCH_QUERIES_STORAGE_KEY) || '[]');
    if (!Array.isArray(parsed)) return [];
    const seen = new Set<string>();
    return parsed.filter((value): value is string => {
      if (typeof value !== 'string' || !value.trim()) return false;
      const normalized = normalizeFavoriteSearchQuery(value);
      if (seen.has(normalized)) return false;
      seen.add(normalized);
      return true;
    });
  } catch {
    return [];
  }
};

const issueStorageKey = (issue: { key: string; instance_id: number }) => `${issue.instance_id}:${issue.key}`;

const isUnavailableIssue = (issue: Partial<JiraIssue> | null | undefined) =>
  Boolean(
    issue?.favorite_unavailable ||
    (Array.isArray(issue?.errorMessages) && issue.errorMessages.length > 0) ||
    !issue?.fields
  );

interface JiraIssueCardProps {
  issue: JiraIssue;
  type: 'assigned' | 'mentioned' | 'reported';
  isUpdated: boolean;
  instanceName?: string;
  showInstanceName: boolean;
  isFavorite: boolean;
  isUnavailable: boolean;
  isClosed: boolean;
  personRole: DashboardPersonRole;
  onOpen: (issue: JiraIssue) => void;
  onToggleFavorite: (issue: JiraIssue) => void;
}

const JiraIssueCard = memo(function JiraIssueCard({
  issue,
  type,
  isUpdated,
  instanceName,
  showInstanceName,
  isFavorite,
  isUnavailable,
  isClosed,
  personRole,
  onOpen,
  onToggleFavorite,
}: JiraIssueCardProps) {
  const issuePriority = issue.fields?.priority?.name;
  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, scale: 0.9 }}>
      <div className={`issue-card ${type === 'mentioned' ? 'mentioned' : ''} ${type === 'reported' ? 'reported' : ''} ${isUpdated ? 'has-update' : ''}`} onClick={() => onOpen(issue)}>
        <button
          className={`favorite-star-button ${isFavorite ? 'active' : ''}`}
          title={isFavorite ? '즐겨찾기 해제' : '즐겨찾기'}
          onClick={(event) => {
            event.stopPropagation();
            onToggleFavorite(issue);
          }}
        >
          <Star size={17} fill={isFavorite ? '#f1c40f' : 'none'} />
        </button>
        <div className="issue-header" style={{alignItems: 'center', justifyContent: 'space-between', display: 'flex'}}>
          <span className="issue-key">
            {showInstanceName && instanceName && <span className="instance-badge">{instanceName}</span>}
            {type === 'mentioned' && '📢 '}{type === 'reported' && '👀 '}{type === 'assigned' && '📅 '}{issue.key}
          </span>
          <span className="status-badge" style={{marginTop: 0}}>
            {isUnavailable ? '삭제 됨' : isClosed ? '닫힘(jiraauto)' : issue.fields?.status?.name}
          </span>
        </div>
        <div className="issue-summary">{issue.fields?.summary}</div>
        <div className="issue-footer" style={{marginTop: 'auto'}}>
          <div className="issue-assignee" style={{fontSize: '12px', fontWeight: 600, color: 'var(--text-secondary)'}}>
            <span>
              {personRole === 'reporter'
                ? issue.fields?.reporter?.displayName || issue.fields?.reporter?.name || '보고자 없음'
                : issue.fields?.assignee?.displayName || issue.fields?.assignee?.name || '할당 안됨'}
            </span>
          </div>
          <div style={{display: 'flex', alignItems: 'center', gap: '8px'}}>
            {issuePriority && (
              <Flag
                size={16}
                color={priorityColor(issuePriority)}
                fill={priorityColor(issuePriority)}
                aria-label={`우선순위: ${issuePriority}`}
              >
                <title>{`우선순위: ${issuePriority}`}</title>
              </Flag>
            )}
            <span className="issue-date" style={{fontSize: '12px', color: 'var(--text-secondary)'}}>{new Date(issue.fields?.updated || issue.fields?.created || 0).toLocaleDateString()}</span>
          </div>
        </div>
      </div>
    </motion.div>
  );
});

const getUnavailableReason = (data: unknown, fallback = 'Jira 이슈를 찾을 수 없습니다.') => {
  const record = asRecord(data);
  if (Array.isArray(record?.errorMessages) && record.errorMessages.length > 0) return record.errorMessages.join(', ');
  if (typeof record?.message === 'string' && record.message.trim()) return record.message;
  if (typeof record?.detail === 'string' && record.detail.trim()) return record.detail;
  return fallback;
};

const getUpdatedTime = (value: string | undefined) => {
  if (!value) return 0;
  const time = new Date(value).getTime();
  return Number.isFinite(time) ? time : 0;
};

const isReadUpdate = (readValue: string | undefined, updateValue: string | undefined) =>
  Boolean(readValue && updateValue && getUpdatedTime(readValue) >= getUpdatedTime(updateValue));

const isSameJiraUser = (left?: JiraPerson | null, right?: JiraPerson | null) => {
  if (!left || !right) return false;
  const pairs: Array<[string | undefined, string | undefined]> = [
    [left.accountId, right.accountId],
    [left.name, right.name],
    [left.key, right.key],
    [left.displayName, right.displayName],
  ];
  return pairs.some(([a, b]) => Boolean(a && b && a === b));
};

const getLatestIssueActor = (detail: JiraIssueDetail | null | undefined): JiraPerson | null => {
  if (!detail) return null;
  const candidates: Array<{ at: number; actor?: JiraPerson | null }> = [];

  detail.changelog?.histories?.forEach(history => {
    candidates.push({ at: getUpdatedTime(history.created), actor: history.author });
  });
  detail.fields.comment?.comments?.forEach(comment => {
    candidates.push({
      at: getUpdatedTime(comment.updated || comment.created),
      actor: comment.updateAuthor || comment.author,
    });
  });

  candidates.sort((left, right) => right.at - left.at);
  return candidates.find(candidate => candidate.at > 0 && candidate.actor)?.actor || null;
};

const normalizeJiraUserSuggestion = (value: unknown): JiraUserSuggestion | null => {
  const user = asRecord(value);
  if (!user) return null;
  const id = [user.accountId, user.name, user.key].find(item => typeof item === 'string' && item.trim()) as string | undefined;
  const display = [user.displayName, user.name, user.key, user.accountId].find(item => typeof item === 'string' && item.trim()) as string | undefined;
  if (!id || !display) return null;
  return {
    id,
    display,
    name: typeof user.name === 'string' ? user.name : undefined,
    key: typeof user.key === 'string' ? user.key : undefined,
    accountId: typeof user.accountId === 'string' ? user.accountId : undefined,
  };
};

const parseWorklogTime = (input: string, allowZero = false): { ok: boolean; normalized?: string; minutes?: number; error?: string } => {
  const value = input.trim().toLowerCase();
  if (!value) return { ok: false, error: '작업한 시간을 입력하세요.' };
  const source = /^\d+$/.test(value) ? `${value}m` : value.replace(/\s+/g, '');
  const matches = Array.from(source.matchAll(/(\d+)([wdhm])/g));
  if (!matches.length || matches.map(m => m[0]).join('') !== source) {
    return { ok: false, error: '시간 형식이 올바르지 않습니다. 예: 70, 1h 10m, 1w3h' };
  }
  const unitMinutes: Record<string, number> = { w: 5 * 8 * 60, d: 8 * 60, h: 60, m: 1 };
  const totalMinutes = matches.reduce((sum, match) => sum + Number(match[1]) * unitMinutes[match[2]], 0);
  if (totalMinutes <= 0 && !allowZero) return { ok: false, error: '작업한 시간은 0보다 커야 합니다.' };

  let rest = totalMinutes;
  const weeks = Math.floor(rest / unitMinutes.w); rest %= unitMinutes.w;
  const days = Math.floor(rest / unitMinutes.d); rest %= unitMinutes.d;
  const hours = Math.floor(rest / unitMinutes.h); rest %= unitMinutes.h;
  const parts = [
    weeks ? `${weeks}w` : '',
    days ? `${days}d` : '',
    hours ? `${hours}h` : '',
    rest ? `${rest}m` : '',
  ].filter(Boolean);
  return { ok: true, minutes: totalMinutes, normalized: parts.join(' ') || '0m' };
};

const toLocalDateTimeInputValue = (date = new Date()) => {
  const offset = date.getTimezoneOffset();
  const local = new Date(date.getTime() - offset * 60000);
  return local.toISOString().slice(0, 16);
};

const getAutoStartedValue = (minutes?: number) => {
  if (!minutes || minutes <= 0) return toLocalDateTimeInputValue();
  return toLocalDateTimeInputValue(new Date(Date.now() - minutes * 60000));
};

const toJiraStartedValue = (localDateTime: string) => {
  const date = localDateTime ? new Date(localDateTime) : new Date();
  const pad = (n: number) => String(Math.abs(Math.trunc(n))).padStart(2, '0');
  const offsetMinutes = -date.getTimezoneOffset();
  const sign = offsetMinutes >= 0 ? '+' : '-';
  const hours = Math.floor(Math.abs(offsetMinutes) / 60);
  const minutes = Math.abs(offsetMinutes) % 60;
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}:00.000${sign}${pad(hours)}${pad(minutes)}`;
};

type MentionSearch = (query: string, callback: (users: JiraUserSuggestion[]) => void) => void | Promise<void>;

const commentMentionsStyle = {
  ...mentionsStyle,
  control: { ...mentionsStyle.control, backgroundColor: 'transparent' },
  '&multiLine': {
    ...mentionsStyle['&multiLine'],
    input: {
      ...mentionsStyle['&multiLine'].input,
      backgroundColor: 'var(--card-bg)',
      border: '1px solid rgba(0,0,0,0.1)',
    },
  },
};

const CommentComposer = memo(function CommentComposer({
  issue,
  searchUsers,
  onSubmitted,
}: {
  issue: JiraIssue;
  searchUsers: MentionSearch;
  onSubmitted: () => void | Promise<void>;
}) {
  const [text, setText] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  const submit = async () => {
    if (!text.trim() || submitting) return;
    setSubmitting(true);
    setError('');
    try {
      const res = await fetch(`${API_BASE}/issues/${issue.key}/comments?instance_id=${issue.instance_id}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ body: text }),
      });
      if (!res.ok) throw new Error('코멘트 추가에 실패했습니다.');
      setText(current => current === text ? '' : current);
      await onSubmitted();
    } catch (submitError) {
      setError(errorMessage(submitError, '코멘트 추가에 실패했습니다.'));
    } finally {
      setSubmitting(false);
    }
  };

  const handlePasteImage = async (event: React.ClipboardEvent) => {
    const items = event.clipboardData?.items;
    if (!items) return;
    for (const item of items) {
      if (!item.type.includes('image')) continue;
      event.preventDefault();
      const file = item.getAsFile();
      if (!file) continue;
      const formData = new FormData();
      formData.append('file', file);
      try {
        const res = await fetch(`${API_BASE}/issues/${issue.key}/attachments?instance_id=${issue.instance_id}`, { method: 'POST', body: formData });
        if (!res.ok) throw new Error('이미지 업로드에 실패했습니다.');
        const data = await res.json();
        const filename = data.data?.[0]?.filename || file.name;
        setText(previous => `${previous}\n!${filename}!\n`);
      } catch (uploadError) {
        setError(errorMessage(uploadError, '이미지 업로드에 실패했습니다.'));
      }
    }
  };

  return (
    <div className="glass-panel" style={{padding: '20px', marginBottom: '20px'}}>
      <div onPaste={handlePasteImage}>
        <MentionsInput
          value={text}
          onChange={(_, newValue) => setText(newValue)}
          onKeyDown={event => {
            if (event.altKey && event.key === 'Enter') {
              event.preventDefault();
              void submit();
            }
          }}
          style={commentMentionsStyle}
          placeholder="@를 입력하여 팀원 멘션... (Alt+Enter로 즉시 작성)"
        >
          <Mention trigger="@" data={searchUsers} markup="@[__display__](__id__)" displayTransform={(_id, display) => display} className="mention-badge" appendSpaceOnAdd />
        </MentionsInput>
      </div>
      {error && <div style={{ marginTop: 10, color: '#d63031', fontSize: 13, fontWeight: 700 }}>{error}</div>}
      <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: '12px' }}>
        <button className="btn-premium" style={{whiteSpace: 'nowrap', opacity: submitting ? 0.6 : 1}} disabled={submitting} onClick={() => void submit()}>
          {submitting ? '처리 중...' : '코멘트 추가'}
        </button>
      </div>
    </div>
  );
});

const CommentEditor = memo(function CommentEditor({
  issue,
  comment,
  searchUsers,
  onCancel,
  onSaved,
}: {
  issue: JiraIssue;
  comment: JiraComment;
  searchUsers: MentionSearch;
  onCancel: () => void;
  onSaved: () => void | Promise<void>;
}) {
  const [text, setText] = useState(comment.body || '');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  const submit = async () => {
    if (!text.trim() || submitting) return;
    setSubmitting(true);
    setError('');
    try {
      const res = await fetch(`${API_BASE}/issues/${issue.key}/comments/${comment.id}?instance_id=${issue.instance_id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ body: text }),
      });
      if (!res.ok) throw new Error('코멘트 수정에 실패했습니다.');
      await onSaved();
    } catch (submitError) {
      setError(errorMessage(submitError, '코멘트 수정에 실패했습니다.'));
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="glass-panel" style={{padding: 15, width: '100%', minWidth: 300}}>
      <MentionsInput
        value={text}
        onChange={(_, newValue) => setText(newValue)}
        onKeyDown={event => {
          if (event.altKey && event.key === 'Enter') {
            event.preventDefault();
            void submit();
          }
        }}
        style={mentionsStyle}
        placeholder="코멘트 수정..."
      >
        <Mention trigger="@" data={searchUsers} markup="@[__display__](__id__)" displayTransform={(_id, display) => display} className="mention-badge" appendSpaceOnAdd />
      </MentionsInput>
      {error && <div style={{ marginTop: 10, color: '#d63031', fontSize: 13, fontWeight: 700 }}>{error}</div>}
      <div style={{display:'flex', justifyContent:'flex-end', gap:'8px', marginTop:'10px'}}>
        <button className="btn-secondary" onClick={onCancel} disabled={submitting}>취소</button>
        <button className="btn-premium" onClick={() => void submit()} disabled={submitting}>{submitting ? '저장 중...' : '저장'}</button>
      </div>
    </div>
  );
});

const WorklogPanel = memo(function WorklogPanel({
  issue,
  onUpdated,
}: {
  issue: JiraIssue;
  onUpdated: () => void | Promise<void>;
}) {
  const [open, setOpen] = useState(false);
  const [trackingLoading, setTrackingLoading] = useState(false);
  const [tracking, setTracking] = useState<TimeTrackingSnapshot | null>(null);
  const [historyOpen, setHistoryOpen] = useState(false);
  const [editingWorklogId, setEditingWorklogId] = useState<string | null>(null);
  const [editTime, setEditTime] = useState('');
  const [editComment, setEditComment] = useState('');
  const [editStarted, setEditStarted] = useState('');
  const [worklogActionId, setWorklogActionId] = useState<string | null>(null);
  const [time, setTime] = useState('');
  const [comment, setComment] = useState('');
  const [started, setStarted] = useState(() => toLocalDateTimeInputValue());
  const [startedTouched, setStartedTouched] = useState(false);
  const [adjustEstimate, setAdjustEstimate] = useState<'auto' | 'new' | 'leave'>('auto');
  const [newEstimate, setNewEstimate] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  const fetchTracking = async () => {
    setTrackingLoading(true);
    setError('');
    try {
      const res = await fetch(`${API_BASE}/issues/${issue.key}/timetracking?instance_id=${issue.instance_id}`);
      if (!res.ok) throw new Error('시간 추적 정보를 불러오지 못했습니다.');
      const nextTracking = await res.json() as TimeTrackingSnapshot;
      setTracking(nextTracking);
    } catch (trackingError) {
      setError(errorMessage(trackingError, '시간 추적 정보를 불러오지 못했습니다.'));
    } finally {
      setTrackingLoading(false);
    }
  };

  const handleTimeChange = (value: string) => {
    setTime(value);
    if (!startedTouched) {
      const parsed = parseWorklogTime(value);
      if (parsed.ok) setStarted(getAutoStartedValue(parsed.minutes));
    }
  };

  const submit = async () => {
    if (submitting) return;
    setError('');
    setMessage('');
    const parsedTime = parseWorklogTime(time);
    if (!parsedTime.ok || !parsedTime.normalized) {
      setError(parsedTime.error || '작업한 시간을 확인하세요.');
      return;
    }
    const payload: WorklogPayload = {
      timeSpent: parsedTime.normalized,
      comment: comment.trim(),
      started: toJiraStartedValue(started),
      adjustEstimate,
    };
    if (adjustEstimate === 'new') {
      const parsedEstimate = parseWorklogTime(newEstimate, true);
      if (!parsedEstimate.ok || !parsedEstimate.normalized) {
        setError(parsedEstimate.error || '새 남은 시간을 확인하세요.');
        return;
      }
      payload.newEstimate = parsedEstimate.normalized;
      setNewEstimate(parsedEstimate.normalized);
    }
    setSubmitting(true);
    try {
      const res = await fetch(`${API_BASE}/issues/${issue.key}/worklog?instance_id=${issue.instance_id}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(typeof data.detail === 'string' ? data.detail : '작업로그 등록에 실패했습니다.');
      setTime(current => current === time ? parsedTime.normalized! : current);
      setComment(current => current === comment ? '' : current);
      setMessage('작업로그가 추가되었습니다.');
      await fetchTracking();
      await onUpdated();
    } catch (submitError) {
      setError(errorMessage(submitError, '작업로그 등록에 실패했습니다.'));
    } finally {
      setSubmitting(false);
    }
  };

  const beginEdit = (entry: WorklogEntry) => {
    setEditingWorklogId(entry.id);
    setEditTime(entry.timeSpent);
    setEditComment(entry.comment || '');
    setEditStarted(entry.started ? toLocalDateTimeInputValue(new Date(entry.started)) : toLocalDateTimeInputValue());
    setError('');
    setMessage('');
  };

  const saveWorklog = async (entry: WorklogEntry) => {
    const parsedTime = parseWorklogTime(editTime);
    if (!parsedTime.ok || !parsedTime.normalized) {
      setError(parsedTime.error || '작업한 시간을 확인하세요.');
      return;
    }
    setWorklogActionId(entry.id);
    setError('');
    setMessage('');
    try {
      const res = await fetch(`${API_BASE}/issues/${issue.key}/worklog/${entry.id}?instance_id=${issue.instance_id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          timeSpent: parsedTime.normalized,
          comment: editComment.trim(),
          started: toJiraStartedValue(editStarted),
        }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(typeof data.detail === 'string' ? data.detail : '작업로그 수정에 실패했습니다.');
      setEditingWorklogId(current => current === entry.id ? null : current);
      setMessage('작업로그가 수정되었습니다.');
      await fetchTracking();
      await onUpdated();
    } catch (saveError) {
      setError(errorMessage(saveError, '작업로그 수정에 실패했습니다.'));
    } finally {
      setWorklogActionId(null);
    }
  };

  const removeWorklog = async (entry: WorklogEntry) => {
    if (!window.confirm(`${entry.timeSpent} 작업로그를 삭제하시겠습니까?`)) return;
    setWorklogActionId(entry.id);
    setError('');
    setMessage('');
    try {
      const res = await fetch(`${API_BASE}/issues/${issue.key}/worklog/${entry.id}?instance_id=${issue.instance_id}`, { method: 'DELETE' });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(typeof data.detail === 'string' ? data.detail : '작업로그 삭제에 실패했습니다.');
      setEditingWorklogId(current => current === entry.id ? null : current);
      setMessage('작업로그가 삭제되었습니다.');
      await fetchTracking();
      await onUpdated();
    } catch (deleteError) {
      setError(errorMessage(deleteError, '작업로그 삭제에 실패했습니다.'));
    } finally {
      setWorklogActionId(null);
    }
  };

  const timePreview = time.trim() ? parseWorklogTime(time) : null;
  const estimatePreview = newEstimate.trim() ? parseWorklogTime(newEstimate, true) : null;
  const tracked = tracking?.timetracking || {};

  return (
    <div className="glass-panel" style={{ padding: 18, marginBottom: 20 }}>
      <button
        className="btn-secondary"
        onClick={() => {
          const nextOpen = !open;
          setOpen(nextOpen);
          if (nextOpen) {
            setStarted(toLocalDateTimeInputValue());
            setStartedTouched(false);
            void fetchTracking();
          }
        }}
        style={{ width: '100%', display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 12px' }}
      >
        <span>시간 추적 / 작업로그</span>
        <span>{open ? '접기' : '펼치기'}</span>
      </button>
      {open && (
        <div style={{ marginTop: 16 }}>
          <div className="apple-meta-grid" style={{ marginBottom: 16 }}>
            <div className="apple-meta-item"><span className="apple-meta-label">원래 추정</span><span className="apple-meta-value">{trackingLoading ? '불러오는 중...' : tracked.originalEstimate || '없음'}</span></div>
            <div className="apple-meta-item"><span className="apple-meta-label">남은 시간</span><span className="apple-meta-value">{trackingLoading ? '불러오는 중...' : tracked.remainingEstimate || '없음'}</span></div>
            <div className="apple-meta-item"><span className="apple-meta-label">기록된 시간</span><span className="apple-meta-value">{trackingLoading ? '불러오는 중...' : tracked.timeSpent || '없음'}</span></div>
            <div className="apple-meta-item"><span className="apple-meta-label">작업로그 수</span><span className="apple-meta-value">{trackingLoading ? '불러오는 중...' : `${tracking?.worklog?.total ?? 0}개`}</span></div>
          </div>
          <div className="create-issue-grid">
            <label>
              <span className="apple-meta-label">작업한 시간 *</span>
              <input className="glass-input" value={time} onChange={event => handleTimeChange(event.target.value)} onBlur={() => { const parsed = parseWorklogTime(time); if (parsed.ok && parsed.normalized) setTime(parsed.normalized); }} placeholder="예: 70, 1h 10m, 1w3h" />
              {timePreview && <span style={{ marginTop: 6, fontSize: 12, color: timePreview.ok ? 'var(--text-secondary)' : '#d63031' }}>{timePreview.ok ? `변환: ${timePreview.normalized}` : timePreview.error}</span>}
            </label>
            <label>
              <span className="apple-meta-label">작업 시작 시각</span>
              <input className="glass-input" type="datetime-local" value={started} onChange={event => { setStartedTouched(true); setStarted(event.target.value); }} />
              <span style={{ marginTop: 6, fontSize: 12, color: 'var(--text-secondary)' }}>{startedTouched ? '직접 수정됨: 작업한 시간을 바꿔도 시작 시각은 유지됩니다.' : '자동 계산됨: 현재 시각에서 작업한 시간을 뺀 값입니다.'}</span>
              {startedTouched && <button type="button" className="btn-secondary" style={{ marginTop: 8, alignSelf: 'flex-start', padding: '5px 10px' }} onClick={() => { const parsed = parseWorklogTime(time); setStarted(getAutoStartedValue(parsed.ok ? parsed.minutes : undefined)); setStartedTouched(false); }}>자동 계산 다시 적용</button>}
            </label>
          </div>
          <label style={{ display: 'flex', flexDirection: 'column', gap: 8, marginTop: 14 }}>
            <span className="apple-meta-label">작업 설명</span>
            <textarea className="glass-input" value={comment} onChange={event => setComment(event.target.value)} placeholder="선택 입력" style={{ minHeight: 80, resize: 'vertical' }} />
          </label>
          <div style={{ marginTop: 16 }}>
            <span className="apple-meta-label" style={{ display: 'block', marginBottom: 8 }}>남은 시간 처리</span>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 12, color: 'var(--text-primary)', fontSize: 13 }}>
              <label style={{ display: 'flex', alignItems: 'center', gap: 6 }}><input type="radio" checked={adjustEstimate === 'auto'} onChange={() => setAdjustEstimate('auto')} /> 자동 감소</label>
              <label style={{ display: 'flex', alignItems: 'center', gap: 6 }}><input type="radio" checked={adjustEstimate === 'new'} onChange={() => setAdjustEstimate('new')} /> 남은 시간 직접 설정</label>
              <label style={{ display: 'flex', alignItems: 'center', gap: 6 }}><input type="radio" checked={adjustEstimate === 'leave'} onChange={() => setAdjustEstimate('leave')} /> 변경 안 함</label>
            </div>
            {adjustEstimate === 'new' && <label style={{ display: 'flex', flexDirection: 'column', gap: 8, marginTop: 12 }}><span className="apple-meta-label">새 남은 시간</span><input className="glass-input" value={newEstimate} onChange={event => setNewEstimate(event.target.value)} onBlur={() => { const parsed = parseWorklogTime(newEstimate, true); if (parsed.ok && parsed.normalized) setNewEstimate(parsed.normalized); }} placeholder="예: 0, 30m, 2h" />{estimatePreview && <span style={{ fontSize: 12, color: estimatePreview.ok ? 'var(--text-secondary)' : '#d63031' }}>{estimatePreview.ok ? `변환: ${estimatePreview.normalized}` : estimatePreview.error}</span>}</label>}
          </div>
          {error && <div style={{ marginTop: 12, color: '#d63031', fontSize: 13, fontWeight: 700 }}>{error}</div>}
          {message && <div style={{ marginTop: 12, color: '#078f55', fontSize: 13, fontWeight: 700 }}>{message}</div>}
          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 10, marginTop: 16 }}>
            <button className="btn-secondary" onClick={() => void fetchTracking()} disabled={trackingLoading}>새로고침</button>
            <button className="btn-premium" onClick={() => void submit()} disabled={submitting} style={{ opacity: submitting ? 0.65 : 1 }}>{submitting ? '등록 중...' : '작업로그 추가'}</button>
          </div>
          <div style={{ marginTop: 18, paddingTop: 16, borderTop: '1px solid rgba(127, 140, 141, 0.22)' }}>
            <button
              type="button"
              className="btn-secondary"
              onClick={() => setHistoryOpen(previous => !previous)}
              style={{ width: '100%', display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '9px 12px' }}
            >
              <span>작업 기록 ({tracking?.worklog?.total ?? 0})</span>
              <span>{historyOpen ? '접기' : '펼치기'}</span>
            </button>
            {historyOpen && (
              <div style={{ marginTop: 10, display: 'flex', flexDirection: 'column', gap: 10 }}>
                {trackingLoading && <div style={{ padding: 12, color: 'var(--text-secondary)', fontSize: 13 }}>작업 기록을 불러오는 중...</div>}
                {!trackingLoading && !(tracking?.worklog?.worklogs?.length) && <div style={{ padding: 12, color: 'var(--text-secondary)', fontSize: 13 }}>작성된 작업 기록이 없습니다.</div>}
                {tracking?.worklog?.worklogs?.map(entry => {
                  const isEditing = editingWorklogId === entry.id;
                  const actionPending = worklogActionId === entry.id;
                  const authorName = entry.author.displayName || entry.author.name || entry.author.key || '알 수 없음';
                  const startedLabel = entry.started && !Number.isNaN(new Date(entry.started).getTime())
                    ? new Date(entry.started).toLocaleString()
                    : '-';
                  return (
                    <div key={entry.id} className="glass-panel" style={{ padding: 13, margin: 0 }}>
                      {isEditing ? (
                        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                          <div className="create-issue-grid">
                            <label><span className="apple-meta-label">작업한 시간</span><input className="glass-input" value={editTime} onChange={event => setEditTime(event.target.value)} /></label>
                            <label><span className="apple-meta-label">작업 시작 시각</span><input className="glass-input" type="datetime-local" value={editStarted} onChange={event => setEditStarted(event.target.value)} /></label>
                          </div>
                          <label style={{ display: 'flex', flexDirection: 'column', gap: 7 }}><span className="apple-meta-label">작업 설명</span><textarea className="glass-input" value={editComment} onChange={event => setEditComment(event.target.value)} style={{ minHeight: 64, resize: 'vertical' }} /></label>
                          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8 }}>
                            <button type="button" className="btn-secondary" onClick={() => setEditingWorklogId(null)} disabled={actionPending}>취소</button>
                            <button type="button" className="btn-premium" onClick={() => void saveWorklog(entry)} disabled={actionPending}>{actionPending ? '저장 중...' : '저장'}</button>
                          </div>
                        </div>
                      ) : (
                        <>
                          <div style={{ display: 'flex', justifyContent: 'space-between', gap: 12, alignItems: 'flex-start' }}>
                            <div>
                              <div style={{ color: 'var(--text-primary)', fontWeight: 700 }}>{entry.timeSpent || `${Math.round(entry.timeSpentSeconds / 60)}m`}</div>
                              <div style={{ marginTop: 4, color: 'var(--text-secondary)', fontSize: 12 }}>{authorName} · {startedLabel}</div>
                            </div>
                            {entry.editable && (
                              <div style={{ display: 'flex', gap: 6, flexShrink: 0 }}>
                                <button type="button" className="btn-secondary" style={{ padding: '5px 9px' }} onClick={() => beginEdit(entry)} disabled={actionPending}>수정</button>
                                <button type="button" className="btn-secondary" style={{ padding: '5px 9px', color: '#d63031' }} onClick={() => void removeWorklog(entry)} disabled={actionPending}>{actionPending ? '처리 중...' : '삭제'}</button>
                              </div>
                            )}
                          </div>
                          <div style={{ marginTop: 9, color: entry.comment ? 'var(--text-primary)' : 'var(--text-secondary)', fontSize: 13, whiteSpace: 'pre-wrap', overflowWrap: 'anywhere' }}>{entry.comment || '작업 설명 없음'}</div>
                        </>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
});

const loadFavoriteIssueMap = <T,>(storageKey: string): Record<string, T> => {
  try {
    const raw = localStorage.getItem(storageKey);
    if (!raw) return {};
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : {};
  } catch {
    localStorage.removeItem(storageKey);
    return {};
  }
};

const loadJsonObject = <T,>(storageKey: string): Record<string, T> => {
  try {
    const raw = localStorage.getItem(storageKey);
    if (!raw) return {};
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : {};
  } catch {
    localStorage.removeItem(storageKey);
    return {};
  }
};

const dashboardStateMaps = (states: Record<string, DashboardIssueState>) => {
  const read: Record<string, string> = {};
  const unread: Record<string, string> = {};
  const observed: Record<string, string> = {};
  const jiraautoClosed: Record<string, string> = {};
  Object.entries(states).forEach(([key, state]) => {
    if (state.read_updated_at) read[key] = state.read_updated_at;
    if (state.unread_updated_at) unread[key] = state.unread_updated_at;
    if (state.observed_updated_at) observed[key] = state.observed_updated_at;
    if (state.jiraauto_closed_at) jiraautoClosed[key] = state.jiraauto_closed_at;
  });
  return { read, unread, observed, jiraautoClosed };
};

const isDoneIssue = (issue: JiraIssue | null) => {
  if (!issue) return false;
  if (issue.fields?.status?.statusCategory?.key === 'done') return true;
  const statusName = (issue.fields?.status?.name || '').trim().toLowerCase();
  return ['done', 'closed', 'resolved', '완료', '종료', '닫힘', '해결됨'].includes(statusName);
};

const transitionsExcludingCurrentStatus = (transitions: JiraTransition[], issue: JiraIssue | null) => {
  const currentStatus = issue?.fields?.status;
  if (!currentStatus) return transitions;
  const currentId = String(currentStatus.id || '').trim();
  const currentName = currentStatus.name.trim().toLocaleLowerCase();
  return transitions.filter(transition => {
    const targetId = String(transition.to?.id || '').trim();
    if (currentId && targetId) return targetId !== currentId;
    return transition.to?.name?.trim().toLocaleLowerCase() !== currentName;
  });
};


import { ReactNode } from 'react';

const DashboardContext = React.createContext<any>(null);

export function useDashboardContext() {
  const context = React.useContext(DashboardContext);
  if (!context) throw new Error('useDashboardContext must be used within DashboardProvider');
  return context;
}

export function DashboardProvider({ children }: { children: ReactNode }) {
  const [issues, setIssues] = useState<JiraIssue[]>([]);
  const [userMap, setUserMap] = useState<Record<string, JiraUser>>({});
  const [userMapLoaded, setUserMapLoaded] = useState(false);
  const [loading, setLoading] = useState(true);
  const [lastUpdated, setLastUpdated] = useState<Date>(new Date());
  const [jiraUrl, setJiraUrl] = useState<string>('');
  const [instanceList, setInstanceList] = useState<JiraInstanceInfo[]>([]);
  const [trackingProjects, setTrackingProjects] = useState<string[]>([]);
  const [allowUnassignedProcessing, setAllowUnassignedProcessing] = useState(false);
  const [allowAllProjectWorklog, setAllowAllProjectWorklog] = useState(false);
  const [originalEstimateEnabled, setOriginalEstimateEnabled] = useState(false);
  const [originalEstimateAuto, setOriginalEstimateAuto] = useState(false);
  const [originalEstimateValue, setOriginalEstimateValue] = useState('');
  
  const fetchIssuesAbortRef = useRef<AbortController | null>(null);
  const modalPointerStartedOnOverlayRef = useRef(false);
  const createModalPointerStartedOnOverlayRef = useRef(false);
  const openIssueCardRef = useRef<(issue: JiraIssue) => void>(() => undefined);
  const toggleFavoriteCardRef = useRef<(issue: JiraIssue) => void>(() => undefined);
  const searchInputRef = useRef<HTMLInputElement | null>(null);
  const handleIssueCardOpen = useCallback((issue: JiraIssue) => openIssueCardRef.current(issue), []);
  const handleIssueCardFavoriteToggle = useCallback((issue: JiraIssue) => toggleFavoriteCardRef.current(issue), []);

  const [datePreset, setDatePreset] = useState<string>(() => localStorage.getItem('datePreset') || '30');
  const [startDate, setStartDate] = useState<string>(() => localStorage.getItem('startDate') || '');
  const [endDate, setEndDate] = useState<string>(() => localStorage.getItem('endDate') || '');
  const [projectFilter, setProjectFilter] = useState<string>(() => localStorage.getItem('projectFilter') || 'all');
  const [instanceFilter, setInstanceFilter] = useState<string>(() =>
    localStorage.getItem('dashboardInstanceFilter') ||
    localStorage.getItem('instanceFilter') ||
    'all'
  );
  const [searchQuery, setSearchQuery] = useState<string>(() => localStorage.getItem('dashboardSearchQuery') || '');
  const [searchHelpOpen, setSearchHelpOpen] = useState(false);
  const [favoriteSearchQueries, setFavoriteSearchQueries] = useState<string[]>(loadFavoriteSearchQueries);
  const [toastMessage, setToastMessage] = useState('');
  const [refreshInterval, setRefreshInterval] = useState<number>(() => parseInt(localStorage.getItem('refreshInterval') || '15'));
  const [cacheMinutes, setCacheMinutes] = useState<number>(() => parseInt(localStorage.getItem('cacheMinutes') || '5'));
  const [dashboardPersonRole, setDashboardPersonRole] = useState<DashboardPersonRole>(loadDashboardPersonRole);
  const [trackOwnActivity, setTrackOwnActivity] = useState<boolean>(() => localStorage.getItem(TRACK_OWN_ACTIVITY_STORAGE_KEY) !== 'false');
  const [dashboardActivityTypes, setDashboardActivityTypes] = useState<DashboardActivityType[]>(loadDashboardActivityTypes);
  const [includeClosed, setIncludeClosed] = useState<boolean>(() =>
    localStorage.getItem('dashboardIncludeClosedIssues') === 'true' ||
    localStorage.getItem('includeClosedIssues') === 'true'
  );
  const [readIssues, setReadIssues] = useState<Record<string, string>>(() => loadJsonObject<string>('readIssues'));

  const handleStartDateChange = (value: string) => {
    const next = updateStartDateWithinRange(value, endDate);
    setStartDate(next.startDate);
    setEndDate(next.endDate);
    localStorage.setItem('startDate', next.startDate);
    localStorage.setItem('endDate', next.endDate);
  };

  const handleEndDateChange = (value: string) => {
    const next = updateEndDateWithinRange(startDate, value);
    setStartDate(next.startDate);
    setEndDate(next.endDate);
    localStorage.setItem('startDate', next.startDate);
    localStorage.setItem('endDate', next.endDate);
  };

  const [activeModal, setActiveModal] = useState<'comment' | 'subtask' | 'linked' | 'detail' | null>(null);
  const [selectedIssue, setSelectedIssue] = useState<JiraIssue | null>(null);
  const [issueDetail, setIssueDetail] = useState<JiraIssueDetail | null>(null);
  const [transitions, setTransitions] = useState<JiraTransition[]>([]);
  const [transitionUnavailable, setTransitionUnavailable] = useState(false);
  const [statusChangeSubmitting, setStatusChangeSubmitting] = useState(false);
  const [statusChangeError, setStatusChangeError] = useState('');
  const [detailLoading, setDetailLoading] = useState(false);
  const [detailError, setDetailError] = useState('');
  const [detailSession, setDetailSession] = useState(0);
  const detailSessionRef = useRef(0);
  const detailRequestRef = useRef(0);
  const linkedIssueRequestRef = useRef<AbortController | null>(null);
  const [linkedIssueLoading, setLinkedIssueLoading] = useState<string | null>(null);
  const [linkedIssueError, setLinkedIssueError] = useState('');
  useEffect(() => () => linkedIssueRequestRef.current?.abort(), [activeModal, selectedIssue?.key, selectedIssue?.instance_id]);
  const [editingCommentId, setEditingCommentId] = useState<string | null>(null);
  const [aiSummary, setAiSummary] = useState('');
  const [aiSummaryMeta, setAiSummaryMeta] = useState('');
  const [aiSummaryLoading, setAiSummaryLoading] = useState(false);
  const [aiSummaryError, setAiSummaryError] = useState('');
  const [timetracking, setTimetracking] = useState<TimeTrackingSnapshot | null>(null);
  const [originalEstimateSubmitting, setOriginalEstimateSubmitting] = useState(false);
  const [originalEstimateMessage, setOriginalEstimateMessage] = useState('');
  const [originalEstimateError, setOriginalEstimateError] = useState('');
  const [favoriteIssues, setFavoriteIssues] = useState<Record<string, JiraIssue>>(() => loadFavoriteIssueMap<JiraIssue>(FAVORITES_STORAGE_KEY));
  const [unreadUpdatedIssues, setUnreadUpdatedIssues] = useState<Record<string, string>>(() => loadJsonObject<string>(UNREAD_UPDATES_STORAGE_KEY));
  const [jiraautoClosedIssues, setJiraautoClosedIssues] = useState<Record<string, string>>({});
  const [createModalOpen, setCreateModalOpen] = useState(false);
  const [createMetadata, setCreateMetadata] = useState<IssueCreateProjectMeta[]>([]);
  const [createMetadataLoading, setCreateMetadataLoading] = useState(false);
  const [createSelectedProject, setCreateSelectedProject] = useState('');
  const [createIssueType, setCreateIssueType] = useState('');
  const [createSummary, setCreateSummary] = useState('');
  const [createDescription, setCreateDescription] = useState('');
  const [createComponent, setCreateComponent] = useState('');
  const [createAssigneeMode, setCreateAssigneeMode] = useState<'default' | 'me' | 'manual'>('default');
  const [createAssigneeQuery, setCreateAssigneeQuery] = useState('');
  const [createAssigneeSelected, setCreateAssigneeSelected] = useState<JiraUserSuggestion | null>(null);
  const [createAssigneeSuggestions, setCreateAssigneeSuggestions] = useState<JiraUserSuggestion[]>([]);
  const [createAssigneeLoading, setCreateAssigneeLoading] = useState(false);
  const [createSubmitting, setCreateSubmitting] = useState(false);
  const [createError, setCreateError] = useState('');

  const currentSelectedUser = selectedIssue ? userMap[selectedIssue.instance_id.toString()] : null;
  const isIssueChangeByCurrentUser = useCallback(async (issue: JiraIssue, signal: AbortSignal, isNewIssue: boolean) => {
    const currentUser = userMap[issue.instance_id.toString()];
    if (!currentUser) return false;
    try {
      const res = await fetch(`${API_BASE}/issues/${issue.key}?instance_id=${issue.instance_id}&refresh=true`, { signal });
      const detail = await res.json().catch(() => null);
      if (!res.ok || !detail || isUnavailableIssue(detail)) return false;
      const issueDetail = detail as JiraIssueDetail;
      const actor = isNewIssue
        ? issueDetail.fields?.creator || issue.fields?.creator || getLatestIssueActor(issueDetail)
        : getLatestIssueActor(issueDetail);
      return isSameJiraUser(actor, currentUser);
    } catch (error) {
      if (!(error instanceof DOMException && error.name === 'AbortError')) console.error(error);
      return false;
    }
  }, [userMap]);
  const selectedAssignee = issueDetail?.fields?.assignee || selectedIssue?.fields?.assignee || null;
  const currentStatusIssue = issueDetail?.fields?.status ? issueDetail : selectedIssue;
  const availableTransitions = transitionsExcludingCurrentStatus(transitions, currentStatusIssue);
  const isSelectedIssueAssignedToMe = Boolean(
    selectedIssue &&
    currentSelectedUser &&
    isSameJiraUser(selectedAssignee, currentSelectedUser)
  );
  const selectedIssueProjectKey = (issueDetail?.fields?.project?.key || selectedIssue?.fields?.project?.key || '').toUpperCase();
  const isSelectedIssueTrackedProject = Boolean(
    selectedIssueProjectKey &&
    trackingProjects.map(project => project.toUpperCase()).includes(selectedIssueProjectKey)
  );
  const canUseWorklogPanel = Boolean(
    selectedIssue &&
    (
      allowAllProjectWorklog ||
      (isSelectedIssueTrackedProject && (isSelectedIssueAssignedToMe || allowUnassignedProcessing))
    )
  );
  const normalizedTrackingProjects = trackingProjects.map(project => project.toUpperCase());
  const parsedOriginalEstimate = originalEstimateValue.trim() ? parseWorklogTime(originalEstimateValue) : null;
  const canUseOriginalEstimateValue = Boolean(parsedOriginalEstimate?.ok && parsedOriginalEstimate.normalized);
  const isIssueAssignedToMe = (issue: JiraIssue) => {
    const currentUser = userMap[issue.instance_id.toString()];
    return Boolean(currentUser && isSameJiraUser(issue.fields?.assignee, currentUser));
  };
  const isIssueMentionedForMe = (issue: JiraIssue) => {
    const currentUser = userMap[issue.instance_id.toString()];
    if (!currentUser) return false;
    return !isSameJiraUser(issue.fields?.assignee, currentUser) && !isSameJiraUser(issue.fields?.reporter, currentUser);
  };
  const isIssueReportedByMe = (issue: JiraIssue) => {
    const currentUser = userMap[issue.instance_id.toString()];
    return Boolean(
      currentUser &&
      isSameJiraUser(issue.fields?.reporter, currentUser) &&
      !isSameJiraUser(issue.fields?.assignee, currentUser)
    );
  };
  const isOriginalEstimateTarget = (issue: JiraIssue) => {
    const projectKey = issue.fields?.project?.key?.toUpperCase();
    if (!originalEstimateEnabled || !projectKey || !normalizedTrackingProjects.includes(projectKey)) return false;
    if (isIssueAssignedToMe(issue)) return true;
    return allowUnassignedProcessing && isIssueMentionedForMe(issue);
  };
  const selectedHasOriginalEstimate = Boolean(timetracking?.timetracking?.originalEstimate || selectedIssue?.fields?.timetracking?.originalEstimate);
  const canUseManualOriginalEstimate = Boolean(
    selectedIssue &&
    isOriginalEstimateTarget(selectedIssue) &&
    !originalEstimateAuto &&
    canUseOriginalEstimateValue
  );
  const isFavoriteIssue = (issue: { key: string; instance_id: number }) => Boolean(favoriteIssues[issueStorageKey(issue)]);
  const persistFavorites = useCallback((next: Record<string, JiraIssue>) => {
    setFavoriteIssues(next);
    localStorage.setItem(FAVORITES_STORAGE_KEY, JSON.stringify(next));
    window.dispatchEvent(new Event('jiraFavoritesChanged'));
  }, []);
  const removeFavoriteIssue = (issue: { key: string; instance_id: number }) => {
    const key = issueStorageKey(issue);
    if (!favoriteIssues[key]) return;
    const next = { ...favoriteIssues };
    delete next[key];
    persistFavorites(next);
  };
  const toggleFavoriteIssue = (issue: JiraIssue) => {
    const key = issueStorageKey(issue);
    const next = { ...favoriteIssues };
    if (next[key]) {
      delete next[key];
    } else {
      next[key] = issue;
    }
    persistFavorites(next);
  };
  useEffect(() => {
    const syncFavorites = () => setFavoriteIssues(loadFavoriteIssueMap<JiraIssue>(FAVORITES_STORAGE_KEY));
    window.addEventListener('storage', syncFavorites);
    window.addEventListener('jiraFavoritesChanged', syncFavorites);
    return () => {
      window.removeEventListener('storage', syncFavorites);
      window.removeEventListener('jiraFavoritesChanged', syncFavorites);
    };
  }, []);

  useEffect(() => {
    const syncFavoriteSearchQueries = () => setFavoriteSearchQueries(loadFavoriteSearchQueries());
    window.addEventListener('storage', syncFavoriteSearchQueries);
    window.addEventListener('jiraQueryFavoritesChanged', syncFavoriteSearchQueries);
    return () => {
      window.removeEventListener('storage', syncFavoriteSearchQueries);
      window.removeEventListener('jiraQueryFavoritesChanged', syncFavoriteSearchQueries);
    };
  }, []);

  useEffect(() => {
    if (!toastMessage) return;
    const timer = window.setTimeout(() => setToastMessage(''), 3000);
    return () => window.clearTimeout(timer);
  }, [toastMessage]);

  useEffect(() => {
    const input = searchInputRef.current;
    if (!input) return;
    let closeFrame = 0;
    const handleNativeSearch = () => {
      if (input.value) return;
      window.cancelAnimationFrame(closeFrame);
      closeFrame = window.requestAnimationFrame(() => {
        setSearchHelpOpen(false);
        input.blur();
      });
    };
    input.addEventListener('search', handleNativeSearch);
    return () => {
      window.cancelAnimationFrame(closeFrame);
      input.removeEventListener('search', handleNativeSearch);
    };
  }, []);

  const fetchIssues = useCallback(async () => {
    const fetchFavoriteIssueUpdates = async (baseIssues: JiraIssue[], signal: AbortSignal): Promise<JiraIssue[]> => {
      const baseKeys = new Set(baseIssues.map(issueStorageKey));
      const activeInstanceIds = new Set(instanceList.map(instance => instance.id));
      const favoriteTargets = Object.values(loadFavoriteIssueMap<JiraIssue>(FAVORITES_STORAGE_KEY))
        .filter(issue => activeInstanceIds.has(issue.instance_id) && !baseKeys.has(issueStorageKey(issue)));

      if (favoriteTargets.length === 0) return [];

      const refreshed = await Promise.all(
        favoriteTargets.map(async issue => {
          try {
            const res = await fetch(`${API_BASE}/issues/${issue.key}?instance_id=${issue.instance_id}&refresh=true`, { signal });
            const data = await res.json().catch(() => null);
            if (!res.ok || !data || data === false || isUnavailableIssue(data)) {
              return {
                ...issue,
                favorite_unavailable: true,
                favorite_unavailable_reason: getUnavailableReason(data, !res.ok ? `HTTP ${res.status}` : undefined),
              };
            }
            return { ...data, favorite_unavailable: false, favorite_unavailable_reason: undefined } as JiraIssue;
          } catch (error: unknown) {
            if (!isAbortError(error)) console.error(error);
            return null;
          }
        })
      );

      return refreshed.filter((issue): issue is JiraIssue => Boolean(issue?.key && issue?.instance_id));
    };

    fetchIssuesAbortRef.current?.abort();
    const controller = new AbortController();
    fetchIssuesAbortRef.current = controller;
    try {
      let url = `${API_BASE}/issues?cache_minutes=${cacheMinutes}`;
      if (datePreset === 'custom') { 
        if (startDate) url += `&start_date=${startDate}`; 
        if (endDate) url += `&end_date=${endDate}`; 
      } else if (datePreset !== 'all') { 
        const start = new Date(); start.setDate(start.getDate() - parseInt(datePreset)); 
        url += `&start_date=${start.toISOString().split('T')[0]}`; 
      }
      if (includeClosed) url += '&include_closed=true';
      const res = await fetch(url, { signal: controller.signal });
      if (!res.ok) throw new Error('이슈 목록을 불러오지 못했습니다.');
      const data = await res.json();
      if (controller.signal.aborted) return;
      const newIssues: JiraIssue[] = data.issues || [];
      // Show the requested list before notification checks or detail refreshes.
      const storedInstanceFilter = localStorage.getItem('dashboardInstanceFilter')
        || localStorage.getItem('instanceFilter')
        || 'all';
      const storedProjectFilter = localStorage.getItem('projectFilter') || 'all';
      const nextProjectFilter = normalizeProjectFilter(storedProjectFilter, storedInstanceFilter, newIssues);
      if (nextProjectFilter !== storedProjectFilter) {
        setProjectFilter(nextProjectFilter);
        localStorage.setItem('projectFilter', nextProjectFilter);
      }
      setIssues(current => issueSnapshotSignature(current) === issueSnapshotSignature(newIssues) ? current : newIssues);
      setLastUpdated(new Date());
      setLoading(false);
      const refreshedFavoriteIssues = await fetchFavoriteIssueUpdates(newIssues, controller.signal);
      if (controller.signal.aborted) return;
      const latestIssuesForDetection = [
        ...newIssues,
        ...refreshedFavoriteIssues.filter(fav => !newIssues.some(issue => issueStorageKey(issue) === issueStorageKey(fav)))
      ];
      const currentFavorites = loadFavoriteIssueMap<JiraIssue>(FAVORITES_STORAGE_KEY);
      let favoritesChanged = false;
      const nextFavorites = { ...currentFavorites };
      latestIssuesForDetection.forEach(issue => {
        const key = issueStorageKey(issue);
        if (nextFavorites[key]) {
          nextFavorites[key] = issue;
          favoritesChanged = true;
        }
      });
      if (favoritesChanged) persistFavorites(nextFavorites);

      const successfulInstanceIds: number[] = Array.isArray(data.successful_instance_ids)
        ? data.successful_instance_ids
        : Array.from(new Set(newIssues.map(issue => issue.instance_id)));
      const stateRes = await fetch(`${API_BASE}/dashboard/issue-states`, { signal: controller.signal });
      let dashboardState = await stateRes.json().catch(() => null) as DashboardIssueStatePayload | null;
      if (controller.signal.aborted) return;
      if (!stateRes.ok || !dashboardState) throw new Error('대시보드 알림 상태를 불러오지 못했습니다.');

      const pendingMigrationIds = dashboardState.migration_pending_instance_ids
        .filter(iid => successfulInstanceIds.includes(iid));
      if (pendingMigrationIds.length > 0) {
        const legacyRead = loadJsonObject<string>('readIssues');
        const legacyUnread = loadJsonObject<string>(UNREAD_UPDATES_STORAGE_KEY);
        const hasLegacyReadHistory = Object.keys(legacyRead).length > 0;
        const issueKeyCounts = latestIssuesForDetection.reduce<Record<string, number>>((counts, issue) => {
          counts[issue.key] = (counts[issue.key] || 0) + 1;
          return counts;
        }, {});
        const migrationIssues = latestIssuesForDetection
          .filter(issue => pendingMigrationIds.includes(issue.instance_id) && issue.fields?.updated)
          .map(issue => {
            const key = issueStorageKey(issue);
            const legacyReadValue = issueKeyCounts[issue.key] === 1 ? legacyRead[issue.key] : undefined;
            const readUpdatedAt = legacyRead[key] || legacyReadValue || null;
            const currentUser = userMap[issue.instance_id.toString()];
            const isOwnCreation = Boolean(currentUser && isSameJiraUser(issue.fields?.creator, currentUser));
            const inferredUnread = hasLegacyReadHistory && !readUpdatedAt && (trackOwnActivity || !isOwnCreation)
              ? issue.fields.updated
              : null;
            return {
              instance_id: issue.instance_id,
              issue_key: issue.key,
              observed_updated_at: issue.fields.updated,
              unread_updated_at: legacyUnread[key] || inferredUnread,
              read_updated_at: readUpdatedAt,
            };
          });
        const migrationRes = await fetch(`${API_BASE}/dashboard/issue-states/migrate`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ issues: migrationIssues, instance_ids: pendingMigrationIds }),
          signal: controller.signal,
        });
        const migratedState = await migrationRes.json().catch(() => null) as DashboardIssueStatePayload | null;
        if (!migrationRes.ok || !migratedState) throw new Error('기존 대시보드 알림 상태를 DB로 이관하지 못했습니다.');
        dashboardState = migratedState;
        if (dashboardState.migration_pending_instance_ids.length === 0) {
          localStorage.removeItem('readIssues');
          localStorage.removeItem(UNREAD_UPDATES_STORAGE_KEY);
        }
      }

      const changedIssues: JiraIssue[] = [];
      const observations: Array<{
        instance_id: number;
        issue_key: string;
        observed_updated_at: string;
        mark_unread: boolean;
        activity_snapshot?: Record<string, unknown>;
      }> = [];
      const initializedInstances = new Set(dashboardState.initialized_instance_ids);

      for (const issue of latestIssuesForDetection) {
        const key = issueStorageKey(issue);
        const state = dashboardState.states[key];
        const currentUpdate = issue.fields?.updated;
        if (!currentUpdate || !successfulInstanceIds.includes(issue.instance_id)) continue;

        const previousUpdate = state?.observed_updated_at;
        const lastSyncAt = dashboardState.last_sync_at_by_instance[issue.instance_id.toString()];
        const isNewIssue = Boolean(
          initializedInstances.has(issue.instance_id) &&
          !previousUpdate &&
          lastSyncAt &&
          getUpdatedTime(currentUpdate) > getUpdatedTime(lastSyncAt)
        );
        const isUpdatedIssue = Boolean(
          previousUpdate && getUpdatedTime(currentUpdate) > getUpdatedTime(previousUpdate)
        );
        const wasRead = isReadUpdate(state?.read_updated_at || undefined, currentUpdate);
        const alreadyUnread = state?.unread_updated_at === currentUpdate;
        let markUnread = false;
        let activitySnapshot: Record<string, unknown> | undefined;

        if ((isNewIssue || isUpdatedIssue) && !wasRead && !alreadyUnread) {
          let activity: DashboardIssueActivityPayload | null = null;
          try {
            const activityRes = await fetch(
              `${API_BASE}/dashboard/issues/${encodeURIComponent(issue.key)}/activity?instance_id=${issue.instance_id}`,
              { signal: controller.signal },
            );
            if (!activityRes.ok) throw new Error('Jira 신규 활동 종류를 확인하지 못했습니다.');
            activity = await activityRes.json() as DashboardIssueActivityPayload;
            activitySnapshot = activity.snapshot;
          } catch (error) {
            if (isAbortError(error)) throw error;
            console.error(error);
            if (!isNewIssue) continue;
          }

          const enabledActivity = isNewIssue
            ? dashboardActivityTypes.includes('new_issue')
            : Boolean(activity?.categories.some(category => dashboardActivityTypes.includes(category)));
          if (enabledActivity) {
            const isOwnChange = !trackOwnActivity && await isIssueChangeByCurrentUser(
              issue,
              controller.signal,
              isNewIssue,
            );
            if (!isOwnChange) {
              markUnread = true;
              changedIssues.push(issue);
            }
          }
        }

        observations.push({
          instance_id: issue.instance_id,
          issue_key: issue.key,
          observed_updated_at: currentUpdate,
          mark_unread: markUnread,
          activity_snapshot: activitySnapshot,
        });
      }

      let finalDashboardState = dashboardState;
      let observationPersisted = false;
      const observeRes = await fetch(`${API_BASE}/dashboard/issue-states/observe`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ issues: observations, successful_instance_ids: successfulInstanceIds }),
        signal: controller.signal,
      });
      const observedState = await observeRes.json().catch(() => null) as DashboardIssueStatePayload | null;
      if (controller.signal.aborted) return;
      if (observeRes.ok && observedState) {
        finalDashboardState = observedState;
        observationPersisted = true;
      } else {
        console.error('대시보드 알림 상태를 DB에 저장하지 못했습니다.');
      }
      const finalMaps = dashboardStateMaps(finalDashboardState.states);
      setReadIssues(current => sameStringRecord(current, finalMaps.read) ? current : finalMaps.read);
      setUnreadUpdatedIssues(current => sameStringRecord(current, finalMaps.unread) ? current : finalMaps.unread);
      setJiraautoClosedIssues(current => sameStringRecord(current, finalMaps.jiraautoClosed) ? current : finalMaps.jiraautoClosed);

      if (observationPersisted && changedIssues.length > 0 && 'Notification' in window && Notification.permission === 'granted') {
        changedIssues.forEach(issue => {
          const currentUser = userMap[issue.instance_id.toString()];
          const isAssigned = Boolean(currentUser && isSameJiraUser(issue.fields?.assignee, currentUser));
          const isMentioned = Boolean(
            currentUser &&
            !isSameJiraUser(issue.fields?.assignee, currentUser) &&
            !isSameJiraUser(issue.fields?.reporter, currentUser)
          );
          if ((isAssigned || isMentioned) && notificationsAllowed()) {
            const inst = instanceList.find(ins => ins.id === issue.instance_id);
            const instName = inst?.name || 'Jira';
            const n = new Notification(`[${instName}] ${isAssigned ? '내 업무 업데이트' : '멘션 알림'}`, {
              body: `${issue.key}: ${issue.fields?.summary || ''}`,
              icon: '/favicon.svg',
              tag: `${issueStorageKey(issue)}:${issue.fields?.updated || ''}`,
            });
            n.onclick = () => { window.open(`${inst?.base_url || jiraUrl}/browse/${issue.key}`, '_blank'); window.focus(); };
          }
        });
      }

    } catch (error: unknown) {
      if (!isAbortError(error)) console.error(error);
    } finally {
      if (fetchIssuesAbortRef.current === controller) {
        fetchIssuesAbortRef.current = null;
        setLoading(false);
      }
    }
  }, [datePreset, startDate, endDate, cacheMinutes, includeClosed, trackOwnActivity, dashboardActivityTypes, userMap, jiraUrl, instanceList, isIssueChangeByCurrentUser, persistFavorites]);

  const fetchIssueDetail = async (key: string, iid: number, session = detailSession, preloaded?: JiraIssueDetail) => {
    // A saved mutation may finish after another issue (or the same issue) is reopened.
    if (session !== detailSessionRef.current) return;
    const request = ++detailRequestRef.current;
    const isCurrent = () => session === detailSessionRef.current && request === detailRequestRef.current;
    setDetailError('');
    try {
      const [d, t] = await Promise.all([
        preloaded ? Promise.resolve({ ok: true, json: async () => preloaded }) : fetch(`${API_BASE}/issues/${key}?instance_id=${iid}`),
        fetch(`${API_BASE}/issues/${key}/transitions?instance_id=${iid}&refresh=true`),
      ]);
      const detailData = await d.json().catch(() => null);
      const transitionData = await t.json().catch(() => ({}));
      if (!isCurrent()) return;
      setTransitions(transitionData.transitions || []);
      setTransitionUnavailable(!t.ok || transitionData.jira_available !== true);
      if (!d.ok || !detailData || isUnavailableIssue(detailData)) {
        throw new Error('이슈 상세 정보를 불러오지 못했습니다. 잠시 후 다시 시도해주세요.');
      }
      setIssueDetail(detailData);
    } catch {
      // Keep the rendered editors and last successful data during refresh failures.
      if (isCurrent()) setDetailError('이슈 상세 정보를 불러오지 못했습니다. 잠시 후 다시 시도해주세요.');
    } finally {
      if (isCurrent()) setDetailLoading(false);
    }
  };

  const formatAiSummaryMeta = (provider?: string, elapsedMs?: number, createdAt?: string) => {
    const parts = [provider || ''];
    if (typeof elapsedMs === 'number') parts.push(`${(elapsedMs / 1000).toFixed(1)}초`);
    if (createdAt) parts.push(formatDateTime(createdAt));
    return parts.filter(Boolean).join(' · ');
  };

  const loadCachedAiSummary = async (issue: JiraIssue, session: number) => {
    try {
      const res = await fetch(`${API_BASE}/ai/issue-summary?issue_key=${encodeURIComponent(issue.key)}&instance_id=${issue.instance_id}`);
      const data = await res.json().catch(() => null);
      if (session !== detailSessionRef.current) return;
      if (res.ok && data?.cached && data.summary) {
        setAiSummary(data.summary);
        setAiSummaryMeta(formatAiSummaryMeta(data.provider, data.elapsed_ms, data.created_at));
      }
    } catch {
      // 캐시 조회 실패는 조용히 무시하고 새로 생성하게 둔다.
    }
  };

  const generateAiSummary = async () => {
    if (!selectedIssue || aiSummaryLoading) return;
    const session = detailSessionRef.current;
    setAiSummaryLoading(true);
    setAiSummaryError('');
    try {
      const res = await fetch(`${API_BASE}/ai/summarize-issue`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ issue_key: selectedIssue.key, instance_id: selectedIssue.instance_id }),
      });
      const data = await res.json().catch(() => null);
      if (session !== detailSessionRef.current) return;
      if (!res.ok) {
        const detail = data && typeof data.detail === 'string' ? data.detail : '';
        throw new Error(detail || 'AI 요약 요청에 실패했습니다.');
      }
      if (!data?.ok) throw new Error(data?.error || 'AI 요약 생성에 실패했습니다.');
      setAiSummary(data.summary || '');
      setAiSummaryMeta(formatAiSummaryMeta(data.provider, data.elapsed_ms, data.created_at));
    } catch (error: unknown) {
      if (session !== detailSessionRef.current) return;
      setAiSummaryError(errorMessage(error, 'AI 요약 생성에 실패했습니다.'));
    } finally {
      if (session === detailSessionRef.current) setAiSummaryLoading(false);
    }
  };

  const updateJiraautoClosedState = async (closed: boolean) => {
    if (!selectedIssue || statusChangeSubmitting) return;
    setStatusChangeSubmitting(true);
    setStatusChangeError('');
    try {
      const res = await fetch(`${API_BASE}/dashboard/issue-states/local-close`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          instance_id: selectedIssue.instance_id,
          issue_key: selectedIssue.key,
          closed,
          observed_updated_at: selectedIssue.fields?.updated,
        }),
      });
      const payload = await res.json().catch(() => null) as DashboardIssueStatePayload | null;
      if (!res.ok || !payload) throw new Error(closed ? '로컬 닫힘 처리에 실패했습니다.' : '로컬 닫힘 해제에 실패했습니다.');
      const maps = dashboardStateMaps(payload.states);
      setJiraautoClosedIssues(maps.jiraautoClosed);
      setActiveModal(null);
      setSelectedIssue(null);
      setIssueDetail(null);
      await fetchIssues();
    } catch (error: unknown) {
      setStatusChangeError(errorMessage(error, '상태 변경에 실패했습니다.'));
    } finally {
      setStatusChangeSubmitting(false);
    }
  };

  const handleStatusChange = async (value: string) => {
    if (!selectedIssue || !value || statusChangeSubmitting) return;
    if (value === '__jiraauto_close__') {
      await updateJiraautoClosedState(true);
      return;
    }
    if (value === '__jiraauto_reopen__') {
      await updateJiraautoClosedState(false);
      return;
    }
    setStatusChangeSubmitting(true);
    setStatusChangeError('');
    try {
      const res = await fetch(`${API_BASE}/issues/${selectedIssue.key}/transitions?instance_id=${selectedIssue.instance_id}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ transition_id: value }),
      });
      if (!res.ok) throw new Error('Jira 상태 변경에 실패했습니다.');
      // 상태가 바뀌면 이전 AI 요약은 오해를 부를 수 있으므로 즉시 비운다.
      setAiSummary('');
      setAiSummaryMeta('');
      setAiSummaryError('');
      await fetchIssues();
      await fetchIssueDetail(selectedIssue.key, selectedIssue.instance_id);
    } catch (error: unknown) {
      setStatusChangeError(errorMessage(error, 'Jira 상태 변경에 실패했습니다.'));
    } finally {
      setStatusChangeSubmitting(false);
    }
  };

  const refreshTimeTrackingSnapshot = async (issue: JiraIssue) => {
    const res = await fetch(`${API_BASE}/issues/${issue.key}/timetracking?instance_id=${issue.instance_id}`);
    if (!res.ok) throw new Error('시간 추적 정보를 불러오지 못했습니다.');
    setTimetracking(await res.json());
  };

  const submitOriginalEstimate = async () => {
    if (!selectedIssue || originalEstimateSubmitting) return;
    setOriginalEstimateError('');
    setOriginalEstimateMessage('');
    const parsed = parseWorklogTime(originalEstimateValue);
    if (!parsed.ok || !parsed.normalized) {
      setOriginalEstimateError(parsed.error || '최초 추정 시간을 확인하세요.');
      return;
    }
    setOriginalEstimateSubmitting(true);
    try {
      const res = await fetch(`${API_BASE}/issues/${selectedIssue.key}/original-estimate?instance_id=${selectedIssue.instance_id}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ originalEstimate: parsed.normalized }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(typeof data.detail === 'string' ? data.detail : '최초 추정 입력에 실패했습니다.');
      setOriginalEstimateValue(parsed.normalized);
      setOriginalEstimateMessage(data.status === 'updated' ? '최초 추정을 입력했습니다.' : '이미 최초 추정이 입력되어 있습니다.');
      await refreshTimeTrackingSnapshot(selectedIssue);
      await fetchIssueDetail(selectedIssue.key, selectedIssue.instance_id);
    } catch (error: unknown) {
      setOriginalEstimateError(errorMessage(error, '최초 추정 입력에 실패했습니다.'));
    } finally {
      setOriginalEstimateSubmitting(false);
    }
  };

  const autoSubmitOriginalEstimateForIssue = async (issue: JiraIssue) => {
    if (!originalEstimateEnabled || !originalEstimateAuto) return;
    if (!isOriginalEstimateTarget(issue) || issue.fields?.timetracking?.originalEstimate) return;
    const parsed = parseWorklogTime(originalEstimateValue);
    if (!parsed.ok || !parsed.normalized) return;

    setOriginalEstimateError('');
    setOriginalEstimateMessage('');
    setOriginalEstimateSubmitting(true);
    try {
      const res = await fetch(`${API_BASE}/issues/${issue.key}/original-estimate?instance_id=${issue.instance_id}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ originalEstimate: parsed.normalized }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(typeof data.detail === 'string' ? data.detail : '최초 추정 자동 입력에 실패했습니다.');
      if (data.status === 'updated') {
        setOriginalEstimateMessage('최초 추정을 자동 입력했습니다.');
      }
      await refreshTimeTrackingSnapshot(issue);
    } catch (error: unknown) {
      setOriginalEstimateError(errorMessage(error, '최초 추정 자동 입력에 실패했습니다.'));
    } finally {
      setOriginalEstimateSubmitting(false);
    }
  };

  const metaKey = (meta: IssueCreateProjectMeta) => `${meta.instance_id}:${meta.project_key}`;
  const selectedCreateMeta = createMetadata.find(meta => metaKey(meta) === createSelectedProject);
  const currentCreateUser = selectedCreateMeta ? userMap[selectedCreateMeta.instance_id.toString()] : null;
  const createAssigneeValue =
    createAssigneeMode === 'me'
      ? (currentCreateUser?.name || currentCreateUser?.key || currentCreateUser?.accountId || '')
      : createAssigneeMode === 'manual'
        ? (createAssigneeSelected?.name || createAssigneeSelected?.key || createAssigneeSelected?.id || '')
        : '';

  const searchUsersForContext = useCallback(async (
    query: string,
    options: { issueKey?: string; instanceId?: number; projectKey?: string; assignable?: boolean }
  ): Promise<JiraUserSuggestion[]> => {
    if (!query.trim()) return [];
    const params = new URLSearchParams({ query: query.trim() });
    if (options.issueKey) params.set('issue_key', options.issueKey);
    if (options.instanceId !== undefined) params.set('instance_id', String(options.instanceId));
    if (options.projectKey) params.set('project_key', options.projectKey);
    if (options.assignable) params.set('assignable', 'true');
    try {
      const res = await fetch(`${API_BASE}/users/search?${params.toString()}`);
      const data = await res.json();
      const users = Array.isArray(data) ? data : (data.users || []);
      return users.map(normalizeJiraUserSuggestion).filter(Boolean) as JiraUserSuggestion[];
    } catch {
      return [];
    }
  }, []);

  const applyCreateDefaults = (meta?: IssueCreateProjectMeta) => {
    setCreateIssueType(meta?.issue_types[0]?.name || '');
    setCreateComponent('');
    setCreateAssigneeMode('default');
    setCreateAssigneeQuery('');
    setCreateAssigneeSelected(null);
    setCreateAssigneeSuggestions([]);
  };

  const loadCreateMetadata = async () => {
    setCreateMetadataLoading(true);
    setCreateError('');
    try {
      const res = await fetch(`${API_BASE}/issues/create-metadata`);
      const data = await res.json();
      const availableProjects: IssueCreateProjectMeta[] = (data.projects || []).filter((meta: IssueCreateProjectMeta) => meta.issue_types?.length || meta.components?.length);
      setCreateMetadata(availableProjects);
      const current = availableProjects.find(meta => metaKey(meta) === createSelectedProject);
      const next = current || availableProjects[0];
      setCreateSelectedProject(next ? metaKey(next) : '');
      applyCreateDefaults(next);
    } catch (error: unknown) {
      setCreateError(errorMessage(error, '생성 정보를 불러오지 못했습니다.'));
    } finally {
      setCreateMetadataLoading(false);
    }
  };

  const resetCreateIssueForm = useCallback(() => {
    setCreateSummary('');
    setCreateDescription('');
    setCreateComponent('');
    setCreateAssigneeMode('default');
    setCreateAssigneeQuery('');
    setCreateAssigneeSelected(null);
    setCreateAssigneeSuggestions([]);
    setCreateError('');
  }, []);

  const openCreateIssueModal = () => {
    resetCreateIssueForm();
    createModalPointerStartedOnOverlayRef.current = false;
    setCreateModalOpen(true);
    if (createMetadata.length === 0) void loadCreateMetadata();
  };

  const closeCreateIssueModal = useCallback(() => {
    if (createSubmitting) return;
    createModalPointerStartedOnOverlayRef.current = false;
    resetCreateIssueForm();
    setCreateModalOpen(false);
  }, [createSubmitting, resetCreateIssueForm]);

  useEffect(() => {
    if (!activeModal && !createModalOpen) return;

    const previousBodyOverflow = document.body.style.overflow;
    const previousHtmlOverflow = document.documentElement.style.overflow;
    document.body.style.overflow = 'hidden';
    document.documentElement.style.overflow = 'hidden';

    const handleModalKeyDown = (event: KeyboardEvent) => {
      if (event.key !== 'Escape') return;
      event.preventDefault();
      if (createModalOpen) {
        closeCreateIssueModal();
        return;
      }
      setActiveModal(null);
    };
    document.addEventListener('keydown', handleModalKeyDown);

    return () => {
      document.removeEventListener('keydown', handleModalKeyDown);
      document.body.style.overflow = previousBodyOverflow;
      document.documentElement.style.overflow = previousHtmlOverflow;
    };
  }, [activeModal, closeCreateIssueModal, createModalOpen]);

  const extractJiraErrorMessage = (payload: unknown, fallback: string) => {
    const collect = (value: unknown): string[] => {
      if (!value) return [];
      if (typeof value === 'string') {
        const trimmed = value.trim();
        if (!trimmed) return [];
        if (trimmed.startsWith('{') || trimmed.startsWith('[')) {
          try {
            return collect(JSON.parse(trimmed));
          } catch {
            return [trimmed];
          }
        }
        return [trimmed];
      }
      if (Array.isArray(value)) return value.flatMap(collect);
      if (typeof value === 'object') {
        const record = value as UnknownRecord;
        const messages: string[] = [];
        if (record.detail) messages.push(...collect(record.detail));
        if (record.message) messages.push(...collect(record.message));
        if (record.errorMessages) messages.push(...collect(record.errorMessages));
        if (record.errors && typeof record.errors === 'object') {
          messages.push(...Object.values(record.errors).flatMap(collect));
        }
        return messages;
      }
      return [];
    };

    const messages = Array.from(new Set(collect(payload)));
    return messages.length ? messages.join('\n') : fallback;
  };

  const submitCreateIssue = async () => {
    if (!selectedCreateMeta || !createIssueType || !createSummary.trim() || createSubmitting) return;
    if (createAssigneeMode === 'me' && !createAssigneeValue) {
      setCreateError('현재 Jira 계정 정보를 찾을 수 없습니다.');
      return;
    }
    if (createAssigneeMode === 'manual' && !createAssigneeValue) {
      setCreateError('담당자를 선택해 주세요.');
      return;
    }
    setCreateSubmitting(true);
    setCreateError('');
    try {
      const res = await fetch(`${API_BASE}/issues`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          instance_id: selectedCreateMeta.instance_id,
          project_key: selectedCreateMeta.project_key,
          issuetype_name: createIssueType,
          summary: createSummary.trim(),
          description: convertMentionsToJiraFormat(createDescription),
          component_name: createComponent || null,
          assignee_name: createAssigneeValue || null,
        }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(extractJiraErrorMessage(data, 'Jira 이슈 생성에 실패했습니다.'));
      resetCreateIssueForm();
      setCreateModalOpen(false);
      await fetchIssues();
      if (data?.key) {
        const createdIssue: JiraIssue = {
          key: data.key,
          instance_id: selectedCreateMeta.instance_id,
          fields: {
            summary: createSummary.trim(),
            status: { name: 'Created' },
            project: { key: selectedCreateMeta.project_key },
            issuetype: { name: createIssueType },
            assignee: createAssigneeValue ? { name: createAssigneeValue, displayName: createAssigneeMode === 'manual' ? (createAssigneeSelected?.display || createAssigneeValue) : (currentCreateUser?.displayName || createAssigneeValue) } : null,
            reporter: null,
            updated: new Date().toISOString(),
            created: new Date().toISOString(),
          },
        };
        handleOpenDetailModal(createdIssue);
      }
    } catch (error: unknown) {
      setCreateError(errorMessage(error, 'Jira 이슈 생성에 실패했습니다.'));
    } finally {
      setCreateSubmitting(false);
    }
  };

  // Preserve both the display name and Jira user id. The backend converts this
  // to an ADF mention for Cloud or [~username] for Server/Data Center.
  const convertMentionsToJiraFormat = (text: string) => text;

  const escapeHtml = (value: string) => value
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');

  const stripEmptyJiraMarkers = (value: string): string => value
    .replace(/\{\s*(?:<!--[\s\S]*?-->\s*)*(?:<\/?[^>]+>\s*)*\}/g, '')
    .replace(/&#0*123;\s*(?:<!--[\s\S]*?-->\s*)*(?:<\/?[^>]+>\s*)*&#0*125;/gi, '')
    .replace(/&#x0*7b;\s*(?:<!--[\s\S]*?-->\s*)*(?:<\/?[^>]+>\s*)*&#x0*7d;/gi, '')
    .replace(/&lbrace;\s*(?:<!--[\s\S]*?-->\s*)*(?:<\/?[^>]+>\s*)*&rbrace;/gi, '');

  const normalizeJiraWikiMarkers = (value: string): string => value
    .replace(/\{\*\}/g, '*')
    .replace(/\{_\}/g, '_')
    .replace(/\{\+\}/g, '+')
    .replace(/\{-\}/g, '-');

  const renderJiraWikiToHtml = (text: string): string => {
    const trimJiraTableRow = (row: string, delimiter: '|' | '||'): string => {
      let value = row;
      if (value.startsWith(delimiter)) value = value.slice(delimiter.length);
      if (value.endsWith(delimiter)) value = value.slice(0, -delimiter.length);
      return value;
    };

    const splitJiraTableCells = (row: string, delimiter: '|' | '||'): string[] => {
      const cells: string[] = [];
      let current = '';
      let bracketDepth = 0;

      for (let index = 0; index < row.length; index += 1) {
        const char = row[index];

        if (char === '[') {
          bracketDepth += 1;
          current += char;
          continue;
        }

        if (char === ']' && bracketDepth > 0) {
          bracketDepth -= 1;
          current += char;
          continue;
        }

        if (bracketDepth === 0 && row.startsWith(delimiter, index)) {
          cells.push(current);
          current = '';
          index += delimiter.length - 1;
          continue;
        }

        current += char;
      }

      cells.push(current);
      return cells;
    };

    const mergeMultilineTableRows = (rawLines: string[]) => {
      const merged: string[] = [];
      let pending: string | null = null;

      rawLines.forEach(line => {
        const trimmed = line.trim();
        if (pending !== null) {
          pending += trimmed ? `\n${line}` : '\n';
          if (trimmed.endsWith('|')) {
            merged.push(pending);
            pending = null;
          }
          return;
        }

        if (/^\|/.test(trimmed) && !trimmed.endsWith('|')) {
          pending = line;
          return;
        }

        merged.push(line);
      });

      if (pending !== null) merged.push(pending);
      return merged;
    };

    const lines = mergeMultilineTableRows(stripEmptyJiraMarkers(text).split('\n'));
    const result: string[] = [];
    let inTable = false;

    for (const line of lines) {
      const trimmed = line.trim();
      const isHeaderRow = /^\|\|/.test(trimmed);
      const isDataRow = !isHeaderRow && /^\|/.test(trimmed) && /\|$/.test(trimmed);

      if (isHeaderRow || isDataRow) {
        if (!inTable) { result.push('<table class="jira-wiki-table"><tbody>'); inTable = true; }
        if (isHeaderRow) {
          const cells = splitJiraTableCells(trimJiraTableRow(trimmed, '||'), '||');
          result.push('<tr>' + cells.map(c => `<th>${renderJiraTableCell(c.trim())}</th>`).join('') + '</tr>');
        } else {
          const cells = splitJiraTableCells(trimJiraTableRow(trimmed, '|'), '|');
          result.push('<tr>' + cells.map(c => `<td>${renderJiraTableCell(c.trim())}</td>`).join('') + '</tr>');
        }
      } else {
        if (inTable) { result.push('</tbody></table>'); inTable = false; }
        result.push(trimmed === '' ? '<br/>' : `<p>${renderJiraInline(line)}</p>`);
      }
    }
    if (inTable) result.push('</tbody></table>');
    return result.join('');
  };

  const renderJiraTableCell = (text: string): string =>
    renderJiraInline(normalizeJiraWikiMarkers(text)).replace(/\r?\n/g, '<br/>');

  const replaceBoundedJiraStyle = (
    value: string,
    marker: '*' | '_' | '+' | '-',
    render: (content: string) => string
  ): string => {
    const escapedMarker = marker.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const contentPattern = marker === '-'
      ? `(?!&gt;)([^${escapedMarker}\\n]+?)`
      : `([^${escapedMarker}\\n]+?)`;
    const pattern = new RegExp(
      `(^|[^\\p{L}\\p{N}_-])${escapedMarker}${contentPattern}${escapedMarker}(?=$|[^\\p{L}\\p{N}_-])`,
      'gu'
    );

    return value.replace(pattern, (_match, prefix, content) => `${prefix}${render(content)}`);
  };

  const renderJiraInline = (text: string): string => {
    const safeColor = (color: string) => {
      const trimmed = color.trim();
      if (/^#[0-9a-fA-F]{3}([0-9a-fA-F]{3})?$/.test(trimmed)) return trimmed;
      if (/^rgba?\(\s*\d{1,3}\s*,\s*\d{1,3}\s*,\s*\d{1,3}(?:\s*,\s*(?:0|1|0?\.\d+))?\s*\)$/.test(trimmed)) return trimmed;
      return '';
    };

    const protectedTokens: string[] = [];
    const protectToken = (html: string) => {
      const token = `@@JIRA_INLINE_${protectedTokens.length}@@`;
      protectedTokens.push(html);
      return token;
    };
    const protectExplicitStyle = (
      value: string,
      marker: '*' | '_' | '+' | '-',
      render: (content: string) => string
    ) => {
      const escapedMarker = marker.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      return value.replace(
        new RegExp(`\\{${escapedMarker}\\}([\\s\\S]+?)\\{${escapedMarker}\\}`, 'g'),
        (_match, content) => protectToken(render(content))
      );
    };

    let html = escapeHtml(stripEmptyJiraMarkers(text));
    html = protectExplicitStyle(html, '*', (content) => `<strong>${content}</strong>`);
    html = protectExplicitStyle(html, '_', (content) => `<em>${content}</em>`);
    html = protectExplicitStyle(html, '+', (content) => `<span class="jira-underline">${content}</span>`);
    html = protectExplicitStyle(html, '-', (content) => `<span class="jira-strike">${content}</span>`);
    html = normalizeJiraWikiMarkers(html)
      .replace(/\{color:([^}]+)\}([\s\S]*?)\{color\}/g, (_match, color, content) => {
        const colorValue = safeColor(color);
        return colorValue ? `<span style="color:${colorValue}">${content}</span>` : content;
      })
      .replace(/\{\}/g, '')
      .replace(/\{\{([^}]+)\}\}/g, (_match, content) => protectToken(`<code>${content}</code>`))
      .replace(/\?\?([^?\n]+)\?\?/g, (_match, content) => protectToken(`<cite>${content}</cite>`));

    html = replaceBoundedJiraStyle(html, '*', (content) => `<strong>${content}</strong>`);
    html = replaceBoundedJiraStyle(html, '_', (content) => `<em>${content}</em>`);
    html = replaceBoundedJiraStyle(html, '+', (content) => `<span class="jira-underline">${content}</span>`);
    html = replaceBoundedJiraStyle(html, '-', (content) => `<span class="jira-strike">${content}</span>`);

    return html
      .replace(/\[([^\]|]+)\|([^\]]+)\]/g, (_match, label, url) => {
        const href = url.trim();
        if (!/^https?:\/\//i.test(href)) return label;
        return `<a href="${href}" target="_blank" rel="noopener noreferrer">${label}</a>`;
      })
      .replace(/\[~([^\]]+)\]/g, '<span class="jira-mention">@$1</span>')
      .replace(/@@JIRA_INLINE_(\d+)@@/g, (_match, index) => protectedTokens[Number(index)] || '');
  };

  const renderJiraCommentHtml = (comment: JiraComment, mentionedCurrentUser?: JiraPerson | null): string => {
    const currentUserDisplay = mentionedCurrentUser?.displayName
      ? escapeHtml(mentionedCurrentUser.displayName)
      : '';
    return renderJiraWikiToHtml(comment.displayBody || comment.body || '')
      .replace(/<span class="jira-mention">@([^<]+)<\/span>/g, (_match, display) => {
        const className = currentUserDisplay && display === currentUserDisplay
          ? 'jira-mention jira-mention-me'
          : 'jira-mention';
        return `<span class="${className}">${display}</span>`;
      });
  };

  const renderJiraDescriptionHtml = (description: string, mentionedCurrentUser?: JiraPerson | null): string => {
    const currentUserDisplay = mentionedCurrentUser?.displayName
      ? escapeHtml(mentionedCurrentUser.displayName)
      : '';
    return renderJiraWikiToHtml(description)
      .replace(/<span class="jira-mention">@([^<]+)<\/span>/g, (_match, display) => {
        const className = currentUserDisplay && display === currentUserDisplay
          ? 'jira-mention jira-mention-me'
          : 'jira-mention';
        return `<span class="${className}">${display}</span>`;
      });
  };

  const searchUsers = useCallback(async (query: string, callback: (users: JiraUserSuggestion[]) => void) => {
    if (!query || !selectedIssue) return;
    const users = await searchUsersForContext(query, {
      issueKey: selectedIssue.key,
      instanceId: selectedIssue.instance_id,
    });
    callback(users);
  }, [searchUsersForContext, selectedIssue]);

  const searchCreateMentionUsers = async (query: string, callback: (users: JiraUserSuggestion[]) => void) => {
    if (!selectedCreateMeta) {
      callback([]);
      return;
    }
    const users = await searchUsersForContext(query, {
      instanceId: selectedCreateMeta.instance_id,
      projectKey: selectedCreateMeta.project_key,
    });
    callback(users);
  };

  useEffect(() => {
    let cancelled = false;
    const timer = window.setTimeout(async () => {
      if (createAssigneeMode !== 'manual' || !selectedCreateMeta || createAssigneeSelected || createAssigneeQuery.trim().length < 1) {
        setCreateAssigneeSuggestions([]);
        setCreateAssigneeLoading(false);
        return;
      }
      setCreateAssigneeLoading(true);
      const users = await searchUsersForContext(createAssigneeQuery, {
        instanceId: selectedCreateMeta.instance_id,
        projectKey: selectedCreateMeta.project_key,
        assignable: true,
      });
      if (!cancelled) {
        setCreateAssigneeSuggestions(users);
        setCreateAssigneeLoading(false);
      }
    }, 180);
    return () => {
      cancelled = true;
      window.clearTimeout(timer);
    };
  }, [createAssigneeMode, createAssigneeQuery, createAssigneeSelected, searchUsersForContext, selectedCreateMeta]);

  useEffect(() => { 
    const fetchConfig = async () => {
      try {
        const res = await fetch(`${API_BASE}/config`);
        const data = await res.json();
        const instances: JiraInstanceInfo[] = data.instances || [];
        const storedInstanceFilter = localStorage.getItem('dashboardInstanceFilter')
          || localStorage.getItem('instanceFilter')
          || 'all';
        const nextInstanceFilter = normalizeInstanceFilter(storedInstanceFilter, instances);
        setJiraUrl(data.jira_base_url);
        setInstanceList(instances);
        if (nextInstanceFilter !== storedInstanceFilter) {
          setInstanceFilter(nextInstanceFilter);
          localStorage.setItem('dashboardInstanceFilter', nextInstanceFilter);
          localStorage.removeItem('instanceFilter');
          setProjectFilter('all');
          localStorage.setItem('projectFilter', 'all');
        }
        setTrackingProjects(data.tracking_projects || []);
        setAllowUnassignedProcessing(Boolean(data.allow_unassigned_processing));
        setAllowAllProjectWorklog(Boolean(data.allow_all_project_worklog));
        setOriginalEstimateEnabled(Boolean(data.original_estimate_enabled));
        setOriginalEstimateAuto(Boolean(data.original_estimate_auto));
        setOriginalEstimateValue(data.original_estimate_value || '');
      } catch {
        // Dashboard settings are optional; retain the current defaults.
      }
    };
    const fetchMe = async () => {
      try {
        const res = await fetch(`${API_BASE}/me`);
        const data = await res.json();
        setUserMap(data);
      } catch {
        // User metadata is optional for rendering the dashboard.
      } finally {
        setUserMapLoaded(true);
      }
    };
    fetchMe(); fetchConfig(); 
    if ('Notification' in window && Notification.permission !== 'granted' && Notification.permission !== 'denied') Notification.requestPermission(); 
  }, []);

  useEffect(() => {
    const syncDashboardSettings = () => {
      setRefreshInterval(parseInt(localStorage.getItem('refreshInterval') || '15'));
      setCacheMinutes(parseInt(localStorage.getItem('cacheMinutes') || '5'));
      setDashboardPersonRole(loadDashboardPersonRole());
      setTrackOwnActivity(localStorage.getItem(TRACK_OWN_ACTIVITY_STORAGE_KEY) !== 'false');
      setDashboardActivityTypes(loadDashboardActivityTypes());
      fetch(`${API_BASE}/config`)
        .then(res => res.json())
        .then(data => {
          setTrackingProjects(data.tracking_projects || []);
          setAllowUnassignedProcessing(Boolean(data.allow_unassigned_processing));
          setAllowAllProjectWorklog(Boolean(data.allow_all_project_worklog));
          setOriginalEstimateEnabled(Boolean(data.original_estimate_enabled));
          setOriginalEstimateAuto(Boolean(data.original_estimate_auto));
          setOriginalEstimateValue(data.original_estimate_value || '');
        })
        .catch(() => {});
    };
    window.addEventListener('storage', syncDashboardSettings);
    window.addEventListener('refreshIntervalChanged', syncDashboardSettings);
    window.addEventListener('dashboardSettingsChanged', syncDashboardSettings);
    return () => {
      window.removeEventListener('storage', syncDashboardSettings);
      window.removeEventListener('refreshIntervalChanged', syncDashboardSettings);
      window.removeEventListener('dashboardSettingsChanged', syncDashboardSettings);
    };
  }, []);

  useEffect(() => {
    if (!userMapLoaded) return;
    const initialTimer = window.setTimeout(() => {
      void fetchIssues();
    }, 0);
    const interval = window.setInterval(() => {
      // Automatic polling must let the current collection finish.
      if (!fetchIssuesAbortRef.current) void fetchIssues();
    }, refreshInterval * 1000);
    return () => {
      window.clearTimeout(initialTimer);
      window.clearInterval(interval);
      fetchIssuesAbortRef.current?.abort();
    };
  }, [datePreset, startDate, endDate, refreshInterval, userMapLoaded, fetchIssues]);

  const formatDateTime = (s: string | undefined) => {
    if (!s) return '-'; const d = new Date(s); const now = new Date(); const diff = now.getTime() - d.getTime();
    if (diff > 0 && diff < 7200000) {
      const min = Math.floor(diff/60000);
      return `${min < 1 ? '방금 전' : (min < 60 ? min+'분 전' : '1시간 전')} (${d.toLocaleString()})`;
    }
    return d.toLocaleString();
  };

  const persistReadState = async (readTargets: JiraIssue[]) => {
    if (readTargets.length === 0) return;
    try {
      const res = await fetch(`${API_BASE}/dashboard/issue-states/read`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          issues: readTargets
            .filter(issue => Boolean(issue.fields?.updated))
            .map(issue => ({
              instance_id: issue.instance_id,
              issue_key: issue.key,
              observed_updated_at: issue.fields.updated,
              read_updated_at: issue.fields.updated,
            })),
        }),
      });
      const payload = await res.json().catch(() => null) as DashboardIssueStatePayload | null;
      if (!res.ok || !payload) throw new Error('읽음 상태 저장에 실패했습니다.');
      const maps = dashboardStateMaps(payload.states);
      setReadIssues(maps.read);
      setUnreadUpdatedIssues(maps.unread);
    } catch (error) {
      console.error(error);
    }
  };

  const handleOpenDetailModal = (i: JiraIssue, preloaded?: JiraIssueDetail) => {
    if (isUnavailableIssue(i)) {
      removeFavoriteIssue(i);
      return;
    }
    const session = ++detailSessionRef.current;
    linkedIssueRequestRef.current?.abort();
    linkedIssueRequestRef.current = null;
    setLinkedIssueLoading(null);
    setLinkedIssueError('');
    setDetailSession(session);
    setIssueDetail(null);
    setTransitions([]);
    setTransitionUnavailable(false);
    setStatusChangeError('');
    // Only opening a modal replaces its contents with the initial loading screen.
    setDetailLoading(true);
    setSelectedIssue(i); setActiveModal('detail'); void fetchIssueDetail(i.key, i.instance_id, session, preloaded);
    setEditingCommentId(null);
    setAiSummary('');
    setAiSummaryMeta('');
    setAiSummaryError('');
    setAiSummaryLoading(false);
    void loadCachedAiSummary(i, session);
    setTimetracking(null);
    setOriginalEstimateMessage('');
    setOriginalEstimateError('');
    if (!preloaded) autoSubmitOriginalEstimateForIssue(i);
    const key = issueStorageKey(i);
    const readUpdated = i.fields?.updated;
    const nr = readUpdated ? { ...readIssues, [key]: readUpdated } : readIssues;
    setReadIssues(nr);
    if (unreadUpdatedIssues[key]) {
      const nextUnread = { ...unreadUpdatedIssues };
      delete nextUnread[key];
      setUnreadUpdatedIssues(nextUnread);
    }
    void persistReadState([i]);
  };

  const handleOpenLinkedIssue = async (linked: JiraLinkedIssue) => {
    if (!selectedIssue || linkedIssueRequestRef.current) return;
    const instanceId = selectedIssue.instance_id;
    const session = detailSessionRef.current;
    const controller = new AbortController();
    linkedIssueRequestRef.current = controller;
    setLinkedIssueLoading(linked.key);
    setLinkedIssueError('');
    try {
      const res = await fetch(`${API_BASE}/issues/${encodeURIComponent(linked.key)}?instance_id=${instanceId}`, { signal: controller.signal });
      const detail = await res.json() as JiraIssueDetail;
      if (controller.signal.aborted || session !== detailSessionRef.current) return;
      if (!res.ok || isUnavailableIssue(detail)) throw new Error('연결된 이슈를 불러오지 못했습니다. Jira 접근 권한과 연결 상태를 확인해주세요.');
      const known = issues.find(issue => issue.key === linked.key && issue.instance_id === instanceId)
        || favoriteIssues[`${instanceId}:${linked.key}`];
      const target: JiraIssue = {
        key: linked.key,
        instance_id: instanceId,
        fields: {
          summary: detail.fields.summary || known?.fields.summary || linked.fields?.summary || linked.key,
          status: detail.fields.status || known?.fields.status || { name: linked.fields?.status?.name || '' },
          project: detail.fields.project || known?.fields.project || { key: linked.key.split('-')[0] },
          issuetype: detail.fields.issuetype || known?.fields.issuetype || { name: linked.fields?.issuetype?.name || '' },
          assignee: known?.fields.assignee || detail.fields.assignee || null,
          reporter: known?.fields.reporter || detail.fields.reporter || null,
          updated: detail.fields.updated || known?.fields.updated || '',
          created: detail.fields.created || known?.fields.created || '',
          timetracking: detail.fields.timetracking || known?.fields.timetracking,
        },
      };
      handleOpenDetailModal(target, detail);
    } catch (error) {
      if (!controller.signal.aborted && session === detailSessionRef.current) setLinkedIssueError(errorMessage(error, '연결된 이슈를 불러오지 못했습니다.'));
    } finally {
      if (linkedIssueRequestRef.current === controller) {
        linkedIssueRequestRef.current = null;
        setLinkedIssueLoading(null);
      }
    }
  };

  const issuesByKey = new Map(issues.map(issue => [issueStorageKey(issue), issue]));
  const displaySourceIssues = [
    ...Object.values(favoriteIssues).map(issue => issuesByKey.get(issueStorageKey(issue)) || issue),
    ...issues.filter(issue => !favoriteIssues[issueStorageKey(issue)])
  ];
  const visibleIssuesForFilter = instanceFilter === 'all' ? issues : issues.filter(i => i.instance_id.toString() === instanceFilter);
  const projectList = Array.from(new Set(visibleIssuesForFilter.map(i => i.fields?.project?.key).filter(Boolean))).sort();
  const matchesIssueSearch = (issue: JiraIssue) => {
    const query = searchQuery.trim().toLowerCase();
    if (!query) return true;
    const parsedExpression = parseIssueSearchExpression(query);
    const assignee = issue.fields?.assignee;
    const reporter = issue.fields?.reporter;
    const components = issue.fields?.components || [];
    const labels = issue.fields?.labels || [];
    if (parsedExpression) {
      const fieldValues: Record<IssueSearchField, string[]> = {
        ticket: [issue.key || ''],
        summary: [issue.fields?.summary || ''],
        assignee: jiraPersonSearchValues(assignee),
        reporter: jiraPersonSearchValues(reporter),
        component: components.map(component => component.name).filter(Boolean),
        label: labels,
      };
      const matchesQuery = (parsedQuery: ParsedIssueSearchQuery) => {
        const values = fieldValues[parsedQuery.field].map(value => value.toLowerCase());
        const matched = parsedQuery.operator === '='
          ? values.some(value => value === parsedQuery.value)
          : values.some(value => value.includes(parsedQuery.value));
        return parsedQuery.negated ? !matched : matched;
      };
      return parsedExpression.orGroups.some(group => group.every(matchesQuery));
    }
    const haystack = [
      issue.key,
      issue.fields?.summary,
      assignee?.displayName,
      assignee?.name,
      assignee?.key,
      assignee?.accountId,
      reporter?.displayName,
      reporter?.name,
      reporter?.key,
      reporter?.accountId,
      ...components.map(component => component.name),
      ...labels,
    ].filter(Boolean).join(' ').toLowerCase();
    return haystack.includes(query);
  };
  const filteredIssues = displaySourceIssues.filter(i => {
    const isLocallyClosed = Boolean(jiraautoClosedIssues[issueStorageKey(i)] || i.jiraauto_closed);
    if (isLocallyClosed && !includeClosed) return false;
    if (isFavoriteIssue(i)) return matchesIssueSearch(i);
    const pMatch = projectFilter === 'all' || i.fields?.project?.key === projectFilter;
    const iMatch = instanceFilter === 'all' || i.instance_id.toString() === instanceFilter;
    const sMatch = matchesIssueSearch(i);
    return pMatch && iMatch && sMatch;
  });

  const activeSearchClause = searchQuery.split(/\s+(?:AND|OR)\s+/i).at(-1)?.trim() || '';
  const searchClauseIsFieldOnly = /^(티켓번호|티켓|제목|담당자|보고자|컴포넌트|레이블)$/i.test(activeSearchClause);
  const searchClauseNeedsValue = /^(티켓번호|티켓|제목|담당자|보고자|컴포넌트|레이블)\s*(!?=|!~|~)\s*$/i.test(activeSearchClause);
  const completedSearchClause = parseIssueSearchQuery(activeSearchClause);
  const searchHelpMode: 'field' | 'operator' | 'value' | 'connector' = !activeSearchClause
    ? 'field'
    : searchClauseIsFieldOnly
      ? 'operator'
      : searchClauseNeedsValue
        ? 'value'
        : completedSearchClause
          ? 'connector'
          : 'field';
  const searchHelpItems = searchHelpMode === 'operator'
    ? ISSUE_SEARCH_OPERATORS
    : searchHelpMode === 'connector'
      ? ISSUE_SEARCH_CONNECTORS
      : searchHelpMode === 'field'
        ? ISSUE_SEARCH_FIELDS
        : [];
  const searchHelpTitle = searchHelpMode === 'field'
    ? '검색 필드를 선택하세요'
    : searchHelpMode === 'operator'
      ? '연산자를 선택하세요'
      : searchHelpMode === 'connector'
        ? '조건을 더 추가할 수 있습니다'
        : '검색할 값을 입력하세요';
  const applySearchHelpItem = (token: string) => {
    let nextValue: string;
    if (searchHelpMode === 'field') {
      nextValue = activeSearchClause ? `${token} ` : `${searchQuery}${token} `;
    } else if (searchHelpMode === 'operator') {
      nextValue = `${searchQuery.trimEnd()} ${token} `;
    } else {
      nextValue = `${searchQuery.trim()} ${token} `;
    }
    setSearchQuery(nextValue);
    localStorage.setItem('dashboardSearchQuery', nextValue);
  };
  const normalizedCurrentSearchQuery = normalizeFavoriteSearchQuery(searchQuery);
  const isCurrentSearchQueryFavorite = Boolean(
    normalizedCurrentSearchQuery
    && favoriteSearchQueries.some(value => normalizeFavoriteSearchQuery(value) === normalizedCurrentSearchQuery)
  );
  const persistFavoriteSearchQueries = (nextQueries: string[]) => {
    setFavoriteSearchQueries(nextQueries);
    localStorage.setItem(FAVORITE_SEARCH_QUERIES_STORAGE_KEY, JSON.stringify(nextQueries));
    window.dispatchEvent(new Event('jiraQueryFavoritesChanged'));
  };
  const removeFavoriteSearchQuery = (query: string) => {
    const normalizedQuery = normalizeFavoriteSearchQuery(query);
    persistFavoriteSearchQueries(
      favoriteSearchQueries.filter(value => normalizeFavoriteSearchQuery(value) !== normalizedQuery)
    );
    setToastMessage('쿼리 즐겨찾기가 삭제되었습니다');
  };
  const toggleFavoriteSearchQuery = () => {
    const query = searchQuery.trim();
    if (!query) return;
    const normalizedQuery = normalizeFavoriteSearchQuery(query);
    const existingIndex = favoriteSearchQueries.findIndex(
      value => normalizeFavoriteSearchQuery(value) === normalizedQuery
    );
    if (existingIndex >= 0) {
      removeFavoriteSearchQuery(favoriteSearchQueries[existingIndex]);
      return;
    }
    persistFavoriteSearchQueries([query, ...favoriteSearchQueries]);
    setToastMessage('쿼리 즐겨찾기가 추가되었습니다');
  };
  const applyFavoriteSearchQuery = (query: string) => {
    setSearchQuery(query);
    localStorage.setItem('dashboardSearchQuery', query);
    setSearchHelpOpen(false);
  };

  const isUnreadIssue = (issue: JiraIssue) => {
    const key = issueStorageKey(issue);
    return Boolean(unreadUpdatedIssues[key] && !isReadUpdate(readIssues[key], unreadUpdatedIssues[key]));
  };
  const assignedIssues = filteredIssues.filter(isIssueAssignedToMe);
  const mentionedIssues = filteredIssues.filter(isIssueMentionedForMe);
  const reportedIssues = filteredIssues.filter(isIssueReportedByMe);
  const assignedUnreadCount = assignedIssues.filter(isUnreadIssue).length;
  const mentionedUnreadCount = mentionedIssues.filter(isUnreadIssue).length;
  const reportedUnreadCount = reportedIssues.filter(isUnreadIssue).length;
  const hasUnreadVisibleIssue = filteredIssues.some(isUnreadIssue);

  const markVisibleIssuesAsRead = () => {
    const nextRead = { ...readIssues };
    const nextUnread = { ...unreadUpdatedIssues };
    const readTargets: JiraIssue[] = [];
    let changed = false;

    filteredIssues.forEach(issue => {
      const key = issueStorageKey(issue);
      const unreadUpdated = unreadUpdatedIssues[key];
      if (!unreadUpdated) return;

      const readUpdated = issue.fields?.updated || unreadUpdated;
      nextRead[key] = readUpdated;
      delete nextUnread[key];
      readTargets.push(issue);
      changed = true;
    });

    if (!changed) return;
    setReadIssues(nextRead);
    setUnreadUpdatedIssues(nextUnread);
    void persistReadState(readTargets);
  };

  const sortIssues = (a: JiraIssue, b: JiraIssue) => {
    const favoriteDiff = Number(isFavoriteIssue(b)) - Number(isFavoriteIssue(a));
    if (favoriteDiff !== 0) return favoriteDiff;
    const aUpdated = isUnreadIssue(a);
    const bUpdated = isUnreadIssue(b);
    if (aUpdated && !bUpdated) return -1;
    if (!aUpdated && bUpdated) return 1;
    const dateA = new Date(a.fields?.updated || a.fields?.created || 0).getTime();
    const dateB = new Date(b.fields?.updated || b.fields?.created || 0).getTime();
    return dateB - dateA;
  };

  const renderIssueCard = (issue: JiraIssue, type: 'assigned' | 'mentioned' | 'reported') => {
    const isUpdated = isUnreadIssue(issue);
    const instName = instanceList.find(ins => ins.id === issue.instance_id)?.name;
    const isFavorite = isFavoriteIssue(issue);
    const isUnavailable = isUnavailableIssue(issue);
    return (
      <JiraIssueCard
        key={`${issue.instance_id}_${issue.key}`}
        issue={issue}
        type={type}
        isUpdated={isUpdated}
        instanceName={instName}
        showInstanceName={instanceList.length > 1}
        isFavorite={isFavorite}
        isUnavailable={isUnavailable}
        isClosed={Boolean(jiraautoClosedIssues[issueStorageKey(issue)] || issue.jiraauto_closed)}
        personRole={dashboardPersonRole}
        onOpen={handleIssueCardOpen}
        onToggleFavorite={handleIssueCardFavoriteToggle}
      />
    );
  };

  useEffect(() => {
    openIssueCardRef.current = handleOpenDetailModal;
    toggleFavoriteCardRef.current = toggleFavoriteIssue;
  });


  const contextValue = {
    activeModal,
    activeSearchClause,
    aiSummary,
    aiSummaryError,
    aiSummaryLoading,
    aiSummaryMeta,
    allowAllProjectWorklog,
    allowUnassignedProcessing,
    applyCreateDefaults,
    applyFavoriteSearchQuery,
    applySearchHelpItem,
    assignedIssues,
    assignedUnreadCount,
    autoSubmitOriginalEstimateForIssue,
    availableTransitions,
    cacheMinutes,
    canUseManualOriginalEstimate,
    canUseOriginalEstimateValue,
    canUseWorklogPanel,
    closeCreateIssueModal,
    completedSearchClause,
    convertMentionsToJiraFormat,
    createAssigneeLoading,
    createAssigneeMode,
    createAssigneeQuery,
    createAssigneeSelected,
    createAssigneeSuggestions,
    createAssigneeValue,
    createComponent,
    createDescription,
    createError,
    createIssueType,
    createMetadata,
    createMetadataLoading,
    createModalOpen,
    createModalPointerStartedOnOverlayRef,
    createSelectedProject,
    createSubmitting,
    createSummary,
    currentCreateUser,
    currentSelectedUser,
    currentStatusIssue,
    dashboardActivityTypes,
    dashboardPersonRole,
    datePreset,
    detailError,
    detailLoading,
    detailRequestRef,
    detailSession,
    detailSessionRef,
    displaySourceIssues,
    editingCommentId,
    endDate,
    escapeHtml,
    extractJiraErrorMessage,
    favoriteIssues,
    favoriteSearchQueries,
    fetchIssueDetail,
    fetchIssues,
    fetchIssuesAbortRef,
    filteredIssues,
    formatAiSummaryMeta,
    formatDateTime,
    generateAiSummary,
    handleEndDateChange,
    handleIssueCardFavoriteToggle,
    handleIssueCardOpen,
    handleOpenDetailModal,
    handleOpenLinkedIssue,
    handleStartDateChange,
    handleStatusChange,
    hasUnreadVisibleIssue,
    includeClosed,
    instanceFilter,
    instanceList,
    isCurrentSearchQueryFavorite,
    isFavoriteIssue,
    isIssueAssignedToMe,
    isIssueChangeByCurrentUser,
    isIssueMentionedForMe,
    isIssueReportedByMe,
    isOriginalEstimateTarget,
    isSelectedIssueAssignedToMe,
    isSelectedIssueTrackedProject,
    isUnreadIssue,
    issueDetail,
    issues,
    issuesByKey,
    jiraUrl,
    jiraautoClosedIssues,
    lastUpdated,
    linkedIssueError,
    linkedIssueLoading,
    linkedIssueRequestRef,
    loadCachedAiSummary,
    loadCreateMetadata,
    loading,
    markVisibleIssuesAsRead,
    matchesIssueSearch,
    mentionedIssues,
    mentionedUnreadCount,
    metaKey,
    modalPointerStartedOnOverlayRef,
    normalizeJiraWikiMarkers,
    normalizedCurrentSearchQuery,
    normalizedTrackingProjects,
    openCreateIssueModal,
    openIssueCardRef,
    originalEstimateAuto,
    originalEstimateEnabled,
    originalEstimateError,
    originalEstimateMessage,
    originalEstimateSubmitting,
    originalEstimateValue,
    parsedOriginalEstimate,
    persistFavoriteSearchQueries,
    persistFavorites,
    persistReadState,
    projectFilter,
    projectList,
    readIssues,
    refreshInterval,
    refreshTimeTrackingSnapshot,
    removeFavoriteIssue,
    removeFavoriteSearchQuery,
    renderIssueCard,
    renderJiraCommentHtml,
    renderJiraDescriptionHtml,
    renderJiraInline,
    renderJiraTableCell,
    renderJiraWikiToHtml,
    replaceBoundedJiraStyle,
    reportedIssues,
    reportedUnreadCount,
    resetCreateIssueForm,
    searchClauseIsFieldOnly,
    searchClauseNeedsValue,
    searchCreateMentionUsers,
    searchHelpItems,
    searchHelpMode,
    searchHelpOpen,
    searchHelpTitle,
    searchInputRef,
    searchQuery,
    searchUsers,
    searchUsersForContext,
    selectedAssignee,
    selectedCreateMeta,
    selectedHasOriginalEstimate,
    selectedIssue,
    selectedIssueProjectKey,
    setActiveModal,
    setAiSummary,
    setAiSummaryError,
    setAiSummaryLoading,
    setAiSummaryMeta,
    setAllowAllProjectWorklog,
    setAllowUnassignedProcessing,
    setCacheMinutes,
    setCreateAssigneeLoading,
    setCreateAssigneeMode,
    setCreateAssigneeQuery,
    setCreateAssigneeSelected,
    setCreateAssigneeSuggestions,
    setCreateComponent,
    setCreateDescription,
    setCreateError,
    setCreateIssueType,
    setCreateMetadata,
    setCreateMetadataLoading,
    setCreateModalOpen,
    setCreateSelectedProject,
    setCreateSubmitting,
    setCreateSummary,
    setDashboardActivityTypes,
    setDashboardPersonRole,
    setDatePreset,
    setDetailError,
    setDetailLoading,
    setDetailSession,
    setEditingCommentId,
    setEndDate,
    setFavoriteIssues,
    setFavoriteSearchQueries,
    setIncludeClosed,
    setInstanceFilter,
    setInstanceList,
    setIssueDetail,
    setIssues,
    setJiraUrl,
    setJiraautoClosedIssues,
    setLastUpdated,
    setLinkedIssueError,
    setLinkedIssueLoading,
    setLoading,
    setOriginalEstimateAuto,
    setOriginalEstimateEnabled,
    setOriginalEstimateError,
    setOriginalEstimateMessage,
    setOriginalEstimateSubmitting,
    setOriginalEstimateValue,
    setProjectFilter,
    setReadIssues,
    setRefreshInterval,
    setSearchHelpOpen,
    setSearchQuery,
    setSelectedIssue,
    setStartDate,
    setStatusChangeError,
    setStatusChangeSubmitting,
    setTimetracking,
    setToastMessage,
    setTrackOwnActivity,
    setTrackingProjects,
    setTransitionUnavailable,
    setTransitions,
    setUnreadUpdatedIssues,
    setUserMap,
    setUserMapLoaded,
    sortIssues,
    startDate,
    statusChangeError,
    statusChangeSubmitting,
    stripEmptyJiraMarkers,
    submitCreateIssue,
    submitOriginalEstimate,
    timetracking,
    toastMessage,
    toggleFavoriteCardRef,
    toggleFavoriteIssue,
    toggleFavoriteSearchQuery,
    trackOwnActivity,
    trackingProjects,
    transitionUnavailable,
    transitions,
    unreadUpdatedIssues,
    updateJiraautoClosedState,
    userMap,
    userMapLoaded,
    visibleIssuesForFilter
  };

  return <DashboardContext.Provider value={contextValue}>{children}</DashboardContext.Provider>;
}
