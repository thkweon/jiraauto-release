import type { TourDefinition } from '../types';

export const bulkTransitionTour: TourDefinition = {
  id: 'bulk-transition',
  version: 1,
  steps: [
    {
      target: '[data-tour="bulk-page"]',
      title: '일괄 변경',
      description: '내 담당 Jira 이슈를 여러 개 선택해 같은 상태로 한 번에 변경할 수 있습니다.',
      side: 'top',
    },
    {
      target: '[data-tour="bulk-issue-list"]',
      title: '이슈 선택',
      description: '변경할 이슈를 체크하세요. 표의 첫 체크박스를 선택하면 현재 목록 전체가 선택됩니다.',
      side: 'top',
    },
    {
      target: '[data-tour="bulk-transition-select"]',
      title: '새 상태 선택',
      description: '이슈를 선택한 뒤 적용할 수 있는 Jira 상태를 선택하세요.',
      side: 'bottom',
    },
    {
      target: '[data-tour="bulk-run"]',
      title: '변경 실행',
      description: '선택한 이슈 수를 확인한 뒤 버튼을 누르면 상태 변경이 진행됩니다.',
      side: 'bottom',
    },
    {
      target: '[data-tour="bulk-refresh"]',
      title: '목록 갱신',
      description: 'Jira의 최신 이슈 상태를 다시 불러올 수 있습니다.',
      side: 'left',
    },
  ],
};
