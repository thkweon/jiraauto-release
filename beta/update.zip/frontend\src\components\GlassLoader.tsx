import type { ReactNode } from 'react';
import '../TeamStyles.css';

interface GlassLoaderProps {
  /** 굵게 표시되는 제목 */
  title?: ReactNode;
  /** 제목 아래 보조 문구 */
  message?: ReactNode;
  /** 0~100. 생략하면 indeterminate 바로 표시 */
  progress?: number;
  /** 하단에 표시할 스켈레톤 카드 개수 (0이면 숨김) */
  skeletonCount?: number;
  /** glass-panel 래퍼 없이 내용만 렌더링 (테이블 셀 등에 삽입할 때) */
  bare?: boolean;
  style?: React.CSSProperties;
}

export default function GlassLoader({
  title = '데이터를 불러오는 중입니다',
  message,
  progress,
  skeletonCount = 0,
  bare = false,
  style,
}: GlassLoaderProps) {
  const determinate = typeof progress === 'number' && Number.isFinite(progress);
  const pct = determinate ? Math.min(100, Math.max(0, progress as number)) : 0;

  const body = (
    <div className="glass-loader" role="status" aria-live="polite" aria-busy="true">
      <div className="glass-loader-ring" aria-hidden="true" />
      <div className="glass-loader-title">
        {title}
        {!determinate && <span className="ai-loading-dots" aria-hidden="true" />}
      </div>
      {message && <div className="glass-loader-message">{message}</div>}
      <div
        className={`glass-loader-bar${determinate ? '' : ' indeterminate'}`}
        role="progressbar"
        aria-valuemin={0}
        aria-valuemax={100}
        aria-valuenow={determinate ? pct : undefined}
      >
        <div className="glass-loader-bar-fill" style={determinate ? { width: `${pct}%` } : undefined} />
      </div>
      {determinate && <div className="glass-loader-percent">{pct}%</div>}
    </div>
  );

  if (bare) return <div style={style}>{body}</div>;

  return (
    <div style={style}>
      <div className="glass-panel" style={{ padding: 0 }}>{body}</div>
      {skeletonCount > 0 && (
        <div className="glass-loader-skeleton-grid" aria-hidden="true">
          {Array.from({ length: skeletonCount }).map((_, i) => (
            <div key={i} className="glass-panel glass-loader-skeleton">
              <div className="sk-line" />
              <div className="sk-block" />
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
