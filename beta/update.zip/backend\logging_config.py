from __future__ import annotations

import json
import logging
import os
from logging.handlers import TimedRotatingFileHandler
from pathlib import Path
from typing import Any

from update_manifest import is_valid_semver


LOG_ENABLED_ENV = "JIRAAUTO_LOG_ENABLED"
DEFAULT_BACKUP_COUNT = 5
APP_HANDLER_NAME = "jiraauto.app.file"
SERVER_HANDLER_NAME = "jiraauto.server.file"


def _env_bool(name: str, default: bool = True) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().upper() not in {"N", "NO", "FALSE", "0", "OFF"}


def installed_release() -> dict[str, str]:
    root = Path(__file__).resolve().parent.parent
    for filename in ("installed-version.json", "version.json"):
        path = root / filename
        try:
            with path.open("r", encoding="utf-8-sig") as handle:
                data: Any = json.load(handle)
        except (OSError, ValueError, json.JSONDecodeError):
            continue
        if not isinstance(data, dict):
            continue
        version = str(data.get("version") or "").strip().removeprefix("v")
        if not is_valid_semver(version):
            continue
        channel = data.get("channel")
        if channel not in {"stable", "beta"}:
            channel = "beta" if "-beta." in version else "stable"
        return {"version": version, "channel": channel}
    return {"version": "0.0.0", "channel": "stable"}


def logging_status(user_enabled: bool | None = None) -> dict[str, Any]:
    if user_enabled is None:
        user_enabled = _env_bool(LOG_ENABLED_ENV, True)
    release = installed_release()
    forced = release["channel"] == "beta"
    return {
        "installed_version": release["version"],
        "installed_channel": release["channel"],
        "user_enabled": bool(user_enabled),
        "effective_enabled": forced or bool(user_enabled),
        "forced": forced,
    }


class ArchiveTimedRotatingFileHandler(TimedRotatingFileHandler):
    """Rotate at local midnight and keep dated files in a shared archive folder."""

    def __init__(self, filename: str, archive_dir: str, backup_count: int) -> None:
        self.archive_dir = Path(archive_dir)
        self.archive_dir.mkdir(parents=True, exist_ok=True)
        self.retention_count = max(0, backup_count)
        super().__init__(
            filename,
            when="midnight",
            interval=1,
            backupCount=0,
            encoding="utf-8",
            delay=True,
        )
        self._prune_archives()

    def rotation_filename(self, default_name: str) -> str:
        suffix = Path(default_name).name.removeprefix(f"{Path(self.baseFilename).name}.")
        base = Path(self.baseFilename)
        return str(self.archive_dir / f"{base.stem}_{suffix}{base.suffix}")

    def doRollover(self) -> None:
        super().doRollover()
        self._prune_archives()

    def _prune_archives(self) -> None:
        base = Path(self.baseFilename)
        candidates = {
            path
            for pattern in (f"{base.stem}_*", f"{base.name}_*")
            for path in self.archive_dir.glob(pattern)
            if path.is_file()
        }
        archives = sorted(
            candidates,
            key=lambda path: (path.stat().st_mtime, path.name),
            reverse=True,
        )
        for path in archives[self.retention_count :]:
            try:
                path.unlink()
            except OSError:
                pass


class StripAccessQueryFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        if record.name == "uvicorn.access" and isinstance(record.args, tuple) and len(record.args) >= 3:
            args = list(record.args)
            args[2] = str(args[2]).partition("?")[0]
            record.args = tuple(args)
        return True


def _close_named_file_handlers() -> None:
    handlers_to_close: set[logging.Handler] = set()
    for logger_name in ("", "uvicorn", "uvicorn.error", "uvicorn.access"):
        target = logging.getLogger(logger_name)
        for handler in list(target.handlers):
            if getattr(handler, "name", None) in {APP_HANDLER_NAME, SERVER_HANDLER_NAME}:
                target.removeHandler(handler)
                handlers_to_close.add(handler)
    for handler in handlers_to_close:
        handler.close()


def configure_logging(enabled: bool | None = None) -> dict[str, Any]:
    status = logging_status() if enabled is None else logging_status(enabled)
    _close_named_file_handlers()

    formatter = logging.Formatter("%(asctime)s [%(levelname)s] %(message)s")
    root_logger = logging.getLogger()
    console = next(
        (handler for handler in root_logger.handlers if getattr(handler, "name", None) == "jiraauto.console"),
        None,
    )
    if console is None:
        console = logging.StreamHandler()
        console.name = "jiraauto.console"
        console.setLevel(getattr(logging, os.getenv("LOG_CONSOLE_LEVEL", "WARNING").upper(), logging.WARNING))
        console.setFormatter(formatter)
        root_logger.addHandler(console)

    root_logger.setLevel(logging.INFO)
    logging.getLogger("httpx").setLevel(logging.WARNING)

    for name in ("uvicorn", "uvicorn.error", "uvicorn.access"):
        target = logging.getLogger(name)
        target.setLevel(logging.INFO)
        target.propagate = False
        target.handlers.clear()
        target.addHandler(console)
    access_logger = logging.getLogger("uvicorn.access")
    access_logger.filters = [
        current_filter
        for current_filter in access_logger.filters
        if not isinstance(current_filter, StripAccessQueryFilter)
    ]
    access_logger.addFilter(StripAccessQueryFilter())

    if status["effective_enabled"]:
        log_dir = Path(os.getenv("LOG_DIR", str(Path(__file__).resolve().parent / "logs")))
        log_dir.mkdir(parents=True, exist_ok=True)
        archive_dir = log_dir / "archive"
        backup_count = max(0, int(os.getenv("LOG_BACKUP_COUNT", str(DEFAULT_BACKUP_COUNT))))

        app_handler = ArchiveTimedRotatingFileHandler(
            os.getenv("LOG_FILE", str(log_dir / "app.log")), str(archive_dir), backup_count
        )
        app_handler.name = APP_HANDLER_NAME
        app_handler.setLevel(logging.INFO)
        app_handler.setFormatter(formatter)
        root_logger.addHandler(app_handler)

        server_handler = ArchiveTimedRotatingFileHandler(
            str(log_dir / "backend_start.log"), str(archive_dir), backup_count
        )
        server_handler.name = SERVER_HANDLER_NAME
        server_handler.setLevel(logging.INFO)
        server_handler.setFormatter(formatter)
        for name in ("uvicorn", "uvicorn.error", "uvicorn.access"):
            logging.getLogger(name).addHandler(server_handler)

    return status
