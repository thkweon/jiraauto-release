import type { LockMethod } from './screenLock';

export interface Config {
  enabled: boolean;
  method: LockMethod;
  idleSeconds: number;
  blurSeconds: number;
  showLines: boolean;
  resetAfter: number;
  notifyWhileLocked: boolean;
  otp: boolean;
  failures?: number;
  retryAt?: number;
}

export const defaults: Config = { enabled: false, method: 'pin6', idleSeconds: 300, blurSeconds: -1, showLines: false, resetAfter: 0, notifyWhileLocked: false, otp: false };

export async function request(path = '', body?: object, method = 'POST') {
  const response = await fetch('http://localhost:8000/api/screen-lock' + path, body ? {
    method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body),
  } : undefined);
  const data = await response.json();
  if (!response.ok) throw new Error(typeof data.detail === 'string' ? data.detail : '잠금 설정을 확인할 수 없습니다.');
  return data;
}

const SESSION_KEY = 'screenLockSession';
export const getSession = () => sessionStorage.getItem(SESSION_KEY) ?? '';
export const setSession = (token: string) => sessionStorage.setItem(SESSION_KEY, token);
export function dropSession() {
  const session = getSession();
  if (!session) return;
  sessionStorage.removeItem(SESSION_KEY);
  void request('/lock', { session }).catch(() => {});
}

export function handleReset() {
  localStorage.setItem('screenLockReset', String(Date.now()));
  window.location.assign('/activation');
}
