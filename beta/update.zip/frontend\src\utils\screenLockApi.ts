import type { LockMethod } from './screenLock';

export interface Config {
  enabled: boolean;
  method: LockMethod;
  idleSeconds: number;
  blurSeconds: number;
  showLines: boolean;
  resetAfter: number;
  failures?: number;
  retryAt?: number;
}

export const defaults: Config = { enabled: false, method: 'pin6', idleSeconds: 300, blurSeconds: -1, showLines: false, resetAfter: 0 };

export async function request(path = '', body?: object, method = 'POST') {
  const response = await fetch('http://localhost:8000/api/screen-lock' + path, body ? {
    method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body),
  } : undefined);
  const data = await response.json();
  if (!response.ok) throw new Error(typeof data.detail === 'string' ? data.detail : '잠금 설정을 확인할 수 없습니다.');
  return data;
}

export function handleReset() {
  localStorage.setItem('screenLockReset', String(Date.now()));
  window.location.assign('/activation');
}
