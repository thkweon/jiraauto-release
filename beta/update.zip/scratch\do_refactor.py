import re
import os

path = 'frontend/src/pages/DashboardPage.tsx'
with open(path, 'r', encoding='utf-8') as f:
    content = f.read()

lines = content.split('\n')

start_idx = -1
for i, line in enumerate(lines):
    if line.startswith('export default function DashboardPage() {'):
        start_idx = i
        break

end_idx = -1
for i in range(start_idx, len(lines)):
    if lines[i].startswith('  return (') and lines[i+1].strip().startswith('<div className="dashboard-glass-container">'):
        end_idx = i
        break

imports_and_helpers = '\n'.join(lines[:start_idx])
logic_code = '\n'.join(lines[start_idx+1:end_idx])
jsx_code = '\n'.join(lines[end_idx:])

# Find variables
vars_to_export = set()
for m in re.finditer(r'^  (?:const|let)\s+\[(.*?)\]\s*=', logic_code, re.MULTILINE):
    parts = m.group(1).split(',')
    for p in parts:
        p = p.strip()
        if p: vars_to_export.add(p)
for m in re.finditer(r'^  (?:const|let)\s+([a-zA-Z0-9_]+)\s*[:=]', logic_code, re.MULTILINE):
    vars_to_export.add(m.group(1))
for m in re.finditer(r'^  function\s+([a-zA-Z0-9_]+)\s*\(', logic_code, re.MULTILINE):
    vars_to_export.add(m.group(1))

vars_list = sorted(list(vars_to_export))
value_obj = '{\n' + ',\n'.join(['    ' + v for v in vars_list]) + '\n  }'
destructure_str = '  const {\n' + ',\n'.join(['    ' + v for v in vars_list]) + '\n  } = useDashboardContext();\n'

context_code = f"""{imports_and_helpers}

import {{ ReactNode }} from 'react';

const DashboardContext = React.createContext<any>(null);

export function useDashboardContext() {{
  const context = React.useContext(DashboardContext);
  if (!context) throw new Error('useDashboardContext must be used within DashboardProvider');
  return context;
}}

export function DashboardProvider({{ children }}: {{ children: ReactNode }}) {{
{logic_code}

  const contextValue = {value_obj};

  return <DashboardContext.Provider value={{contextValue}}>{{children}}</DashboardContext.Provider>;
}}
"""

page_code = f"""{imports_and_helpers}
import {{ useDashboardContext }} from '../contexts/DashboardContext';

export default function DashboardPage() {{
{destructure_str}
{jsx_code}
"""

with open('frontend/src/contexts/DashboardContext.tsx', 'w', encoding='utf-8') as f:
    f.write(context_code)

with open(path, 'w', encoding='utf-8') as f:
    f.write(page_code)

print("Refactor complete.")
