import { createTour } from './createTour';
import { dashboardTour } from './tours/dashboard';
import { bulkTransitionTour } from './tours/bulkTransition';
import { overviewTour } from './tours/overview';
import { teamDashboardTour } from './tours/teamDashboard';
import { teamNoticesLeaderTour, teamNoticesMemberTour } from './tours/teamNotices';
import { teamBoardTour } from './tours/teamBoard';
import { teamReportLeaderTour, teamReportMemberTour } from './tours/teamReport';
import { teamInfoTour } from './tours/teamInfo';
import { teamAnalyticsTour } from './tours/teamAnalytics';
import { teamStartTour } from './tours/teamStart';
import { teamManageTour } from './tours/teamManage';
import { settingsTour } from './tours/settings';

export const overviewTourController = createTour(overviewTour);

const routeTours = {
  '/': createTour(dashboardTour),
  '/bulk': createTour(bulkTransitionTour),
  '/team/analytics': createTour(teamAnalyticsTour),
  '/join': createTour(teamStartTour),
  '/team-manage': createTour(teamManageTour),
  '/settings': createTour(settingsTour),
} as const;

const teamTours = {
  dashboard: createTour(teamDashboardTour),
  noticesLeader: createTour(teamNoticesLeaderTour),
  noticesMember: createTour(teamNoticesMemberTour),
  board: createTour(teamBoardTour),
  reportLeader: createTour(teamReportLeaderTour),
  reportMember: createTour(teamReportMemberTour),
  infoMember: createTour(teamInfoTour),
};

export const getTourForPath = (pathname: string) => {
  const directTour = routeTours[pathname as keyof typeof routeTours];
  if (directTour) return directTour;

  const isLeader = localStorage.getItem('teamRole') === 'leader';
  if (pathname === '/team') return teamTours.dashboard;
  if (pathname === '/team/notices') return isLeader ? teamTours.noticesLeader : teamTours.noticesMember;
  if (pathname === '/team/board') return teamTours.board;
  if (pathname === '/team/report') return isLeader ? teamTours.reportLeader : teamTours.reportMember;
  if (pathname === '/team-info' && !isLeader) return teamTours.infoMember;
  return undefined;
};

export const destroyAllTours = () => {
  overviewTourController.destroy();
  Object.values(routeTours).forEach(tour => tour.destroy());
  Object.values(teamTours).forEach(tour => tour.destroy());
};
