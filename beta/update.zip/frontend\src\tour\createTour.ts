import { driver, type DriveStep, type Driver, type PopoverDOM } from 'driver.js';
import type { StartTourOptions, TourDefinition, TourStepDefinition } from './types';
import { isTourCompleted, markTourCompleted } from './storage';

const isVisible = (element: Element) => {
  const htmlElement = element as HTMLElement;
  const style = window.getComputedStyle(htmlElement);
  const rect = htmlElement.getBoundingClientRect();
  return style.display !== 'none'
    && style.visibility !== 'hidden'
    && rect.width > 0
    && rect.height > 0;
};

const visibleSteps = (steps: TourStepDefinition[]) => steps.filter(step => {
  const element = document.querySelector(step.target);
  return Boolean(element && isVisible(element));
});

const renderAccessiblePopover = (popover: PopoverDOM) => {
  popover.wrapper.setAttribute('role', 'dialog');
  popover.wrapper.setAttribute('aria-modal', 'true');
  popover.closeButton.setAttribute('aria-label', '안내 닫기');
  popover.previousButton.setAttribute('aria-label', '이전 안내 단계');
  popover.nextButton.setAttribute('aria-label', '다음 안내 단계');
  window.requestAnimationFrame(() => popover.nextButton.focus());
};

export const createTour = (definition: TourDefinition) => {
  let instance: Driver | null = null;
  let interrupted = false;
  let finishCallback: (() => void) | undefined;
  let keydownHandler: ((event: KeyboardEvent) => void) | null = null;
  let keyupHandler: ((event: KeyboardEvent) => void) | null = null;
  let enterHeld = false;
  let transitionLocked = false;
  let transitionTimer: number | null = null;

  const clearTransitionLock = () => {
    if (transitionTimer !== null) window.clearTimeout(transitionTimer);
    transitionTimer = null;
    transitionLocked = false;
  };

  const runStepTransition = (action: () => void, duration: number) => {
    if (transitionLocked) return;
    transitionLocked = true;
    action();
    transitionTimer = window.setTimeout(clearTransitionLock, duration + 40);
  };

  const removeKeyboardHandler = () => {
    if (keydownHandler) document.removeEventListener('keydown', keydownHandler);
    if (keyupHandler) document.removeEventListener('keyup', keyupHandler);
    keydownHandler = null;
    keyupHandler = null;
    enterHeld = false;
  };

  const finish = () => {
    removeKeyboardHandler();
    clearTransitionLock();
    if (!interrupted) markTourCompleted(definition.id, definition.version);
    const callback = finishCallback;
    finishCallback = undefined;
    instance = null;
    if (!interrupted) callback?.();
    interrupted = false;
  };

  const start = ({ force = false, onFinish }: StartTourOptions = {}) => {
    if (instance?.isActive()) instance.destroy();
    if (!force && isTourCompleted(definition.id, definition.version)) return false;

    const availableSteps = visibleSteps(definition.steps);
    if (availableSteps.length === 0) return false;

    interrupted = false;
    finishCallback = onFinish;
    clearTransitionLock();
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const transitionDuration = prefersReducedMotion ? 0 : 400;
    const steps: DriveStep[] = availableSteps.map((step, index) => ({
      element: step.target,
      popover: {
        title: step.title,
        description: step.description,
        side: step.side || 'bottom',
        align: step.align || 'center',
        showButtons: index === 0 ? ['next', 'close'] : ['previous', 'next', 'close'],
      },
    }));

    instance = driver({
      steps,
      animate: !prefersReducedMotion,
      duration: transitionDuration,
      smoothScroll: !prefersReducedMotion,
      allowClose: true,
      allowKeyboardControl: true,
      overlayClickBehavior: 'close',
      overlayColor: '#080b12',
      overlayOpacity: document.documentElement.dataset.theme === 'dark' ? 0.62 : 0.5,
      stagePadding: 6,
      stageRadius: 12,
      popoverOffset: 14,
      popoverClass: 'jiraauto-tour-popover',
      showButtons: ['previous', 'next', 'close'],
      showProgress: true,
      progressText: '단계 {{current}} / {{total}}',
      prevBtnText: '‹ 이전',
      nextBtnText: '다음 ›',
      doneBtnText: '완료 ✓',
      onPopoverRender: renderAccessiblePopover,
      onNextClick: (_element, _step, { driver: tourDriver }) => {
        runStepTransition(() => tourDriver.moveNext(), transitionDuration);
      },
      onPrevClick: (_element, _step, { driver: tourDriver }) => {
        runStepTransition(() => tourDriver.movePrevious(), transitionDuration);
      },
      onDoneClick: (_element, _step, { driver: tourDriver }) => {
        if (transitionLocked) return;
        transitionLocked = true;
        tourDriver.destroy();
      },
      onDestroyed: finish,
    });

    keydownHandler = event => {
      if (event.key !== 'Enter' || !instance?.isActive()) return;
      const target = event.target as HTMLElement | null;
      if (target?.closest('input, textarea, select, [contenteditable="true"]')) return;

      if (event.repeat || enterHeld) {
        event.preventDefault();
        return;
      }

      enterHeld = true;
      if (target?.closest('button')) return;

      event.preventDefault();
      if (instance.hasNextStep()) {
        runStepTransition(() => instance?.moveNext(), transitionDuration);
      } else if (!transitionLocked) {
        transitionLocked = true;
        instance.destroy();
      }
    };
    keyupHandler = event => {
      if (event.key === 'Enter') enterHeld = false;
    };
    document.addEventListener('keydown', keydownHandler);
    document.addEventListener('keyup', keyupHandler);
    instance.drive();
    return true;
  };

  return {
    id: definition.id,
    version: definition.version,
    start,
    restart: (onFinish?: () => void) => start({ force: true, onFinish }),
    destroy: () => {
      if (!instance?.isActive()) return;
      interrupted = true;
      instance.destroy();
    },
    isCompleted: () => isTourCompleted(definition.id, definition.version),
  };
};

export type TourController = ReturnType<typeof createTour>;
