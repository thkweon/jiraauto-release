import { driver, type DriveStep, type Driver, type PopoverDOM } from 'driver.js';
import type { StartTourOptions, TourDefinition, TourStepDefinition } from './types';
import { isTourCompleted, markTourCompleted } from './storage';

const isVisible = (element: Element) => {
  const htmlElement = element as HTMLElement;
  const style = window.getComputedStyle(htmlElement);
  const rect = htmlElement.getBoundingClientRect();
  return style.display !== 'none'
    && style.visibility !== 'hidden'
    && rect.width > 0
    && rect.height > 0;
};

const visibleSteps = (steps: TourStepDefinition[]) => steps.filter(step => {
  const element = document.querySelector(step.target);
  return Boolean(element && isVisible(element));
});

const renderAccessiblePopover = (popover: PopoverDOM) => {
  popover.wrapper.setAttribute('role', 'dialog');
  popover.wrapper.setAttribute('aria-modal', 'true');
  popover.closeButton.setAttribute('aria-label', '안내 닫기');
  popover.previousButton.setAttribute('aria-label', '이전 안내 단계');
  popover.nextButton.setAttribute('aria-label', '다음 안내 단계');
  window.requestAnimationFrame(() => popover.nextButton.focus());
};

export const createTour = (definition: TourDefinition) => {
  let instance: Driver | null = null;
  let interrupted = false;
  let finishCallback: (() => void) | undefined;
  let keydownHandler: ((event: KeyboardEvent) => void) | null = null;

  const removeKeyboardHandler = () => {
    if (!keydownHandler) return;
    document.removeEventListener('keydown', keydownHandler);
    keydownHandler = null;
  };

  const finish = () => {
    removeKeyboardHandler();
    if (!interrupted) markTourCompleted(definition.id, definition.version);
    const callback = finishCallback;
    finishCallback = undefined;
    instance = null;
    if (!interrupted) callback?.();
    interrupted = false;
  };

  const start = ({ force = false, onFinish }: StartTourOptions = {}) => {
    if (instance?.isActive()) instance.destroy();
    if (!force && isTourCompleted(definition.id, definition.version)) return false;

    const availableSteps = visibleSteps(definition.steps);
    if (availableSteps.length === 0) return false;

    interrupted = false;
    finishCallback = onFinish;
    const steps: DriveStep[] = availableSteps.map((step, index) => ({
      element: step.target,
      popover: {
        title: step.title,
        description: step.description,
        side: step.side || 'bottom',
        align: step.align || 'center',
        showButtons: index === 0 ? ['next', 'close'] : ['previous', 'next', 'close'],
      },
    }));

    instance = driver({
      steps,
      animate: !window.matchMedia('(prefers-reduced-motion: reduce)').matches,
      smoothScroll: !window.matchMedia('(prefers-reduced-motion: reduce)').matches,
      allowClose: true,
      allowKeyboardControl: true,
      overlayClickBehavior: 'close',
      overlayColor: '#080b12',
      overlayOpacity: document.documentElement.dataset.theme === 'dark' ? 0.62 : 0.5,
      stagePadding: 6,
      stageRadius: 12,
      popoverOffset: 14,
      popoverClass: 'jiraauto-tour-popover',
      showButtons: ['previous', 'next', 'close'],
      showProgress: true,
      progressText: '단계 {{current}} / {{total}}',
      prevBtnText: '‹ 이전',
      nextBtnText: '다음 ›',
      doneBtnText: '완료 ✓',
      onPopoverRender: renderAccessiblePopover,
      onDestroyed: finish,
    });

    keydownHandler = event => {
      if (event.key !== 'Enter' || event.repeat || !instance?.isActive()) return;
      const target = event.target as HTMLElement | null;
      if (target?.closest('input, textarea, select, button, [contenteditable="true"]')) return;
      event.preventDefault();
      if (instance.hasNextStep()) instance.moveNext();
      else instance.destroy();
    };
    document.addEventListener('keydown', keydownHandler);
    instance.drive();
    return true;
  };

  return {
    id: definition.id,
    version: definition.version,
    start,
    restart: (onFinish?: () => void) => start({ force: true, onFinish }),
    destroy: () => {
      if (!instance?.isActive()) return;
      interrupted = true;
      instance.destroy();
    },
    isCompleted: () => isTourCompleted(definition.id, definition.version),
  };
};

export type TourController = ReturnType<typeof createTour>;
