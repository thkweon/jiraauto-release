export type LockMethod = 'pattern3' | 'pattern4' | 'pattern5' | 'pin4' | 'pin6' | 'password';
export const LOCK_EVENT = 'screenLockChanged';
export const LOCK_NOW = 'screenLockNow';
export const methods: Record<LockMethod, string> = { pattern3: '3×3 패턴', pattern4: '4×4 패턴', pattern5: '5×5 패턴', pin4: 'PIN 4자리', pin6: 'PIN 6자리', password: '패스워드' };
export function validSecret(method: LockMethod, value: string) {
  if (method.startsWith('pattern')) { const size = Number(method.slice(-1)); const points = value.split(',').map(Number); return points.length >= size + 1 && new Set(points).size === points.length && points.every(p => Number.isInteger(p) && p >= 0 && p < size * size); }
  if (method.startsWith('pin')) return new RegExp(`^\\d{${method.slice(-1)}}$`).test(value);
  return value.length >= 8;
}
export function appendPoint(path: number[], point: number, size: number): number[] {
  if (path.includes(point)) return path;
  if (!path.length) return [point];
  const last = path[path.length - 1];
  const dx = point % size - last % size, dy = Math.floor(point / size) - Math.floor(last / size);
  const gcd = (a: number, b: number): number => b ? gcd(b, a % b) : a;
  const steps = gcd(Math.abs(dx), Math.abs(dy));
  const next = [...path];
  for (let step = 1; step < steps; step++) { const p = last + step * (dy / steps * size + dx / steps); if (!next.includes(p)) next.push(p); }
  return [...next, point];
}

// Coordinates use 60 units per cell. Cell corners must not select nearby points.
export function hitPatternPoint(x: number, y: number, size: number): number | null {
  const column = Math.floor(x / 60), row = Math.floor(y / 60);
  if (column < 0 || row < 0 || column >= size || row >= size) return null;
  return Math.hypot(x - (column * 60 + 30), y - (row * 60 + 30)) <= 16 ? row * size + column : null;
}
