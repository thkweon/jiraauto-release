import { useEffect, useRef, useState } from 'react';
import { Braces, Check, Copy, Download, Eye, EyeOff, KeyRound, Lock, NotebookPen, Trash2, Unlock } from 'lucide-react';
import { useFloatingWidgetLayout } from '../hooks/useFloatingWidgetLayout';
import MarkdownPreview from './MarkdownPreview';
import {
  createNotepadPage,
  isNotepadDoublePlacement,
  loadNotepadPagesState,
  loadNotepadWidgetSettings,
  NOTEPAD_PAGES_STORAGE_KEY,
  NOTEPAD_WIDGET_SETTINGS_CHANGED_EVENT,
  saveNotepadPagesState,
} from '../utils/notepadWidget';
import type { NotepadPagesState, NotepadWidgetSettings } from '../utils/notepadWidget';
import {
  createNotepadPageLock,
  encryptUnlockedNotepadPage,
  matchesPreviousNotepadPassword,
  unlockNotepadPage,
} from '../utils/notepadSecurity';

type PasswordDialogMode = 'setup' | 'manage' | null;

export default function NotepadFloatingWidget() {
  const [settings, setSettings] = useState<NotepadWidgetSettings>(loadNotepadWidgetSettings);
  const [pagesState, setPagesState] = useState<NotepadPagesState>(loadNotepadPagesState);
  const [markdownPreviewEnabled, setMarkdownPreviewEnabled] = useState(false);
  const [statusMessage, setStatusMessage] = useState('');
  const [unlockedContents, setUnlockedContents] = useState<Record<string, string>>({});
  const [unlockPassword, setUnlockPassword] = useState('');
  const [passwordDialogMode, setPasswordDialogMode] = useState<PasswordDialogMode>(null);
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [passwordError, setPasswordError] = useState('');
  const [passwordBusy, setPasswordBusy] = useState(false);
  const unlockedKeysRef = useRef<Record<string, Uint8Array>>({});
  const encryptionVersionsRef = useRef<Record<string, number>>({});
  const { ref: layoutRef, ...layout } = useFloatingWidgetLayout(
    'notepad',
    settings.placement,
    settings.enabled,
    isNotepadDoublePlacement(settings.placement) ? 'double' : 'single',
  );

  useEffect(() => {
    const syncSettings = () => setSettings(loadNotepadWidgetSettings());
    const syncStorage = (event: StorageEvent) => {
      syncSettings();
      if (event.key === NOTEPAD_PAGES_STORAGE_KEY) setPagesState(loadNotepadPagesState());
    };
    window.addEventListener(NOTEPAD_WIDGET_SETTINGS_CHANGED_EVENT, syncSettings);
    window.addEventListener('storage', syncStorage);
    return () => {
      window.removeEventListener(NOTEPAD_WIDGET_SETTINGS_CHANGED_EVENT, syncSettings);
      window.removeEventListener('storage', syncStorage);
    };
  }, []);

  useEffect(() => {
    if (!statusMessage) return;
    const timer = window.setTimeout(() => setStatusMessage(''), 2200);
    return () => window.clearTimeout(timer);
  }, [statusMessage]);

  useEffect(() => {
    let lockTimer: number | undefined;
    const cancelLock = () => {
      if (lockTimer !== undefined) window.clearTimeout(lockTimer);
      lockTimer = undefined;
    };
    const scheduleLock = () => {
      cancelLock();
      lockTimer = window.setTimeout(() => {
        setUnlockedContents({});
        unlockedKeysRef.current = {};
        setMarkdownPreviewEnabled(false);
        setStatusMessage('포커스 해제 후 5분이 지나 메모장을 잠갔습니다.');
      }, 5 * 60 * 1000);
    };
    const lockImmediately = () => { cancelLock(); setUnlockedContents({}); unlockedKeysRef.current = {}; setMarkdownPreviewEnabled(false); setUnlockPassword(''); setCurrentPassword(''); setNewPassword(''); setConfirmPassword(''); setPasswordDialogMode(null); };
    window.addEventListener('screenLocked', lockImmediately);
    window.addEventListener('blur', scheduleLock);
    window.addEventListener('focus', cancelLock);
    return () => {
      cancelLock();
      window.removeEventListener('blur', scheduleLock);
      window.removeEventListener('focus', cancelLock);
      window.removeEventListener('screenLocked', lockImmediately);
    };
  }, []);

  if (!settings.enabled) return null;

  const activePageIndex = Math.max(
    0,
    pagesState.pages.findIndex(page => page.id === pagesState.activePageId),
  );
  const activePage = pagesState.pages[activePageIndex];
  const pageIsPasswordProtected = Boolean(activePage?.lock);
  const pageIsLocked = pageIsPasswordProtected && !(activePage.id in unlockedContents);
  const content = activePage?.lock
    ? unlockedContents[activePage.id] || ''
    : activePage?.content || '';
  const visiblePageStart = Math.max(
    0,
    Math.min(activePageIndex - 1, pagesState.pages.length - 3),
  );
  const visiblePages = pagesState.pages.slice(visiblePageStart, visiblePageStart + 3);

  const updatePagesState = (state: NotepadPagesState) => {
    setPagesState(state);
    saveNotepadPagesState(state);
  };

  const updateContent = (nextContent: string) => {
    if (!activePage || pageIsLocked) return;
    if (activePage.lock) {
      const pageId = activePage.id;
      const encryptionKey = unlockedKeysRef.current[pageId];
      if (!encryptionKey) return;
      setUnlockedContents(previous => ({ ...previous, [pageId]: nextContent }));
      const version = (encryptionVersionsRef.current[pageId] || 0) + 1;
      encryptionVersionsRef.current[pageId] = version;
      void encryptUnlockedNotepadPage(activePage.lock, nextContent, encryptionKey).then(lock => {
        if (encryptionVersionsRef.current[pageId] !== version) return;
        setPagesState(previous => {
          const pages = previous.pages.map(page => (
            page.id === pageId && page.lock ? { ...page, lock } : page
          ));
          const nextState = { ...previous, pages };
          saveNotepadPagesState(nextState);
          return nextState;
        });
      }).catch(() => setStatusMessage('암호화된 메모를 저장하지 못했습니다.'));
      return;
    }
    const pages = pagesState.pages.map(page => (
      page.id === pagesState.activePageId ? { ...page, content: nextContent } : page
    ));
    updatePagesState({ ...pagesState, pages });
  };

  const selectPage = (index: number) => {
    const page = pagesState.pages[index];
    if (!page || page.id === pagesState.activePageId) return;
    updatePagesState({ ...pagesState, activePageId: page.id });
    setUnlockPassword('');
    setPasswordDialogMode(null);
    setPasswordError('');
    setMarkdownPreviewEnabled(false);
  };

  const addPageAfterCurrent = () => {
    const page = createNotepadPage();
    const pages = [...pagesState.pages];
    pages.splice(activePageIndex + 1, 0, page);
    updatePagesState({ pages, activePageId: page.id });
    setMarkdownPreviewEnabled(false);
    setStatusMessage(`${activePageIndex + 2}페이지를 추가했습니다.`);
  };

  const addPageAtEnd = () => {
    const page = createNotepadPage();
    updatePagesState({ pages: [...pagesState.pages, page], activePageId: page.id });
    setMarkdownPreviewEnabled(false);
    setStatusMessage(`${pagesState.pages.length + 1}페이지를 추가했습니다.`);
  };

  const deleteCurrentPage = () => {
    if (!confirm(`${activePageIndex + 1}페이지를 삭제할까요?`)) return;
    if (pagesState.pages.length === 1) {
      const page = createNotepadPage();
      updatePagesState({ pages: [page], activePageId: page.id });
      setMarkdownPreviewEnabled(false);
      setStatusMessage('빈 1페이지로 초기화했습니다.');
      setUnlockedContents({});
      unlockedKeysRef.current = {};
      return;
    }
    const pages = pagesState.pages.filter(page => page.id !== pagesState.activePageId);
    const nextPage = pages[Math.min(activePageIndex, pages.length - 1)];
    updatePagesState({ pages, activePageId: nextPage.id });
    setUnlockedContents(previous => {
      const next = { ...previous };
      delete next[pagesState.activePageId];
      return next;
    });
    delete unlockedKeysRef.current[pagesState.activePageId];
    setMarkdownPreviewEnabled(false);
    setStatusMessage('현재 페이지를 삭제했습니다.');
  };

  const deleteAllPages = () => {
    if (!confirm(`메모장 ${pagesState.pages.length}페이지의 내용을 모두 삭제할까요?`)) return;
    const page = createNotepadPage();
    updatePagesState({ pages: [page], activePageId: page.id });
    setUnlockedContents({});
    unlockedKeysRef.current = {};
    setMarkdownPreviewEnabled(false);
    setPasswordDialogMode(null);
    setPasswordError('');
    setStatusMessage('모든 페이지를 삭제하고 1페이지로 초기화했습니다.');
  };

  const closePasswordDialog = () => {
    setPasswordDialogMode(null);
    setCurrentPassword('');
    setNewPassword('');
    setConfirmPassword('');
    setPasswordError('');
  };

  const lockActivePage = () => {
    if (!activePage?.lock) {
      setPasswordDialogMode('setup');
      setPasswordError('');
      return;
    }
    if (pageIsLocked) return;
    setUnlockedContents(previous => {
      const next = { ...previous };
      delete next[activePage.id];
      return next;
    });
    delete unlockedKeysRef.current[activePage.id];
    setMarkdownPreviewEnabled(false);
    setStatusMessage('현재 페이지를 잠갔습니다.');
  };

  const configurePagePassword = async () => {
    if (!activePage || !newPassword || !confirmPassword) {
      setPasswordError('암호와 암호 확인을 모두 입력해 주세요.');
      return;
    }
    if (newPassword !== confirmPassword) {
      setPasswordError('암호 확인이 일치하지 않습니다.');
      return;
    }
    setPasswordBusy(true);
    setPasswordError('');
    try {
      const lock = await createNotepadPageLock(newPassword, content);
      const pages = pagesState.pages.map(page => (
        page.id === activePage.id ? { ...page, content: '', lock } : page
      ));
      updatePagesState({ ...pagesState, pages });
      setUnlockedContents(previous => {
        const next = { ...previous };
        delete next[activePage.id];
        return next;
      });
      delete unlockedKeysRef.current[activePage.id];
      closePasswordDialog();
      setMarkdownPreviewEnabled(false);
      setStatusMessage('암호를 설정하고 현재 페이지를 잠갔습니다.');
    } catch {
      setPasswordError('페이지를 암호화하지 못했습니다.');
    } finally {
      setPasswordBusy(false);
    }
  };

  const unlockActivePage = async () => {
    if (!activePage?.lock || !unlockPassword) return;
    setPasswordBusy(true);
    setPasswordError('');
    try {
      const unlocked = await unlockNotepadPage(activePage.lock, unlockPassword);
      if (!unlocked) {
        setPasswordError('암호가 올바르지 않습니다.');
        return;
      }
      unlockedKeysRef.current[activePage.id] = unlocked.encryptionKey;
      setUnlockedContents(previous => ({ ...previous, [activePage.id]: unlocked.content }));
      setUnlockPassword('');
      setPasswordError('');
      setStatusMessage('현재 페이지의 잠금을 해제했습니다.');
    } finally {
      setPasswordBusy(false);
    }
  };

  const changePagePassword = async () => {
    if (!activePage?.lock || !currentPassword || !newPassword || !confirmPassword) {
      setPasswordError('기존 암호, 새 암호, 암호 확인을 모두 입력해 주세요.');
      return;
    }
    if (newPassword !== confirmPassword) {
      setPasswordError('새 암호 확인이 일치하지 않습니다.');
      return;
    }
    setPasswordBusy(true);
    setPasswordError('');
    try {
      const currentUnlocked = await unlockNotepadPage(activePage.lock, currentPassword);
      if (!currentUnlocked) {
        setPasswordError('기존 암호가 올바르지 않습니다.');
        return;
      }
      if (await unlockNotepadPage(activePage.lock, newPassword)) {
        setPasswordError('현재 사용 중인 암호로는 변경할 수 없습니다.');
        return;
      }
      if (await matchesPreviousNotepadPassword(activePage.lock, newPassword)) {
        setPasswordError('직전에 사용한 암호로는 다시 변경할 수 없습니다.');
        return;
      }
      const latestContent = unlockedContents[activePage.id] ?? currentUnlocked.content;
      encryptionVersionsRef.current[activePage.id] = (encryptionVersionsRef.current[activePage.id] || 0) + 1;
      const lock = await createNotepadPageLock(newPassword, latestContent, activePage.lock);
      const pages = pagesState.pages.map(page => (
        page.id === activePage.id ? { ...page, content: '', lock } : page
      ));
      updatePagesState({ ...pagesState, pages });
      setUnlockedContents(previous => {
        const next = { ...previous };
        delete next[activePage.id];
        return next;
      });
      delete unlockedKeysRef.current[activePage.id];
      closePasswordDialog();
      setMarkdownPreviewEnabled(false);
      setStatusMessage('암호를 변경하고 현재 페이지를 잠갔습니다.');
    } catch {
      setPasswordError('암호를 변경하지 못했습니다.');
    } finally {
      setPasswordBusy(false);
    }
  };

  const removePagePassword = async () => {
    if (!activePage?.lock || !currentPassword) {
      setPasswordError('기존 암호를 입력해 주세요.');
      return;
    }
    setPasswordBusy(true);
    setPasswordError('');
    try {
      const currentUnlocked = await unlockNotepadPage(activePage.lock, currentPassword);
      if (!currentUnlocked) {
        setPasswordError('기존 암호가 올바르지 않습니다.');
        return;
      }
      const latestContent = unlockedContents[activePage.id] ?? currentUnlocked.content;
      encryptionVersionsRef.current[activePage.id] = (encryptionVersionsRef.current[activePage.id] || 0) + 1;
      const pages = pagesState.pages.map(page => (
        page.id === activePage.id ? { id: page.id, content: latestContent } : page
      ));
      updatePagesState({ ...pagesState, pages });
      setUnlockedContents(previous => {
        const next = { ...previous };
        delete next[activePage.id];
        return next;
      });
      delete unlockedKeysRef.current[activePage.id];
      closePasswordDialog();
      setStatusMessage('현재 페이지의 암호를 제거했습니다.');
    } catch {
      setPasswordError('잠금을 해제하지 못했습니다.');
    } finally {
      setPasswordBusy(false);
    }
  };

  const downloadText = () => {
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    const date = new Date().toISOString().slice(0, 10);
    anchor.href = url;
    anchor.download = `jiraauto-note-${activePageIndex + 1}-${date}.txt`;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    URL.revokeObjectURL(url);
  };

  const copyContent = async () => {
    try {
      if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(content);
      } else {
        const copyTarget = document.createElement('textarea');
        copyTarget.value = content;
        copyTarget.style.position = 'fixed';
        copyTarget.style.opacity = '0';
        document.body.appendChild(copyTarget);
        copyTarget.select();
        let copied = false;
        try {
          copied = document.execCommand('copy');
        } finally {
          copyTarget.remove();
        }
        if (!copied) throw new Error('Clipboard copy failed');
      }
      setStatusMessage('클립보드에 복사했습니다.');
    } catch {
      setStatusMessage('클립보드에 복사하지 못했습니다.');
    }
  };

  const prettifyJson = () => {
    try {
      const prettyContent = JSON.stringify(JSON.parse(content), null, 2);
      updateContent(prettyContent);
      setStatusMessage('JSON을 정리했습니다.');
    } catch {
      setStatusMessage('올바른 JSON 형식인지 확인해 주세요.');
    }
  };

  return (
    <section
      ref={layoutRef}
      className={`notepad-floating-widget floating-widget-responsive notepad-placement-${settings.placement}${isNotepadDoublePlacement(settings.placement) ? ' double' : ' single'}`}
      data-floating-side={layout.side}
      data-floating-block={layout.block}
      data-floating-stacked={layout.stacked || undefined}
      hidden={layout.hidden}
      aria-hidden={layout.hidden || undefined}
      aria-label="메모장"
      style={layout.style}
    >
      <header className="notepad-widget-header">
        <strong>
          <NotebookPen size={17} /> 메모장
          <small>{activePageIndex + 1}/{pagesState.pages.length}</small>
        </strong>
        <div className="notepad-widget-header-actions">
          <button type="button" onClick={deleteAllPages} title="모든 페이지 삭제" aria-label="메모장 모든 페이지 삭제">
            <Trash2 size={16} />
          </button>
          <button
            type="button"
            onClick={lockActivePage}
            title={pageIsLocked ? '현재 페이지 잠김' : pageIsPasswordProtected ? '현재 페이지 잠그기' : '현재 페이지 암호 설정'}
            aria-label={pageIsLocked ? '현재 메모장 페이지 잠김' : '현재 메모장 페이지 잠그기'}
          >
            {pageIsLocked ? <Lock size={16} /> : <Unlock size={16} />}
          </button>
          <button
            type="button"
            onClick={() => {
              setPasswordDialogMode('manage');
              setPasswordError('');
            }}
            title="페이지 암호 변경 또는 제거"
            aria-label="현재 메모장 페이지 암호 관리"
            disabled={!pageIsPasswordProtected}
          >
            <KeyRound size={16} />
          </button>
          <button type="button" onClick={prettifyJson} title="JSON Pretty" aria-label="JSON 들여쓰기 정리" disabled={pageIsLocked}>
            <Braces size={16} />
          </button>
          <button
            type="button"
            className={markdownPreviewEnabled ? 'active' : undefined}
            onClick={() => setMarkdownPreviewEnabled(value => !value)}
            title={markdownPreviewEnabled ? 'Markdown 편집' : 'Markdown 미리보기'}
            aria-label={markdownPreviewEnabled ? 'Markdown 편집 화면으로 전환' : 'Markdown 미리보기로 전환'}
            aria-pressed={markdownPreviewEnabled}
            disabled={pageIsLocked}
          >
            {markdownPreviewEnabled ? <EyeOff size={16} /> : <Eye size={16} />}
          </button>
          <button type="button" onClick={() => void copyContent()} title="클립보드에 복사" aria-label="메모를 클립보드에 복사" disabled={pageIsLocked}>
            {statusMessage === '클립보드에 복사했습니다.' ? <Check size={16} /> : <Copy size={16} />}
          </button>
          <button type="button" onClick={downloadText} title="TXT로 다운로드" aria-label="메모를 TXT로 다운로드" disabled={pageIsLocked}>
            <Download size={16} />
          </button>
        </div>
      </header>
      {pageIsLocked ? (
        <div className="notepad-locked-page">
          <Lock size={28} />
          <strong>{activePageIndex + 1}페이지가 잠겨 있습니다.</strong>
          <form onSubmit={event => {
            event.preventDefault();
            void unlockActivePage();
          }}>
            <input
              type="password"
              value={unlockPassword}
              onChange={event => setUnlockPassword(event.target.value)}
              placeholder="암호 입력"
              autoComplete="current-password"
              autoFocus
            />
            <button type="submit" disabled={!unlockPassword || passwordBusy}>확인</button>
          </form>
          {passwordError && <small>{passwordError}</small>}
        </div>
      ) : markdownPreviewEnabled ? (
        <MarkdownPreview content={content} />
      ) : (
        <textarea
          value={content}
          onChange={event => {
            updateContent(event.target.value);
          }}
          placeholder="메모를 입력하세요. 내용은 이 브라우저에 자동 저장됩니다."
          aria-label="메모 내용"
        />
      )}
      <span className={`notepad-widget-save-status${statusMessage ? ' has-message' : ''}`}>
        {statusMessage || `자동 저장 · ${content.length.toLocaleString('ko-KR')}자`}
      </span>
      <nav className="notepad-page-navigation" aria-label="메모장 페이지 이동">
        <button type="button" onClick={deleteCurrentPage} title="현재 페이지 삭제" aria-label="현재 메모장 페이지 삭제">−</button>
        <button type="button" onClick={() => selectPage(0)} disabled={activePageIndex === 0}>처음</button>
        <button type="button" onClick={() => selectPage(activePageIndex - 1)} disabled={activePageIndex === 0}>이전</button>
        {visiblePages.map((page, visibleIndex) => {
          const pageIndex = visiblePageStart + visibleIndex;
          return (
            <button
              type="button"
              key={page.id}
              className={pageIndex === activePageIndex ? 'active' : undefined}
              onClick={() => selectPage(pageIndex)}
              aria-current={pageIndex === activePageIndex ? 'page' : undefined}
            >
              {pageIndex + 1}
            </button>
          );
        })}
        <button
          type="button"
          onClick={() => selectPage(activePageIndex + 1)}
          disabled={activePageIndex === pagesState.pages.length - 1}
        >
          다음
        </button>
        <button
          type="button"
          onClick={() => selectPage(pagesState.pages.length - 1)}
          disabled={activePageIndex === pagesState.pages.length - 1}
        >
          끝
        </button>
        <button type="button" onClick={addPageAfterCurrent} title="현재 페이지 바로 뒤에 추가">+</button>
        <button type="button" onClick={addPageAtEnd} title="맨 끝에 페이지 추가">*</button>
      </nav>
      {passwordDialogMode && (
        <div className="notepad-password-dialog-backdrop" role="presentation">
          <section className="notepad-password-dialog" role="dialog" aria-modal="true" aria-label={passwordDialogMode === 'setup' ? '페이지 암호 설정' : '페이지 암호 관리'}>
            <header>
              <strong>{passwordDialogMode === 'setup' ? '페이지 암호 설정' : '페이지 암호 관리'}</strong>
              <button type="button" onClick={closePasswordDialog} aria-label="암호 창 닫기">×</button>
            </header>
            {passwordDialogMode === 'manage' && (
              <label>
                기존 암호
                <input
                  type="password"
                  value={currentPassword}
                  onChange={event => setCurrentPassword(event.target.value)}
                  autoComplete="current-password"
                  autoFocus
                />
              </label>
            )}
            <label>
              {passwordDialogMode === 'setup' ? '암호' : '새 암호'}
              <input
                type="password"
                value={newPassword}
                onChange={event => setNewPassword(event.target.value)}
                autoComplete="new-password"
                autoFocus={passwordDialogMode === 'setup'}
              />
            </label>
            <label>
              {passwordDialogMode === 'setup' ? '암호 확인' : '새 암호 확인'}
              <input
                type="password"
                value={confirmPassword}
                onChange={event => setConfirmPassword(event.target.value)}
                autoComplete="new-password"
              />
            </label>
            {passwordError && <p>{passwordError}</p>}
            <div className="notepad-password-dialog-actions">
              {passwordDialogMode === 'setup' ? (
                <button type="button" onClick={() => void configurePagePassword()} disabled={passwordBusy}>잠금</button>
              ) : (
                <>
                  <button type="button" onClick={() => void changePagePassword()} disabled={passwordBusy}>암호 변경</button>
                  <button type="button" className="danger" onClick={() => void removePagePassword()} disabled={passwordBusy}>잠금 해제</button>
                </>
              )}
            </div>
          </section>
        </div>
      )}
    </section>
  );
}
