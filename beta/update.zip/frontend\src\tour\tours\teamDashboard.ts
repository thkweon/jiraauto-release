import type { TourDefinition } from '../types';

export const teamDashboardTour: TourDefinition = {
  id: 'team-dashboard',
  version: 1,
  steps: [
    {
      target: '[data-tour="team-dashboard-page"]',
      title: '팀 현황판',
      description: '팀원들의 Jira 업무를 한곳에서 확인하고 필요한 이슈로 이동하는 화면입니다.',
      side: 'top',
    },
    {
      target: '[data-tour="team-dashboard-filters"]',
      title: '팀 업무 필터',
      description: '연동 멤버, Jira 계정, 기간과 프로젝트를 선택해 팀 업무를 좁힐 수 있습니다.',
      side: 'bottom',
    },
    {
      target: '[data-tour="team-dashboard-search"]',
      title: '팀 업무 검색',
      description: '티켓 번호나 제목으로 현재 팀 업무를 검색할 수 있습니다.',
      side: 'bottom',
    },
    {
      target: '[data-tour="team-dashboard-list"]',
      title: '팀 이슈 목록',
      description: '카드에서 담당자, 연동 멤버, 계정과 현재 상태를 확인하고 Jira 이슈를 열 수 있습니다.',
      side: 'top',
    },
  ],
};
