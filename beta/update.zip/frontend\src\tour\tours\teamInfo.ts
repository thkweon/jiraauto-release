import type { TourDefinition } from '../types';

export const teamInfoTour: TourDefinition = {
  id: 'team-info-member',
  version: 1,
  steps: [
    {
      target: '[data-tour="team-info-page"]',
      title: '팀 정보',
      description: '현재 팀 연결에 사용하는 내 식별자와 팀장 서버를 확인하는 화면입니다.',
      side: 'top',
    },
    {
      target: '[data-tour="team-info-member-id"]',
      title: '내 식별자',
      description: '팀 동기화에서 나를 구분하는 식별자입니다.',
      side: 'right',
    },
    {
      target: '[data-tour="team-info-server"]',
      title: '팀장 서버',
      description: '팀 데이터가 동기화되는 팀장 PC의 서버 주소입니다.',
      side: 'right',
    },
    {
      target: '[data-tour="team-info-leave"]',
      title: '팀 탈퇴',
      description: '팀 연결을 종료할 수 있습니다. 선택하면 확인 후 동기화가 중단됩니다.',
      side: 'top',
    },
  ],
};
