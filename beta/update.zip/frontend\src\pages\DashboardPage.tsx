// @ts-nocheck
import React, { memo, useState, useEffect, useCallback, useRef } from 'react';
import { CheckCheck, Flag, Plus, RefreshCcw, Search, Sparkles, Star } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { MentionsInput, Mention } from 'react-mentions';
import '../App.css';
import { updateEndDateWithinRange, updateStartDateWithinRange } from '../utils/dateRange';
import { formatJiraInstanceName, type JiraDeploymentType } from '../utils/jiraInstance';
import { loadDashboardActivityTypes, type DashboardActivityType } from '../utils/dashboardActivity';
import { normalizeInstanceFilter, normalizeProjectFilter } from '../utils/dashboardFilters';
import { notificationsAllowed } from '../utils/screenLock';
import MarkdownPreview from '../components/MarkdownPreview';
import ScrollToTopButton from '../components/ScrollToTopButton';

// ---------------------------------------------------------
// 1. 타입 정의
// ---------------------------------------------------------
interface JiraPerson {
  name?: string;
  key?: string;
  accountId?: string;
  displayName?: string;
}

interface JiraIssue {
  key: string;
  instance_id: number;
  jiraauto_closed?: boolean;
  jiraauto_closed_at?: string;
  errorMessages?: string[];
  favorite_unavailable?: boolean;
  favorite_unavailable_reason?: string;
  fields: {
    summary: string;
    status: { id?: string; name: string; statusCategory?: { key?: string } };
    project: { key: string };
    issuetype: { name: string };
    priority?: { name?: string; iconUrl?: string };
    components?: { name: string }[];
    labels?: string[];
    assignee: JiraPerson | null;
    reporter: JiraPerson | null;
    creator?: JiraPerson | null;
    updated: string;
    created: string;
    timetracking?: {
      originalEstimate?: string;
      remainingEstimate?: string;
      timeSpent?: string;
    };
  };
}

interface JiraComment {
  id: string;
  author: JiraPerson;
  updateAuthor?: JiraPerson;
  body: string;
  displayBody?: string;
  renderedBody?: string;
  created: string;
  updated?: string;
}

interface JiraHistoryItem {
  id: string;
  author: JiraPerson;
  created: string;
  items: { field: string; fromString: string; toString: string; }[];
}

interface JiraLinkedIssue {
  key: string;
  fields?: {
    summary?: string;
    status?: { name?: string };
    issuetype?: { name?: string };
  };
}

interface JiraIssueLink {
  id: string;
  type?: { name?: string; inward?: string; outward?: string };
  inwardIssue?: JiraLinkedIssue;
  outwardIssue?: JiraLinkedIssue;
}

interface JiraIssueDetail extends JiraIssue {
  fields: JiraIssue['fields'] & {
    description: string;
    displayDescription?: string;
    issuelinks?: JiraIssueLink[];
    comment: { comments: JiraComment[] };
    priority: { name: string };
    components: { name: string }[];
    labels: string[];
    watchers: string[];
    created: string;
    updated: string;
  };
  changelog?: { histories: JiraHistoryItem[]; };
}

interface JiraTransition { id: string; name: string; to: { id?: string; name: string }; }
type JiraUser = JiraPerson;
interface JiraUserSuggestion { id: string; display: string; name?: string; key?: string; accountId?: string; }
interface JiraInstanceInfo { id: number; base_url: string; name: string; deployment_type: JiraDeploymentType; }
interface TimeTrackingSnapshot {
  timetracking: {
    originalEstimate?: string;
    remainingEstimate?: string;
    timeSpent?: string;
  };
  worklog?: { total?: number; worklogs?: WorklogEntry[] };
}

interface WorklogEntry {
  id: string;
  author: JiraPerson;
  timeSpent: string;
  timeSpentSeconds: number;
  started?: string;
  created?: string;
  updated?: string;
  comment: string;
  editable: boolean;
}

const priorityColor = (name?: string) => {
  const normalized = (name || '').trim().toLowerCase();
  if (['highest', 'blocker', 'critical', '긴급', '매우 높음'].some(value => normalized.includes(value))) return '#d32f2f';
  if (['high', 'major', '높음'].some(value => normalized.includes(value))) return '#f57c00';
  if (['medium', 'normal', '중간', '보통'].some(value => normalized.includes(value))) return '#f9a825';
  if (['lowest', 'trivial', '매우 낮음'].some(value => normalized.includes(value))) return '#78909c';
  if (['low', 'minor', '낮음'].some(value => normalized.includes(value))) return '#1976d2';
  return '#78909c';
};

const sameStringRecord = (left: Record<string, string>, right: Record<string, string>) => {
  const leftKeys = Object.keys(left);
  const rightKeys = Object.keys(right);
  return leftKeys.length === rightKeys.length && leftKeys.every(key => left[key] === right[key]);
};

const issueSnapshotSignature = (issues: JiraIssue[]) => issues
  .map(issue => [
    issue.instance_id,
    issue.key,
    issue.fields?.updated || '',
    issue.fields?.status?.name || '',
    issue.fields?.assignee?.accountId || issue.fields?.assignee?.key || issue.fields?.assignee?.name || '',
    issue.favorite_unavailable ? '1' : '0',
  ].join(':'))
  .sort()
  .join('|');
interface IssueCreateOption { id?: string; name: string; }
interface IssueCreateProjectMeta {
  instance_id: number;
  instance_name: string;
  base_url: string;
  project_key: string;
  issue_types: IssueCreateOption[];
  components: IssueCreateOption[];
  error?: string;
}

interface WorklogPayload {
  timeSpent: string;
  comment: string;
  started: string;
  adjustEstimate: 'auto' | 'new' | 'leave';
  newEstimate?: string;
}

interface DashboardIssueState {
  observed_updated_at: string;
  unread_updated_at?: string | null;
  read_updated_at?: string | null;
  jiraauto_closed_at?: string | null;
}

interface DashboardIssueStatePayload {
  states: Record<string, DashboardIssueState>;
  initialized_instance_ids: number[];
  migration_pending_instance_ids: number[];
  last_sync_at_by_instance: Record<string, string>;
}

interface DashboardIssueActivityPayload {
  categories: DashboardActivityType[];
  snapshot: Record<string, unknown>;
}

type UnknownRecord = Record<string, unknown>;

const asRecord = (value: unknown): UnknownRecord | null =>
  typeof value === 'object' && value !== null ? value as UnknownRecord : null;

const errorMessage = (error: unknown, fallback: string) =>
  error instanceof Error && error.message ? error.message : fallback;

const isAbortError = (error: unknown) =>
  error instanceof DOMException
    ? error.name === 'AbortError'
    : asRecord(error)?.name === 'AbortError';

const mentionsStyle = {
  control: { backgroundColor: 'var(--card-bg)', color: 'var(--text-primary)', fontSize: 14, lineHeight: 1.5, fontFamily: 'inherit' },
  '&multiLine': {
    control: { minHeight: 150, fontFamily: 'inherit' },
    highlighter: { padding: 12, border: '1px solid transparent', boxSizing: 'border-box' as const, color: 'var(--text-primary)' },
    input: { padding: 12, border: '1px solid rgba(127, 140, 141, 0.32)', borderRadius: 8, outline: 'none', boxSizing: 'border-box' as const, minHeight: 150, color: 'var(--text-primary)', caretColor: 'var(--text-primary)' },
  },
  suggestions: {
    list: { backgroundColor: 'var(--card-bg)', color: 'var(--text-primary)', border: '1px solid rgba(127, 140, 141, 0.32)', borderRadius: 8, boxShadow: '0 4px 15px rgba(0,0,0,0.15)', fontSize: 13, zIndex: 10000 },
    item: { padding: '8px 12px', borderBottom: '1px solid rgba(127, 140, 141, 0.18)', '&focused': { backgroundColor: 'rgba(9, 132, 227, 0.12)', color: 'var(--accent-color)' } },
  },
};

const API_BASE = 'http://localhost:8000/api';
const FAVORITES_STORAGE_KEY = 'jiraDashboardFavoriteIssueMap';
const UNREAD_UPDATES_STORAGE_KEY = 'jiraDashboardUnreadUpdatedIssueMap';
const TRACK_OWN_ACTIVITY_STORAGE_KEY = 'jiraDashboardTrackOwnActivity';
const DASHBOARD_PERSON_ROLE_STORAGE_KEY = 'jiraDashboardPersonRole';
const FAVORITE_SEARCH_QUERIES_STORAGE_KEY = 'jiraDashboardFavoriteSearchQueries';

type DashboardPersonRole = 'assignee' | 'reporter';
type IssueSearchField = 'ticket' | 'summary' | 'assignee' | 'reporter' | 'component' | 'label';

interface ParsedIssueSearchQuery {
  field: IssueSearchField;
  operator: '=' | '~';
  value: string;
  negated: boolean;
}

interface ParsedIssueSearchExpression {
  orGroups: ParsedIssueSearchQuery[][];
}

const ISSUE_SEARCH_FIELDS = [
  { token: '티켓번호', description: '티켓 키로 검색' },
  { token: '제목', description: '티켓 제목으로 검색' },
  { token: '담당자', description: '담당자 정보로 검색' },
  { token: '보고자', description: '보고자 정보로 검색' },
  { token: '컴포넌트', description: '컴포넌트 이름으로 검색' },
  { token: '레이블', description: '레이블 문자열로 검색' },
];

const ISSUE_SEARCH_OPERATORS = [
  { token: '=', description: '정확히 일치' },
  { token: '~', description: '문자열 포함' },
  { token: '!=', description: '정확히 일치하지 않음' },
  { token: '!~', description: '문자열을 포함하지 않음' },
];

const ISSUE_SEARCH_CONNECTORS = [
  { token: 'AND', description: '모든 조건을 만족' },
  { token: 'OR', description: '조건 중 하나를 만족' },
];

const loadDashboardPersonRole = (): DashboardPersonRole =>
  localStorage.getItem(DASHBOARD_PERSON_ROLE_STORAGE_KEY) === 'reporter' ? 'reporter' : 'assignee';

const parseIssueSearchQuery = (input: string): ParsedIssueSearchQuery | null => {
  const match = input.match(/^\s*(티켓번호|티켓|제목|담당자|보고자|컴포넌트|레이블)\s*(!?=|!~|~)\s*(.+?)\s*$/i);
  if (!match) return null;
  const fieldMap: Record<string, IssueSearchField> = {
    티켓번호: 'ticket',
    티켓: 'ticket',
    제목: 'summary',
    담당자: 'assignee',
    보고자: 'reporter',
    컴포넌트: 'component',
    레이블: 'label',
  };
  const operator = match[2];
  return {
    field: fieldMap[match[1]],
    operator: operator.endsWith('=') ? '=' : '~',
    value: match[3].trim().toLowerCase(),
    negated: operator.startsWith('!'),
  };
};

const parseIssueSearchExpression = (input: string): ParsedIssueSearchExpression | null => {
  const parts = input.trim().split(/\s+(AND|OR)\s+/i);
  if (!parts.length || parts.length % 2 === 0) return null;

  const orGroups: ParsedIssueSearchQuery[][] = [[]];
  for (let index = 0; index < parts.length; index += 2) {
    const query = parseIssueSearchQuery(parts[index]);
    if (!query) return null;
    if (index > 0 && parts[index - 1].toUpperCase() === 'OR') orGroups.push([]);
    orGroups[orGroups.length - 1].push(query);
  }
  return { orGroups };
};

const jiraPersonSearchValues = (person?: JiraPerson | null) => [
  person?.displayName,
  person?.name,
  person?.key,
  person?.accountId,
].filter((value): value is string => Boolean(value)).map(value => value.toLowerCase());

const normalizeFavoriteSearchQuery = (value: string) => value.trim().replace(/\s+/g, ' ').toLowerCase();

const loadFavoriteSearchQueries = (): string[] => {
  try {
    const parsed = JSON.parse(localStorage.getItem(FAVORITE_SEARCH_QUERIES_STORAGE_KEY) || '[]');
    if (!Array.isArray(parsed)) return [];
    const seen = new Set<string>();
    return parsed.filter((value): value is string => {
      if (typeof value !== 'string' || !value.trim()) return false;
      const normalized = normalizeFavoriteSearchQuery(value);
      if (seen.has(normalized)) return false;
      seen.add(normalized);
      return true;
    });
  } catch {
    return [];
  }
};

const issueStorageKey = (issue: { key: string; instance_id: number }) => `${issue.instance_id}:${issue.key}`;

const isUnavailableIssue = (issue: Partial<JiraIssue> | null | undefined) =>
  Boolean(
    issue?.favorite_unavailable ||
    (Array.isArray(issue?.errorMessages) && issue.errorMessages.length > 0) ||
    !issue?.fields
  );

interface JiraIssueCardProps {
  issue: JiraIssue;
  type: 'assigned' | 'mentioned' | 'reported';
  isUpdated: boolean;
  instanceName?: string;
  showInstanceName: boolean;
  isFavorite: boolean;
  isUnavailable: boolean;
  isClosed: boolean;
  personRole: DashboardPersonRole;
  onOpen: (issue: JiraIssue) => void;
  onToggleFavorite: (issue: JiraIssue) => void;
}

const JiraIssueCard = memo(function JiraIssueCard({
  issue,
  type,
  isUpdated,
  instanceName,
  showInstanceName,
  isFavorite,
  isUnavailable,
  isClosed,
  personRole,
  onOpen,
  onToggleFavorite,
}: JiraIssueCardProps) {
  const issuePriority = issue.fields?.priority?.name;
  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, scale: 0.9 }}>
      <div className={`issue-card ${type === 'mentioned' ? 'mentioned' : ''} ${type === 'reported' ? 'reported' : ''} ${isUpdated ? 'has-update' : ''}`} onClick={() => onOpen(issue)}>
        <button
          className={`favorite-star-button ${isFavorite ? 'active' : ''}`}
          title={isFavorite ? '즐겨찾기 해제' : '즐겨찾기'}
          onClick={(event) => {
            event.stopPropagation();
            onToggleFavorite(issue);
          }}
        >
          <Star size={17} fill={isFavorite ? '#f1c40f' : 'none'} />
        </button>
        <div className="issue-header" style={{alignItems: 'center', justifyContent: 'space-between', display: 'flex'}}>
          <span className="issue-key">
            {showInstanceName && instanceName && <span className="instance-badge">{instanceName}</span>}
            {type === 'mentioned' && '📢 '}{type === 'reported' && '👀 '}{type === 'assigned' && '📅 '}{issue.key}
          </span>
          <span className="status-badge" style={{marginTop: 0}}>
            {isUnavailable ? '삭제 됨' : isClosed ? '닫힘(jiraauto)' : issue.fields?.status?.name}
          </span>
        </div>
        <div className="issue-summary">{issue.fields?.summary}</div>
        <div className="issue-footer" style={{marginTop: 'auto'}}>
          <div className="issue-assignee" style={{fontSize: '12px', fontWeight: 600, color: 'var(--text-secondary)'}}>
            <span>
              {personRole === 'reporter'
                ? issue.fields?.reporter?.displayName || issue.fields?.reporter?.name || '보고자 없음'
                : issue.fields?.assignee?.displayName || issue.fields?.assignee?.name || '할당 안됨'}
            </span>
          </div>
          <div style={{display: 'flex', alignItems: 'center', gap: '8px'}}>
            {issuePriority && (
              <Flag
                size={16}
                color={priorityColor(issuePriority)}
                fill={priorityColor(issuePriority)}
                aria-label={`우선순위: ${issuePriority}`}
              >
                <title>{`우선순위: ${issuePriority}`}</title>
              </Flag>
            )}
            <span className="issue-date" style={{fontSize: '12px', color: 'var(--text-secondary)'}}>{new Date(issue.fields?.updated || issue.fields?.created || 0).toLocaleDateString()}</span>
          </div>
        </div>
      </div>
    </motion.div>
  );
});

const getUnavailableReason = (data: unknown, fallback = 'Jira 이슈를 찾을 수 없습니다.') => {
  const record = asRecord(data);
  if (Array.isArray(record?.errorMessages) && record.errorMessages.length > 0) return record.errorMessages.join(', ');
  if (typeof record?.message === 'string' && record.message.trim()) return record.message;
  if (typeof record?.detail === 'string' && record.detail.trim()) return record.detail;
  return fallback;
};

const getUpdatedTime = (value: string | undefined) => {
  if (!value) return 0;
  const time = new Date(value).getTime();
  return Number.isFinite(time) ? time : 0;
};

const isReadUpdate = (readValue: string | undefined, updateValue: string | undefined) =>
  Boolean(readValue && updateValue && getUpdatedTime(readValue) >= getUpdatedTime(updateValue));

const isSameJiraUser = (left?: JiraPerson | null, right?: JiraPerson | null) => {
  if (!left || !right) return false;
  const pairs: Array<[string | undefined, string | undefined]> = [
    [left.accountId, right.accountId],
    [left.name, right.name],
    [left.key, right.key],
    [left.displayName, right.displayName],
  ];
  return pairs.some(([a, b]) => Boolean(a && b && a === b));
};

const getLatestIssueActor = (detail: JiraIssueDetail | null | undefined): JiraPerson | null => {
  if (!detail) return null;
  const candidates: Array<{ at: number; actor?: JiraPerson | null }> = [];

  detail.changelog?.histories?.forEach(history => {
    candidates.push({ at: getUpdatedTime(history.created), actor: history.author });
  });
  detail.fields.comment?.comments?.forEach(comment => {
    candidates.push({
      at: getUpdatedTime(comment.updated || comment.created),
      actor: comment.updateAuthor || comment.author,
    });
  });

  candidates.sort((left, right) => right.at - left.at);
  return candidates.find(candidate => candidate.at > 0 && candidate.actor)?.actor || null;
};

const normalizeJiraUserSuggestion = (value: unknown): JiraUserSuggestion | null => {
  const user = asRecord(value);
  if (!user) return null;
  const id = [user.accountId, user.name, user.key].find(item => typeof item === 'string' && item.trim()) as string | undefined;
  const display = [user.displayName, user.name, user.key, user.accountId].find(item => typeof item === 'string' && item.trim()) as string | undefined;
  if (!id || !display) return null;
  return {
    id,
    display,
    name: typeof user.name === 'string' ? user.name : undefined,
    key: typeof user.key === 'string' ? user.key : undefined,
    accountId: typeof user.accountId === 'string' ? user.accountId : undefined,
  };
};

const parseWorklogTime = (input: string, allowZero = false): { ok: boolean; normalized?: string; minutes?: number; error?: string } => {
  const value = input.trim().toLowerCase();
  if (!value) return { ok: false, error: '작업한 시간을 입력하세요.' };
  const source = /^\d+$/.test(value) ? `${value}m` : value.replace(/\s+/g, '');
  const matches = Array.from(source.matchAll(/(\d+)([wdhm])/g));
  if (!matches.length || matches.map(m => m[0]).join('') !== source) {
    return { ok: false, error: '시간 형식이 올바르지 않습니다. 예: 70, 1h 10m, 1w3h' };
  }
  const unitMinutes: Record<string, number> = { w: 5 * 8 * 60, d: 8 * 60, h: 60, m: 1 };
  const totalMinutes = matches.reduce((sum, match) => sum + Number(match[1]) * unitMinutes[match[2]], 0);
  if (totalMinutes <= 0 && !allowZero) return { ok: false, error: '작업한 시간은 0보다 커야 합니다.' };

  let rest = totalMinutes;
  const weeks = Math.floor(rest / unitMinutes.w); rest %= unitMinutes.w;
  const days = Math.floor(rest / unitMinutes.d); rest %= unitMinutes.d;
  const hours = Math.floor(rest / unitMinutes.h); rest %= unitMinutes.h;
  const parts = [
    weeks ? `${weeks}w` : '',
    days ? `${days}d` : '',
    hours ? `${hours}h` : '',
    rest ? `${rest}m` : '',
  ].filter(Boolean);
  return { ok: true, minutes: totalMinutes, normalized: parts.join(' ') || '0m' };
};

const toLocalDateTimeInputValue = (date = new Date()) => {
  const offset = date.getTimezoneOffset();
  const local = new Date(date.getTime() - offset * 60000);
  return local.toISOString().slice(0, 16);
};

const getAutoStartedValue = (minutes?: number) => {
  if (!minutes || minutes <= 0) return toLocalDateTimeInputValue();
  return toLocalDateTimeInputValue(new Date(Date.now() - minutes * 60000));
};

const toJiraStartedValue = (localDateTime: string) => {
  const date = localDateTime ? new Date(localDateTime) : new Date();
  const pad = (n: number) => String(Math.abs(Math.trunc(n))).padStart(2, '0');
  const offsetMinutes = -date.getTimezoneOffset();
  const sign = offsetMinutes >= 0 ? '+' : '-';
  const hours = Math.floor(Math.abs(offsetMinutes) / 60);
  const minutes = Math.abs(offsetMinutes) % 60;
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}:00.000${sign}${pad(hours)}${pad(minutes)}`;
};

type MentionSearch = (query: string, callback: (users: JiraUserSuggestion[]) => void) => void | Promise<void>;

const commentMentionsStyle = {
  ...mentionsStyle,
  control: { ...mentionsStyle.control, backgroundColor: 'transparent' },
  '&multiLine': {
    ...mentionsStyle['&multiLine'],
    input: {
      ...mentionsStyle['&multiLine'].input,
      backgroundColor: 'var(--card-bg)',
      border: '1px solid rgba(0,0,0,0.1)',
    },
  },
};

const CommentComposer = memo(function CommentComposer({
  issue,
  searchUsers,
  onSubmitted,
}: {
  issue: JiraIssue;
  searchUsers: MentionSearch;
  onSubmitted: () => void | Promise<void>;
}) {
  const [text, setText] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  const submit = async () => {
    if (!text.trim() || submitting) return;
    setSubmitting(true);
    setError('');
    try {
      const res = await fetch(`${API_BASE}/issues/${issue.key}/comments?instance_id=${issue.instance_id}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ body: text }),
      });
      if (!res.ok) throw new Error('코멘트 추가에 실패했습니다.');
      setText(current => current === text ? '' : current);
      await onSubmitted();
    } catch (submitError) {
      setError(errorMessage(submitError, '코멘트 추가에 실패했습니다.'));
    } finally {
      setSubmitting(false);
    }
  };

  const handlePasteImage = async (event: React.ClipboardEvent) => {
    const items = event.clipboardData?.items;
    if (!items) return;
    for (const item of items) {
      if (!item.type.includes('image')) continue;
      event.preventDefault();
      const file = item.getAsFile();
      if (!file) continue;
      const formData = new FormData();
      formData.append('file', file);
      try {
        const res = await fetch(`${API_BASE}/issues/${issue.key}/attachments?instance_id=${issue.instance_id}`, { method: 'POST', body: formData });
        if (!res.ok) throw new Error('이미지 업로드에 실패했습니다.');
        const data = await res.json();
        const filename = data.data?.[0]?.filename || file.name;
        setText(previous => `${previous}\n!${filename}!\n`);
      } catch (uploadError) {
        setError(errorMessage(uploadError, '이미지 업로드에 실패했습니다.'));
      }
    }
  };

  return (
    <div className="glass-panel" style={{padding: '20px', marginBottom: '20px'}}>
      <div onPaste={handlePasteImage}>
        <MentionsInput
          value={text}
          onChange={(_, newValue) => setText(newValue)}
          onKeyDown={event => {
            if (event.altKey && event.key === 'Enter') {
              event.preventDefault();
              void submit();
            }
          }}
          style={commentMentionsStyle}
          placeholder="@를 입력하여 팀원 멘션... (Alt+Enter로 즉시 작성)"
        >
          <Mention trigger="@" data={searchUsers} markup="@[__display__](__id__)" displayTransform={(_id, display) => display} className="mention-badge" appendSpaceOnAdd />
        </MentionsInput>
      </div>
      {error && <div style={{ marginTop: 10, color: '#d63031', fontSize: 13, fontWeight: 700 }}>{error}</div>}
      <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: '12px' }}>
        <button className="btn-premium" style={{whiteSpace: 'nowrap', opacity: submitting ? 0.6 : 1}} disabled={submitting} onClick={() => void submit()}>
          {submitting ? '처리 중...' : '코멘트 추가'}
        </button>
      </div>
    </div>
  );
});

const CommentEditor = memo(function CommentEditor({
  issue,
  comment,
  searchUsers,
  onCancel,
  onSaved,
}: {
  issue: JiraIssue;
  comment: JiraComment;
  searchUsers: MentionSearch;
  onCancel: () => void;
  onSaved: () => void | Promise<void>;
}) {
  const [text, setText] = useState(comment.body || '');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  const submit = async () => {
    if (!text.trim() || submitting) return;
    setSubmitting(true);
    setError('');
    try {
      const res = await fetch(`${API_BASE}/issues/${issue.key}/comments/${comment.id}?instance_id=${issue.instance_id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ body: text }),
      });
      if (!res.ok) throw new Error('코멘트 수정에 실패했습니다.');
      await onSaved();
    } catch (submitError) {
      setError(errorMessage(submitError, '코멘트 수정에 실패했습니다.'));
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="glass-panel" style={{padding: 15, width: '100%', minWidth: 300}}>
      <MentionsInput
        value={text}
        onChange={(_, newValue) => setText(newValue)}
        onKeyDown={event => {
          if (event.altKey && event.key === 'Enter') {
            event.preventDefault();
            void submit();
          }
        }}
        style={mentionsStyle}
        placeholder="코멘트 수정..."
      >
        <Mention trigger="@" data={searchUsers} markup="@[__display__](__id__)" displayTransform={(_id, display) => display} className="mention-badge" appendSpaceOnAdd />
      </MentionsInput>
      {error && <div style={{ marginTop: 10, color: '#d63031', fontSize: 13, fontWeight: 700 }}>{error}</div>}
      <div style={{display:'flex', justifyContent:'flex-end', gap:'8px', marginTop:'10px'}}>
        <button className="btn-secondary" onClick={onCancel} disabled={submitting}>취소</button>
        <button className="btn-premium" onClick={() => void submit()} disabled={submitting}>{submitting ? '저장 중...' : '저장'}</button>
      </div>
    </div>
  );
});

const WorklogPanel = memo(function WorklogPanel({
  issue,
  onUpdated,
}: {
  issue: JiraIssue;
  onUpdated: () => void | Promise<void>;
}) {
  const [open, setOpen] = useState(false);
  const [trackingLoading, setTrackingLoading] = useState(false);
  const [tracking, setTracking] = useState<TimeTrackingSnapshot | null>(null);
  const [historyOpen, setHistoryOpen] = useState(false);
  const [editingWorklogId, setEditingWorklogId] = useState<string | null>(null);
  const [editTime, setEditTime] = useState('');
  const [editComment, setEditComment] = useState('');
  const [editStarted, setEditStarted] = useState('');
  const [worklogActionId, setWorklogActionId] = useState<string | null>(null);
  const [time, setTime] = useState('');
  const [comment, setComment] = useState('');
  const [started, setStarted] = useState(() => toLocalDateTimeInputValue());
  const [startedTouched, setStartedTouched] = useState(false);
  const [adjustEstimate, setAdjustEstimate] = useState<'auto' | 'new' | 'leave'>('auto');
  const [newEstimate, setNewEstimate] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  const fetchTracking = async () => {
    setTrackingLoading(true);
    setError('');
    try {
      const res = await fetch(`${API_BASE}/issues/${issue.key}/timetracking?instance_id=${issue.instance_id}`);
      if (!res.ok) throw new Error('시간 추적 정보를 불러오지 못했습니다.');
      const nextTracking = await res.json() as TimeTrackingSnapshot;
      setTracking(nextTracking);
    } catch (trackingError) {
      setError(errorMessage(trackingError, '시간 추적 정보를 불러오지 못했습니다.'));
    } finally {
      setTrackingLoading(false);
    }
  };

  const handleTimeChange = (value: string) => {
    setTime(value);
    if (!startedTouched) {
      const parsed = parseWorklogTime(value);
      if (parsed.ok) setStarted(getAutoStartedValue(parsed.minutes));
    }
  };

  const submit = async () => {
    if (submitting) return;
    setError('');
    setMessage('');
    const parsedTime = parseWorklogTime(time);
    if (!parsedTime.ok || !parsedTime.normalized) {
      setError(parsedTime.error || '작업한 시간을 확인하세요.');
      return;
    }
    const payload: WorklogPayload = {
      timeSpent: parsedTime.normalized,
      comment: comment.trim(),
      started: toJiraStartedValue(started),
      adjustEstimate,
    };
    if (adjustEstimate === 'new') {
      const parsedEstimate = parseWorklogTime(newEstimate, true);
      if (!parsedEstimate.ok || !parsedEstimate.normalized) {
        setError(parsedEstimate.error || '새 남은 시간을 확인하세요.');
        return;
      }
      payload.newEstimate = parsedEstimate.normalized;
      setNewEstimate(parsedEstimate.normalized);
    }
    setSubmitting(true);
    try {
      const res = await fetch(`${API_BASE}/issues/${issue.key}/worklog?instance_id=${issue.instance_id}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(typeof data.detail === 'string' ? data.detail : '작업로그 등록에 실패했습니다.');
      setTime(current => current === time ? parsedTime.normalized! : current);
      setComment(current => current === comment ? '' : current);
      setMessage('작업로그가 추가되었습니다.');
      await fetchTracking();
      await onUpdated();
    } catch (submitError) {
      setError(errorMessage(submitError, '작업로그 등록에 실패했습니다.'));
    } finally {
      setSubmitting(false);
    }
  };

  const beginEdit = (entry: WorklogEntry) => {
    setEditingWorklogId(entry.id);
    setEditTime(entry.timeSpent);
    setEditComment(entry.comment || '');
    setEditStarted(entry.started ? toLocalDateTimeInputValue(new Date(entry.started)) : toLocalDateTimeInputValue());
    setError('');
    setMessage('');
  };

  const saveWorklog = async (entry: WorklogEntry) => {
    const parsedTime = parseWorklogTime(editTime);
    if (!parsedTime.ok || !parsedTime.normalized) {
      setError(parsedTime.error || '작업한 시간을 확인하세요.');
      return;
    }
    setWorklogActionId(entry.id);
    setError('');
    setMessage('');
    try {
      const res = await fetch(`${API_BASE}/issues/${issue.key}/worklog/${entry.id}?instance_id=${issue.instance_id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          timeSpent: parsedTime.normalized,
          comment: editComment.trim(),
          started: toJiraStartedValue(editStarted),
        }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(typeof data.detail === 'string' ? data.detail : '작업로그 수정에 실패했습니다.');
      setEditingWorklogId(current => current === entry.id ? null : current);
      setMessage('작업로그가 수정되었습니다.');
      await fetchTracking();
      await onUpdated();
    } catch (saveError) {
      setError(errorMessage(saveError, '작업로그 수정에 실패했습니다.'));
    } finally {
      setWorklogActionId(null);
    }
  };

  const removeWorklog = async (entry: WorklogEntry) => {
    if (!window.confirm(`${entry.timeSpent} 작업로그를 삭제하시겠습니까?`)) return;
    setWorklogActionId(entry.id);
    setError('');
    setMessage('');
    try {
      const res = await fetch(`${API_BASE}/issues/${issue.key}/worklog/${entry.id}?instance_id=${issue.instance_id}`, { method: 'DELETE' });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(typeof data.detail === 'string' ? data.detail : '작업로그 삭제에 실패했습니다.');
      setEditingWorklogId(current => current === entry.id ? null : current);
      setMessage('작업로그가 삭제되었습니다.');
      await fetchTracking();
      await onUpdated();
    } catch (deleteError) {
      setError(errorMessage(deleteError, '작업로그 삭제에 실패했습니다.'));
    } finally {
      setWorklogActionId(null);
    }
  };

  const timePreview = time.trim() ? parseWorklogTime(time) : null;
  const estimatePreview = newEstimate.trim() ? parseWorklogTime(newEstimate, true) : null;
  const tracked = tracking?.timetracking || {};

  return (
    <div className="glass-panel" style={{ padding: 18, marginBottom: 20 }}>
      <button
        className="btn-secondary"
        onClick={() => {
          const nextOpen = !open;
          setOpen(nextOpen);
          if (nextOpen) {
            setStarted(toLocalDateTimeInputValue());
            setStartedTouched(false);
            void fetchTracking();
          }
        }}
        style={{ width: '100%', display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 12px' }}
      >
        <span>시간 추적 / 작업로그</span>
        <span>{open ? '접기' : '펼치기'}</span>
      </button>
      {open && (
        <div style={{ marginTop: 16 }}>
          <div className="apple-meta-grid" style={{ marginBottom: 16 }}>
            <div className="apple-meta-item"><span className="apple-meta-label">원래 추정</span><span className="apple-meta-value">{trackingLoading ? '불러오는 중...' : tracked.originalEstimate || '없음'}</span></div>
            <div className="apple-meta-item"><span className="apple-meta-label">남은 시간</span><span className="apple-meta-value">{trackingLoading ? '불러오는 중...' : tracked.remainingEstimate || '없음'}</span></div>
            <div className="apple-meta-item"><span className="apple-meta-label">기록된 시간</span><span className="apple-meta-value">{trackingLoading ? '불러오는 중...' : tracked.timeSpent || '없음'}</span></div>
            <div className="apple-meta-item"><span className="apple-meta-label">작업로그 수</span><span className="apple-meta-value">{trackingLoading ? '불러오는 중...' : `${tracking?.worklog?.total ?? 0}개`}</span></div>
          </div>
          <div className="create-issue-grid">
            <label>
              <span className="apple-meta-label">작업한 시간 *</span>
              <input className="glass-input" value={time} onChange={event => handleTimeChange(event.target.value)} onBlur={() => { const parsed = parseWorklogTime(time); if (parsed.ok && parsed.normalized) setTime(parsed.normalized); }} placeholder="예: 70, 1h 10m, 1w3h" />
              {timePreview && <span style={{ marginTop: 6, fontSize: 12, color: timePreview.ok ? 'var(--text-secondary)' : '#d63031' }}>{timePreview.ok ? `변환: ${timePreview.normalized}` : timePreview.error}</span>}
            </label>
            <label>
              <span className="apple-meta-label">작업 시작 시각</span>
              <input className="glass-input" type="datetime-local" value={started} onChange={event => { setStartedTouched(true); setStarted(event.target.value); }} />
              <span style={{ marginTop: 6, fontSize: 12, color: 'var(--text-secondary)' }}>{startedTouched ? '직접 수정됨: 작업한 시간을 바꿔도 시작 시각은 유지됩니다.' : '자동 계산됨: 현재 시각에서 작업한 시간을 뺀 값입니다.'}</span>
              {startedTouched && <button type="button" className="btn-secondary" style={{ marginTop: 8, alignSelf: 'flex-start', padding: '5px 10px' }} onClick={() => { const parsed = parseWorklogTime(time); setStarted(getAutoStartedValue(parsed.ok ? parsed.minutes : undefined)); setStartedTouched(false); }}>자동 계산 다시 적용</button>}
            </label>
          </div>
          <label style={{ display: 'flex', flexDirection: 'column', gap: 8, marginTop: 14 }}>
            <span className="apple-meta-label">작업 설명</span>
            <textarea className="glass-input" value={comment} onChange={event => setComment(event.target.value)} placeholder="선택 입력" style={{ minHeight: 80, resize: 'vertical' }} />
          </label>
          <div style={{ marginTop: 16 }}>
            <span className="apple-meta-label" style={{ display: 'block', marginBottom: 8 }}>남은 시간 처리</span>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 12, color: 'var(--text-primary)', fontSize: 13 }}>
              <label style={{ display: 'flex', alignItems: 'center', gap: 6 }}><input type="radio" checked={adjustEstimate === 'auto'} onChange={() => setAdjustEstimate('auto')} /> 자동 감소</label>
              <label style={{ display: 'flex', alignItems: 'center', gap: 6 }}><input type="radio" checked={adjustEstimate === 'new'} onChange={() => setAdjustEstimate('new')} /> 남은 시간 직접 설정</label>
              <label style={{ display: 'flex', alignItems: 'center', gap: 6 }}><input type="radio" checked={adjustEstimate === 'leave'} onChange={() => setAdjustEstimate('leave')} /> 변경 안 함</label>
            </div>
            {adjustEstimate === 'new' && <label style={{ display: 'flex', flexDirection: 'column', gap: 8, marginTop: 12 }}><span className="apple-meta-label">새 남은 시간</span><input className="glass-input" value={newEstimate} onChange={event => setNewEstimate(event.target.value)} onBlur={() => { const parsed = parseWorklogTime(newEstimate, true); if (parsed.ok && parsed.normalized) setNewEstimate(parsed.normalized); }} placeholder="예: 0, 30m, 2h" />{estimatePreview && <span style={{ fontSize: 12, color: estimatePreview.ok ? 'var(--text-secondary)' : '#d63031' }}>{estimatePreview.ok ? `변환: ${estimatePreview.normalized}` : estimatePreview.error}</span>}</label>}
          </div>
          {error && <div style={{ marginTop: 12, color: '#d63031', fontSize: 13, fontWeight: 700 }}>{error}</div>}
          {message && <div style={{ marginTop: 12, color: '#078f55', fontSize: 13, fontWeight: 700 }}>{message}</div>}
          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 10, marginTop: 16 }}>
            <button className="btn-secondary" onClick={() => void fetchTracking()} disabled={trackingLoading}>새로고침</button>
            <button className="btn-premium" onClick={() => void submit()} disabled={submitting} style={{ opacity: submitting ? 0.65 : 1 }}>{submitting ? '등록 중...' : '작업로그 추가'}</button>
          </div>
          <div style={{ marginTop: 18, paddingTop: 16, borderTop: '1px solid rgba(127, 140, 141, 0.22)' }}>
            <button
              type="button"
              className="btn-secondary"
              onClick={() => setHistoryOpen(previous => !previous)}
              style={{ width: '100%', display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '9px 12px' }}
            >
              <span>작업 기록 ({tracking?.worklog?.total ?? 0})</span>
              <span>{historyOpen ? '접기' : '펼치기'}</span>
            </button>
            {historyOpen && (
              <div style={{ marginTop: 10, display: 'flex', flexDirection: 'column', gap: 10 }}>
                {trackingLoading && <div style={{ padding: 12, color: 'var(--text-secondary)', fontSize: 13 }}>작업 기록을 불러오는 중...</div>}
                {!trackingLoading && !(tracking?.worklog?.worklogs?.length) && <div style={{ padding: 12, color: 'var(--text-secondary)', fontSize: 13 }}>작성된 작업 기록이 없습니다.</div>}
                {tracking?.worklog?.worklogs?.map(entry => {
                  const isEditing = editingWorklogId === entry.id;
                  const actionPending = worklogActionId === entry.id;
                  const authorName = entry.author.displayName || entry.author.name || entry.author.key || '알 수 없음';
                  const startedLabel = entry.started && !Number.isNaN(new Date(entry.started).getTime())
                    ? new Date(entry.started).toLocaleString()
                    : '-';
                  return (
                    <div key={entry.id} className="glass-panel" style={{ padding: 13, margin: 0 }}>
                      {isEditing ? (
                        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                          <div className="create-issue-grid">
                            <label><span className="apple-meta-label">작업한 시간</span><input className="glass-input" value={editTime} onChange={event => setEditTime(event.target.value)} /></label>
                            <label><span className="apple-meta-label">작업 시작 시각</span><input className="glass-input" type="datetime-local" value={editStarted} onChange={event => setEditStarted(event.target.value)} /></label>
                          </div>
                          <label style={{ display: 'flex', flexDirection: 'column', gap: 7 }}><span className="apple-meta-label">작업 설명</span><textarea className="glass-input" value={editComment} onChange={event => setEditComment(event.target.value)} style={{ minHeight: 64, resize: 'vertical' }} /></label>
                          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8 }}>
                            <button type="button" className="btn-secondary" onClick={() => setEditingWorklogId(null)} disabled={actionPending}>취소</button>
                            <button type="button" className="btn-premium" onClick={() => void saveWorklog(entry)} disabled={actionPending}>{actionPending ? '저장 중...' : '저장'}</button>
                          </div>
                        </div>
                      ) : (
                        <>
                          <div style={{ display: 'flex', justifyContent: 'space-between', gap: 12, alignItems: 'flex-start' }}>
                            <div>
                              <div style={{ color: 'var(--text-primary)', fontWeight: 700 }}>{entry.timeSpent || `${Math.round(entry.timeSpentSeconds / 60)}m`}</div>
                              <div style={{ marginTop: 4, color: 'var(--text-secondary)', fontSize: 12 }}>{authorName} · {startedLabel}</div>
                            </div>
                            {entry.editable && (
                              <div style={{ display: 'flex', gap: 6, flexShrink: 0 }}>
                                <button type="button" className="btn-secondary" style={{ padding: '5px 9px' }} onClick={() => beginEdit(entry)} disabled={actionPending}>수정</button>
                                <button type="button" className="btn-secondary" style={{ padding: '5px 9px', color: '#d63031' }} onClick={() => void removeWorklog(entry)} disabled={actionPending}>{actionPending ? '처리 중...' : '삭제'}</button>
                              </div>
                            )}
                          </div>
                          <div style={{ marginTop: 9, color: entry.comment ? 'var(--text-primary)' : 'var(--text-secondary)', fontSize: 13, whiteSpace: 'pre-wrap', overflowWrap: 'anywhere' }}>{entry.comment || '작업 설명 없음'}</div>
                        </>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
});

const loadFavoriteIssueMap = <T,>(storageKey: string): Record<string, T> => {
  try {
    const raw = localStorage.getItem(storageKey);
    if (!raw) return {};
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : {};
  } catch {
    localStorage.removeItem(storageKey);
    return {};
  }
};

const loadJsonObject = <T,>(storageKey: string): Record<string, T> => {
  try {
    const raw = localStorage.getItem(storageKey);
    if (!raw) return {};
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : {};
  } catch {
    localStorage.removeItem(storageKey);
    return {};
  }
};

const dashboardStateMaps = (states: Record<string, DashboardIssueState>) => {
  const read: Record<string, string> = {};
  const unread: Record<string, string> = {};
  const observed: Record<string, string> = {};
  const jiraautoClosed: Record<string, string> = {};
  Object.entries(states).forEach(([key, state]) => {
    if (state.read_updated_at) read[key] = state.read_updated_at;
    if (state.unread_updated_at) unread[key] = state.unread_updated_at;
    if (state.observed_updated_at) observed[key] = state.observed_updated_at;
    if (state.jiraauto_closed_at) jiraautoClosed[key] = state.jiraauto_closed_at;
  });
  return { read, unread, observed, jiraautoClosed };
};

const isDoneIssue = (issue: JiraIssue | null) => {
  if (!issue) return false;
  if (issue.fields?.status?.statusCategory?.key === 'done') return true;
  const statusName = (issue.fields?.status?.name || '').trim().toLowerCase();
  return ['done', 'closed', 'resolved', '완료', '종료', '닫힘', '해결됨'].includes(statusName);
};

const transitionsExcludingCurrentStatus = (transitions: JiraTransition[], issue: JiraIssue | null) => {
  const currentStatus = issue?.fields?.status;
  if (!currentStatus) return transitions;
  const currentId = String(currentStatus.id || '').trim();
  const currentName = currentStatus.name.trim().toLocaleLowerCase();
  return transitions.filter(transition => {
    const targetId = String(transition.to?.id || '').trim();
    if (currentId && targetId) return targetId !== currentId;
    return transition.to?.name?.trim().toLocaleLowerCase() !== currentName;
  });
};

import { useDashboardContext } from '../contexts/DashboardContext';

export default function DashboardPage() {
  const {
    activeModal,
    aiSummary,
    aiSummaryError,
    aiSummaryLoading,
    aiSummaryMeta,
    applyCreateDefaults,
    applyFavoriteSearchQuery,
    applySearchHelpItem,
    assignedIssues,
    assignedUnreadCount,
    availableTransitions,
    canUseManualOriginalEstimate,
    canUseWorklogPanel,
    closeCreateIssueModal,
    createAssigneeLoading,
    createAssigneeMode,
    createAssigneeQuery,
    createAssigneeSelected,
    createAssigneeSuggestions,
    createAssigneeValue,
    createComponent,
    createDescription,
    createError,
    createIssueType,
    createMetadata,
    createMetadataLoading,
    createModalOpen,
    createModalPointerStartedOnOverlayRef,
    createSelectedProject,
    createSubmitting,
    createSummary,
    currentCreateUser,
    currentSelectedUser,
    datePreset,
    detailError,
    detailLoading,
    detailSession,
    detailSessionRef,
    editingCommentId,
    endDate,
    favoriteSearchQueries,
    fetchIssueDetail,
    fetchIssues,
    formatDateTime,
    generateAiSummary,
    handleEndDateChange,
    handleOpenLinkedIssue,
    handleStartDateChange,
    handleStatusChange,
    hasUnreadVisibleIssue,
    includeClosed,
    instanceFilter,
    instanceList,
    isCurrentSearchQueryFavorite,
    isFavoriteIssue,
    isOriginalEstimateTarget,
    issueDetail,
    issues,
    jiraautoClosedIssues,
    lastUpdated,
    linkedIssueError,
    linkedIssueLoading,
    loading,
    markVisibleIssuesAsRead,
    mentionedIssues,
    mentionedUnreadCount,
    metaKey,
    modalPointerStartedOnOverlayRef,
    openCreateIssueModal,
    originalEstimateAuto,
    originalEstimateError,
    originalEstimateMessage,
    originalEstimateSubmitting,
    projectFilter,
    projectList,
    removeFavoriteSearchQuery,
    renderIssueCard,
    renderJiraCommentHtml,
    renderJiraDescriptionHtml,
    reportedIssues,
    reportedUnreadCount,
    searchCreateMentionUsers,
    searchHelpItems,
    searchHelpOpen,
    searchHelpTitle,
    searchInputRef,
    searchQuery,
    searchUsers,
    selectedCreateMeta,
    selectedHasOriginalEstimate,
    selectedIssue,
    setActiveModal,
    setCreateAssigneeMode,
    setCreateAssigneeQuery,
    setCreateAssigneeSelected,
    setCreateAssigneeSuggestions,
    setCreateComponent,
    setCreateDescription,
    setCreateIssueType,
    setCreateSelectedProject,
    setCreateSummary,
    setDatePreset,
    setEditingCommentId,
    setIncludeClosed,
    setInstanceFilter,
    setProjectFilter,
    setSearchHelpOpen,
    setSearchQuery,
    setToastMessage,
    sortIssues,
    startDate,
    statusChangeError,
    statusChangeSubmitting,
    submitCreateIssue,
    submitOriginalEstimate,
    toastMessage,
    toggleFavoriteIssue,
    toggleFavoriteSearchQuery,
    transitionUnavailable,
    userMap
  } = useDashboardContext();
  const detailModalRef = useRef<HTMLDivElement>(null);

  return (
    <div className="dashboard-glass-container">
      {toastMessage && (
        <button
          type="button"
          className="settings-toast"
          onClick={() => setToastMessage('')}
          title="닫기"
        >
          {toastMessage}
        </button>
      )}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 20, marginBottom: 30 }}>
        <div style={{display:'flex', gap:'12px', alignItems:'center', flexWrap: 'nowrap', width: '100%', boxSizing: 'border-box', background: 'var(--card-bg)', padding: '12px 16px', borderRadius: '12px', boxShadow: '0 4px 15px rgba(0,0,0,0.05)', overflowX: 'auto', overflowY: 'hidden'}}>
          <div style={{display: 'flex', alignItems: 'center', gap: 5, flexShrink: 0}}>
            <span style={{fontSize: 13, fontWeight: 700, color: 'var(--text-secondary)'}}>계정</span>
            <select className="glass-input" style={{width: 'auto', padding: '6px 12px'}} value={instanceFilter} onChange={e => {setInstanceFilter(e.target.value); localStorage.setItem('dashboardInstanceFilter', e.target.value); setProjectFilter('all');}}>
              <option value="all">모든 계정</option>
              {instanceList.map(inst => <option key={inst.id} value={inst.id}>{formatJiraInstanceName(inst.name, inst.deployment_type)}</option>)}
            </select>
          </div>

          <div style={{display: 'flex', alignItems: 'center', gap: 5, flexShrink: 0}}>
            <span style={{fontSize: 13, fontWeight: 700, color: 'var(--text-secondary)'}}>기간</span>
            <select className="glass-input" style={{width: 'auto', padding: '6px 12px'}} value={datePreset} onChange={(e) => {setDatePreset(e.target.value); localStorage.setItem('datePreset', e.target.value)}}>
              <option value="1">1일</option><option value="7">7일</option><option value="14">14일</option><option value="30">30일</option><option value="90">90일</option><option value="all">전체</option><option value="custom">직접입력</option>
            </select>
            {datePreset === 'custom' && (
              <div style={{display: 'flex', alignItems: 'center', gap: 5, marginLeft: 5, flexShrink: 0}}>
                <input type="date" className="glass-input" style={{padding: '6px', fontSize: 12}} value={startDate} onChange={e => handleStartDateChange(e.target.value)} />
                <span style={{color: '#ccc'}}>~</span>
                <input type="date" className="glass-input" style={{padding: '6px', fontSize: 12}} value={endDate} onChange={e => handleEndDateChange(e.target.value)} />
              </div>
            )}
          </div>

          <div style={{display: 'flex', alignItems: 'center', gap: 5, flexShrink: 0}}>
            <span style={{fontSize: 13, fontWeight: 700, color: 'var(--text-secondary)'}}>프로젝트</span>
            <select className="glass-input" style={{width: 'auto', padding: '6px 12px'}} value={projectFilter} onChange={e => {setProjectFilter(e.target.value); localStorage.setItem('projectFilter', e.target.value)}}>
              <option value="all">모든 프로젝트</option>
              {projectList.map(p => <option key={p} value={p}>{p}</option>)}
            </select>
          </div>

          <label
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: 6,
              fontSize: 13,
              fontWeight: 700,
              color: 'var(--text-secondary)',
              cursor: 'pointer',
              whiteSpace: 'nowrap',
              flexShrink: 0
            }}
          >
            <input
              type="checkbox"
              checked={includeClosed}
              onChange={e => {
                setIncludeClosed(e.target.checked);
                localStorage.setItem('dashboardIncludeClosedIssues', e.target.checked ? 'true' : 'false');
                localStorage.setItem('includeClosedIssues', e.target.checked ? 'true' : 'false');
              }}
              style={{cursor: 'pointer'}}
            />
            완료/닫힘 포함
          </label>
          
          <div style={{display: 'flex', alignItems: 'center', gap: 10, marginLeft: 'auto', flexWrap: 'nowrap', flexShrink: 0}}>
            <div style={{display: 'flex', alignItems: 'center', gap: 8, whiteSpace: 'nowrap', flexShrink: 0}}>
               <span style={{ fontSize: '11px', color: 'var(--text-secondary)' }}>최종 갱신: {lastUpdated.toLocaleTimeString()}</span>
               <button className="btn-premium" style={{padding: '6px 12px'}} onClick={markVisibleIssuesAsRead} disabled={!hasUnreadVisibleIssue} title="현재 표시된 티켓 모두 읽음"><CheckCheck size={14} /></button>
               <button className="btn-premium" style={{padding: '6px 12px'}} onClick={fetchIssues}><RefreshCcw size={14} /></button>
            </div>
          </div>
        </div>
        <div style={{width: '100%'}}>
          <div style={{position: 'relative', width: '100%'}}>
            <div style={{display: 'flex', alignItems: 'center', gap: 8}}>
              <div style={{position: 'relative', flex: 1, minWidth: 0}}>
                <Search size={16} style={{position: 'absolute', left: 14, top: '50%', transform: 'translateY(-50%)', color: 'var(--text-secondary)', pointerEvents: 'none'}} />
                <input
                  ref={searchInputRef}
                  className="glass-input"
                  type="search"
                  value={searchQuery}
                  onFocus={() => setSearchHelpOpen(true)}
                  onClick={() => setSearchHelpOpen(true)}
                  onBlur={() => setSearchHelpOpen(false)}
                  onKeyDown={event => {
                    if (event.key === 'Enter' || event.key === 'Escape') {
                      if (event.key === 'Escape') event.preventDefault();
                      setSearchHelpOpen(false);
                    }
                  }}
                  onChange={e => {
                    setSearchQuery(e.target.value);
                    localStorage.setItem('dashboardSearchQuery', e.target.value);
                  }}
                  placeholder="티켓 번호, 제목, 사용자, 컴포넌트 또는 레이블 검색"
                  style={{width: '100%', padding: '10px 14px 10px 40px', boxSizing: 'border-box'}}
                />
              </div>
              <button
                type="button"
                className={`query-favorite-button ${isCurrentSearchQueryFavorite ? 'active' : ''}`}
                disabled={!searchQuery.trim()}
                aria-label={isCurrentSearchQueryFavorite ? '쿼리 즐겨찾기 삭제' : '쿼리 즐겨찾기 추가'}
                aria-pressed={isCurrentSearchQueryFavorite}
                title={isCurrentSearchQueryFavorite ? '쿼리 즐겨찾기 삭제' : '쿼리 즐겨찾기 추가'}
                onMouseDown={event => event.preventDefault()}
                onClick={toggleFavoriteSearchQuery}
              >
                <Star
                  size={17}
                  fill={isCurrentSearchQueryFavorite ? '#f1c40f' : 'none'}
                  stroke={isCurrentSearchQueryFavorite ? 'none' : 'currentColor'}
                  strokeWidth={2}
                />
              </button>
            </div>
            {searchHelpOpen && (
              <div
                role="listbox"
                aria-label="검색 쿼리 도움말"
                style={{
                  position: 'absolute',
                  top: 'calc(100% + 6px)',
                  left: 0,
                  width: 'clamp(320px, 48vw, 560px)',
                  maxWidth: '100%',
                  maxHeight: 'min(420px, calc(100vh - 180px))',
                  overflowY: 'auto',
                  boxSizing: 'border-box',
                  zIndex: 100,
                  padding: 10,
                  borderRadius: 10,
                  border: '1px solid rgba(127, 140, 141, 0.28)',
                  background: 'var(--card-bg)',
                  boxShadow: '0 12px 30px rgba(0, 0, 0, 0.18)',
                }}
              >
                {favoriteSearchQueries.length > 0 && (
                  <div style={{paddingBottom: 8, marginBottom: 8, borderBottom: '1px solid rgba(127, 140, 141, 0.2)'}}>
                    <div style={{padding: '2px 8px 6px', color: 'var(--text-secondary)', fontSize: 11, fontWeight: 700}}>
                      즐겨찾기 쿼리
                    </div>
                    {favoriteSearchQueries.map(query => (
                      <div
                        key={normalizeFavoriteSearchQuery(query)}
                        className={`query-favorite-help-row ${searchQuery === query ? 'selected' : ''}`}
                        role="option"
                        aria-selected={searchQuery === query}
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: 4,
                          width: '100%',
                          borderRadius: 7,
                        }}
                      >
                        <button
                          type="button"
                          className="query-favorite-list-remove"
                          aria-label={`${query} 즐겨찾기 삭제`}
                          title="쿼리 즐겨찾기 삭제"
                          onMouseDown={event => {
                            event.preventDefault();
                            event.stopPropagation();
                            removeFavoriteSearchQuery(query);
                          }}
                        >
                          <Star size={17} fill="#f1c40f" stroke="none" strokeWidth={2} />
                        </button>
                        <button
                          type="button"
                          title={query}
                          onMouseDown={event => {
                            event.preventDefault();
                            applyFavoriteSearchQuery(query);
                          }}
                          style={{
                            flex: 1,
                            minWidth: 0,
                            padding: '8px',
                            border: 0,
                            borderRadius: 7,
                            background: 'transparent',
                            color: 'var(--text-primary)',
                            fontFamily: 'inherit',
                            fontSize: 12,
                            textAlign: 'left',
                            cursor: 'pointer',
                            overflow: 'hidden',
                            textOverflow: 'ellipsis',
                            whiteSpace: 'nowrap',
                          }}
                        >
                          {query}
                        </button>
                      </div>
                    ))}
                  </div>
                )}
                <div style={{padding: '2px 8px 8px'}}>
                  <div style={{color: 'var(--text-primary)', fontSize: 12, fontWeight: 700}}>{searchHelpTitle}</div>
                  <div style={{marginTop: 3, color: 'var(--text-secondary)', fontSize: 11}}>
                    쿼리를 사용하지 않으면 기존처럼 전체 텍스트를 검색합니다.
                  </div>
                </div>
                {searchHelpItems.map(item => (
                  <button
                    key={item.token}
                    type="button"
                    className="query-search-help-item"
                    role="option"
                    aria-selected="false"
                    onMouseDown={event => {
                      event.preventDefault();
                      applySearchHelpItem(item.token);
                    }}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      gap: 12,
                      width: '100%',
                      padding: '8px',
                      border: 0,
                      borderRadius: 7,
                      color: 'var(--text-primary)',
                      fontFamily: 'inherit',
                      fontSize: 12,
                      textAlign: 'left',
                      cursor: 'pointer',
                    }}
                  >
                    <span style={{fontWeight: 700}}>{item.token}</span>
                    <span style={{color: 'var(--text-secondary)', fontSize: 11}}>{item.description}</span>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {loading ? (<div style={{ textAlign: 'center', marginTop: '100px', color: 'var(--text-secondary)' }}><div style={{margin: '0 auto 15px auto', width: 30, height: 30, border: '3px solid rgba(0,0,0,0.1)', borderTopColor: 'var(--accent-color)', borderRadius: '50%', animation: 'spin 1s linear infinite'}} />데이터 수집 중...</div>) : (
        <div className="dashboard-board">
          {/* Assigned Column */}
          <div className="dashboard-column">
            <div className="dashboard-column-header">
              <h2>내 업무 <span style={{fontWeight: 400, opacity: 0.6, fontSize: 13}}>(Assigned)</span></h2>
              <div className="dashboard-header-actions">
                <button className="dashboard-create-issue-button" onClick={openCreateIssueModal} title="내 업무 Jira 기록">
                  <Plus size={14} />
                  <span>기록</span>
                </button>
                {assignedUnreadCount > 0 && (
                  <span
                    className="dashboard-count-badge dashboard-unread-count-badge"
                    aria-label={`내 업무 신규 활동 ${assignedUnreadCount}건`}
                    title={`신규 활동 ${assignedUnreadCount}건`}
                  >
                    {assignedUnreadCount}
                  </span>
                )}
                <span className="dashboard-count-badge">{assignedIssues.length}</span>
              </div>
            </div>
            <motion.div className="issue-grid" style={{display: 'flex', flexDirection: 'column', gap: 15}}>
              <AnimatePresence>
                {assignedIssues.sort(sortIssues).map(issue => renderIssueCard(issue, 'assigned'))}
              </AnimatePresence>
            </motion.div>
          </div>
          
          {/* Mentioned Column */}
          <div className="dashboard-column">
            <div className="dashboard-column-header">
              <h2>멘션된 업무 <span style={{fontWeight: 400, opacity: 0.6, fontSize: 13}}>(Mentioned)</span></h2>
              <div className="dashboard-header-actions">
                {mentionedUnreadCount > 0 && (
                  <span
                    className="dashboard-count-badge dashboard-unread-count-badge"
                    aria-label={`멘션된 업무 신규 활동 ${mentionedUnreadCount}건`}
                    title={`신규 활동 ${mentionedUnreadCount}건`}
                  >
                    {mentionedUnreadCount}
                  </span>
                )}
                <span className="dashboard-count-badge">{mentionedIssues.length}</span>
              </div>
            </div>
            <motion.div className="issue-grid" style={{display: 'flex', flexDirection: 'column', gap: 15}}>
              <AnimatePresence>
                {mentionedIssues.sort(sortIssues).map(issue => renderIssueCard(issue, 'mentioned'))}
              </AnimatePresence>
            </motion.div>
          </div>
          
          {/* Reported Column */}
          <div className="dashboard-column">
            <div className="dashboard-column-header">
              <h2>보고한 업무 <span style={{fontWeight: 400, opacity: 0.6, fontSize: 13}}>(Reported)</span></h2>
              <div className="dashboard-header-actions">
                {reportedUnreadCount > 0 && (
                  <span
                    className="dashboard-count-badge dashboard-unread-count-badge"
                    aria-label={`보고한 업무 신규 활동 ${reportedUnreadCount}건`}
                    title={`신규 활동 ${reportedUnreadCount}건`}
                  >
                    {reportedUnreadCount}
                  </span>
                )}
                <span className="dashboard-count-badge">{reportedIssues.length}</span>
              </div>
            </div>
            <motion.div className="issue-grid" style={{display: 'flex', flexDirection: 'column', gap: 15}}>
              <AnimatePresence>
                {reportedIssues.sort(sortIssues).map(issue => renderIssueCard(issue, 'reported'))}
              </AnimatePresence>
            </motion.div>
          </div>
        </div>
      )}

      <AnimatePresence>
        {createModalOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="glass-modal-overlay"
            onPointerDown={event => {
              createModalPointerStartedOnOverlayRef.current = event.target === event.currentTarget;
            }}
            onPointerUp={event => {
              const shouldClose = createModalPointerStartedOnOverlayRef.current && event.target === event.currentTarget;
              createModalPointerStartedOnOverlayRef.current = false;
              if (shouldClose) closeCreateIssueModal();
            }}
            onPointerCancel={() => {
              createModalPointerStartedOnOverlayRef.current = false;
            }}
          >
            <motion.div initial={{ scale: 0.94, y: 18 }} animate={{ scale: 1, y: 0 }} exit={{ scale: 0.94, y: 18 }} className="glass-modal-content create-issue-modal" onClick={e => e.stopPropagation()} style={{textAlign: 'left'}}>
              <div className="create-issue-modal-header">
                <div>
                  <div className="apple-meta-label">Jira issue</div>
                  <h2>내 업무 기록</h2>
                </div>
                <button className="btn-secondary" onClick={closeCreateIssueModal} disabled={createSubmitting}>닫기</button>
              </div>

              {createMetadataLoading ? (
                <div className="create-issue-loading">
                  <div style={{margin: '0 auto 15px auto', width: 30, height: 30, border: '3px solid rgba(0,0,0,0.1)', borderTopColor: 'var(--accent-color)', borderRadius: '50%', animation: 'spin 1s linear infinite'}} />
                  생성 정보를 불러오는 중...
                </div>
              ) : (
                <div className="create-issue-form">
                  {createMetadata.length === 0 ? (
                    <div className="create-issue-empty">
                      JIRA_TRACKING_PROJECTS에 설정된 프로젝트에서 생성 가능한 정보를 찾지 못했습니다.
                    </div>
                  ) : (
                    <>
                      <div className="create-issue-grid">
                        <label>
                          <span className="apple-meta-label">프로젝트</span>
                          <select
                            className="glass-input"
                            value={createSelectedProject}
                            onChange={e => {
                              const nextKey = e.target.value;
                              const nextMeta = createMetadata.find(meta => metaKey(meta) === nextKey);
                              setCreateSelectedProject(nextKey);
                              applyCreateDefaults(nextMeta);
                            }}
                          >
                            {createMetadata.map(meta => (
                              <option key={metaKey(meta)} value={metaKey(meta)}>
                                {instanceList.length > 1 ? `[${meta.instance_name}] ` : ''}{meta.project_key}
                              </option>
                            ))}
                          </select>
                        </label>

                        <label>
                          <span className="apple-meta-label">이슈 유형</span>
                          <select
                            className="glass-input"
                            value={createIssueType}
                            disabled={!selectedCreateMeta || selectedCreateMeta.issue_types.length <= 1}
                            onChange={e => setCreateIssueType(e.target.value)}
                          >
                            {(selectedCreateMeta?.issue_types || []).map(type => (
                              <option key={type.id || type.name} value={type.name}>{type.name}</option>
                            ))}
                          </select>
                        </label>
                      </div>

                      <label>
                        <span className="apple-meta-label">요약</span>
                        <input
                          className="glass-input"
                          value={createSummary}
                          onChange={e => setCreateSummary(e.target.value)}
                          placeholder="Jira에 기록할 업무 요약"
                        />
                      </label>

                      <label>
                        <span className="apple-meta-label">설명</span>
                        <MentionsInput
                          value={createDescription}
                          onChange={(_, newValue) => setCreateDescription(newValue)}
                          style={{
                            ...mentionsStyle,
                            '&multiLine': {
                              ...mentionsStyle['&multiLine'],
                              control: { ...mentionsStyle['&multiLine'].control, minHeight: 120 },
                              input: { ...mentionsStyle['&multiLine'].input, minHeight: 120, backgroundColor: 'var(--card-bg)' },
                            },
                          }}
                          placeholder="@를 입력하여 팀원을 멘션할 수 있습니다."
                        >
                          <Mention trigger="@" data={searchCreateMentionUsers} markup="@[__display__](__id__)" displayTransform={(_id, display) => display} className="mention-badge" appendSpaceOnAdd />
                        </MentionsInput>
                      </label>

                      <label>
                        <span className="apple-meta-label">구성요소</span>
                        <select className="glass-input" value={createComponent} onChange={e => setCreateComponent(e.target.value)} disabled={!selectedCreateMeta?.components.length}>
                          <option value="">선택 안 함</option>
                          {(selectedCreateMeta?.components || []).map(component => (
                            <option key={component.id || component.name} value={component.name}>{component.name}</option>
                          ))}
                        </select>
                      </label>

                      <div className="create-assignee-section">
                        <span className="apple-meta-label">담당자</span>
                        <div className="create-assignee-options">
                          <label>
                            <input
                              type="radio"
                              checked={createAssigneeMode === 'default'}
                              onChange={() => {
                                setCreateAssigneeMode('default');
                                setCreateAssigneeQuery('');
                                setCreateAssigneeSelected(null);
                              }}
                            />
                            구성 요소 기본값
                          </label>
                          <label>
                            <input
                              type="radio"
                              checked={createAssigneeMode === 'me'}
                              onChange={() => {
                                setCreateAssigneeMode('me');
                                setCreateAssigneeQuery('');
                                setCreateAssigneeSelected(null);
                              }}
                            />
                            나{currentCreateUser?.displayName ? ` (${currentCreateUser.displayName})` : ''}
                          </label>
                          <label>
                            <input
                              type="radio"
                              checked={createAssigneeMode === 'manual'}
                              onChange={() => {
                                setCreateAssigneeMode('manual');
                                setCreateAssigneeQuery('');
                                setCreateAssigneeSelected(null);
                              }}
                            />
                            직접 지정
                          </label>
                        </div>

                        {createAssigneeMode === 'manual' && (
                          <div className="create-assignee-search">
                            <input
                              className="glass-input"
                              value={createAssigneeQuery}
                              onChange={e => {
                                setCreateAssigneeQuery(e.target.value);
                                setCreateAssigneeSelected(null);
                              }}
                              placeholder="이름으로 검색"
                            />
                            {createAssigneeSelected && <span className="create-assignee-selected">선택됨: {createAssigneeSelected.display}</span>}
                            {!createAssigneeSelected && createAssigneeQuery.trim() && (
                              <div className="create-assignee-suggestions">
                                {createAssigneeLoading ? (
                                  <div className="create-assignee-suggestion muted">검색 중...</div>
                                ) : createAssigneeSuggestions.length ? (
                                  createAssigneeSuggestions.map(user => (
                                    <button
                                      type="button"
                                      key={user.id}
                                      className="create-assignee-suggestion"
                                      onClick={() => {
                                        setCreateAssigneeSelected(user);
                                        setCreateAssigneeQuery(user.display);
                                        setCreateAssigneeSuggestions([]);
                                      }}
                                    >
                                      {user.display}
                                    </button>
                                  ))
                                ) : (
                                  <div className="create-assignee-suggestion muted">검색 결과가 없습니다.</div>
                                )}
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    </>
                  )}

                  {createError && <div className="create-issue-error">{createError}</div>}

                  <div className="create-issue-actions">
                    <button className="btn-secondary" onClick={closeCreateIssueModal} disabled={createSubmitting}>취소</button>
                    <button
                      className="btn-premium"
                      onClick={submitCreateIssue}
                      disabled={createSubmitting || createMetadata.length === 0 || !createIssueType || !createSummary.trim() || (createAssigneeMode === 'manual' && !createAssigneeValue)}
                    >
                      {createSubmitting ? '기록 중...' : 'Jira에 기록'}
                    </button>
                  </div>
                </div>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Detail Modal */}
      <AnimatePresence>
        {activeModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="glass-modal-overlay"
            onPointerDown={e => {
              modalPointerStartedOnOverlayRef.current = e.target === e.currentTarget;
            }}
            onPointerUp={e => {
              const shouldClose = modalPointerStartedOnOverlayRef.current && e.target === e.currentTarget;
              modalPointerStartedOnOverlayRef.current = false;
              if (shouldClose) setActiveModal(null);
            }}
            onPointerCancel={() => {
              modalPointerStartedOnOverlayRef.current = false;
            }}
          >
            <motion.div
              ref={detailModalRef}
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              className="glass-modal-content jira-detail-modal"
              role="dialog"
              aria-modal="true"
              aria-labelledby="jira-detail-modal-title"
              tabIndex={-1}
              autoFocus
              onClick={e => e.stopPropagation()}
              style={{textAlign: 'left'}}
            >
              
              <div style={{display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:'20px'}}>
                <h2 id="jira-detail-modal-title" style={{margin: 0, fontSize: 22, fontWeight: 700}}>
                  {activeModal === 'comment' && '코멘트 작성'}
                  {activeModal === 'subtask' && '하위 작업 생성'}
                  {activeModal === 'linked' && '연관 이슈 생성'}
                  {activeModal === 'detail' && '이슈 상세 정보'}
                </h2>
                {issueDetail && (
                  <div style={{display: 'flex', alignItems: 'center', gap: 8}}>
                    <button
                      className={`favorite-star-button modal-star ${isFavoriteIssue(issueDetail) ? 'active' : ''}`}
                      title={isFavoriteIssue(issueDetail) ? '즐겨찾기 해제' : '즐겨찾기'}
                      onClick={() => toggleFavoriteIssue(issueDetail)}
                    >
                      <Star size={18} fill={isFavoriteIssue(issueDetail) ? '#f1c40f' : 'none'} />
                    </button>
                    <span className="premium-badge" style={{position: 'relative', top: 0, right: 0}}>{(() => {
                      const instance = instanceList.find(ins => ins.id === issueDetail.instance_id);
                      return instance ? formatJiraInstanceName(instance.name, instance.deployment_type) : 'Jira';
                    })()}</span>
                  </div>
                )}
              </div>
              
              <p style={{ fontSize: '15px', color: 'var(--text-secondary)', marginBottom: 25 }}>
                <a href={`${instanceList.find(ins=>ins.id===selectedIssue?.instance_id)?.base_url}/browse/${selectedIssue?.key}`} target="_blank" rel="noreferrer" style={{textDecoration: 'none', color: '#0984e3', fontWeight: 600}}>
                  {selectedIssue?.key}
                </a>
                <span style={{margin: '0 8px'}}>-</span>
                <span style={{color: 'var(--text-primary)'}}>{selectedIssue?.fields?.summary}</span>
              </p>

              {(activeModal === 'comment' || activeModal === 'detail') && (
                <div>
                  {detailError && <div role="alert" style={{ marginBottom: 16, color: '#d63031', fontSize: 13 }}>{detailError} <button className="btn-secondary" onClick={() => selectedIssue && void fetchIssueDetail(selectedIssue.key, selectedIssue.instance_id)}>다시 불러오기</button></div>}
                  {detailLoading ? (<div style={{padding: 40, textAlign: 'center', color: 'var(--text-secondary)'}}><div style={{margin: '0 auto 15px auto', width: 30, height: 30, border: '3px solid rgba(0,0,0,0.1)', borderTopColor: 'var(--accent-color)', borderRadius: '50%', animation: 'spin 1s linear infinite'}} />데이터 불러오는 중...</div>) : (
                    <>
                      <div style={{display: 'flex', alignItems: 'center', gap: 12, marginBottom: 20, flexWrap: 'wrap'}}>
                         {selectedIssue && isOriginalEstimateTarget(selectedIssue) && !originalEstimateAuto && (
                           <button
                             className="btn-secondary"
                             onClick={submitOriginalEstimate}
                             disabled={originalEstimateSubmitting || selectedHasOriginalEstimate || !canUseManualOriginalEstimate}
                             title={selectedHasOriginalEstimate ? '이미 최초 추정이 입력되어 있습니다.' : ''}
                             style={{ whiteSpace: 'nowrap', opacity: (originalEstimateSubmitting || selectedHasOriginalEstimate || !canUseManualOriginalEstimate) ? 0.65 : 1 }}
                           >
                             {originalEstimateSubmitting ? '입력 중...' : selectedHasOriginalEstimate ? '최초 추정 입력됨' : '최초 추정 입력'}
                           </button>
                         )}
                         <span className="apple-meta-label" style={{whiteSpace: 'nowrap', flexShrink: 0}}>상태 변경</span>
                         <select
                           className="glass-input"
                           value=""
                           disabled={statusChangeSubmitting}
                           style={{flex: '1 1 260px', minWidth: 220}}
                           onChange={e => void handleStatusChange(e.target.value)}
                         >
                           <option value="" disabled>새로운 상태 선택...</option>
                           {availableTransitions.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
                           {selectedIssue && jiraautoClosedIssues[issueStorageKey(selectedIssue)] && (
                             <option value="__jiraauto_reopen__">다시 표시(jiraauto)</option>
                           )}
                           {selectedIssue && !jiraautoClosedIssues[issueStorageKey(selectedIssue)] && availableTransitions.length === 0 && !transitionUnavailable && !isDoneIssue(selectedIssue) && (
                             <option value="__jiraauto_close__">닫힘(jiraauto)</option>
                           )}
                         </select>
                       </div>
                       {transitionUnavailable && availableTransitions.length === 0 && (
                         <div style={{ marginTop: -10, marginBottom: 16, color: '#d97706', fontSize: 13, fontWeight: 700 }}>
                           Jira 상태 목록을 확인할 수 없어 로컬 닫힘을 제공하지 않습니다. 연결 상태를 확인해주세요.
                         </div>
                       )}
                       {statusChangeError && <div style={{ marginTop: -10, marginBottom: 16, color: '#d63031', fontSize: 13, fontWeight: 700 }}>{statusChangeError}</div>}
                      {originalEstimateError && <div style={{ marginTop: -10, marginBottom: 16, color: '#d63031', fontSize: 13, fontWeight: 700 }}>{originalEstimateError}</div>}
                      {originalEstimateMessage && <div style={{ marginTop: -10, marginBottom: 16, color: '#078f55', fontSize: 13, fontWeight: 700 }}>{originalEstimateMessage}</div>}

                      {canUseWorklogPanel && (
                        <WorklogPanel
                          key={`worklog:${selectedIssue?.instance_id}:${selectedIssue?.key}`}
                          issue={selectedIssue!}
                          onUpdated={() => fetchIssueDetail(selectedIssue!.key, selectedIssue!.instance_id)}
                        />
                      )}

                      <div className="apple-meta-grid">
                        <div className="apple-meta-item"><span className="apple-meta-label">유형</span><span className="apple-meta-value">{issueDetail?.fields?.issuetype?.name}</span></div>
                        <div className="apple-meta-item">
                          <span className="apple-meta-label">컴포넌트</span>
                          <span className="apple-meta-value apple-meta-list">
                            {issueDetail?.fields?.components?.length
                              ? issueDetail.fields.components.map((component, index) => <span className="apple-meta-list-item" key={`${component.name}-${index}`}>{component.name}</span>)
                              : '없음'}
                          </span>
                        </div>
                        <div className="apple-meta-item"><span className="apple-meta-label">담당자</span><span className="apple-meta-value">{issueDetail?.fields?.assignee?.displayName || '미지정'}</span></div>
                        <div className="apple-meta-item"><span className="apple-meta-label">보고자</span><span className="apple-meta-value">{issueDetail?.fields?.reporter?.displayName}</span></div>
                        <div className="apple-meta-item">
                          <span className="apple-meta-label">지켜보는 사람</span>
                          <span className="apple-meta-value apple-meta-list">
                            {issueDetail?.fields?.watchers?.length
                              ? issueDetail.fields.watchers.map((watcher, index) => <span className="apple-meta-list-item" key={`${watcher}-${index}`}>{watcher}</span>)
                              : '없음'}
                          </span>
                        </div>
                        <div className="apple-meta-item">
                          <span className="apple-meta-label">레이블</span>
                          <span className="apple-meta-value apple-meta-list">
                            {issueDetail?.fields?.labels?.length
                              ? issueDetail.fields.labels.map((label, index) => <span className="apple-meta-list-item" key={`${label}-${index}`}>{label}</span>)
                              : '없음'}
                          </span>
                        </div>
                        <div className="apple-meta-item"><span className="apple-meta-label">생성 날짜</span><span className="apple-meta-value">{formatDateTime(issueDetail?.fields?.created)}</span></div>
                        <div className="apple-meta-item"><span className="apple-meta-label">최종 변경</span><span className="apple-meta-value">{formatDateTime(issueDetail?.fields?.updated)}</span></div>
                      </div>

                      {activeModal === 'detail' && (
                        <div style={{marginBottom: 24}}>
                          <div style={{display: 'flex', alignItems: 'center', gap: 12, marginBottom: 8, flexWrap: 'wrap'}}>
                            <span className="apple-meta-label">AI 요약</span>
                            <button
                              className="btn-secondary"
                              onClick={() => void generateAiSummary()}
                              disabled={aiSummaryLoading}
                              style={{display: 'inline-flex', alignItems: 'center', gap: 6, whiteSpace: 'nowrap', opacity: aiSummaryLoading ? 0.65 : 1}}
                            >
                              <Sparkles size={14} />
                              {aiSummaryLoading ? <span className="ai-loading-dots">요약 생성 중</span> : aiSummary ? '다시 요약' : 'AI 요약 생성'}
                            </button>
                            {aiSummaryMeta && !aiSummaryLoading && (
                              <span style={{fontSize: 12, color: 'var(--text-secondary)'}}>{aiSummaryMeta}</span>
                            )}
                          </div>
                          {aiSummaryError && <div style={{color: '#d63031', fontSize: 13, fontWeight: 700, marginBottom: 8}}>{aiSummaryError}</div>}
                          {aiSummaryLoading && (
                            <div style={{display: 'flex', alignItems: 'center', gap: 10, fontSize: 13, color: 'var(--text-secondary)'}}>
                              <div style={{width: 16, height: 16, border: '2px solid rgba(0,0,0,0.1)', borderTopColor: 'var(--accent-color)', borderRadius: '50%', animation: 'spin 0.8s linear infinite', flexShrink: 0}} />
                              <span className="ai-loading-dots">AI가 이슈 내용과 코멘트를 분석하고 있습니다</span>
                            </div>
                          )}
                          {aiSummary && !aiSummaryLoading && (
                            <div className="apple-description-box" style={{marginBottom: 0}}>
                              <MarkdownPreview content={aiSummary} />
                            </div>
                          )}
                        </div>
                      )}

                      <span className="apple-meta-label" style={{display: 'block', marginBottom: 8}}>설명</span>
                      <div className="apple-description-box" dangerouslySetInnerHTML={{__html: issueDetail?.fields?.description ? renderJiraDescriptionHtml(issueDetail.fields.displayDescription || issueDetail.fields.description, currentSelectedUser) : '설명이 없습니다.'}}></div>

                      {issueDetail?.fields?.issuelinks?.some(link => link.inwardIssue || link.outwardIssue) && (
                        <>
                      <span className="apple-meta-label" style={{display: 'block', marginBottom: 8}}>연결된 이슈</span>
                      <div className="glass-panel" style={{padding: 16, marginBottom: 20}}>
                          <div style={{display: 'flex', flexDirection: 'column', gap: 12}}>
                            {issueDetail.fields.issuelinks.map(link => {
                              const linked = link.outwardIssue || link.inwardIssue;
                              if (!linked) return null;
                              const relation = (link.outwardIssue ? link.type?.outward : link.type?.inward) || link.type?.name || '연결';
                              const baseUrl = instanceList.find(instance => instance.id === selectedIssue?.instance_id)?.base_url;
                              return (
                                <div key={link.id} style={{display: 'flex', alignItems: 'baseline', flexWrap: 'wrap', gap: 8, fontSize: 13}}>
                                  <span style={{color: 'var(--text-secondary)'}}>{relation}</span>
                                  {baseUrl ? <a href={`${baseUrl.replace(/\/$/, '')}/browse/${encodeURIComponent(linked.key)}`} target="_blank" rel="noopener noreferrer" title="Jira에서 새 탭으로 열기" style={{color: '#0984e3', fontWeight: 700}}>{linked.key}</a> : <span style={{fontWeight: 700}}>{linked.key}</span>}
                                  <span style={{flex: '1 1 200px', overflowWrap: 'anywhere'}}>{linked.fields?.summary || '제목 정보 없음'}</span>
                                  {linked.fields?.issuetype?.name && <span style={{color: 'var(--text-secondary)'}}>{linked.fields.issuetype.name}</span>}
                                  {linked.fields?.status?.name && <span className="status-badge" style={{padding: '4px 10px', borderRadius: 999, fontSize: 12}}>{linked.fields.status.name}</span>}
                                  <button type="button" className="btn-secondary" style={{padding: '4px 10px', borderRadius: 999, fontSize: 12, whiteSpace: 'nowrap'}} disabled={linkedIssueLoading !== null} onClick={() => void handleOpenLinkedIssue(linked)} aria-label={`${linked.key} jiraauto에서 보기`}>
                                    {linkedIssueLoading === linked.key ? '불러오는 중...' : 'jiraauto에서 보기'}
                                  </button>
                                </div>
                              );
                            })}
                          </div>
                          {linkedIssueError && <div role="alert" style={{marginTop: 12, color: '#d63031', fontSize: 13}}>{linkedIssueError}</div>}
                      </div>
                        </>
                      )}

                      <span className="apple-meta-label" style={{display: 'block', marginBottom: 8}}>코멘트</span>
                      {selectedIssue && (
                        <CommentComposer
                          key={`comment-composer:${selectedIssue.instance_id}:${selectedIssue.key}`}
                          issue={selectedIssue}
                          searchUsers={searchUsers}
                          onSubmitted={() => fetchIssueDetail(selectedIssue.key, selectedIssue.instance_id)}
                        />
                      )}

                      <div className="imessage-container">
                        {!issueDetail?.fields?.comment?.comments?.length ? <p style={{fontSize:'13px', color:'var(--text-secondary)', textAlign: 'center'}}>작성된 코멘트가 없습니다.</p> :
                          [...issueDetail.fields.comment.comments].sort((a,b)=>new Date(b.created).getTime()-new Date(a.created).getTime()).map(c => {
                            const currentCommentUser = selectedIssue
                              ? userMap[selectedIssue.instance_id.toString()]
                              : null;
                            const isMine = Boolean(currentCommentUser && isSameJiraUser(c.author, currentCommentUser));
                            return (
                              <div key={c.id} className={`imessage-bubble-wrapper ${isMine ? 'mine' : 'others'}`}>
                                {!isMine && <div className="imessage-author">{c.author.displayName}</div>}
                                
                                {editingCommentId === c.id ? (
                                  selectedIssue && (
                                    <CommentEditor
                                      key={`comment-editor:${selectedIssue.instance_id}:${selectedIssue.key}:${c.id}`}
                                      issue={selectedIssue}
                                      comment={c}
                                      searchUsers={searchUsers}
                                      onCancel={() => setEditingCommentId(null)}
                                      onSaved={async () => {
                                        if (detailSession !== detailSessionRef.current) return;
                                        setEditingCommentId(current => current === c.id ? null : current);
                                        await fetchIssueDetail(selectedIssue.key, selectedIssue.instance_id);
                                      }}
                                    />
                                  )
                                ) : (
                                  <>
                                    <div className="imessage-bubble" dangerouslySetInnerHTML={{__html: renderJiraCommentHtml(c, isMine ? null : currentCommentUser)}} />
                                    <div className="imessage-date">{formatDateTime(c.created)}</div>
                                    {isMine && (
                                      <div className="imessage-actions">
                                        <button onClick={()=>setEditingCommentId(c.id)}>수정</button>
                                        <button className="danger" onClick={async ()=>{
                                          if(!confirm('삭제하시겠습니까?')) return;
                                          await fetch(`${API_BASE}/issues/${selectedIssue?.key}/comments/${c.id}?instance_id=${selectedIssue?.instance_id}`, { method: 'DELETE' });
                                          fetchIssueDetail(selectedIssue!.key, selectedIssue!.instance_id);
                                        }}>삭제</button>
                                      </div>
                                    )}
                                  </>
                                )}
                              </div>
                            );
                          })
                        }
                      </div>
                      
                      <div style={{marginTop: 40}}>
                        <span className="apple-meta-label" style={{display: 'block', marginBottom: 8}}>활동 이력</span>
                        <div className="glass-panel" style={{padding: 20}}>
                          {!issueDetail?.changelog?.histories?.length ? <p style={{fontSize:'13px',color:'var(--text-secondary)'}}>기록이 없습니다.</p> : 
                            issueDetail.changelog.histories.slice(0,5).map(h=>(
                              <div key={h.id} style={{marginBottom: 15, paddingBottom: 15, borderBottom: '1px solid rgba(0,0,0,0.05)'}}>
                                <div style={{display: 'flex', justifyContent: 'space-between', marginBottom: 8}}>
                                  <span style={{fontWeight: 700, fontSize: 13, color: 'var(--text-primary)'}}>{h.author.displayName}</span>
                                  <span style={{fontSize: 12, color: 'var(--text-secondary)'}}>{formatDateTime(h.created)}</span>
                                </div>
                                <div style={{fontSize: 13, color: 'var(--text-secondary)', lineHeight: 1.5}}>
                                  {h.items.map((it,idx)=>(<div key={idx}>• <b>{it.field}</b>: {it.fromString||'없음'} → <b>{it.toString}</b></div>))}
                                </div>
                              </div>
                            ))
                          }
                        </div>
                      </div>
                    </>
                  )}
                </div>
              )}
              
              <div style={{display:'flex',justifyContent:'flex-end',gap:'10px',marginTop:'30px', paddingTop: '20px', borderTop: '1px solid rgba(0,0,0,0.05)'}}>
                <button className="btn-secondary" onClick={()=>setActiveModal(null)}>닫기</button>
              </div>
            </motion.div>
            {activeModal === 'detail' && (
              <ScrollToTopButton scrollContainerRef={detailModalRef} className="modal-scroll-to-top-button" />
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

