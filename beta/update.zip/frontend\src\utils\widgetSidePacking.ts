export type WidgetVerticalBlock = 'top' | 'middle' | 'bottom' | 'top-middle' | 'middle-bottom';

export interface WidgetSidePackingItem<T extends string> {
  id: T;
  block: WidgetVerticalBlock;
  alreadyOnTargetSide: boolean;
}

const BLOCK_SLOTS: Record<WidgetVerticalBlock, number[]> = {
  top: [0],
  middle: [1],
  bottom: [2],
  'top-middle': [0, 1],
  'middle-bottom': [1, 2],
};

const BLOCK_CENTERS: Record<WidgetVerticalBlock, number> = {
  top: 0,
  middle: 1,
  bottom: 2,
  'top-middle': 0.5,
  'middle-bottom': 1.5,
};

const candidatesFor = (block: WidgetVerticalBlock): WidgetVerticalBlock[] => (
  BLOCK_SLOTS[block].length === 2
    ? ['top-middle', 'middle-bottom']
    : ['top', 'middle', 'bottom']
);

const placementCost = <T extends string>(
  item: WidgetSidePackingItem<T>,
  candidate: WidgetVerticalBlock,
) => {
  if (candidate === item.block) return 0;
  const distance = Math.abs(BLOCK_CENTERS[item.block] - BLOCK_CENTERS[candidate]);
  return distance * 10 + (item.alreadyOnTargetSide ? 1000 : 0);
};

export const packWidgetsOnSide = <T extends string>(
  items: WidgetSidePackingItem<T>[],
): Record<T, WidgetVerticalBlock> | null => {
  const requiredSlots = items.reduce((total, item) => total + BLOCK_SLOTS[item.block].length, 0);
  if (requiredSlots > 3) return null;

  let bestCost = Number.POSITIVE_INFINITY;
  let bestPlan: Partial<Record<T, WidgetVerticalBlock>> | null = null;

  const visit = (
    index: number,
    occupiedSlots: Set<number>,
    plan: Partial<Record<T, WidgetVerticalBlock>>,
    cost: number,
  ) => {
    if (cost >= bestCost) return;
    if (index >= items.length) {
      bestCost = cost;
      bestPlan = { ...plan };
      return;
    }

    const item = items[index];
    for (const candidate of candidatesFor(item.block)) {
      const slots = BLOCK_SLOTS[candidate];
      if (slots.some(slot => occupiedSlots.has(slot))) continue;
      slots.forEach(slot => occupiedSlots.add(slot));
      plan[item.id] = candidate;
      visit(index + 1, occupiedSlots, plan, cost + placementCost(item, candidate));
      delete plan[item.id];
      slots.forEach(slot => occupiedSlots.delete(slot));
    }
  };

  visit(0, new Set(), {}, 0);
  return bestPlan as Record<T, WidgetVerticalBlock> | null;
};
