from __future__ import annotations

import logging

from logging_config import configure_logging


configure_logging()
server_logger = logging.getLogger("uvicorn.error")

try:
    import uvicorn

    from main import app

    uvicorn.run(app, host="0.0.0.0", port=8000, reload=False, log_config=None)
except BaseException:
    server_logger.exception("Backend startup failed")
    raise
