@echo off
setlocal enabledelayedexpansion

:: Refresh PATH from registry (picks up newly installed tools)
for /f "usebackq delims=" %%P in (`powershell -NoProfile -Command "[Environment]::GetEnvironmentVariable('PATH','Machine')+';'+[Environment]::GetEnvironmentVariable('PATH','User')"`) do set "PATH=%%P"

:: ============================================================
:: [0/3] Check and install dependencies
:: ============================================================

set "HAVE_WINGET=0"
where winget >nul 2>&1 && set "HAVE_WINGET=1"

set "NEEDS_RESTART=0"

where python >nul 2>&1
if !errorlevel! neq 0 (
    set "USE_POWERSHELL_PYTHON=0"
    if "!HAVE_WINGET!"=="1" (
        echo [0/3] Python not found. Installing via winget...
        winget install --id Python.Python.3.14 --silent --accept-source-agreements --accept-package-agreements
        if !errorlevel! neq 0 (
            echo [0/3] Winget failed, falling back to PowerShell download...
            set "USE_POWERSHELL_PYTHON=1"
        )
    ) else (
        set "USE_POWERSHELL_PYTHON=1"
    )

    if "!USE_POWERSHELL_PYTHON!"=="1" (
        echo [0/3] Python not found. Downloading installer...
        powershell -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $ProgressPreference='SilentlyContinue'; [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; $ts=[datetime]::Now.ToString('yyyyMMddHHmmss'); $out=$env:TEMP+'\python_inst_'+$ts+'.exe'; Write-Host 'Downloading Python 3.14.5...'; Invoke-WebRequest -Uri 'https://www.python.org/ftp/python/3.14.5/python-3.14.5-amd64.exe' -OutFile $out -UseBasicParsing; Write-Host 'Installing...'; $maxRetry=5; $retry=0; do { $p=Start-Process -Wait -PassThru -FilePath $out -ArgumentList '/passive InstallAllUsers=1 PrependPath=1 Include_launcher=0'; if($p.ExitCode -eq 1618){$retry++; Write-Host ('Windows Installer busy, retrying in 15s... ('+$retry+'/'+$maxRetry+')'); Start-Sleep 15} } while($p.ExitCode -eq 1618 -and $retry -lt $maxRetry); if($p.ExitCode -ne 0){throw 'Python installer failed with exit code '+$p.ExitCode}"
        if !errorlevel! neq 0 (
            echo [ERROR] Python installation failed. Install manually: https://www.python.org
            pause
            exit /b 1
        )
    )
    set "NEEDS_RESTART=1"
)

where node >nul 2>&1
if !errorlevel! neq 0 (
    set "USE_POWERSHELL_NODE=0"
    if "!HAVE_WINGET!"=="1" (
        echo [0/3] Node.js not found. Installing via winget...
        winget install --id OpenJS.NodeJS.LTS --silent --accept-source-agreements --accept-package-agreements
        if !errorlevel! neq 0 (
            echo [0/3] Winget failed, falling back to PowerShell download...
            set "USE_POWERSHELL_NODE=1"
        )
    ) else (
        set "USE_POWERSHELL_NODE=1"
    )

    if "!USE_POWERSHELL_NODE!"=="1" (
        echo [0/3] Node.js not found. Downloading installer...
        powershell -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $ProgressPreference='SilentlyContinue'; [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; $ts=[datetime]::Now.ToString('yyyyMMddHHmmss'); $out=$env:TEMP+'\node_inst_'+$ts+'.msi'; Write-Host 'Downloading Node.js v24.16.0...'; Invoke-WebRequest -Uri 'https://nodejs.org/dist/v24.16.0/node-v24.16.0-x64.msi' -OutFile $out -UseBasicParsing; Write-Host 'Installing...'; $maxRetry=5; $retry=0; do { $p=Start-Process -Wait -PassThru msiexec -ArgumentList @('/i',$out,'/passive','/norestart','ADDLOCAL=ALL'); if($p.ExitCode -eq 1618){$retry++; Write-Host ('Windows Installer busy, retrying in 15s... ('+$retry+'/'+$maxRetry+')'); Start-Sleep 15} } while($p.ExitCode -eq 1618 -and $retry -lt $maxRetry); if($p.ExitCode -ne 0){throw 'Node.js installer failed with exit code '+$p.ExitCode}"
        if !errorlevel! neq 0 (
            echo [ERROR] Node.js installation failed. Install manually: https://nodejs.org
            pause
            exit /b 1
        )
    )
    set "NEEDS_RESTART=1"
)

if "!NEEDS_RESTART!"=="1" (
    echo.
    echo Installation complete. Restarting in a new window...
    start "Jira Auto" cmd /k "%~f0"
    exit /b 0
)

:: ============================================================
:: [1/3] Backend
:: ============================================================

echo [1/3] Backend setting up...
cd /d "%~dp0backend"
if not exist venv (
    python -m venv venv
)

set "LICENSE_PROVIDER=server"
set "LICENSE_SERVER_URL=https://license.shadowspace.i234.me"
set "LICENSE_SERVER_VERIFY_TLS=N"
set "LICENSE_GATE_ENABLED=Y"
set "JIRAAUTO_APP_VERSION=1.0.0"
set "JIRAAUTO_APP_CHANNEL=stable"
set "JIRAAUTO_ENV=production"
set "TEAM_BACKFILL_MAX_PAGES=0"
set "JIRA_DETAIL_PREFETCH_LIMIT=30"

venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 (
    echo [ERROR] Failed to install backend dependencies.
    pause
    exit /b 1
)

:: ============================================================
:: [2/3] Frontend
:: ============================================================

echo [2/3] Frontend setting up...
cd /d "%~dp0frontend"
set "NEED_NPM_INSTALL=0"
if not exist node_modules set "NEED_NPM_INSTALL=1"
if not exist "node_modules\.bin\vite.cmd" set "NEED_NPM_INSTALL=1"

if "%NEED_NPM_INSTALL%"=="1" (
    call npm.cmd install --no-audit --fund=false
    if errorlevel 1 (
        if exist "node_modules\.bin\vite.cmd" (
            echo [WARN] npm returned a non-zero exit code, but required frontend tools are present. Continuing.
        ) else (
            echo [ERROR] Failed to install frontend dependencies.
            pause
            exit /b 1
        )
    )
)

if not exist "node_modules\.bin\vite.cmd" (
    echo [ERROR] Failed to install frontend dependencies.
    pause
    exit /b 1
)

echo [3/3] Environment ready.

:: Register auto-start shortcut in Windows Startup folder
echo Registering JiraAuto to start automatically on Windows login...
set "VBS_TARGET=%~dp0start_dashboard.vbs"
powershell -NoProfile -Command "& { $ws=New-Object -ComObject WScript.Shell; $lnkPath=[IO.Path]::Combine($env:APPDATA,'Microsoft\Windows\Start Menu\Programs\Startup\JiraAuto.lnk'); $sc=$ws.CreateShortcut($lnkPath); $sc.TargetPath=$env:VBS_TARGET; $sc.WorkingDirectory=[IO.Path]::GetDirectoryName($env:VBS_TARGET); $sc.Description='JiraAuto Dashboard'; $sc.Save() }"
if errorlevel 1 (
    echo [WARN] Failed to register startup shortcut. You can add it manually.
) else (
    echo Startup shortcut registered. JiraAuto will launch automatically on login.
)

:: Launch dashboard
if exist "%~dp0start_dashboard.vbs" (
    start "" "%~dp0start_dashboard.vbs"
    echo Dashboard launched. Backend: http://localhost:8000 / Frontend: http://localhost:5173
    timeout /t 5 > nul
    exit /b 0
) else (
    echo [ERROR] start_dashboard.vbs not found.
    pause
    exit /b 1
)
