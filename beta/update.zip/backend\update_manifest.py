from __future__ import annotations

import json
import os
import re
import sys
from pathlib import Path
from typing import Any


SEMVER_RE = re.compile(
    r"^v?(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)"
    r"(?:-([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?"
    r"(?:\+[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?$"
)
BETA_RE = re.compile(r"^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)-beta\.([1-9]\d*)$")
STABLE_RE = re.compile(r"^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)$")


def parse_semver(value: Any) -> tuple[int, int, int, tuple[tuple[int, Any], ...]] | None:
    if not isinstance(value, str):
        return None
    match = SEMVER_RE.fullmatch(value.strip())
    if not match:
        return None
    prerelease: list[tuple[int, Any]] = []
    if match.group(4):
        for identifier in match.group(4).split("."):
            if identifier.isdigit():
                if len(identifier) > 1 and identifier.startswith("0"):
                    return None
                prerelease.append((0, int(identifier)))
            else:
                prerelease.append((1, identifier))
    return int(match.group(1)), int(match.group(2)), int(match.group(3)), tuple(prerelease)


def is_valid_semver(value: Any) -> bool:
    return parse_semver(value) is not None


def compare_semver(left: str, right: str) -> int:
    a = parse_semver(left)
    b = parse_semver(right)
    if a is None or b is None:
        raise ValueError(f"Invalid semantic version comparison: {left}, {right}")
    if a[:3] != b[:3]:
        return (a[:3] > b[:3]) - (a[:3] < b[:3])
    a_pre, b_pre = a[3], b[3]
    if not a_pre and not b_pre:
        return 0
    if not a_pre:
        return 1
    if not b_pre:
        return -1
    for index in range(max(len(a_pre), len(b_pre))):
        if index >= len(a_pre):
            return -1
        if index >= len(b_pre):
            return 1
        a_part, b_part = a_pre[index], b_pre[index]
        if a_part == b_part:
            continue
        if a_part[0] != b_part[0]:
            return -1 if a_part[0] == 0 else 1
        return (a_part[1] > b_part[1]) - (a_part[1] < b_part[1])
    return 0


def load_manifest(path: str | os.PathLike[str]) -> dict[str, Any]:
    with open(path, "r", encoding="utf-8-sig") as handle:
        data = json.load(handle)
    if not isinstance(data, dict):
        raise ValueError("Release metadata must be a JSON object")
    return data


def _release(value: Any, channel: str) -> dict[str, str] | None:
    if not isinstance(value, dict) or not is_valid_semver(value.get("version")):
        return None
    version = str(value["version"]).strip().removeprefix("v")
    if channel == "stable" and not STABLE_RE.fullmatch(version):
        return None
    if channel == "beta" and not BETA_RE.fullmatch(version):
        return None
    result = {"channel": channel, "version": version}
    for key in ("download_url", "sha256", "release_notes"):
        if isinstance(value.get(key), str) and value[key].strip():
            result[key] = value[key].strip()
    return result


def normalized_releases(manifest: dict[str, Any]) -> tuple[dict[str, str] | None, dict[str, str] | None]:
    channels = manifest.get("channels") if isinstance(manifest.get("channels"), dict) else {}
    stable = _release(channels.get("stable"), "stable") or _release(manifest, "stable")
    beta = _release(channels.get("beta"), "beta")
    return stable, beta


def select_release(manifest: dict[str, Any], channel: str) -> dict[str, str]:
    if channel not in {"stable", "beta"}:
        raise ValueError("Update channel must be stable or beta")
    stable, beta = normalized_releases(manifest)
    selected = stable
    if channel == "beta" and beta and (not stable or compare_semver(beta["version"], stable["version"]) > 0):
        selected = beta
    if not selected:
        raise ValueError(f"No valid {channel} release is available")
    if not selected.get("download_url") or not selected.get("sha256"):
        raise ValueError("Selected release is missing download_url or sha256")
    return selected


def _core_version(version: str) -> str:
    parsed = parse_semver(version)
    if parsed is None:
        raise ValueError(f"Invalid version: {version}")
    return f"{parsed[0]}.{parsed[1]}.{parsed[2]}"


def suggest_release_version(manifest: dict[str, Any], channel: str) -> str:
    stable, beta = normalized_releases(manifest)
    if not stable:
        raise ValueError("A valid current stable version is required")
    stable_version = stable["version"]
    stable_parsed = parse_semver(stable_version)
    assert stable_parsed is not None

    if channel == "stable":
        if beta and compare_semver(beta["version"], stable_version) > 0:
            return _core_version(beta["version"])
        return f"{stable_parsed[0]}.{stable_parsed[1]}.{stable_parsed[2] + 1}"
    if channel != "beta":
        raise ValueError("Release channel must be stable or beta")
    channels = manifest.get("channels")
    if manifest.get("schema_version") != 2 or not isinstance(channels, dict) or not _release(channels.get("stable"), "stable"):
        raise ValueError("Publish the stable bridge release before creating a beta release")

    if beta and compare_semver(beta["version"], stable_version) > 0:
        match = BETA_RE.fullmatch(beta["version"])
        if match:
            return f"{match.group(1)}.{match.group(2)}.{match.group(3)}-beta.{int(match.group(4)) + 1}"
    return f"{stable_parsed[0]}.{stable_parsed[1]}.{stable_parsed[2] + 1}-beta.1"


def validate_release_version(manifest: dict[str, Any], channel: str, new_version: str) -> None:
    stable, beta = normalized_releases(manifest)
    if not stable:
        raise ValueError("A valid current stable version is required")
    if channel == "stable":
        if not STABLE_RE.fullmatch(new_version):
            raise ValueError("Stable version must use X.Y.Z format")
        if compare_semver(new_version, stable["version"]) <= 0:
            raise ValueError("Stable version must be newer than the current stable version")
        return
    if channel != "beta" or not BETA_RE.fullmatch(new_version):
        raise ValueError("Beta version must use X.Y.Z-beta.N format with N >= 1")
    channels = manifest.get("channels")
    if manifest.get("schema_version") != 2 or not isinstance(channels, dict) or not _release(channels.get("stable"), "stable"):
        raise ValueError("Publish the stable bridge release before creating a beta release")
    core = _core_version(new_version)
    if compare_semver(core, stable["version"]) <= 0:
        raise ValueError("Beta base version must be newer than the current stable version")
    if beta and compare_semver(new_version, beta["version"]) <= 0:
        raise ValueError("Beta version must be newer than the current beta version")


def update_release_manifest(
    manifest: dict[str, Any], channel: str, version: str, download_url: str,
    sha256: str, updater_url: str, updater_sha256: str, min_required_version: str | None,
) -> dict[str, Any]:
    validate_release_version(manifest, channel, version)
    stable, beta = normalized_releases(manifest)
    channels: dict[str, Any] = {}
    if stable:
        channels["stable"] = {key: value for key, value in stable.items() if key != "channel"}
    if beta:
        channels["beta"] = {key: value for key, value in beta.items() if key != "channel"}
    channels[channel] = {"version": version, "download_url": download_url, "sha256": sha256}

    result: dict[str, Any] = {
        "schema_version": 2,
        "channels": channels,
        "updater_url": updater_url,
        "updater_sha256": updater_sha256,
    }
    if channel == "stable":
        result.update({"version": version, "download_url": download_url, "sha256": sha256})
        if min_required_version:
            result["min_required_version"] = min_required_version
    else:
        if not stable:
            raise ValueError("Cannot publish beta without a stable release")
        result.update({
            "version": stable["version"],
            "download_url": stable.get("download_url"),
            "sha256": stable.get("sha256"),
        })
        if manifest.get("min_required_version"):
            result["min_required_version"] = manifest["min_required_version"]
    return result


def _write_json_atomic(path: str | os.PathLike[str], data: dict[str, Any]) -> None:
    target = Path(path)
    temporary = target.with_suffix(target.suffix + ".tmp")
    with open(temporary, "w", encoding="utf-8", newline="\n") as handle:
        json.dump(data, handle, ensure_ascii=False, indent=2)
        handle.write("\n")
    os.replace(temporary, target)


def _main(argv: list[str]) -> int:
    try:
        command = argv[1]
        if command == "select":
            manifest = load_manifest(argv[2])
            selected = select_release(manifest, argv[3])
            if len(argv) > 4 and argv[4] and selected["version"] != argv[4]:
                raise ValueError("Selected release no longer matches the expected version")
            print(f"SELECTED_VERSION={selected['version']}")
            print(f"SELECTED_CHANNEL={selected['channel']}")
            print(f"DOWNLOAD_URL={selected['download_url']}")
            print(f"EXPECTED_HASH={selected['sha256']}")
        elif command == "suggest":
            print(suggest_release_version(load_manifest(argv[2]), argv[3]))
        elif command == "validate-release":
            validate_release_version(load_manifest(argv[2]), argv[3], argv[4])
        elif command == "publish":
            path, channel, version, download_url, sha256, updater_url, updater_sha256 = argv[2:9]
            minimum = argv[9] if len(argv) > 9 and argv[9] else None
            manifest = load_manifest(path)
            _write_json_atomic(path, update_release_manifest(
                manifest, channel, version, download_url, sha256,
                updater_url, updater_sha256, minimum,
            ))
        elif command == "write-installed":
            path, version, channel = argv[2:5]
            if not is_valid_semver(version) or channel not in {"stable", "beta"}:
                raise ValueError("Invalid installed version data")
            from datetime import datetime
            _write_json_atomic(path, {
                "version": version,
                "channel": channel,
                "installed_at": datetime.now().astimezone().isoformat(timespec="seconds"),
            })
        else:
            raise ValueError(f"Unknown command: {command}")
        return 0
    except (IndexError, OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"ERROR={exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(_main(sys.argv))
