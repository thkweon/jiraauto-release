import React, { useEffect, useLayoutEffect, useState } from 'react';
import { ThemeContext, type ResolvedTheme, type Theme } from './theme-context';

const SYSTEM_THEME_QUERY = '(prefers-color-scheme: dark)';
const THEME_CYCLE: Theme[] = ['light', 'dark', 'system'];

const isTheme = (value: string | null): value is Theme => (
  value === 'light' || value === 'dark' || value === 'system'
);

const getSystemTheme = (): ResolvedTheme => (
  window.matchMedia(SYSTEM_THEME_QUERY).matches ? 'dark' : 'light'
);

export const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [theme, setTheme] = useState<Theme>(() => {
    const savedTheme = localStorage.getItem('theme');
    return isTheme(savedTheme) ? savedTheme : 'light';
  });
  const [systemTheme, setSystemTheme] = useState<ResolvedTheme>(getSystemTheme);
  const resolvedTheme = theme === 'system' ? systemTheme : theme;

  useEffect(() => {
    const mediaQuery = window.matchMedia(SYSTEM_THEME_QUERY);
    const handleSystemThemeChange = (event: MediaQueryListEvent) => {
      setSystemTheme(event.matches ? 'dark' : 'light');
    };

    mediaQuery.addEventListener('change', handleSystemThemeChange);

    return () => mediaQuery.removeEventListener('change', handleSystemThemeChange);
  }, []);

  useLayoutEffect(() => {
    document.documentElement.setAttribute('data-theme', resolvedTheme);
    localStorage.setItem('theme', theme);
  }, [resolvedTheme, theme]);

  const toggleTheme = () => setTheme(previousTheme => {
    const currentIndex = THEME_CYCLE.indexOf(previousTheme);
    return THEME_CYCLE[(currentIndex + 1) % THEME_CYCLE.length];
  });

  return (
    <ThemeContext.Provider value={{ theme, resolvedTheme, toggleTheme }}>
      {children}
    </ThemeContext.Provider>
  );
};
