import type { TourDefinition } from '../types';

export const teamManageTour: TourDefinition = {
  id: 'team-manage',
  version: 1,
  steps: [
    { target: '[data-tour="team-manage-page"]', title: '팀 관리', description: '팀 초대 정보와 현재 동기화 중인 팀원을 관리하는 팀장 전용 화면입니다.', side: 'top' },
    { target: '[data-tour="team-manage-invite"]', title: '초대 코드', description: '초대 코드를 복사해 가입할 팀원에게 전달할 수 있습니다.', side: 'right' },
    { target: '[data-tour="team-manage-members"]', title: '동기화 팀원', description: '동기화된 팀원과 각 팀원의 마지막 연결 시간을 확인할 수 있습니다.', side: 'top' },
    { target: '[data-tour="team-manage-disband"]', title: '팀 해체', description: '팀장 권한과 팀 연결을 종료할 수 있습니다. 선택하면 확인 절차가 표시됩니다.', side: 'left' },
  ],
};
