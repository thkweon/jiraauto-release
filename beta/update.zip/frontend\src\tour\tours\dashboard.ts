import type { TourDefinition } from '../types';

export const dashboardTour: TourDefinition = {
  id: 'dashboard',
  version: 1,
  steps: [
    {
      target: '[data-tour="dashboard-page"]',
      title: '개인 현황판',
      description: '내가 담당하거나 언급되고 보고한 Jira 업무를 한 화면에서 확인할 수 있습니다.',
      side: 'top',
    },
    {
      target: '[data-tour="dashboard-filters"]',
      title: '업무 필터',
      description: '계정, 기간과 프로젝트를 선택하면 조건에 맞는 업무만 표시됩니다.',
      side: 'bottom',
    },
    {
      target: '[data-tour="dashboard-search"]',
      title: '업무 검색',
      description: '티켓 번호, 제목, 사용자, 컴포넌트 또는 레이블로 업무를 찾을 수 있습니다.',
      side: 'bottom',
    },
    {
      target: '[data-tour="dashboard-assigned"]',
      title: '내 업무',
      description: '나에게 할당된 업무가 표시됩니다. 기록 버튼으로 새 업무 기록을 만들 수 있습니다.',
      side: 'right',
    },
    {
      target: '[data-tour="dashboard-mentioned"]',
      title: '멘션된 업무',
      description: '댓글이나 설명에서 내가 언급된 업무를 확인할 수 있습니다.',
      side: 'top',
    },
    {
      target: '[data-tour="dashboard-reported"]',
      title: '보고한 업무',
      description: '내가 보고자로 등록된 업무를 확인할 수 있습니다.',
      side: 'left',
    },
  ],
};
