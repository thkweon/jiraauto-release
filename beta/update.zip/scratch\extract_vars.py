import re
import os

path = 'frontend/src/pages/DashboardPage.tsx'
with open(path, 'r', encoding='utf-8') as f:
    content = f.read()

lines = content.split('\n')
start_idx = -1
for i, line in enumerate(lines):
    if line.startswith('export default function DashboardPage() {'):
        start_idx = i
        break
end_idx = -1
for i in range(start_idx, len(lines)):
    if lines[i].startswith('  return (') and lines[i+1].strip().startswith('<div className="dashboard-glass-container">'):
        end_idx = i
        break

logic_code = '\n'.join(lines[start_idx+1:end_idx])

vars_to_export = set()

for m in re.finditer(r'^  (?:const|let)\s+\[(.*?)\]\s*=', logic_code, re.MULTILINE):
    parts = m.group(1).split(',')
    for p in parts:
        p = p.strip()
        if p:
            vars_to_export.add(p)

for m in re.finditer(r'^  (?:const|let)\s+([a-zA-Z0-9_]+)\s*[:=]', logic_code, re.MULTILINE):
    vars_to_export.add(m.group(1))

for m in re.finditer(r'^  function\s+([a-zA-Z0-9_]+)\s*\(', logic_code, re.MULTILINE):
    vars_to_export.add(m.group(1))

print("Found", len(vars_to_export), "variables.")

value_str = '{\n' + ',\n'.join(['    ' + v for v in sorted(list(vars_to_export))]) + '\n  }'
with open('scratch/context_vars.txt', 'w', encoding='utf-8') as f:
    f.write(value_str)
