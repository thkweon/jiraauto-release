export type FloatingWidgetKind =
  | 'calendar'
  | 'clock'
  | 'd-day'
  | 'it-calculator'
  | 'uptime-kuma'
  | 'checkauto'
  | 'worklog-summary'
  | 'notepad'
  | 'quick-link';

export type FloatingWidgetSide = 'left' | 'right';
export type FloatingWidgetBlock = 'top' | 'middle' | 'bottom' | 'top-middle' | 'middle-bottom';
export type FloatingWidgetVariant = 'default' | 'world-time' | 'single' | 'double';
export type FloatingWidgetHiddenReason = 'horizontal-space' | 'vertical-space';

export interface FloatingWidgetReferenceProfile {
  width: number;
  height: number;
  minScale: number;
  maxScale: number;
  minViewportWidth?: number;
}

export interface FloatingWidgetLayoutInput {
  viewportWidth: number;
  viewportHeight: number;
  kind: FloatingWidgetKind;
  placement: string;
  variant?: FloatingWidgetVariant;
  restoreMargin?: number;
  constrainToSlots?: boolean;
}

export interface FloatingWidgetLayoutResult {
  side: FloatingWidgetSide;
  block: FloatingWidgetBlock;
  scale: number;
  width: number;
  height: number;
  visible: boolean;
  hiddenReason?: FloatingWidgetHiddenReason;
}

export interface FloatingWidgetStackItem {
  kind: FloatingWidgetKind;
  side: FloatingWidgetSide;
  block: FloatingWidgetBlock;
  height: number;
}

export const FLOATING_WIDGET_REFERENCE_VIEWPORT = {
  width: 1920,
  height: 1080,
} as const;

// 1100px is the existing visual rail. It is intentionally separate from the
// minimum width required to keep the three dashboard columns usable.
export const FLOATING_WIDGET_LAYOUT_METRICS = {
  preferredContentWidth: 1100,
  dashboardHardMinWidth: 1020,
  contentGap: 20,
  viewportEdgeGap: 16,
  restoreHysteresis: 40,
  resizeDebounceMs: 150,
} as const;

export const FLOATING_WIDGET_SAFE_AREAS = {
  left: {
    singleTop: 8,
    singleBottom: 24,
    doubleTop: 8,
    doubleBottom: 28,
  },
  right: {
    singleTop: 40,
    singleBottom: 90,
    doubleTop: 56,
    doubleBottom: 102,
  },
} as const;

const FLOATING_WIDGET_BLOCK_SLOTS: Record<FloatingWidgetBlock, number[]> = {
  top: [0],
  middle: [1],
  bottom: [2],
  'top-middle': [0, 1],
  'middle-bottom': [1, 2],
};

const FLOATING_WIDGET_BLOCK_ORDER: Record<FloatingWidgetBlock, number> = {
  top: 0,
  'top-middle': 0,
  middle: 1,
  'middle-bottom': 1,
  bottom: 2,
};

export const calculateFloatingWidgetStackTops = (
  viewportHeight: number,
  widgets: FloatingWidgetStackItem[],
) => {
  const tops: Partial<Record<FloatingWidgetKind, number>> = {};
  (['left', 'right'] as FloatingWidgetSide[]).forEach(side => {
    const sideWidgets = widgets
      .filter(widget => widget.side === side && widget.kind !== 'quick-link')
      .sort((left, right) => FLOATING_WIDGET_BLOCK_ORDER[left.block] - FLOATING_WIDGET_BLOCK_ORDER[right.block]);
    if (sideWidgets.length < 2) return;

    const occupiedSlots = new Set(sideWidgets.flatMap(widget => FLOATING_WIDGET_BLOCK_SLOTS[widget.block]));
    if (occupiedSlots.size !== 3) return;

    const safeArea = FLOATING_WIDGET_SAFE_AREAS[side];
    const first = sideWidgets[0];
    const last = sideWidgets[sideWidgets.length - 1];
    const topInset = first.block === 'top-middle' ? safeArea.doubleTop : safeArea.singleTop;
    const bottomInset = last.block === 'middle-bottom' ? safeArea.doubleBottom : safeArea.singleBottom;
    const totalWidgetHeight = sideWidgets.reduce((sum, widget) => sum + widget.height, 0);
    const gap = (viewportHeight - topInset - bottomInset - totalWidgetHeight) / (sideWidgets.length - 1);
    if (gap < 0) return;

    let top = topInset;
    sideWidgets.forEach(widget => {
      tops[widget.kind] = top;
      top += widget.height + gap;
    });
  });
  return tops;
};

// These are the effective 1920x1080 sizes of the current design. Calendar and
// clock variants are bounded by their existing internal overflow rules.
export const FLOATING_WIDGET_REFERENCE_PROFILES: Record<
  FloatingWidgetKind,
  Partial<Record<FloatingWidgetVariant, FloatingWidgetReferenceProfile>>
> = {
  calendar: {
    default: { width: 286, height: 288, minScale: 0.78, maxScale: 1.3 },
  },
  clock: {
    default: { width: 220, height: 104, minScale: 0.85, maxScale: 1.3 },
    'world-time': {
      width: 320,
      height: 205,
      minScale: 0.82,
      maxScale: 1.3,
      // A world-time clock is substantially wider than the local clock and
      // can contain long city/UTC labels. Treat it as a large rail widget so
      // it does not outlive larger widgets on a compact viewport.
      minViewportWidth: 1740,
    },
  },
  'd-day': {
    default: { width: 250, height: 220, minScale: 0.82, maxScale: 1.3 },
  },
  'it-calculator': {
    double: { width: 340, height: 560, minScale: 0.93, maxScale: 1.3 },
  },
  'uptime-kuma': {
    double: { width: 340, height: 560, minScale: 0.93, maxScale: 1.3 },
  },
  checkauto: {
    double: { width: 340, height: 560, minScale: 0.93, maxScale: 1.3 },
  },
  'worklog-summary': {
    default: { width: 286, height: 288, minScale: 0.82, maxScale: 1.3 },
  },
  notepad: {
    single: { width: 360, height: 288, minScale: 0.9, maxScale: 1.3 },
    double: { width: 360, height: 560, minScale: 0.9, maxScale: 1.3 },
  },
  'quick-link': {
    default: {
      width: 58,
      height: 300,
      minScale: 0.9,
      maxScale: 1.2,
      // The 58px vertical rail naturally fits down to about 1197px while
      // preserving the dashboard hard minimum. Keep one standard breakpoint
      // of safety so it remains useful on 1366px laptops without intruding on
      // the dashboard at tablet-sized widths.
      minViewportWidth: 1280,
    },
  },
};

const clamp = (value: number, minimum: number, maximum: number) => (
  Math.min(maximum, Math.max(minimum, value))
);

export const parseFloatingWidgetPlacement = (placement: string) => {
  const [rawSide, ...rawBlock] = placement.split('-');
  const side: FloatingWidgetSide = rawSide === 'right' ? 'right' : 'left';
  const joinedBlock = rawBlock.join('-');
  const block: FloatingWidgetBlock = (
    joinedBlock === 'middle'
    || joinedBlock === 'bottom'
    || joinedBlock === 'top-middle'
    || joinedBlock === 'middle-bottom'
  ) ? joinedBlock : 'top';
  return { side, block };
};

export const getFloatingWidgetReferenceProfile = (
  kind: FloatingWidgetKind,
  variant: FloatingWidgetVariant = 'default',
) => {
  const profiles = FLOATING_WIDGET_REFERENCE_PROFILES[kind];
  const profile = profiles[variant] || profiles.default || profiles.single || profiles.double;
  if (!profile) throw new Error(`Missing floating widget profile: ${kind}/${variant}`);
  return profile;
};

const getVerticalAvailableSpace = (
  viewportHeight: number,
  side: FloatingWidgetSide,
  block: FloatingWidgetBlock,
  constrainToSlots: boolean,
) => {
  const safeArea = FLOATING_WIDGET_SAFE_AREAS[side];
  const double = block === 'top-middle' || block === 'middle-bottom';
  const top = double ? safeArea.doubleTop : safeArea.singleTop;
  const bottom = double ? safeArea.doubleBottom : safeArea.singleBottom;
  if (!constrainToSlots) return Math.max(0, viewportHeight - top - bottom);

  const slotGap = 16;
  const singleUsableHeight = Math.max(
    0,
    viewportHeight - safeArea.singleTop - safeArea.singleBottom - slotGap * 2,
  );
  const singleSlotHeight = singleUsableHeight / 3;
  if (!double) return singleSlotHeight;

  const doubleInsetAdjustment = block === 'top-middle'
    ? safeArea.doubleTop - safeArea.singleTop
    : safeArea.doubleBottom - safeArea.singleBottom;
  return Math.max(0, singleSlotHeight * 2 + slotGap - doubleInsetAdjustment);
};

export const calculateFloatingWidgetLayout = ({
  viewportWidth,
  viewportHeight,
  kind,
  placement,
  variant = 'default',
  restoreMargin = 0,
  constrainToSlots = false,
}: FloatingWidgetLayoutInput): FloatingWidgetLayoutResult => {
  const { side, block } = parseFloatingWidgetPlacement(placement);
  const profile = getFloatingWidgetReferenceProfile(kind, variant);
  const { dashboardHardMinWidth, contentGap, viewportEdgeGap } = FLOATING_WIDGET_LAYOUT_METRICS;

  const availableSideWidth = Math.max(
    0,
    (viewportWidth - dashboardHardMinWidth) / 2
      - contentGap
      - viewportEdgeGap
      - restoreMargin,
  );
  const availableHeight = Math.max(
    0,
    getVerticalAvailableSpace(viewportHeight, side, block, constrainToSlots) - restoreMargin,
  );
  // The original 1920x1080 composition used fixed widget sizes inside a
  // browser viewport whose usable height is naturally smaller than the monitor
  // resolution. Width therefore controls the preferred visual scale; height is
  // enforced separately through heightFitScale so short windows still shrink
  // or hide widgets without making a normal maximized window look smaller.
  const viewportScale = viewportWidth / FLOATING_WIDGET_REFERENCE_VIEWPORT.width;
  const preferredScale = clamp(viewportScale, profile.minScale, profile.maxScale);
  const widthFitScale = availableSideWidth / profile.width;
  const heightFitScale = availableHeight / profile.height;
  const scale = Math.min(preferredScale, widthFitScale, heightFitScale, profile.maxScale);
  const horizontalFit = widthFitScale >= profile.minScale;
  const verticalFit = heightFitScale >= profile.minScale;
  const viewportWidthFit = viewportWidth >= (profile.minViewportWidth || 0);
  const visible = horizontalFit && verticalFit && viewportWidthFit;

  return {
    side,
    block,
    scale: visible ? Math.max(profile.minScale, scale) : profile.minScale,
    width: profile.width * (visible ? Math.max(profile.minScale, scale) : profile.minScale),
    height: profile.height * (visible ? Math.max(profile.minScale, scale) : profile.minScale),
    visible,
    hiddenReason: !horizontalFit || !viewportWidthFit
      ? 'horizontal-space'
      : !verticalFit
        ? 'vertical-space'
        : undefined,
  };
};
