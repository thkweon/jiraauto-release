import { useEffect, useState, type RefObject } from 'react';
import { ArrowDown, ArrowUp } from 'lucide-react';

const SHOW_AFTER_PX = 360;

interface ScrollToTopButtonProps {
  scrollContainerRef?: RefObject<HTMLElement | null>;
  /** When supplied, the bottom button first scrolls here, then to the true bottom. */
  middleTargetRef?: RefObject<HTMLElement | null>;
  className?: string;
}

export default function ScrollToTopButton({ scrollContainerRef, middleTargetRef, className = '' }: ScrollToTopButtonProps) {
  const [visible, setVisible] = useState(false);
  const [bottomVisible, setBottomVisible] = useState(false);
  const [middleReached, setMiddleReached] = useState(false);

  useEffect(() => {
    const scrollTarget = scrollContainerRef?.current;
    const handleScroll = () => {
      const scrollTop = scrollTarget?.scrollTop ?? window.scrollY;
      const scrollHeight = scrollTarget?.scrollHeight ?? document.documentElement.scrollHeight;
      const clientHeight = scrollTarget?.clientHeight ?? window.innerHeight;
      setVisible(scrollTop > SHOW_AFTER_PX);
      setBottomVisible(scrollHeight - clientHeight - scrollTop > SHOW_AFTER_PX);
      if (middleTargetRef?.current && scrollTarget) {
        const targetTop = middleTargetRef.current.getBoundingClientRect().top
          - scrollTarget.getBoundingClientRect().top + scrollTop;
        setMiddleReached(scrollTop >= targetTop - 48);
      }
    };

    handleScroll();
    const eventTarget = scrollTarget || window;
    eventTarget.addEventListener('scroll', handleScroll, { passive: true });
    window.addEventListener('resize', handleScroll);

    // The modal can open before its async issue details arrive. A fixed-height
    // scroll container may keep the same box size while scrollHeight changes,
    // so also watch DOM mutations and descendant resizes (e.g. loaded images).
    let resizeObserver: ResizeObserver | undefined;
    let mutationObserver: MutationObserver | undefined;
    if (scrollTarget) {
      if (typeof ResizeObserver !== 'undefined') {
        resizeObserver = new ResizeObserver(handleScroll);
        resizeObserver.observe(scrollTarget);
        scrollTarget.querySelectorAll('*').forEach(element => resizeObserver?.observe(element));
      }
      if (typeof MutationObserver !== 'undefined') {
        mutationObserver = new MutationObserver(records => {
          for (const record of records) {
            record.addedNodes.forEach(node => {
              if (node instanceof HTMLElement) {
                resizeObserver?.observe(node);
                node.querySelectorAll('*').forEach(element => resizeObserver?.observe(element));
              }
            });
          }
          handleScroll();
        });
        mutationObserver.observe(scrollTarget, { childList: true, subtree: true, characterData: true });
      }
    }

    return () => {
      eventTarget.removeEventListener('scroll', handleScroll);
      window.removeEventListener('resize', handleScroll);
      mutationObserver?.disconnect();
      resizeObserver?.disconnect();
    };
  }, [scrollContainerRef, middleTargetRef]);

  const isModalControl = className.split(/\s+/).includes('modal-scroll-to-top-button');
  const topButtonStyle = isModalControl
    ? { bottom: 'var(--modal-scroll-top-button-bottom, 62px)' }
    : undefined;
  const bottomButtonStyle = isModalControl
    ? { bottom: 'var(--modal-scroll-bottom-button-bottom, 116px)' }
    : undefined;

  const scrollToTop = () => {
    const scrollTarget = scrollContainerRef?.current;
    if (scrollTarget) {
      scrollTarget.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const scrollToBottom = () => {
    const scrollTarget = scrollContainerRef?.current;
    if (scrollTarget && middleTargetRef?.current) {
      const targetTop = middleTargetRef.current.getBoundingClientRect().top
        - scrollTarget.getBoundingClientRect().top + scrollTarget.scrollTop;
      if (scrollTarget.scrollTop < targetTop - 48) {
        scrollTarget.scrollTo({ top: targetTop, behavior: 'smooth' });
        return;
      }
      scrollTarget.scrollTo({ top: scrollTarget.scrollHeight, behavior: 'smooth' });
      return;
    }
    if (scrollTarget) {
      scrollTarget.scrollTo({ top: scrollTarget.scrollHeight, behavior: 'smooth' });
      return;
    }
    window.scrollTo({ top: document.documentElement.scrollHeight, behavior: 'smooth' });
  };

  return (
    <>
    <button
      type="button"
      className={`scroll-to-top-button ${className} ${visible ? 'visible' : ''}`.trim()}
      style={topButtonStyle}
      onClick={scrollToTop}
      aria-label="상단으로 이동"
      title="상단으로 이동"
    >
      <ArrowUp size={20} strokeWidth={2.4} />
    </button>
    <button
      type="button"
      className={`scroll-to-top-button scroll-to-bottom-button ${className} ${bottomVisible ? 'visible' : ''}`.trim()}
      style={bottomButtonStyle}
      onClick={scrollToBottom}
      aria-label={middleTargetRef && !middleReached ? '코멘트로 이동' : '하단으로 이동'}
      title={middleTargetRef && !middleReached ? '코멘트로 이동' : '하단으로 이동'}
    >
      <ArrowDown size={20} strokeWidth={2.4} />
    </button>
    </>
  );
}
