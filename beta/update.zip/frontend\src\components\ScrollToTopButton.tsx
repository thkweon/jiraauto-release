import { useEffect, useState, type RefObject } from 'react';
import { ArrowDown, ArrowUp } from 'lucide-react';

const SHOW_AFTER_PX = 360;

interface ScrollToTopButtonProps {
  scrollContainerRef?: RefObject<HTMLElement | null>;
  className?: string;
}

export default function ScrollToTopButton({ scrollContainerRef, className = '' }: ScrollToTopButtonProps) {
  const [visible, setVisible] = useState(false);
  const [bottomVisible, setBottomVisible] = useState(false);

  useEffect(() => {
    const scrollTarget = scrollContainerRef?.current;
    const handleScroll = () => {
      const scrollTop = scrollTarget?.scrollTop ?? window.scrollY;
      const scrollHeight = scrollTarget?.scrollHeight ?? document.documentElement.scrollHeight;
      const clientHeight = scrollTarget?.clientHeight ?? window.innerHeight;
      setVisible(scrollTop > SHOW_AFTER_PX);
      setBottomVisible(scrollHeight - clientHeight - scrollTop > SHOW_AFTER_PX);
    };

    handleScroll();
    const eventTarget = scrollTarget || window;
    eventTarget.addEventListener('scroll', handleScroll, { passive: true });
    return () => eventTarget.removeEventListener('scroll', handleScroll);
  }, [scrollContainerRef]);

  const scrollToTop = () => {
    const scrollTarget = scrollContainerRef?.current;
    if (scrollTarget) {
      scrollTarget.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const scrollToBottom = () => {
    const scrollTarget = scrollContainerRef?.current;
    if (scrollTarget) {
      scrollTarget.scrollTo({ top: scrollTarget.scrollHeight, behavior: 'smooth' });
      return;
    }
    window.scrollTo({ top: document.documentElement.scrollHeight, behavior: 'smooth' });
  };

  return (
    <>
    <button
      type="button"
      className={`scroll-to-top-button ${className} ${visible ? 'visible' : ''}`.trim()}
      onClick={scrollToTop}
      aria-label="상단으로 이동"
      title="상단으로 이동"
    >
      <ArrowUp size={20} strokeWidth={2.4} />
    </button>
    <button
      type="button"
      className={`scroll-to-top-button scroll-to-bottom-button ${className} ${bottomVisible ? 'visible' : ''}`.trim()}
      onClick={scrollToBottom}
      aria-label="하단으로 이동"
      title="하단으로 이동"
    >
      <ArrowDown size={20} strokeWidth={2.4} />
    </button>
    </>
  );
}
