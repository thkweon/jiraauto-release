import { useEffect, useState, type RefObject } from 'react';
import { ArrowUp } from 'lucide-react';

const SHOW_AFTER_PX = 360;

interface ScrollToTopButtonProps {
  scrollContainerRef?: RefObject<HTMLElement | null>;
  className?: string;
}

export default function ScrollToTopButton({ scrollContainerRef, className = '' }: ScrollToTopButtonProps) {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const scrollTarget = scrollContainerRef?.current;
    const handleScroll = () => {
      setVisible((scrollTarget?.scrollTop ?? window.scrollY) > SHOW_AFTER_PX);
    };

    handleScroll();
    const eventTarget = scrollTarget || window;
    eventTarget.addEventListener('scroll', handleScroll, { passive: true });
    return () => eventTarget.removeEventListener('scroll', handleScroll);
  }, [scrollContainerRef]);

  const scrollToTop = () => {
    const scrollTarget = scrollContainerRef?.current;
    if (scrollTarget) {
      scrollTarget.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <button
      type="button"
      className={`scroll-to-top-button ${className} ${visible ? 'visible' : ''}`.trim()}
      onClick={scrollToTop}
      aria-label="상단으로 이동"
      title="상단으로 이동"
    >
      <ArrowUp size={20} strokeWidth={2.4} />
    </button>
  );
}
