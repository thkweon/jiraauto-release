import type { TourDefinition } from '../types';

export const teamStartTour: TourDefinition = {
  id: 'team-start',
  version: 1,
  steps: [
    { target: '[data-tour="team-start-page"]', title: '팀 참여하기', description: '새 팀을 개설하거나 기존 팀의 초대 코드를 이용해 참여할 수 있습니다.', side: 'top' },
    { target: '[data-tour="team-start-leader"]', title: '팀 개설', description: '내 PC를 팀 서버로 사용하려면 표시 이름을 확인하고 팀 개설하기를 선택하세요.', side: 'right' },
    { target: '[data-tour="team-start-member"]', title: '팀 가입', description: '팀장이 제공한 초대 코드와 내 식별자를 입력하면 팀에 참여할 수 있습니다.', side: 'left' },
  ],
};
