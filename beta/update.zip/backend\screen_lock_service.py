"""Local screen privacy lock. Credentials and failure counters stay server-side."""
import base64
import hashlib
import hmac
import json
import secrets
import sqlite3
import struct
import time
from contextlib import contextmanager
from urllib.parse import quote

import qrcode
import qrcode.image.svg

METHODS = {'pattern3', 'pattern4', 'pattern5', 'pin4', 'pin6', 'password'}
# Unlock sessions let a page reload stay unlocked; clients refresh them while unlocked and revoke on lock.
SESSION_TTL = 120
OTP_ISSUER = 'JIRAAUTO'
OTP_LABEL = '화면 잠금'


def totp_code(secret, counter):
    digest = hmac.new(base64.b32decode(secret), struct.pack('>Q', counter), hashlib.sha1).digest()
    offset = digest[-1] & 15
    return f'{(struct.unpack(">I", digest[offset:offset + 4])[0] & 0x7FFFFFFF) % 1000000:06d}'


def totp_match(secret, code, last_counter=-1):
    """Return the matched time step (±1 step drift allowed), refusing steps already used."""
    counter = int(time.time() // 30)
    for candidate in (counter, counter - 1, counter + 1):
        if candidate > last_counter and hmac.compare_digest(totp_code(secret, candidate), code):
            return candidate
    return None


class ScreenLockStore:
    def __init__(self, path, unregister=None):
        self.path = path
        self.unregister = unregister

    @contextmanager
    def connect(self):
        conn = sqlite3.connect(self.path, timeout=30)
        try:
            conn.execute('CREATE TABLE IF NOT EXISTS screen_lock (id INTEGER PRIMARY KEY, value TEXT NOT NULL)')
            conn.commit()
            with conn:
                yield conn
        finally:
            conn.close()

    def read(self, conn):
        row = conn.execute('SELECT value FROM screen_lock WHERE id=1').fetchone()
        return json.loads(row[0]) if row else None

    def write(self, conn, state):
        conn.execute('INSERT OR REPLACE INTO screen_lock VALUES (1, ?)', (json.dumps(state),))

    # OTP lives in its own row so it survives disabling the lock and can be reused later.
    def read_otp(self, conn):
        row = conn.execute('SELECT value FROM screen_lock WHERE id=2').fetchone()
        return json.loads(row[0]) if row else None

    def write_otp(self, conn, otp):
        conn.execute('INSERT OR REPLACE INTO screen_lock VALUES (2, ?)', (json.dumps(otp),))

    def public(self, state):
        if not state:
            return {'enabled': False}
        return {k: v for k, v in state.items() if k not in {'salt', 'verifier', 'sessions'}} | {'enabled': True}

    def sessions(self, state):
        now = time.time()
        state['sessions'] = {token: expires for token, expires in state.get('sessions', {}).items() if expires > now}
        return state['sessions']

    def issue(self, state):
        token = secrets.token_urlsafe(32)
        self.sessions(state)[token] = time.time() + SESSION_TTL
        return token

    def status(self, session=''):
        with self.connect() as conn:
            state = self.read(conn)
            unlocked = bool(state and session and session in self.sessions(state))
            return self.public(state) | {'otp': bool(self.read_otp(conn)), 'unlocked': unlocked}

    def otp_setup(self):
        secret = base64.b32encode(secrets.token_bytes(20)).decode()
        uri = f'otpauth://totp/{quote(OTP_ISSUER)}:{quote(OTP_LABEL)}?secret={secret}&issuer={quote(OTP_ISSUER)}&algorithm=SHA1&digits=6&period=30'
        svg = qrcode.make(uri, image_factory=qrcode.image.svg.SvgPathImage, box_size=10, border=2).to_string(encoding='unicode')
        return {'secret': secret, 'uri': uri, 'svg': svg}

    def otp_confirm(self, secret, code, current):
        try:
            if len(base64.b32decode(secret)) != 20:
                raise ValueError
        except Exception:
            raise ValueError('OTP 등록 정보가 올바르지 않습니다. 다시 시도하세요.') from None
        with self.connect() as conn:
            conn.execute('BEGIN IMMEDIATE')
            state = self.read(conn)
            if state:
                result = self.verify(conn, state, current)
                if not result['ok']:
                    return result
            matched = totp_match(secret, code)
            if matched is None:
                return {'ok': False, 'message': 'OTP 코드가 일치하지 않습니다. 앱의 시간 동기화를 확인하세요.'}
            self.write_otp(conn, {'secret': secret, 'failures': 0, 'retryAt': 0, 'lastCounter': matched})
            return {'ok': True, 'otp': True}

    def otp_unlock(self, code):
        """Recovery path: a valid OTP disables the lock and discards the forgotten credential."""
        with self.connect() as conn:
            conn.execute('BEGIN IMMEDIATE')
            otp = self.read_otp(conn)
            if not otp:
                return {'ok': False, 'message': 'OTP가 등록되어 있지 않습니다.'}
            if otp.get('retryAt', 0) > time.time():
                return {'ok': False, 'message': '잠시 후 다시 시도하세요.'}
            matched = totp_match(otp['secret'], code, otp.get('lastCounter', -1))
            if matched is None:
                otp['failures'] = otp.get('failures', 0) + 1
                if otp['failures'] >= 5:
                    otp['retryAt'] = time.time() + min(300, 30 * (2 ** min(4, (otp['failures'] - 5) // 5)))
                self.write_otp(conn, otp)
                return {'ok': False, 'message': 'OTP 코드가 일치하지 않습니다.'}
            otp.update(failures=0, retryAt=0, lastCounter=matched)
            self.write_otp(conn, otp)
            conn.execute('DELETE FROM screen_lock WHERE id=1')
            return {'ok': True, 'enabled': False, 'otp': True}

    def otp_delete(self):
        with self.connect() as conn:
            conn.execute('BEGIN IMMEDIATE')
            if self.read(conn):
                raise ValueError('화면 잠금을 먼저 해제해야 OTP를 삭제할 수 있습니다.')
            conn.execute('DELETE FROM screen_lock WHERE id=2')
            return {'ok': True, 'otp': False}

    def touch(self, session):
        with self.connect() as conn:
            conn.execute('BEGIN IMMEDIATE')
            state = self.read(conn)
            if not state or session not in self.sessions(state):
                return {'ok': False}
            state['sessions'][session] = time.time() + SESSION_TTL
            self.write(conn, state)
            return {'ok': True}

    def revoke(self, session):
        with self.connect() as conn:
            conn.execute('BEGIN IMMEDIATE')
            state = self.read(conn)
            if state:
                self.sessions(state).pop(session, None)
                self.write(conn, state)
            return {'ok': True}

    def digest(self, method, secret, salt):
        return hashlib.pbkdf2_hmac('sha256', f'{method}:{secret}'.encode(), bytes.fromhex(salt), 210000).hex()

    def verify(self, conn, state, secret):
        if state.get('retryAt', 0) > time.time():
            return {'ok': False, 'message': '잠시 후 다시 시도하세요.', **self.public(state)}
        if not state.get('resetPending') and hmac.compare_digest(state['verifier'], self.digest(state['method'], secret, state['salt'])):
            state.update(failures=0, retryAt=0)
            self.write(conn, state)
            return {'ok': True}
        state['failures'] = state.get('failures', 0) + 1
        threshold = state.get('resetAfter', 0)
        if threshold and state['failures'] >= threshold:
            state['resetPending'] = True
            if self.unregister:
                try:
                    self.unregister()
                except Exception:
                    state['retryAt'] = time.time() + 30
                    self.write(conn, state)
                    return {'ok': False, 'message': '라이선스 서버 기기 해제 실패: 데이터를 보존했습니다. 30초 후 다시 시도하세요.', **self.public(state)}
            # Keep schemas intact; clear all local application records atomically.
            tables = conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'").fetchall()
            conn.execute('PRAGMA defer_foreign_keys=ON')
            for (table,) in tables:
                conn.execute('DELETE FROM "' + table.replace('"', '""') + '"')
            return {'ok': False, 'reset': True, 'message': '실패 횟수 초과로 로컬 DB와 라이선스 등록을 초기화했습니다.'}
        if state['failures'] >= 5:
            state['retryAt'] = time.time() + min(300, 30 * (2 ** min(4, (state['failures'] - 5) // 5)))
        self.write(conn, state)
        return {'ok': False, 'message': '입력이 일치하지 않습니다.', **self.public(state)}

    def attempt(self, secret):
        with self.connect() as conn:
            conn.execute('BEGIN IMMEDIATE')
            state = self.read(conn)
            if not state:
                return {'ok': True}
            result = self.verify(conn, state, secret)
            if not result['ok']:
                return result
            token = self.issue(state)
            self.write(conn, state)
            return {'ok': True, 'session': token}

    def configure(self, config, secret, current):
        method = config.get('method', '')
        if config.get('enabled', True):
            if method not in METHODS:
                raise ValueError('지원하지 않는 잠금 방식입니다.')
            valid = False
            if method.startswith('pin'):
                valid = secret.isascii() and secret.isdigit() and len(secret) == int(method[-1])
            elif method == 'password':
                valid = 8 <= len(secret) <= 256
            else:
                size = int(method[-1])
                try:
                    points = [int(p) for p in secret.split(',')]
                    valid = len(points) >= size + 1 and len(set(points)) == len(points) and all(0 <= p < size * size for p in points)
                except ValueError:
                    pass
            if not valid:
                raise ValueError('인증 입력 길이 또는 형식이 올바르지 않습니다.')
            for key, low, high in [('idleSeconds', 0, 86400), ('blurSeconds', -1, 86400), ('resetAfter', 0, 100)]:
                value = config.get(key, 0)
                if type(value) is not int or not low <= value <= high:
                    raise ValueError('잠금 시간 또는 실패 횟수가 올바르지 않습니다.')
            if config.get('resetAfter', 0) and not config.get('resetConfirmed'):
                raise ValueError('DB 전체 삭제 안내에 동의해야 합니다.')
        with self.connect() as conn:
            conn.execute('BEGIN IMMEDIATE')
            previous = self.read(conn)
            if previous:
                result = self.verify(conn, previous, current)
                if not result['ok']:
                    return result
            if not config.get('enabled', True):
                conn.execute('DELETE FROM screen_lock WHERE id=1')
                return {'ok': True, 'enabled': False, 'otp': bool(self.read_otp(conn))}
            if not self.read_otp(conn):
                raise ValueError('OTP 인증을 먼저 등록해야 화면 잠금을 켤 수 있습니다.')
            salt = secrets.token_hex(16)
            state = {key: config[key] for key in ('method', 'idleSeconds', 'blurSeconds', 'showLines', 'resetAfter')}
            state.update(notifyWhileLocked=bool(config.get('notifyWhileLocked', False)), salt=salt, verifier=self.digest(method, secret, salt), failures=0, retryAt=0, sessions=self.sessions(previous) if previous else {})
            token = self.issue(state)
            self.write(conn, state)
            return {'ok': True, 'session': token, 'otp': True, **self.public(state)}
