"""Local screen privacy lock. Credentials and failure counters stay server-side."""
import hashlib
import hmac
import json
import secrets
import sqlite3
import time
from contextlib import contextmanager

METHODS = {'pattern3', 'pattern4', 'pattern5', 'pin4', 'pin6', 'password'}


class ScreenLockStore:
    def __init__(self, path, unregister=None):
        self.path = path
        self.unregister = unregister

    @contextmanager
    def connect(self):
        conn = sqlite3.connect(self.path, timeout=30)
        try:
            conn.execute('CREATE TABLE IF NOT EXISTS screen_lock (id INTEGER PRIMARY KEY, value TEXT NOT NULL)')
            conn.commit()
            with conn:
                yield conn
        finally:
            conn.close()

    def read(self, conn):
        row = conn.execute('SELECT value FROM screen_lock WHERE id=1').fetchone()
        return json.loads(row[0]) if row else None

    def write(self, conn, state):
        conn.execute('INSERT OR REPLACE INTO screen_lock VALUES (1, ?)', (json.dumps(state),))

    def public(self, state):
        if not state:
            return {'enabled': False}
        return {k: v for k, v in state.items() if k not in {'salt', 'verifier'}} | {'enabled': True}

    def status(self):
        with self.connect() as conn:
            return self.public(self.read(conn))

    def digest(self, method, secret, salt):
        return hashlib.pbkdf2_hmac('sha256', f'{method}:{secret}'.encode(), bytes.fromhex(salt), 210000).hex()

    def verify(self, conn, state, secret):
        if state.get('retryAt', 0) > time.time():
            return {'ok': False, 'message': '잠시 후 다시 시도하세요.', **self.public(state)}
        if not state.get('resetPending') and hmac.compare_digest(state['verifier'], self.digest(state['method'], secret, state['salt'])):
            state.update(failures=0, retryAt=0)
            self.write(conn, state)
            return {'ok': True}
        state['failures'] = state.get('failures', 0) + 1
        threshold = state.get('resetAfter', 0)
        if threshold and state['failures'] >= threshold:
            state['resetPending'] = True
            if self.unregister:
                try:
                    self.unregister()
                except Exception:
                    state['retryAt'] = time.time() + 30
                    self.write(conn, state)
                    return {'ok': False, 'message': '라이선스 서버 기기 해제 실패: 데이터를 보존했습니다. 30초 후 다시 시도하세요.', **self.public(state)}
            # Keep schemas intact; clear all local application records atomically.
            tables = conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'").fetchall()
            conn.execute('PRAGMA defer_foreign_keys=ON')
            for (table,) in tables:
                conn.execute('DELETE FROM "' + table.replace('"', '""') + '"')
            return {'ok': False, 'reset': True, 'message': '실패 횟수 초과로 로컬 DB와 라이선스 등록을 초기화했습니다.'}
        if state['failures'] >= 5:
            state['retryAt'] = time.time() + min(300, 30 * (2 ** min(4, (state['failures'] - 5) // 5)))
        self.write(conn, state)
        return {'ok': False, 'message': '입력이 일치하지 않습니다.', **self.public(state)}

    def attempt(self, secret):
        with self.connect() as conn:
            conn.execute('BEGIN IMMEDIATE')
            state = self.read(conn)
            return self.verify(conn, state, secret) if state else {'ok': True}

    def configure(self, config, secret, current):
        method = config.get('method', '')
        if config.get('enabled', True):
            if method not in METHODS:
                raise ValueError('지원하지 않는 잠금 방식입니다.')
            valid = False
            if method.startswith('pin'):
                valid = secret.isascii() and secret.isdigit() and len(secret) == int(method[-1])
            elif method == 'password':
                valid = 8 <= len(secret) <= 256
            else:
                size = int(method[-1])
                try:
                    points = [int(p) for p in secret.split(',')]
                    valid = len(points) >= size + 1 and len(set(points)) == len(points) and all(0 <= p < size * size for p in points)
                except ValueError:
                    pass
            if not valid:
                raise ValueError('인증 입력 길이 또는 형식이 올바르지 않습니다.')
            for key, low, high in [('idleSeconds', 0, 86400), ('blurSeconds', -1, 86400), ('resetAfter', 0, 100)]:
                value = config.get(key, 0)
                if type(value) is not int or not low <= value <= high:
                    raise ValueError('잠금 시간 또는 실패 횟수가 올바르지 않습니다.')
            if config.get('resetAfter', 0) and not config.get('resetConfirmed'):
                raise ValueError('DB 전체 삭제 안내에 동의해야 합니다.')
        with self.connect() as conn:
            conn.execute('BEGIN IMMEDIATE')
            previous = self.read(conn)
            if previous:
                result = self.verify(conn, previous, current)
                if not result['ok']:
                    return result
            if not config.get('enabled', True):
                conn.execute('DELETE FROM screen_lock')
                return {'ok': True, 'enabled': False}
            salt = secrets.token_hex(16)
            state = {key: config[key] for key in ('method', 'idleSeconds', 'blurSeconds', 'showLines', 'resetAfter')}
            state.update(salt=salt, verifier=self.digest(method, secret, salt), failures=0, retryAt=0)
            self.write(conn, state)
            return {'ok': True, **self.public(state)}
