import { useEffect, useRef, useState } from 'react';
import type { ReactNode } from 'react';
import { createPortal } from 'react-dom';
import { AnimatePresence, motion, useReducedMotion } from 'framer-motion';
import { ArrowLeft, ArrowRight, BellRing, Check, CheckCircle2, Clock3, KeyRound, LockKeyhole, MousePointer2, ShieldAlert, Smartphone, Trash2, X } from 'lucide-react';
import LockInput from './LockInput';
import { defaults, handleReset, request, setSession } from '../utils/screenLockApi';
import type { Config } from '../utils/screenLockApi';
import { LOCK_EVENT, methods, validSecret } from '../utils/screenLock';
import type { LockMethod } from '../utils/screenLock';

function Toggle({ checked, label, disabled, onChange }: { checked: boolean; label: string; disabled?: boolean; onChange: (checked: boolean) => void }) {
  return <button type="button" role="switch" aria-label={label} aria-checked={checked} disabled={disabled} className={`beta-update-switch settings-switch ${checked ? 'enabled' : ''}`} onClick={() => onChange(!checked)}><span className="beta-update-switch-thumb" /></button>;
}

function Reveal({ children }: { children: ReactNode }) {
  const reduced = useReducedMotion();
  return <motion.div initial={reduced ? false : { height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={{ duration: reduced ? 0 : 0.2 }} className="lock-reveal">{children}</motion.div>;
}

function TimeSetting({ title, description, seconds, immediate, onChange }: { title: string; description: string; seconds: number; immediate?: boolean; onChange: (seconds: number) => void }) {
  const enabled = immediate ? seconds >= 0 : seconds > 0;
  const initial = Math.max(immediate ? 0 : 1, seconds);
  const [unit, setUnit] = useState(initial > 0 && initial % 3600 === 0 ? 3600 : initial > 0 && initial % 60 === 0 ? 60 : 1);
  const [timeInput, setTimeInput] = useState<string | null>(null);
  const remembered = useRef(seconds >= 0 ? seconds : 30);
  return <div className="lock-option">
    <div className="settings-option-row"><div><h3 className="settings-section-title">{immediate ? <MousePointer2 size={16} /> : <Clock3 size={16} />}{title}</h3><p className="settings-description">{description}</p></div><Toggle label={`${title} 사용`} checked={enabled} onChange={on => { if (!on) remembered.current = seconds; onChange(on ? Math.max(immediate ? 0 : 1, remembered.current) : immediate ? -1 : 0); }} /></div>
    <AnimatePresence initial={false}>{enabled && <Reveal><div className="lock-time-controls">
      <input className="glass-input settings-control" type="number" aria-label={`${title} 시간`} min={immediate ? 0 : 1 / unit} max={86400 / unit} step="any" value={timeInput ?? Number((seconds / unit).toFixed(6))} onBlur={() => setTimeInput(null)} onChange={e => { setTimeInput(e.target.value); if (e.target.value !== '') onChange(Math.max(immediate ? 0 : 1, Math.min(86400, Math.round(Number(e.target.value) * unit)))); }} />
      <select className="glass-input settings-control" aria-label={`${title} 단위`} value={unit} onChange={e => { const next = Number(e.target.value); onChange(Math.max(immediate ? 0 : 1, Math.min(86400, Math.round(seconds / unit * next)))); setUnit(next); }}><option value="1">초</option><option value="60">분</option><option value="3600">시</option></select>
      <span className="settings-description">{immediate && seconds === 0 ? '포커스를 잃으면 즉시 잠금' : '후 잠금'}</span>
    </div><p className="settings-description">{immediate ? '0을 입력하면 즉시 잠깁니다. 최대 24시간.' : '마지막 입력부터 계산합니다. 최소 1초, 최대 24시간.'}</p></Reveal>}</AnimatePresence>
  </div>;
}

export default function ScreenLockSettings() {
  const [saved, setSaved] = useState<Config>(defaults);
  const [draft, setDraft] = useState<Config>(defaults);
  const [pending, setPending] = useState<{ method: LockMethod; secret: string } | null>(null);
  const [modal, setModal] = useState<'register' | 'save' | 'disable' | 'otp' | 'otpDelete' | null>(null);
  const [method, setMethod] = useState<LockMethod>('pin6');
  const [step, setStep] = useState(0);
  const [secret, setSecret] = useState('');
  const [confirm, setConfirm] = useState('');
  const [current, setCurrent] = useState('');
  const [otpSetup, setOtpSetup] = useState<{ secret: string; uri: string; svg: string } | null>(null);
  const [otpCode, setOtpCode] = useState('');
  const [otpStage, setOtpStage] = useState<'current' | 'scan'>('scan');
  const continueAfterOtp = useRef<'register' | 'save' | null>(null);
  const [consent, setConsent] = useState(false);
  const [busy, setBusy] = useState(false);
  const [ready, setReady] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const dialog = useRef<HTMLDialogElement>(null);
  const reduced = useReducedMotion();
  const close = () => { setModal(null); setSecret(''); setConfirm(''); setCurrent(''); setOtpSetup(null); setOtpCode(''); setError(''); setStep(0); };

  useEffect(() => {
    const load = () => request().then(data => { setSaved({ ...defaults, ...data }); setDraft({ ...defaults, ...data }); setReady(true); }).catch(e => setMessage(String(e)));
    void load();
    const sync = (e: StorageEvent) => { if (e.key === LOCK_EVENT) void load(); };
    window.addEventListener(LOCK_EVENT, load); window.addEventListener('storage', sync);
    return () => { window.removeEventListener(LOCK_EVENT, load); window.removeEventListener('storage', sync); };
  }, []);
  useEffect(() => {
    const clear = () => { setPending(null); setModal(null); setSecret(''); setConfirm(''); setCurrent(''); setOtpSetup(null); setOtpCode(''); setStep(0); continueAfterOtp.current = null; dialog.current?.close(); };
    window.addEventListener('screenLocked', clear);
    return () => window.removeEventListener('screenLocked', clear);
  }, []);
  useEffect(() => {
    if (!message) return;
    const timer = window.setTimeout(() => setMessage(''), 4000);
    return () => window.clearTimeout(timer);
  }, [message]);
  useEffect(() => {
    if (!error) return;
    const timer = window.setTimeout(() => setError(''), 4000);
    return () => window.clearTimeout(timer);
  }, [error]);
  useEffect(() => {
    if (!modal) return;
    const element = dialog.current;
    element?.showModal();
    return () => { element?.close(); };
  }, [modal]);

  const save = async (enabled: boolean, credential = current) => {
    if (busy) return;
    setBusy(true); setError(''); setMessage('');
    try {
      const result = await request('', {
        config: { ...draft, method: pending?.method ?? saved.method, enabled, resetConfirmed: consent },
        secret: pending?.secret ?? credential, current: credential,
      }, 'PUT');
      if (result.reset) { handleReset(); return; }
      if (!result.ok) { setError(result.message); setCurrent(''); return; }
      const { session, ...stored } = result;
      if (session) setSession(session);
      setSaved({ ...defaults, ...stored }); setDraft({ ...defaults, ...stored }); setPending(null); setConsent(false); close();
      localStorage.setItem(LOCK_EVENT, String(Date.now())); window.dispatchEvent(new Event(LOCK_EVENT)); setMessage('화면 잠금 설정을 저장했습니다.');
    } catch (e) { const text = e instanceof Error ? e.message : String(e); setError(text); if (!modal) setMessage(text); } finally { setBusy(false); }
  };
  const startRegistration = () => { close(); setMethod(pending?.method ?? draft.method); setModal('register'); };
  const startOtp = async () => {
    close(); setOtpStage(saved.enabled ? 'current' : 'scan'); setModal('otp');
    try { setOtpSetup(await request('/otp/setup', {})); } catch (e) { setError(e instanceof Error ? e.message : String(e)); }
  };
  const confirmOtp = async (code = otpCode) => {
    if (busy || !otpSetup || code.length !== 6) return;
    setBusy(true); setError('');
    try {
      const result = await request('/otp/confirm', { secret: otpSetup.secret, code, current });
      if (result.reset) { handleReset(); return; }
      if (!result.ok) { setError(result.message); setOtpCode(''); if (saved.enabled && !result.message.includes('OTP')) { setCurrent(''); setOtpStage('current'); } return; }
      setSaved(s => ({ ...s, otp: true })); setDraft(d => ({ ...d, otp: true })); close(); setMessage('OTP 인증을 등록했습니다.');
      const resume = continueAfterOtp.current; continueAfterOtp.current = null;
      if (resume === 'register') startRegistration(); else if (resume === 'save') void save(true, '');
    } catch (e) { setError(e instanceof Error ? e.message : String(e)); } finally { setBusy(false); }
  };
  const deleteOtp = async () => {
    if (busy) return;
    setBusy(true); setError('');
    try { await request('/otp', {}, 'DELETE'); setSaved(s => ({ ...s, otp: false })); setDraft(d => ({ ...d, otp: false })); close(); setMessage('OTP 인증을 삭제했습니다.'); }
    catch (e) { setError(e instanceof Error ? e.message : String(e)); } finally { setBusy(false); }
  };
  const enable = () => {
    if (!saved.otp) { continueAfterOtp.current = pending ? 'save' : 'register'; void startOtp(); }
    else if (pending) void save(true, '');
    else startRegistration();
  };
  const next = (entered?: string) => {
    setError('');
    if (step === 0) { if (!validSecret(method, entered ?? secret)) { setError('입력 길이를 확인해 주세요. 패스워드는 최소 8자입니다.'); return; } setStep(1); }
    else if (step === 1) { if (secret !== (entered ?? confirm)) { setError('처음 입력과 일치하지 않습니다. 다시 확인해 주세요.'); setConfirm(''); return; } setStep(2); }
    else { setPending({ method, secret }); setDraft({ ...draft, method }); close(); setMessage('인증 입력을 준비했습니다. 아래 잠금 설정 저장 버튼을 눌러 적용하세요.'); }
  };

  return <section className="glass-panel settings-card screen-lock-settings" aria-labelledby="lock-settings-title">
    <div className="settings-option-row"><div><h2 id="lock-settings-title" className="settings-card-title"><LockKeyhole size={20} />화면 잠금</h2><p className="settings-description">잠금 방식과 자동 잠금 조건을 설정합니다.</p></div><Toggle label="화면 잠금 사용" checked={saved.enabled} disabled={busy || !ready} onChange={on => { setError(''); if (on) enable(); else setModal('disable'); }} /></div>
    <fieldset disabled={busy || !ready} className="lock-fieldset">
      <div className="lock-credential-row"><div className="lock-credential-summary"><div className="lock-emblem compact"><Smartphone size={20} /></div><div><strong>{saved.otp ? 'OTP 인증 등록됨' : 'OTP 인증 미등록 (필수)'}</strong><p className="settings-description">{saved.otp ? '인증 수단을 잊어도 OTP로 해제할 수 있습니다. 잠금이 꺼져도 유지됩니다.' : '화면 잠금을 켜려면 인증 앱(Google Authenticator 등)에 QR을 등록해야 합니다.'}</p></div></div><div className="lock-credential-actions"><button className="btn-secondary settings-action" type="button" onClick={() => void startOtp()}>{saved.otp ? 'OTP 재등록' : 'OTP 등록'}<ArrowRight size={14} /></button>{saved.otp && !saved.enabled && <button className="btn-secondary settings-action" type="button" onClick={() => { setError(''); setModal('otpDelete'); }}><Trash2 size={14} />삭제</button>}</div></div>
      <div className="lock-credential-row"><div className="lock-credential-summary"><div className="lock-emblem compact"><KeyRound size={20} /></div><div><strong>{pending ? methods[pending.method] : saved.enabled ? methods[saved.method] : '인증 수단을 등록하세요'}</strong><p className="settings-description">{pending ? '새 인증 준비 완료 · 아직 저장되지 않았습니다' : saved.enabled ? '등록된 인증으로 화면을 보호하고 있습니다.' : '패턴, PIN 또는 패스워드를 사용할 수 있습니다.'}</p></div></div><button className="btn-secondary settings-action" type="button" aria-disabled={!saved.otp} onClick={() => { if (!saved.otp) { setMessage('OTP 인증을 먼저 등록해야 인증 수단을 등록할 수 있습니다.'); return; } startRegistration(); }}>{saved.enabled || pending ? '인증 변경' : '인증 등록'}<ArrowRight size={14} /></button></div>
      <fieldset disabled={!saved.enabled} className="lock-fieldset lock-options" aria-label="잠금 동작 옵션">
      {!saved.enabled && <p className="settings-description lock-options-hint">화면 잠금을 켜면 아래 옵션을 변경할 수 있습니다.</p>}
      {ready && <div className="lock-time-grid"><TimeSetting title="미사용 잠금" description="앱에서 입력이 없으면 자동으로 잠급니다." seconds={draft.idleSeconds} onChange={idleSeconds => setDraft({ ...draft, idleSeconds })} /><TimeSetting title="포커스 이탈 잠금" description="다른 창이나 탭으로 이동하면 잠급니다." immediate seconds={draft.blurSeconds} onChange={blurSeconds => setDraft({ ...draft, blurSeconds })} /></div>}
      <div className="settings-option-row lock-option"><div><h3 className="settings-section-title"><BellRing size={16} />잠금 중 PC 알림 표시</h3><p className="settings-description">화면이 잠겨 있어도 개인 현황판·팀 게시판 PC 알림을 표시합니다. 알림 내용이 잠금 화면 밖에 노출됩니다.</p></div><Toggle label="잠금 중 PC 알림 표시" checked={draft.notifyWhileLocked} onChange={notifyWhileLocked => setDraft({ ...draft, notifyWhileLocked })} /></div>
      {(pending?.method ?? saved.method).startsWith('pattern') && <div className="settings-option-row lock-option"><div><h3 className="settings-section-title">패턴 연결선 표시</h3><p className="settings-description">잠금 해제 중에도 연결선을 표시합니다. 등록할 때는 항상 표시합니다.</p></div><Toggle label="패턴 연결선 표시" checked={draft.showLines} onChange={showLines => setDraft({ ...draft, showLines })} /></div>}
      <div className="lock-option"><div className="settings-option-row"><div><h3 className="settings-section-title"><ShieldAlert size={16} />연속 실패 시 초기화</h3><p className="settings-description">정해진 횟수에 도달하면 기기 등록 해제와 DB 초기화를 진행합니다.</p></div><Toggle label="연속 실패 시 초기화" checked={draft.resetAfter > 0} onChange={enabled => { setDraft({ ...draft, resetAfter: enabled ? 10 : 0 }); setConsent(false); }} /></div>
        <AnimatePresence initial={false}>{draft.resetAfter > 0 && <Reveal><div className="lock-reset-warning"><label className="settings-field">초기화 기준<div className="lock-time-controls"><input className="glass-input settings-control" type="number" min="1" max="100" value={draft.resetAfter} onChange={e => { if (e.target.value !== '') setDraft({ ...draft, resetAfter: Math.max(1, Math.min(100, Math.floor(Number(e.target.value)))) }); setConsent(false); }} /><span>회 연속 실패</span></div></label><p className="settings-description">로컬 DB의 업무 캐시·팀 게시글·댓글·설정 등 모든 레코드를 삭제하고 라이선스 서버 기기 등록을 해제합니다. 복구할 수 없습니다. Jira 서버 데이터, Windows 계정 설정, 브라우저 메모는 유지됩니다. 서버 해제 실패 시 데이터를 보존합니다.</p><label className="lock-consent"><input type="checkbox" checked={consent} onChange={e => setConsent(e.target.checked)} />삭제 범위를 이해하고 자동 초기화에 동의합니다.</label></div></Reveal>}</AnimatePresence>
      </div>
      </fieldset>
      <p className="settings-description lock-footnote">패턴·PIN·패스워드를 잊으면 잠금 화면의 "OTP로 해제"를 사용하세요. OTP로 해제하면 화면 잠금이 꺼지고 등록된 인증 수단이 삭제됩니다. 잠금 해제 상태는 새로고침해도 유지되며, 탭을 닫거나 잠그면 다시 인증이 필요합니다.</p>
      <div className="settings-actions lock-settings-actions"><button className="btn-premium settings-action" type="button" disabled={(!saved.enabled && !pending) || (draft.resetAfter > 0 && !consent)} onClick={() => { setError(''); if (saved.enabled) setModal('save'); else enable(); }}>{busy ? '저장 중…' : '잠금 설정 저장'}</button></div>
    </fieldset>
    {message && createPortal(<button type="button" role="status" className="settings-toast" title="닫기" onClick={() => setMessage('')}>{message}</button>, document.body)}
    {modal && <dialog ref={dialog} className="glass-panel settings-card lock-registration-dialog" aria-labelledby="lock-dialog-title" onCancel={e => { e.preventDefault(); if (!busy) close(); }}>
      <div className="settings-option-row"><h2 id="lock-dialog-title" className="settings-card-title"><KeyRound size={20} />{modal === 'register' ? '잠금 인증 등록' : modal === 'disable' ? '잠금 기능 해제' : modal === 'otp' ? 'OTP 인증 등록' : modal === 'otpDelete' ? 'OTP 인증 삭제' : '설정 변경 인증'}</h2><button className="btn-secondary lock-close" type="button" aria-label="닫기" disabled={busy} onClick={close}><X size={18} /></button></div>
      {modal === 'register' ? <>
        <ol className="lock-steps" aria-label="인증 등록 단계">{['새 인증 입력', '새 인증 확인', '입력 완료'].map((label, index) => <li key={label} aria-current={step === index ? 'step' : undefined} className={step >= index ? 'active' : ''}><span>{step > index ? <Check size={13} /> : index + 1}</span>{label}</li>)}</ol>
        <AnimatePresence mode="wait" initial={false}><motion.form key={step} initial={reduced ? false : { opacity: 0, x: 22 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: reduced ? 0 : -16 }} transition={{ duration: reduced ? 0 : 0.18 }} onSubmit={e => { e.preventDefault(); next(); }} className="lock-registration-stage">
          {step === 0 && <><label className="settings-field">잠금 방식<select className="glass-input settings-control" value={method} onChange={e => { setMethod(e.target.value as LockMethod); setSecret(''); setConfirm(''); setError(''); }}>{Object.entries(methods).map(([key, label]) => <option key={key} value={key}>{label}</option>)}</select></label><p className="settings-description">사용할 {methods[method]}를 입력하세요.</p><LockInput key={method} method={method} value={secret} onChange={setSecret} onComplete={next} showLines label="새 인증 입력" /></>}
          {step === 1 && <><h3 className="settings-section-title">한 번 더 입력해 주세요</h3><p className="settings-description">같은 {methods[method]}를 입력하면 확인이 완료됩니다.</p><LockInput method={method} value={confirm} onChange={setConfirm} onComplete={next} showLines autoFocus label="새 인증 확인" /></>}
          {step === 2 && <div className="lock-registration-success"><motion.div initial={reduced ? false : { scale: 0.7 }} animate={{ scale: 1 }} transition={{ type: 'spring', stiffness: 260, damping: 18 }}><CheckCircle2 size={48} /></motion.div><h3 className="settings-section-title">인증 입력을 확인했습니다</h3><p className="settings-description">{methods[method]}를 사용할 준비가 되었습니다.<br />완료 후 카드의 잠금 설정 저장 버튼을 눌러 적용하세요.</p></div>}
          <div className="settings-actions">{step > 0 && <button className="btn-secondary settings-action" type="button" onClick={() => { setStep(step - 1); setConfirm(''); setError(''); }}><ArrowLeft size={14} />이전</button>}<button className="btn-premium settings-action" type="submit" disabled={step === 0 ? !validSecret(method, secret) : step === 1 ? !validSecret(method, confirm) : false}>{step === 2 ? '완료' : step === 1 ? '확인' : '다음'}<ArrowRight size={14} /></button></div>
        </motion.form></AnimatePresence>
      </> : modal === 'otp' ? (otpStage === 'current'
        ? <form className="lock-authorization" onSubmit={e => { e.preventDefault(); if (current) setOtpStage('scan'); }}><p className="settings-description">OTP를 변경하려면 현재 등록된 {methods[saved.method]}로 먼저 확인해 주세요.</p><LockInput method={saved.method} value={current} onChange={setCurrent} onComplete={() => setOtpStage('scan')} showLines={saved.showLines} disabled={busy} autoFocus label="현재 인증" /><div className="settings-actions"><button className="btn-secondary settings-action" type="button" disabled={busy} onClick={close}>취소</button><button className="btn-premium settings-action" type="submit" disabled={busy || !current}>다음<ArrowRight size={14} /></button></div></form>
        : <form className="lock-authorization" onSubmit={e => { e.preventDefault(); void confirmOtp(); }}>
          <p className="settings-description">인증 앱으로 QR을 스캔한 뒤 표시된 6자리 코드를 입력하세요. {saved.otp && '기존 OTP는 새 OTP로 교체됩니다.'}</p>
          {otpSetup ? <>
            <img className="lock-otp-qr" alt="OTP 등록 QR 코드" src={`data:image/svg+xml;utf8,${encodeURIComponent(otpSetup.svg)}`} />
            <p className="settings-description lock-otp-secret">수동 입력 키: <code>{otpSetup.secret.replace(/(.{4})/g, '$1 ').trim()}</code></p>
            <input className="glass-input settings-control lock-otp-code" aria-label="OTP 코드" inputMode="numeric" autoComplete="one-time-code" maxLength={6} placeholder="6자리 코드" autoFocus disabled={busy} value={otpCode} onChange={e => { const next = e.target.value.replace(/\D/g, ''); setOtpCode(next); if (next.length === 6) void confirmOtp(next); }} />
          </> : <p className="settings-description">QR 코드를 생성하는 중…</p>}
          <div className="settings-actions"><button className="btn-secondary settings-action" type="button" disabled={busy} onClick={close}>취소</button><button className="btn-premium settings-action" type="submit" disabled={busy || !otpSetup || otpCode.length !== 6}>{busy ? '확인 중…' : 'OTP 등록'}</button></div>
        </form>)
      : modal === 'otpDelete' ? <div className="lock-authorization"><p className="settings-description">등록된 OTP를 삭제합니다. 화면 잠금을 다시 켜려면 OTP를 새로 등록해야 합니다.</p><div className="settings-actions"><button className="btn-secondary settings-action" type="button" disabled={busy} onClick={close}>취소</button><button className="btn-premium settings-action" type="button" disabled={busy} onClick={() => void deleteOtp()}><Trash2 size={14} />{busy ? '삭제 중…' : 'OTP 삭제'}</button></div></div>
      : <form className="lock-authorization" onSubmit={e => { e.preventDefault(); void save(modal !== 'disable'); }}><p className="settings-description">현재 등록된 {methods[saved.method]}로 확인해 주세요. 인증 실패도 연속 실패 횟수에 포함됩니다.</p><LockInput method={saved.method} value={current} onChange={setCurrent} onComplete={value => void save(modal !== 'disable', value)} showLines={saved.showLines} disabled={busy} autoFocus label="현재 인증" /><div className="settings-actions"><button className="btn-secondary settings-action" type="button" disabled={busy} onClick={close}>취소</button><button className="btn-premium settings-action" type="submit" disabled={busy || !current}>{busy ? '확인 중…' : modal === 'disable' ? '기능 해제' : '인증 후 저장'}</button></div></form>}
      {error && <button type="button" role="alert" className="settings-toast" title="닫기" onClick={() => setError('')}>{error}</button>}
    </dialog>}
  </section>;
}
