import { useEffect, useState } from 'react';
import { RefreshCw } from 'lucide-react';
import { fetchUpdateStatus, triggerUpdate, type UpdateStatus } from '../utils/updateClient';
import {
  UPDATE_CHANNEL_CHANGED_EVENT,
  UPDATE_CHANNEL_STORAGE_KEY,
} from '../utils/updateChannel';

const CHECK_INTERVAL_MS = 15 * 60 * 1000;
const EVENT_DEDUPE_MS = 20 * 1000;

export default function Footer() {
  const [isUpdating, setIsUpdating] = useState(false);
  const [status, setStatus] = useState<UpdateStatus | null>(null);

  const refreshStatus = async () => {
    const nextStatus = await fetchUpdateStatus();
    setStatus(nextStatus);
    return nextStatus;
  };

  useEffect(() => {
    let cancelled = false;
    let isChecking = false;
    let lastCheckedAt = 0;

    const load = async (force = false) => {
      const now = Date.now();
      if (isChecking || (!force && now - lastCheckedAt < EVENT_DEDUPE_MS)) return;
      isChecking = true;
      lastCheckedAt = now;
      try {
        const nextStatus = await fetchUpdateStatus();
        if (!cancelled) setStatus(nextStatus);
      } catch (error) {
        console.error('Failed to load update status', error);
      } finally {
        isChecking = false;
      }
    };

    const handleVisibilityChange = () => {
      if (document.visibilityState === 'visible') void load();
    };
    const handleFocus = () => void load();
    const handleChannelChange = () => void load(true);
    const handleStorage = (event: StorageEvent) => {
      if (event.key === UPDATE_CHANNEL_STORAGE_KEY) void load(true);
    };

    void load();
    const interval = window.setInterval(() => void load(), CHECK_INTERVAL_MS);
    document.addEventListener('visibilitychange', handleVisibilityChange);
    window.addEventListener('focus', handleFocus);
    window.addEventListener(UPDATE_CHANNEL_CHANGED_EVENT, handleChannelChange);
    window.addEventListener('storage', handleStorage);

    return () => {
      cancelled = true;
      window.clearInterval(interval);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('focus', handleFocus);
      window.removeEventListener(UPDATE_CHANNEL_CHANGED_EVENT, handleChannelChange);
      window.removeEventListener('storage', handleStorage);
    };
  }, []);

  const handleManualUpdate = async () => {
    let updateStarted = false;
    setIsUpdating(true);
    try {
      const nextStatus = await refreshStatus();
      if (!nextStatus.target) {
        alert('원격 업데이트 정보를 확인할 수 없습니다.');
        return;
      }

      if (!nextStatus.updateAvailable) {
        const channelLabel = nextStatus.selectedChannel === 'beta' ? '베타' : '정식';
        const installedAhead = nextStatus.selectedChannel === 'stable'
          && nextStatus.installedChannel === 'beta';
        alert(installedAhead
          ? `현재 베타 버전(v${nextStatus.localVersion})이 설치되어 있습니다. 자동 다운그레이드는 하지 않으며 다음 정식 버전이 출시되면 업데이트할 수 있습니다.`
          : `현재 ${channelLabel} 채널의 최신 버전(v${nextStatus.localVersion})을 사용 중입니다.`);
        return;
      }

      const targetLabel = nextStatus.target.channel === 'beta' ? '베타' : '정식';
      if (!window.confirm(`새로운 ${targetLabel} 버전(v${nextStatus.target.version})이 있습니다.\n지금 업데이트하시겠습니까?`)) return;
      await triggerUpdate(nextStatus.selectedChannel, nextStatus.target.version);
      updateStarted = true;
      window.setTimeout(() => {
        alert('업데이트 설치를 위해 JiraAuto가 재시작됩니다. 잠시 후 창을 새로고침해 주세요.');
      }, 500);
    } catch (error) {
      console.error('Update check/trigger failed', error);
      alert(error instanceof Error ? error.message : '업데이트 확인 또는 실행에 실패했습니다.');
    } finally {
      if (!updateStarted) setIsUpdating(false);
    }
  };

  return (
    <footer style={{
      textAlign: 'center', padding: '40px 20px 30px', marginTop: 'auto',
      color: 'var(--text-secondary, #888)', fontSize: 13, display: 'flex',
      flexDirection: 'column', alignItems: 'center', gap: 8,
    }}>
      <div style={{ fontWeight: 600, color: 'var(--text-secondary, #999)', fontSize: 14 }}>
        v{status?.localVersion || '확인 중...'}
      </div>
      {status && (
        <div style={{ fontSize: 12 }}>
          업데이트 채널: {status.selectedChannel === 'beta' ? 'Beta' : 'Stable'}
        </div>
      )}
      <button
        type="button"
        onClick={() => void handleManualUpdate()}
        disabled={isUpdating}
        style={{
          display: 'flex', alignItems: 'center', gap: 6, background: 'transparent',
          border: '1px solid var(--border-color, #444)', padding: '6px 12px', borderRadius: 6,
          color: 'var(--text-secondary, #aaa)', cursor: isUpdating ? 'wait' : 'pointer',
          fontSize: 12, opacity: isUpdating ? 0.6 : 1,
        }}
      >
        <RefreshCw size={14} className={isUpdating ? 'spin' : ''} />
        {isUpdating ? '업데이트 확인 중...' : '수동 업데이트 확인'}
      </button>
      <div style={{ marginTop: 8, opacity: 0.8 }}>
        &copy; 2026 <strong>Security Operation(mtp2259)</strong>. All rights reserved.
      </div>
      <style>{`@keyframes spin { 100% { transform: rotate(360deg); } } .spin { animation: spin 1s linear infinite; }`}</style>
    </footer>
  );
}
