export type ReleaseChannel = 'stable' | 'beta';
export interface ReleaseNote {
  version: string;
  released_at?: string;
  title: string;
  notes: string;
}

const API_BASE = 'http://localhost:8000/api';

export async function fetchPendingReleaseNotes() {
  const response = await fetch(`${API_BASE}/release-notes/pending`, { cache: 'no-store' });
  if (!response.ok) throw new Error(`Release notes request failed: ${response.status}`);
  return await response.json() as {
    channel: ReleaseChannel;
    installed_version: string;
    releases: ReleaseNote[];
  };
}

export async function markReleaseNotesSeen(channel: ReleaseChannel, version: string) {
  const response = await fetch(`${API_BASE}/release-notes/seen`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ channel, version }),
  });
  if (!response.ok) throw new Error(`Mark release notes seen failed: ${response.status}`);
}

export async function fetchReleaseNotesHistory(channel: ReleaseChannel, refresh = false) {
  const response = await fetch(`${API_BASE}/release-notes?channel=${channel}&refresh=${refresh}`, { cache: 'no-store' });
  if (!response.ok) throw new Error(`Release notes history request failed: ${response.status}`);
  return await response.json() as { channel: ReleaseChannel; releases: ReleaseNote[]; from_cache: boolean };
}
