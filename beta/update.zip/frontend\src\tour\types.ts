import type { Alignment, Side } from 'driver.js';

export interface TourStepDefinition {
  target: string;
  title: string;
  description: string;
  side?: Side;
  align?: Alignment;
}

export interface TourDefinition {
  id: string;
  version: number;
  steps: TourStepDefinition[];
}

export interface StartTourOptions {
  force?: boolean;
  onFinish?: () => void;
}
