import { useState, useEffect, useCallback } from 'react';
import { MessageSquare, RefreshCcw, Trash2, Send, Edit2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import '../TeamStyles.css';
import type { CommentCountSource, TeamComment, TeamContent, TeamContentItemProps, TeamUserIdentity } from '../types/teamContent';

const API_BASE = 'http://localhost:8000/api';

const getCommentCount = (item: CommentCountSource) => {
  const count = Number(item.comment_count ?? item.commentCount ?? item.comments_count ?? item.commentsCount ?? item.repliesCount ?? item.replyCount ?? 0);
  return Number.isFinite(count) ? count : 0;
};

interface BoardItemProps extends TeamContentItemProps {
  board: TeamContent;
}

const BoardItem = ({ board, role, memberId, leaderUrl, onRefresh }: BoardItemProps) => {
  const [comments, setComments] = useState<TeamComment[]>([]);
  const [commentsLoaded, setCommentsLoaded] = useState(false);
  const [showComments, setShowComments] = useState(false);
  const [commentText, setCommentText] = useState('');
  const [currentUser, setCurrentUser] = useState('');
  const [isEditing, setIsEditing] = useState(false);
  const [editContent, setEditContent] = useState(board.content);
  const [editingCommentId, setEditingCommentId] = useState<string | null>(null);
  const [editCommentContent, setEditCommentContent] = useState('');

  const fetchComments = async () => {
    try {
      const baseUrl = role === 'leader' ? API_BASE : `${leaderUrl}/api`;
      const res = await fetch(`${baseUrl}/team/boards/${board.id}/comments`);
      const data = await res.json();
      setComments(data.comments || []);
      setCommentsLoaded(true);
    } catch {
      // Keep the current comments on transient request failures.
    }
  };

  const commentCount = commentsLoaded ? comments.length : getCommentCount(board);

  useEffect(() => {
    const fetchName = async () => {
      let myName = '';
      try {
        const userMap = JSON.parse(localStorage.getItem('userMap') || '{}');
        const me = Object.values(userMap as Record<string, TeamUserIdentity>)[0];
        if (me) myName = me.displayName || me.name || '';
      } catch {
        // Fall back to the member identifier below.
      }

      if (!myName) {
        try {
          const meRes = await fetch(`${API_BASE}/me`);
          const meData = await meRes.json();
          const me = Object.values(meData as Record<string, TeamUserIdentity>)[0];
          if (me) myName = me.displayName || me.name || '';
        } catch {
          // Fall back to the member identifier below.
        }
      }
      if (!myName) myName = memberId || '팀장';
      setCurrentUser(role === 'leader' ? `${myName} (팀장)` : myName);
    };
    fetchName();
  }, [memberId, role]);

  const handleDeleteComment = async (commentId: string) => {
    if (!window.confirm('댓글을 삭제하시겠습니까?')) return;
    try {
      const baseUrl = role === 'leader' ? API_BASE : `${leaderUrl}/api`;
      await fetch(`${baseUrl}/team/boards/comments/${commentId}`, { method: 'DELETE' });
      fetchComments();
    } catch { console.error('Delete failed'); }
  };

  const handlePost = async () => {
    if (!commentText.trim()) return;
    try {
      const baseUrl = role === 'leader' ? API_BASE : `${leaderUrl}/api`;

      await fetch(`${baseUrl}/team/boards/${board.id}/comments`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ author: currentUser, content: commentText })
      });
      setCommentText('');
      fetchComments();
    } catch {
      // Leave the draft intact so the user can retry.
    }
  };

  const handleEditPost = async () => {
    if (!editContent.trim()) return;
    try {
      const baseUrl = role === 'leader' ? API_BASE : `${leaderUrl}/api`;
      await fetch(`${baseUrl}/team/boards/${board.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content: editContent })
      });
      setIsEditing(false);
      onRefresh();
    } catch {
      // Keep edit mode open so the user can retry.
    }
  };

  const handleEditComment = async (commentId: string) => {
    if (!editCommentContent.trim()) return;
    try {
      const baseUrl = role === 'leader' ? API_BASE : `${leaderUrl}/api`;
      await fetch(`${baseUrl}/team/boards/comments/${commentId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content: editCommentContent })
      });
      setEditingCommentId(null);
      fetchComments();
    } catch {
      // Keep edit mode open so the user can retry.
    }
  };

  const handleDelete = async () => {
    if (window.confirm('정말 이 게시글을 삭제하시겠습니까? 하위 댓글도 함께 삭제됩니다.')) {
      try {
        const baseUrl = role === 'leader' ? API_BASE : `${leaderUrl}/api`;
        await fetch(`${baseUrl}/team/boards/${board.id}`, { method: 'DELETE' });
        onRefresh();
      } catch { console.error('Delete failed'); }
    }
  };

  return (
    <motion.div initial={{opacity: 0, y: 10}} animate={{opacity: 1, y: 0}} className="notice-thread glass-panel" style={{borderBottom: 'none', textAlign: 'left'}}>
      <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start'}}>
        <div style={{flex: 1}}>
          <div style={{display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8}}>
            <strong style={{fontSize: 16}}>{board.author}</strong>
            <span style={{fontSize: 12, color: 'var(--text-secondary)'}}>{new Date(board.created_at.endsWith('Z') ? board.created_at : board.created_at + 'Z').toLocaleString()}</span>
            {board.edit_count > 0 && <span style={{fontSize: 12, color: "#0984e3"}}>({board.edit_count}회 수정)</span>}
          </div>
          {isEditing ? (
            <div style={{marginBottom: 15}}>
              <textarea className="glass-input" style={{width: '100%', padding: '10px', minHeight: '80px', resize: 'vertical'}} value={editContent} onChange={e => setEditContent(e.target.value)} onKeyDown={e => { if (e.key === 'Enter' && e.altKey) { e.preventDefault(); handleEditPost(); } }} />
              <div style={{display: 'flex', gap: 8, justifyContent: 'flex-end', marginTop: 8}}>
                <button className="btn-glass" onClick={() => setIsEditing(false)}>취소</button>
                <button className="btn-premium" onClick={handleEditPost}>저장 (Alt+Enter)</button>
              </div>
            </div>
          ) : (
            <p style={{fontSize: 15, margin: '0 0 15px 0', lineHeight: 1.5, whiteSpace: 'pre-wrap'}}>{board.content}</p>
          )}
        </div>
        <div style={{display: 'flex', gap: 5}}>
          {board.author === currentUser && !isEditing && (
            <button className="btn-glass" onClick={() => setIsEditing(true)} style={{padding: '6px', color: '#0984e3', border: 'none', background: 'transparent'}} title="수정">
              <Edit2 size={18} />
            </button>
          )}
          {(role === 'leader' || board.author === currentUser) && (
            <button className="btn-glass" onClick={handleDelete} style={{padding: '6px', color: '#d63031', border: 'none', background: 'transparent'}} title="삭제">
              <Trash2 size={18} />
            </button>
          )}
        </div>
      </div>

      <button className="btn-glass" style={{padding: '6px 12px', fontSize: 13, display: 'flex', alignItems: 'center', gap: 6, background: 'rgba(0,0,0,0.02)'}} onClick={() => {
        if (!showComments) void fetchComments();
        setShowComments(!showComments);
      }}>
        <MessageSquare size={14}/> {showComments ? '댓글 접기' : `댓글 보기 (${commentCount > 0 ? commentCount : '작성'})`}
      </button>

      <AnimatePresence>
        {showComments && (
          <motion.div initial={{opacity: 0, height: 0}} animate={{opacity: 1, height: 'auto'}} exit={{opacity: 0, height: 0}} style={{overflow: 'hidden'}}>
            <div style={{marginTop: 15, padding: '15px 15px 15px 25px', borderLeft: '3px solid rgba(9, 132, 227, 0.3)', background: 'rgba(0,0,0,0.01)', borderRadius: '0 8px 8px 0'}}>
              {comments.map(c => (
                 <div key={c.id} style={{marginBottom: 12}}>
                   <div style={{display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4}}>
                     <span style={{fontSize: 13, fontWeight: 700}}>{c.author}</span>
                     <span style={{fontSize: 11, color: 'var(--text-secondary)'}}>
                       {new Date(c.created_at.endsWith('Z') ? c.created_at : c.created_at + 'Z').toLocaleString()}
                     </span>
                     {c.edit_count > 0 && <span style={{fontSize: 11, color: "#0984e3"}}>({c.edit_count}회 수정)</span>}
                     
                     {c.author === currentUser && editingCommentId !== c.id && (
                       <button onClick={() => { setEditingCommentId(c.id); setEditCommentContent(c.content); }} style={{background: 'none', border: 'none', color: '#0984e3', cursor: 'pointer', fontSize: 11, padding: 0, marginLeft: 'auto', marginRight: 8}}>수정</button>
                     )}
                     {(role === 'leader' || c.author === currentUser) && (
                       <button onClick={() => handleDeleteComment(c.id)} style={{background: 'none', border: 'none', color: '#ff7675', cursor: 'pointer', fontSize: 11, padding: 0, marginLeft: c.author === currentUser ? 0 : 'auto'}}>삭제</button>
                     )}
                   </div>
                   {editingCommentId === c.id ? (
                     <div style={{marginTop: 8}}>
                       <textarea 
                         className="glass-input" 
                         style={{width: '100%', padding: '8px', minHeight: '40px', resize: 'vertical'}} 
                         value={editCommentContent} 
                         onChange={e => setEditCommentContent(e.target.value)} 
                         onKeyDown={e => { if (e.key === 'Enter' && e.altKey) { e.preventDefault(); handleEditComment(c.id); } }}
                       />
                       <div style={{display: 'flex', gap: 8, justifyContent: 'flex-end', marginTop: 4}}>
                         <button className="btn-glass" style={{fontSize: 11, padding: '4px 8px'}} onClick={() => setEditingCommentId(null)}>취소</button>
                         <button className="btn-premium" style={{fontSize: 11, padding: '4px 8px'}} onClick={() => handleEditComment(c.id)}>저장</button>
                       </div>
                     </div>
                   ) : (
                     <span style={{fontSize: 14, whiteSpace: 'pre-wrap'}}>{c.content}</span>
                   )}
                 </div>
              ))}
              {comments.length === 0 && <div style={{fontSize: 13, color: 'var(--text-secondary)', marginBottom: 10}}>첫 댓글을 남겨보세요!</div>}
              
              <div style={{display: 'flex', gap: 8, marginTop: 15, alignItems: 'flex-start'}}>
                 <textarea 
                   className="glass-input" 
                   style={{flex: 1, padding: '8px 12px', minHeight: '40px', resize: 'vertical', fontFamily: 'inherit'}} 
                   value={commentText} 
                   onChange={e=>setCommentText(e.target.value)} 
                   placeholder="댓글 작성... (줄바꿈은 Shift + Enter, 등록은 Enter)" 
                   onKeyDown={e => {
                     if (e.key === 'Enter' && e.altKey) {
                       e.preventDefault();
                       handlePost();
                     }
                   }} 
                 />
                 <button className="btn-premium" style={{padding: '8px 16px', whiteSpace: 'nowrap'}} onClick={handlePost}>등록</button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};

export default function TeamBoardPage() {
  const [notices, setNotices] = useState<TeamContent[]>([]);
  const [noticeContent, setNoticeContent] = useState('');
  const [currentUser, setCurrentUser] = useState('');

  const role = localStorage.getItem('teamRole');
  const leaderUrl = localStorage.getItem('teamLeaderUrl');
  const memberId = localStorage.getItem('teamMemberId');

  useEffect(() => {
    const fetchName = async () => {
      let myName = '';
      try {
        const userMap = JSON.parse(localStorage.getItem('userMap') || '{}');
        const me = Object.values(userMap as Record<string, TeamUserIdentity>)[0];
        if (me) myName = me.displayName || me.name || '';
      } catch {
        // Fall back to the member identifier below.
      }

      if (!myName) {
        try {
          const meRes = await fetch(`${API_BASE}/me`);
          const meData = await meRes.json();
          const me = Object.values(meData as Record<string, TeamUserIdentity>)[0];
          if (me) myName = me.displayName || me.name || '';
        } catch {
          // Fall back to the member identifier below.
        }
      }
      if (!myName) myName = memberId || '팀장';
      setCurrentUser(role === 'leader' ? `${myName} (팀장)` : myName);
    };
    fetchName();
  }, [memberId, role]);

  const fetchNotices = useCallback(async () => {
    try {
      const baseUrl = role === 'leader' ? API_BASE : `${leaderUrl}/api`;
      const resNot = await fetch(`${baseUrl}/team/boards`);
      const dataNot = await resNot.json();
      const fetchedBoards = (dataNot.boards || []) as TeamContent[];
      const boardsWithCounts = await Promise.all(fetchedBoards.map(async board => {
        try {
          const commentsRes = await fetch(`${baseUrl}/team/boards/${board.id}/comments`);
          if (!commentsRes.ok) return { ...board, comment_count: getCommentCount(board) };
          const commentsData = await commentsRes.json();
          const comments = Array.isArray(commentsData.comments) ? commentsData.comments : [];
          return { ...board, comment_count: comments.length };
        } catch {
          return { ...board, comment_count: getCommentCount(board) };
        }
      }));
      setNotices(boardsWithCounts);
    } catch {
      // Keep the current board list on transient request failures.
    }
  }, [leaderUrl, role]);

  useEffect(() => {
    const initialTimer = window.setTimeout(() => {
      void fetchNotices();
    }, 0);
    const interval = window.setInterval(fetchNotices, 15000);
    return () => {
      window.clearTimeout(initialTimer);
      window.clearInterval(interval);
    };
  }, [fetchNotices]);

  const handlePostNotice = async () => {
    if (!noticeContent.trim()) return;
    try {
      const baseUrl = role === 'leader' ? API_BASE : `${leaderUrl}/api`;
      await fetch(`${baseUrl}/team/boards`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ author: currentUser, content: noticeContent })
      });
      setNoticeContent('');
      fetchNotices();
    } catch {
      // Leave the draft intact so the user can retry.
    }
  };

  return (
    <div className="glass-container" data-tour="team-board-page" data-tour-page-ready="true" style={{textAlign: 'left'}}>
      <div style={{ display: 'flex', justifyContent: 'flex-end', alignItems: 'center', marginBottom: 20 }}>
        <button data-tour="team-board-refresh" className="btn-glass" onClick={fetchNotices} style={{display:'flex', alignItems:'center', gap:6}}><RefreshCcw size={16}/> 새로고침</button>
      </div>
      <motion.div className="glass-panel" data-tour="team-board-compose" style={{marginBottom: 30}} initial={{opacity:0, y:-10}} animate={{opacity:1, y:0}}>
        <h3 style={{marginTop:0, marginBottom:15}}>📢 새로운 게시글 등록</h3>
        <textarea className="glass-input" rows={4} value={noticeContent} onChange={e => setNoticeContent(e.target.value)} onKeyDown={e => { if (e.key === 'Enter' && e.altKey) { e.preventDefault(); handlePostNotice(); } }} placeholder="팀원들에게 공유할 중요한 소식을 작성하세요." style={{resize: 'vertical', marginBottom: 15}} />
        <div style={{textAlign: 'right'}}>
          <button className="btn-premium" onClick={handlePostNotice} style={{display: 'inline-flex', alignItems: 'center', gap: 8}}><Send size={16}/> 글 작성</button>
        </div>
      </motion.div>
      <div data-tour="team-board-list" style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(400px, 1fr))", gap: "20px" }}>
        {notices.length === 0 ? (
          <div style={{gridColumn: '1/-1', padding: 40, textAlign: 'center', color: 'var(--text-secondary)'}}>
            아직 등록된 게시글이 없습니다.
          </div>
        ) : (
          notices.map(n => <BoardItem key={n.id} board={n} role={role} memberId={memberId} leaderUrl={leaderUrl} onRefresh={fetchNotices} />)
        )}
      </div>
    </div>
  );
}
