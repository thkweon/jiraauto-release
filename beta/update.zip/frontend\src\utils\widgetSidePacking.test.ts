import { describe, expect, it } from 'vitest';
import { packWidgetsOnSide } from './widgetSidePacking';

describe('packWidgetsOnSide', () => {
  it('keeps widgets already on the target side and moves the incoming widget to the empty slot', () => {
    const plan = packWidgetsOnSide([
      { id: 'clock', block: 'top', alreadyOnTargetSide: true },
      { id: 'notepad', block: 'middle', alreadyOnTargetSide: true },
      { id: 'worklog', block: 'top', alreadyOnTargetSide: false },
    ]);

    expect(plan).toEqual({
      clock: 'top',
      notepad: 'middle',
      worklog: 'bottom',
    });
  });

  it('repacks a single widget when a two-slot widget needs contiguous space', () => {
    const plan = packWidgetsOnSide([
      { id: 'clock', block: 'middle', alreadyOnTargetSide: true },
      { id: 'calculator', block: 'top-middle', alreadyOnTargetSide: false },
    ]);

    expect(plan).toEqual({
      clock: 'bottom',
      calculator: 'top-middle',
    });
  });

  it('rejects layouts requiring more than three slots', () => {
    expect(packWidgetsOnSide([
      { id: 'notepad', block: 'top-middle', alreadyOnTargetSide: true },
      { id: 'calculator', block: 'middle-bottom', alreadyOnTargetSide: false },
    ])).toBeNull();
  });
});
