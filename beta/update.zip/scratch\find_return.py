import re

path = 'frontend/src/pages/DashboardPage.tsx'
with open(path, 'r', encoding='utf-8') as f:
    lines = f.readlines()

for i, line in enumerate(lines):
    if line.startswith('  return (') or line.startswith('  return('):
        print(f"Line {i+1}: {line.strip()}")
        # Let's check if the next lines look like the main JSX
        if i + 1 < len(lines):
            print(f"Line {i+2}: {lines[i+1].strip()}")
