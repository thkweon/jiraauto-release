import type { TourDefinition } from '../types';

const commonSteps: TourDefinition['steps'] = [
  {
    target: '[data-tour="team-notices-list"]',
    title: '공지 목록',
    description: '팀 공지를 확인하고 각 공지에서 댓글을 열어 의견을 남길 수 있습니다.',
    side: 'top',
  },
  {
    target: '[data-tour="team-notices-refresh"]',
    title: '공지 갱신',
    description: '팀장 서버에서 최신 공지와 댓글 수를 다시 불러옵니다.',
    side: 'left',
  },
];

export const teamNoticesLeaderTour: TourDefinition = {
  id: 'team-notices-leader',
  version: 1,
  steps: [
    {
      target: '[data-tour="team-notices-page"]',
      title: '팀 공지사항',
      description: '팀원에게 중요한 내용을 공지하고 댓글로 소통하는 화면입니다.',
      side: 'top',
    },
    {
      target: '[data-tour="team-notices-compose"]',
      title: '공지 작성',
      description: '팀장만 새 공지를 작성해 팀원에게 배포할 수 있습니다.',
      side: 'bottom',
    },
    ...commonSteps,
  ],
};

export const teamNoticesMemberTour: TourDefinition = {
  id: 'team-notices-member',
  version: 1,
  steps: [
    {
      target: '[data-tour="team-notices-page"]',
      title: '팀 공지사항',
      description: '팀장이 배포한 공지를 확인하고 댓글로 의견을 남길 수 있습니다.',
      side: 'top',
    },
    ...commonSteps,
  ],
};
