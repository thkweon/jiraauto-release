export type UpdateChannel = 'stable' | 'beta';

export interface UpdateRelease {
  channel: UpdateChannel;
  version: string;
  downloadUrl?: string;
  sha256?: string;
  releaseNotes?: string;
}

export interface UpdateManifest {
  stable?: UpdateRelease;
  beta?: UpdateRelease;
  minRequiredVersion?: string;
}

interface ParsedSemVer {
  major: number;
  minor: number;
  patch: number;
  prerelease: Array<number | string>;
}

const SEMVER_PATTERN = /^(?:v)?(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?(?:\+[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?$/;
const STABLE_VERSION_PATTERN = /^(?:v)?(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:\+[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?$/;
const BETA_VERSION_PATTERN = /^(?:v)?(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)-beta\.([1-9]\d*)$/;

const parseSemVer = (value: unknown): ParsedSemVer | null => {
  if (typeof value !== 'string') return null;
  const match = value.trim().match(SEMVER_PATTERN);
  if (!match) return null;

  const prerelease: Array<number | string> = [];
  if (match[4]) {
    for (const identifier of match[4].split('.')) {
      if (/^\d+$/.test(identifier)) {
        if (identifier.length > 1 && identifier.startsWith('0')) return null;
        prerelease.push(Number(identifier));
      } else {
        prerelease.push(identifier);
      }
    }
  }

  return {
    major: Number(match[1]),
    minor: Number(match[2]),
    patch: Number(match[3]),
    prerelease,
  };
};

export const isValidSemVer = (value: unknown): value is string => parseSemVer(value) !== null;

export const compareSemVer = (left: string, right: string): number => {
  const a = parseSemVer(left);
  const b = parseSemVer(right);
  if (!a || !b) throw new Error(`Invalid semantic version comparison: ${left}, ${right}`);

  for (const key of ['major', 'minor', 'patch'] as const) {
    if (a[key] !== b[key]) return a[key] > b[key] ? 1 : -1;
  }

  if (a.prerelease.length === 0 && b.prerelease.length === 0) return 0;
  if (a.prerelease.length === 0) return 1;
  if (b.prerelease.length === 0) return -1;

  const length = Math.max(a.prerelease.length, b.prerelease.length);
  for (let index = 0; index < length; index += 1) {
    const aPart = a.prerelease[index];
    const bPart = b.prerelease[index];
    if (aPart === undefined) return -1;
    if (bPart === undefined) return 1;
    if (aPart === bPart) continue;
    if (typeof aPart === 'number' && typeof bPart === 'string') return -1;
    if (typeof aPart === 'string' && typeof bPart === 'number') return 1;
    return aPart > bPart ? 1 : -1;
  }
  return 0;
};

const asRecord = (value: unknown): Record<string, unknown> | null =>
  value !== null && typeof value === 'object' && !Array.isArray(value)
    ? value as Record<string, unknown>
    : null;

const normalizeRelease = (value: unknown, channel: UpdateChannel): UpdateRelease | undefined => {
  const data = asRecord(value);
  if (!data || !isValidSemVer(data.version)) return undefined;
  if (channel === 'stable' && !STABLE_VERSION_PATTERN.test(data.version.trim())) return undefined;
  if (channel === 'beta' && !BETA_VERSION_PATTERN.test(data.version.trim())) return undefined;
  return {
    channel,
    version: data.version.trim().replace(/^v/, ''),
    downloadUrl: typeof data.download_url === 'string' ? data.download_url : undefined,
    sha256: typeof data.sha256 === 'string' ? data.sha256 : undefined,
    releaseNotes: typeof data.release_notes === 'string' ? data.release_notes : undefined,
  };
};

export const normalizeUpdateManifest = (value: unknown): UpdateManifest => {
  const data = asRecord(value);
  if (!data) return {};
  const channels = asRecord(data.channels);
  const legacyStable = normalizeRelease(data, 'stable');
  const stable = normalizeRelease(channels?.stable, 'stable') ?? legacyStable;
  const beta = normalizeRelease(channels?.beta, 'beta');

  return {
    stable,
    beta,
    minRequiredVersion: isValidSemVer(data.min_required_version)
      ? data.min_required_version.trim().replace(/^v/, '')
      : undefined,
  };
};

export const resolveTargetRelease = (
  manifest: UpdateManifest,
  selectedChannel: UpdateChannel,
): UpdateRelease | undefined => {
  if (selectedChannel === 'stable') return manifest.stable;
  if (!manifest.beta) return manifest.stable;
  if (!manifest.stable) return manifest.beta;
  return compareSemVer(manifest.beta.version, manifest.stable.version) > 0
    ? manifest.beta
    : manifest.stable;
};
