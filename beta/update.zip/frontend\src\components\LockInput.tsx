import { useId, useRef, useState } from 'react';
import { RotateCcw } from 'lucide-react';
import type { LockMethod } from '../utils/screenLock';
import { appendPoint, hitPatternPoint, validSecret } from '../utils/screenLock';

interface Props {
  method: LockMethod; value: string; onChange: (value: string) => void;
  // Fires when a PIN reaches its length or a pattern drag ends with enough points; passwords have no natural end.
  onComplete?: (value: string) => void;
  showLines?: boolean; disabled?: boolean; autoFocus?: boolean; label?: string;
}

export default function LockInput({ method, value, onChange, onComplete, showLines = false, disabled = false, autoFocus = false, label = '잠금 인증 입력' }: Props) {
  const dragging = useRef(false);
  const path = useRef<number[]>([]);
  const [pointer, setPointer] = useState<{ x: number; y: number } | null>(null);
  const gradient = useId().replace(/:/g, '');
  if (!method.startsWith('pattern')) return <input aria-label={label} className="glass-input settings-control lock-secret-input" type="password" autoComplete="off" autoFocus={autoFocus} disabled={disabled} value={value} placeholder={method.startsWith('pin') ? `${method.slice(-1)}자리 숫자` : '8자 이상 입력'} inputMode={method.startsWith('pin') ? 'numeric' : 'text'} maxLength={method.startsWith('pin') ? Number(method.slice(-1)) : 256} onChange={e => {
    const next = method.startsWith('pin') ? e.target.value.replace(/\D/g, '') : e.target.value;
    onChange(next);
    if (method.startsWith('pin') && validSecret(method, next)) onComplete?.(next);
  }} />;
  const size = Number(method.slice(-1));
  const selected = value ? value.split(',').map(Number) : [];
  const add = (p: number) => { path.current = appendPoint(path.current, p, size); onChange(path.current.join(',')); };
  const coordinates = (element: HTMLDivElement, x: number, y: number) => {
    const rect = element.getBoundingClientRect();
    return { x: (x - rect.left) / rect.width * size * 60, y: (y - rect.top) / rect.height * size * 60 };
  };
  const points = selected.map(p => `${(p % size) * 60 + 30},${Math.floor(p / size) * 60 + 30}`);
  if (pointer && selected.length) points.push(`${pointer.x},${pointer.y}`);
  const finish = () => { dragging.current = false; setPointer(null); };
  return <div className="lock-pattern-input" role="group" aria-label={label}>
    <div className="lock-pattern" style={{ gridTemplateColumns: `repeat(${size}, 1fr)` }} onPointerDown={e => {
      if (disabled || e.button !== 0) return;
      const position = coordinates(e.currentTarget, e.clientX, e.clientY);
      const point = hitPatternPoint(position.x, position.y, size);
      if (point === null) return;
      e.preventDefault(); e.currentTarget.setPointerCapture(e.pointerId);
      dragging.current = true; path.current = []; setPointer(position); add(point);
    }} onPointerMove={e => {
      if (!dragging.current || disabled) return;
      const position = coordinates(e.currentTarget, e.clientX, e.clientY);
      setPointer(position);
      const point = hitPatternPoint(position.x, position.y, size);
      if (point !== null) add(point);
    }} onPointerUp={() => {
      const released = dragging.current;
      finish();
      const drawn = path.current.join(',');
      if (released && validSecret(method, drawn)) onComplete?.(drawn);
    }} onPointerCancel={() => { finish(); path.current = []; onChange(''); }} onLostPointerCapture={finish}>
      {showLines && <svg viewBox={`0 0 ${size * 60} ${size * 60}`} aria-hidden="true">
        <defs><linearGradient id={gradient} x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stopColor="var(--accent-color)" stopOpacity="0.35" /><stop offset="50%" stopColor="var(--accent-color)" stopOpacity="0.85" /><stop offset="100%" stopColor="var(--accent-color)" stopOpacity="0.45" /></linearGradient></defs>
        <polyline className="lock-pattern-glow" points={points.join(' ')} fill="none" stroke="var(--accent-color)" strokeOpacity="0.15" strokeWidth="12" strokeLinecap="round" strokeLinejoin="round" />
        <polyline points={points.join(' ')} fill="none" stroke={`url(#${gradient})`} strokeWidth="6" strokeLinecap="round" strokeLinejoin="round" />
        <polyline points={points.join(' ')} fill="none" stroke="white" strokeOpacity="0.5" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
      </svg>}
      {Array.from({ length: size * size }, (_, p) => <button key={p} type="button" data-point={p} autoFocus={autoFocus && p === 0} disabled={disabled} aria-label={`${Math.floor(p / size) + 1}행 ${p % size + 1}열`} aria-pressed={showLines && selected.includes(p)} className={showLines && selected.includes(p) ? 'selected' : ''} onClick={e => { if (e.detail === 0) { path.current = selected; add(p); } }}><span /></button>)}
    </div>
    <div className="lock-pattern-footer"><span className="settings-description" aria-live="polite">{selected.length}개 선택 · 최소 {size + 1}개</span><button className="btn-secondary settings-action" type="button" disabled={disabled} onClick={() => { finish(); path.current = []; onChange(''); }}><RotateCcw size={13} />다시 입력</button></div>
  </div>;
}
