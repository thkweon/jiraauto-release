import type { TourDefinition } from '../types';

export const overviewTour: TourDefinition = {
  id: 'overview',
  version: 2,
  steps: [
    {
      target: '[data-tour="nav-dashboard"]',
      title: 'JiraAuto 둘러보기',
      description: '개인 현황판에서 담당, 멘션 및 보고한 Jira 업무를 확인할 수 있습니다.',
      side: 'bottom',
    },
    { target: '[data-tour="nav-bulk"]', title: '일괄 변경', description: '여러 Jira 이슈를 선택해 같은 상태로 한 번에 변경할 수 있습니다.', side: 'bottom' },
    { target: '[data-tour="nav-team-dashboard"]', title: '팀 현황판', description: '팀원들의 Jira 업무와 현재 상태를 한곳에서 확인합니다.', side: 'bottom' },
    { target: '[data-tour="nav-team-notices"]', title: '팀 공지사항', description: '팀 공지를 확인하고 댓글로 소통할 수 있습니다.', side: 'bottom' },
    { target: '[data-tour="nav-team-board"]', title: '팀 게시판', description: '팀원들과 게시글과 댓글을 주고받을 수 있습니다.', side: 'bottom' },
    { target: '[data-tour="nav-team-analytics"]', title: '팀 통계', description: '팀 업무의 완료율, 처리량과 업무 분포를 차트로 확인합니다.', side: 'bottom' },
    { target: '[data-tour="nav-team-report"]', title: '팀 보고서', description: '팀원의 Jira worklog를 조회하고 보고서로 내보낼 수 있습니다.', side: 'bottom' },
    { target: '[data-tour="nav-team-manage"]', title: '팀 관리', description: '초대 코드를 공유하고 동기화된 팀원 상태를 관리합니다.', side: 'bottom' },
    { target: '[data-tour="nav-team-info"]', title: '팀 정보', description: '내 팀 식별자와 연결된 팀장 서버 정보를 확인합니다.', side: 'bottom' },
    { target: '[data-tour="nav-team-start"]', title: '팀 참여하기', description: '새 팀을 만들거나 초대 코드로 기존 팀에 참여할 수 있습니다.', side: 'bottom' },
    {
      target: '[data-tour="widget-rail-left"]',
      title: '왼쪽 위젯 영역',
      description: '이 공간에 바로가기, 달력, 시계 등의 위젯을 표시할 수 있습니다. 설정의 위젯 탭에서 표시 여부와 위치를 선택하세요.',
      side: 'right',
    },
    {
      target: '[data-tour="widget-rail-right"]',
      title: '오른쪽 위젯 영역',
      description: '위젯은 오른쪽에도 배치할 수 있습니다. 처음에는 비어 있으며 설정의 위젯 탭에서 필요한 위젯을 켤 수 있습니다.',
      side: 'left',
    },
    {
      target: '[data-tour="connected-accounts"]',
      title: '연결 계정',
      description: '현재 연결된 Jira 계정 수를 확인할 수 있습니다.',
      side: 'bottom',
    },
    {
      target: '[data-tour="settings-link"]',
      title: '환경 설정',
      description: 'Jira 계정, 현황판, 위젯과 제품 설정을 관리할 수 있습니다.',
      side: 'bottom',
    },
    {
      target: '[data-tour="theme-toggle"]',
      title: '화면 테마',
      description: '밝게, 어둡게 또는 시스템 설정에 맞춰 화면을 표시합니다.',
      side: 'bottom',
    },
    {
      target: '[data-tour="help-button"]',
      title: '안내 다시 보기',
      description: '이 버튼을 선택하면 현재 화면의 안내를 언제든 다시 볼 수 있습니다.',
      side: 'left',
    },
  ],
};
