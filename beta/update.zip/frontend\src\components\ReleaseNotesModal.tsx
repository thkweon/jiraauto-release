import { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import { X } from 'lucide-react';
import MarkdownPreview from './MarkdownPreview';
import { fetchPendingReleaseNotes, markReleaseNotesSeen, type ReleaseChannel, type ReleaseNote } from '../utils/releaseNotesClient';

export default function ReleaseNotesModal() {
  const location = useLocation();
  const [pending, setPending] = useState<{ channel: ReleaseChannel; version: string; releases: ReleaseNote[] } | null>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (location.pathname === '/activation' || location.pathname === '/setup') return;
    let cancelled = false;
    void fetchPendingReleaseNotes().then(data => {
      if (!cancelled && data.releases.length) setPending({ channel: data.channel, version: data.installed_version, releases: data.releases });
    }).catch(() => { /* Retry on next application start if GitHub/API is unavailable. */ });
    return () => { cancelled = true; };
  }, [location.pathname]);

  const close = async () => {
    if (!pending || saving) return;
    setSaving(true);
    try {
      await markReleaseNotesSeen(pending.channel, pending.version);
      setPending(null);
    } catch {
      // Keep modal open if acknowledgement failed, so the release notes are not lost.
    } finally { setSaving(false); }
  };

  if (!pending) return null;
  return (
    <div className="glass-modal-overlay" role="presentation" onMouseDown={event => { if (event.target === event.currentTarget) void close(); }}>
      <section className="glass-modal-content release-notes-modal" role="dialog" aria-modal="true" aria-labelledby="release-notes-title" style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
        <header className="release-notes-modal-header" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 12 }}>
          <div>
            <h2 id="release-notes-title" style={{ margin: 0 }}>업데이트 안내</h2>
            <span className={`release-notes-channel ${pending.channel}`}>{pending.channel === 'beta' ? 'BETA' : 'STABLE'}</span>
          </div>
          <button type="button" className="btn-glass" aria-label="닫기" title="닫기" onClick={() => void close()} disabled={saving}><X size={18} /></button>
        </header>
        <div className="release-notes-modal-body" style={{ maxHeight: 'min(60vh, 620px)', overflowY: 'auto', paddingRight: 4 }}>
          {pending.releases.map(release => (
            <article className="release-notes-entry" key={`${pending.channel}-${release.version}`} style={{ borderTop: '1px solid var(--border-color)', marginTop: 14, paddingTop: 14 }}>
              <div className="release-notes-entry-heading" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 12, flexWrap: 'wrap' }}>
                <h3>v{release.version} · {release.title}</h3>
                {release.released_at && <time>{new Date(release.released_at).toLocaleDateString()}</time>}
              </div>
              <MarkdownPreview content={release.notes} />
            </article>
          ))}
        </div>
        <footer className="release-notes-modal-footer">
          <button type="button" className="btn-premium" onClick={() => void close()} disabled={saving}>{saving ? '저장 중…' : '확인'}</button>
        </footer>
      </section>
    </div>
  );
}
