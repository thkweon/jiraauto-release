import { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import { X } from 'lucide-react';
import MarkdownPreview from './MarkdownPreview';
import { fetchPendingReleaseNotes, markReleaseNotesSeen, type ReleaseChannel, type ReleaseNote } from '../utils/releaseNotesClient';

export default function ReleaseNotesModal() {
  const location = useLocation();
  const [pending, setPending] = useState<{ channel: ReleaseChannel; version: string; releases: ReleaseNote[] } | null>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (location.pathname === '/activation' || location.pathname === '/setup') return;
    let cancelled = false;
    void fetchPendingReleaseNotes().then(data => {
      if (!cancelled && data.releases.length) setPending({ channel: data.channel, version: data.installed_version, releases: data.releases });
    }).catch(() => { /* Retry on next application start if GitHub/API is unavailable. */ });
    return () => { cancelled = true; };
  }, [location.pathname]);

  const close = async () => {
    if (!pending || saving) return;
    setSaving(true);
    try {
      await markReleaseNotesSeen(pending.channel, pending.version);
      setPending(null);
    } catch {
      // Keep modal open if acknowledgement failed, so the release notes are not lost.
    } finally { setSaving(false); }
  };

  if (!pending) return null;
  return (
    <div className="glass-modal-overlay" role="presentation" onMouseDown={event => { if (event.target === event.currentTarget) void close(); }}>
      <section className="glass-modal-content release-notes-modal" role="dialog" aria-modal="true" aria-labelledby="release-notes-title" style={{ display: 'flex', flexDirection: 'column', gap: 16, fontFamily: 'inherit', fontSize: 13, lineHeight: 1.5 }}>
        <header className="release-notes-modal-header" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 12 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
            <h2 id="release-notes-title" style={{ margin: 0, font: 'inherit', fontSize: 18, fontWeight: 700, color: 'var(--text-primary)' }}>업데이트 안내</h2>
            <span className={`release-notes-channel ${pending.channel}`} style={{ display: 'inline-flex', alignItems: 'center', borderRadius: 999, padding: '3px 8px', color: pending.channel === 'beta' ? '#7c3aed' : '#1d4ed8', background: pending.channel === 'beta' ? '#7c3aed1c' : '#2563eb1c', border: `1px solid ${pending.channel === 'beta' ? '#7c3aed40' : '#2563eb40'}`, fontSize: 10, lineHeight: 1.2, fontWeight: 800, letterSpacing: '.04em' }}>{pending.channel === 'beta' ? 'BETA' : 'STABLE'}</span>
          </div>
          <button type="button" className="release-notes-close" aria-label="닫기" title="닫기" onClick={() => void close()} disabled={saving}><X size={15} /></button>
        </header>
        <div className="release-notes-modal-body" style={{ maxHeight: 'min(60vh, 620px)', overflowY: 'auto', paddingRight: 4 }}>
          {pending.releases.map(release => (
            <article className="release-notes-entry" key={`${pending.channel}-${release.version}`} style={{ borderTop: '1px solid var(--border-color)', marginTop: 14, paddingTop: 14 }}>
              <div className="release-notes-entry-heading" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 12, flexWrap: 'wrap' }}>
                <h3 style={{ margin: 0, font: 'inherit', fontSize: 14, fontWeight: 700, color: 'var(--text-primary)' }}>v{release.version} · {release.title}</h3>
                {release.released_at && <time style={{ color: 'var(--text-secondary)', fontSize: 11, lineHeight: 1.3, whiteSpace: 'nowrap' }}>{new Date(release.released_at).toLocaleDateString()}</time>}
              </div>
              <div style={{ marginTop: 8, color: 'var(--text-primary)', fontSize: 13, lineHeight: 1.6 }}><MarkdownPreview content={release.notes} /></div>
            </article>
          ))}
        </div>
        <footer className="release-notes-modal-footer" style={{ display: 'flex', justifyContent: 'flex-end' }}>
          <button type="button" className="btn-premium" onClick={() => void close()} disabled={saving} style={{ padding: '8px 18px', fontSize: 13, borderRadius: 8 }}>{saving ? '저장 중…' : '확인'}</button>
        </footer>
      </section>
    </div>
  );
}
