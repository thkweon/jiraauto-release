import { useCallback, useEffect, useRef, useState, type ReactNode } from 'react';
import { CircleHelp, Compass, MonitorPlay } from 'lucide-react';
import { useLocation } from 'react-router-dom';
import { destroyAllTours, getTourForPath, overviewTourController } from './registry';
import './tour.css';

const waitForReadyPage = (callback: () => void) => {
  let stopped = false;
  let attempts = 0;
  const check = () => {
    if (stopped) return;
    const page = document.querySelector('[data-tour-page-ready="true"]');
    if (page) {
      callback();
      return;
    }
    attempts += 1;
    if (attempts < 80) window.setTimeout(check, 100);
  };
  window.setTimeout(check, 250);
  return () => { stopped = true; };
};

export const TourProvider = ({ children }: { children: ReactNode }) => {
  const location = useLocation();
  const previousPath = useRef(location.pathname);
  const helpMenuRef = useRef<HTMLDivElement>(null);
  const [helpMenuOpen, setHelpMenuOpen] = useState(false);
  const currentTour = getTourForPath(location.pathname);

  const startCurrentTour = useCallback((force = false) => {
    const current = getTourForPath(location.pathname);
    if (!current) return;
    if (force) current.restart();
    else current.start();
  }, [location.pathname]);

  const restartOverview = useCallback(() => overviewTourController.restart(), []);

  useEffect(() => {
    if (!helpMenuOpen) return;
    const closeMenu = (event: MouseEvent) => {
      if (!helpMenuRef.current?.contains(event.target as Node)) setHelpMenuOpen(false);
    };
    document.addEventListener('mousedown', closeMenu);
    return () => document.removeEventListener('mousedown', closeMenu);
  }, [helpMenuOpen]);

  useEffect(() => {
    if (previousPath.current !== location.pathname) destroyAllTours();
    previousPath.current = location.pathname;

    return waitForReadyPage(() => {
      if (!overviewTourController.isCompleted()) {
        const started = overviewTourController.start({ onFinish: () => startCurrentTour(false) });
        if (started) return;
      }
      startCurrentTour(false);
    });
  }, [location.pathname, startCurrentTour]);

  useEffect(() => () => destroyAllTours(), []);

  return (
    <>
      {children}
      {currentTour && <div className="tour-help" ref={helpMenuRef}>
        {helpMenuOpen && (
          <div className="tour-help-menu" role="menu" aria-label="화면 안내 선택">
            <button type="button" role="menuitem" onClick={() => { setHelpMenuOpen(false); restartOverview(); }}>
              <Compass size={17} aria-hidden="true" />
              <span><strong>전체 메뉴 안내</strong><small>현재 보이는 상단 메뉴 설명</small></span>
            </button>
            <button type="button" role="menuitem" onClick={() => { setHelpMenuOpen(false); startCurrentTour(true); }}>
              <MonitorPlay size={17} aria-hidden="true" />
              <span><strong>현재 화면 안내</strong><small>이 화면의 주요 기능 설명</small></span>
            </button>
          </div>
        )}
        <button
          type="button"
          className="tour-help-button"
          data-tour="help-button"
          aria-label="화면 안내 선택"
          aria-haspopup="menu"
          aria-expanded={helpMenuOpen}
          title="화면 안내"
          onClick={() => setHelpMenuOpen(open => !open)}
        >
          <CircleHelp size={22} aria-hidden="true" />
        </button>
      </div>}
    </>
  );
};
