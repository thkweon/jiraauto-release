import { useCallback, useEffect, useState } from 'react';
import { AlertTriangle, RotateCw, Settings } from 'lucide-react';

const API_BASE = 'http://localhost:8000/api';
interface JiraAuthAccount {
  instanceId: number;
  instanceName: string;
  status: 'ok' | 'unknown' | 'auth_failed' | 'expired' | 'expiring_soon' | string;
  message?: string | null;
}

export default function JiraAuthStatusBanner() {
  const [accounts, setAccounts] = useState<JiraAuthAccount[]>([]);
  const [loading, setLoading] = useState(false);
  const [dismissed, setDismissed] = useState(false);
  const refresh = useCallback(async () => {
    setLoading(true);
    try {
      const response = await fetch(`${API_BASE}/jira/auth-status`);
      if (!response.ok) return;
      const data = await response.json();
      setAccounts(Array.isArray(data.accounts) ? data.accounts : []);
    } catch { /* status is advisory; never block the application */ }
    finally { setLoading(false); }
  }, []);

  useEffect(() => {
    void refresh();
    const timer = window.setInterval(() => void refresh(), 60_000);
    const onFocus = () => void refresh();
    const onAccountsChanged = () => void refresh();
    window.addEventListener('focus', onFocus);
    window.addEventListener('jiraAccountsChanged', onAccountsChanged);
    return () => {
      window.clearInterval(timer);
      window.removeEventListener('focus', onFocus);
      window.removeEventListener('jiraAccountsChanged', onAccountsChanged);
    };
  }, [refresh]);

  const limited = accounts.filter(account => ['auth_failed', 'expired', 'expiring_soon'].includes(account.status));
  const fingerprint = limited.map(account => `${account.instanceId}:${account.status}`).join('|');
  useEffect(() => setDismissed(false), [fingerprint]);
  if (!limited.length) return null;
  const severe = limited.some(account => account.status !== 'expiring_soon');
  const alreadyDismissed = sessionStorage.getItem('jiraAuthBannerDismissed') === fingerprint;
  if (dismissed || alreadyDismissed) return null;
  return (
    <div role="alert" style={{ margin: '0 20px 12px', padding: '9px 14px', borderRadius: 10, display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap', color: severe ? '#991b1b' : '#854d0e', background: severe ? '#fee2e2' : '#fef3c7', border: `1px solid ${severe ? '#fca5a5' : '#fcd34d'}`, fontFamily: 'inherit', fontSize: 12, fontWeight: 500, lineHeight: 1.45 }}>
      <AlertTriangle size={16} />
      <span style={{ flex: 1, minWidth: 220 }}>
        {limited.map(account => `${account.instanceName}: ${account.status === 'expired' ? '토큰 만료' : account.status === 'expiring_soon' ? '토큰 만료 예정' : 'Jira 인증 실패'}`).join(' · ')}
        {' — '}관련 Jira 조회 및 작업로그 기능이 제한될 수 있습니다. 설정에서 인증 정보를 확인해 주세요.
      </span>
      <button className="btn-glass" onClick={() => { window.location.href = '/settings'; }} style={{ display: 'inline-flex', alignItems: 'center', gap: 5, padding: '6px 10px', font: 'inherit', fontSize: 11 }}><Settings size={14} />설정</button>
      <button className="btn-glass" onClick={() => void refresh()} disabled={loading} aria-label="인증 상태 새로고침" title="인증 상태 새로고침" style={{ padding: 7, lineHeight: 0 }}><RotateCw size={14} /></button>
      <button className="btn-glass" onClick={() => { sessionStorage.setItem('jiraAuthBannerDismissed', fingerprint); setDismissed(true); }} aria-label="알림 닫기" title="알림 닫기" style={{ padding: '6px 9px', font: 'inherit', fontSize: 11 }}>닫기</button>
    </div>
  );
}
