import type { TourDefinition } from '../types';

const commonSteps: TourDefinition['steps'] = [
  {
    target: '[data-tour="team-report-settings-button"]',
    title: '보고 대상 설정',
    description: '조회할 팀원을 추가하거나 현재 저장된 팀원 구성을 확인할 수 있습니다.',
    side: 'left',
  },
  {
    target: '[data-tour="team-report-query"]',
    title: '보고서 조회',
    description: 'Jira 계정과 기간을 선택한 뒤 조회하면 작업시간 보고서를 생성합니다.',
    side: 'bottom',
  },
  {
    target: '[data-tour="team-report-export"]',
    title: '결과 내보내기',
    description: '조회 결과를 PNG, CSV, Excel로 저장하거나 표 형태로 복사할 수 있습니다.',
    side: 'bottom',
  },
  {
    target: '[data-tour="team-report-summary"]',
    title: '작업시간 요약',
    description: '팀원별 작업시간과 업무 비율을 차트와 표로 비교할 수 있습니다.',
    side: 'top',
  },
  {
    target: '[data-tour="team-report-detail"]',
    title: '작업 상세',
    description: '계정과 컴포넌트로 원천 worklog를 필터링하고 원하는 기준으로 정렬할 수 있습니다.',
    side: 'top',
  },
];

export const teamReportLeaderTour: TourDefinition = {
  id: 'team-report-leader',
  version: 1,
  steps: [
    {
      target: '[data-tour="team-report-page"]',
      title: '팀 보고서',
      description: '팀원의 Jira worklog를 모아 작업시간 보고서를 생성하는 화면입니다.',
      side: 'top',
    },
    {
      target: '[data-tour="team-report-settings-button"]',
      title: '팀원 조회 방식',
      description: '팀장은 설정을 열어 팀원을 관리하고 각 팀원의 권한으로 조회하는 방식을 선택할 수 있습니다.',
      side: 'left',
    },
    ...commonSteps.slice(1),
  ],
};

export const teamReportMemberTour: TourDefinition = {
  id: 'team-report-member',
  version: 1,
  steps: [
    {
      target: '[data-tour="team-report-page"]',
      title: '팀 보고서',
      description: '허용된 팀원과 Jira 계정의 worklog를 조회해 작업시간을 확인하는 화면입니다.',
      side: 'top',
    },
    ...commonSteps,
  ],
};
