import { useEffect, useState } from 'react';
import { fetchUpdateStatus, triggerUpdate, type UpdateStatus } from '../utils/updateClient';
import {
  UPDATE_CHANNEL_CHANGED_EVENT,
  UPDATE_CHANNEL_STORAGE_KEY,
} from '../utils/updateChannel';

const CHECK_INTERVAL_MS = 15 * 60 * 1000;
const EVENT_DEDUPE_MS = 20 * 1000;

export default function UpdateBanner() {
  const [status, setStatus] = useState<UpdateStatus | null>(null);
  const [isUpdating, setIsUpdating] = useState(false);

  useEffect(() => {
    let cancelled = false;
    let isChecking = false;
    let lastCheckedAt = 0;

    const checkForUpdates = async (force = false) => {
      const now = Date.now();
      if (isChecking || (!force && now - lastCheckedAt < EVENT_DEDUPE_MS)) return;
      isChecking = true;
      lastCheckedAt = now;
      try {
        const nextStatus = await fetchUpdateStatus();
        if (!cancelled) setStatus(nextStatus);
      } catch (error) {
        console.error('Failed to check for updates', error);
      } finally {
        isChecking = false;
      }
    };

    const handleVisibilityChange = () => {
      if (document.visibilityState === 'visible') void checkForUpdates();
    };
    const handleFocus = () => void checkForUpdates();
    const handleChannelChange = () => void checkForUpdates(true);
    const handleStorage = (event: StorageEvent) => {
      if (event.key === UPDATE_CHANNEL_STORAGE_KEY) void checkForUpdates(true);
    };

    void checkForUpdates();
    const interval = window.setInterval(() => void checkForUpdates(), CHECK_INTERVAL_MS);
    document.addEventListener('visibilitychange', handleVisibilityChange);
    window.addEventListener('focus', handleFocus);
    window.addEventListener(UPDATE_CHANNEL_CHANGED_EVENT, handleChannelChange);
    window.addEventListener('storage', handleStorage);

    return () => {
      cancelled = true;
      window.clearInterval(interval);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('focus', handleFocus);
      window.removeEventListener(UPDATE_CHANNEL_CHANGED_EVENT, handleChannelChange);
      window.removeEventListener('storage', handleStorage);
    };
  }, []);

  const handleUpdate = async () => {
    if (!status?.target) return;
    setIsUpdating(true);
    try {
      await triggerUpdate(status.selectedChannel, status.target.version);
      window.setTimeout(() => {
        alert('업데이트 설치를 위해 JiraAuto가 재시작됩니다. 잠시 후 창을 새로고침해 주세요.');
      }, 700);
    } catch (error) {
      console.error('Update trigger failed', error);
      setIsUpdating(false);
      alert(error instanceof Error ? error.message : '업데이트 실행에 실패했습니다.');
    }
  };

  if (!status?.updateAvailable || !status.target) return null;

  if (status.forcedUpdate) {
    return (
      <div style={{
        position: 'fixed', inset: 0, backgroundColor: 'rgba(0, 0, 0, 0.95)', zIndex: 999999,
        display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
        color: 'white', textAlign: 'center', padding: 20,
      }}>
        <div style={{ fontSize: 48, marginBottom: 20 }}>🛡️</div>
        <h1 style={{ fontSize: 28, marginBottom: 10 }}>필수 업데이트 안내</h1>
        <p style={{ fontSize: 16, color: '#ccc', marginBottom: 30, maxWidth: 540, lineHeight: 1.6 }}>
          현재 버전(v{status.localVersion})은 더 이상 사용할 수 없습니다.<br />
          최소 필수 버전은 v{status.minRequiredVersion}이며, v{status.target.version}
          {status.target.channel === 'beta' ? ' 베타' : ' 정식'} 버전이 설치됩니다.
        </p>
        <button
          type="button"
          onClick={() => void handleUpdate()}
          disabled={isUpdating}
          style={{
            background: 'linear-gradient(90deg, #dc2626, #ef4444)', border: 'none', borderRadius: 8,
            padding: '12px 30px', color: 'white', cursor: isUpdating ? 'wait' : 'pointer',
            fontWeight: 700, fontSize: 18, boxShadow: '0 4px 15px rgba(220, 38, 38, 0.4)',
          }}
        >
          {isUpdating ? '업데이트 준비 중...' : '필수 업데이트 설치'}
        </button>
      </div>
    );
  }

  const isBeta = status.target.channel === 'beta';
  return (
    <div style={{
      background: isBeta
        ? 'linear-gradient(90deg, #7c3aed, #9333ea)'
        : 'linear-gradient(90deg, #1d4ed8, #4f46e5)',
      color: 'white', padding: '10px 20px', display: 'flex', alignItems: 'center',
      justifyContent: 'center', gap: 15, fontSize: 14, fontWeight: 500, zIndex: 9999, position: 'relative',
    }}>
      <span>
        새로운 {isBeta ? '베타' : '정식'} 업데이트(v{status.target.version})가 출시되었습니다.
      </span>
      <button
        type="button"
        onClick={() => void handleUpdate()}
        disabled={isUpdating}
        style={{
          background: 'rgba(255,255,255,0.2)', border: '1px solid rgba(255,255,255,0.4)',
          borderRadius: 4, padding: '4px 12px', color: 'white',
          cursor: isUpdating ? 'wait' : 'pointer', fontWeight: 600,
        }}
      >
        {isUpdating ? '업데이트 준비 중...' : isBeta ? '베타 업데이트' : '지금 업데이트'}
      </button>
    </div>
  );
}

