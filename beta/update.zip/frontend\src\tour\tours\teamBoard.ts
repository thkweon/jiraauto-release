import type { TourDefinition } from '../types';

export const teamBoardTour: TourDefinition = {
  id: 'team-board',
  version: 1,
  steps: [
    {
      target: '[data-tour="team-board-page"]',
      title: '팀 게시판',
      description: '팀장과 팀원이 자유롭게 글을 작성하고 댓글로 소통하는 화면입니다.',
      side: 'top',
    },
    {
      target: '[data-tour="team-board-compose"]',
      title: '게시글 작성',
      description: '공유할 내용을 입력하고 글 작성 버튼을 누르면 게시판에 등록됩니다.',
      side: 'bottom',
    },
    {
      target: '[data-tour="team-board-list"]',
      title: '게시글 목록',
      description: '게시글을 확인하고 댓글을 열어 의견을 남길 수 있습니다.',
      side: 'top',
    },
    {
      target: '[data-tour="team-board-refresh"]',
      title: '게시판 갱신',
      description: '최신 게시글과 댓글 수를 다시 불러옵니다.',
      side: 'left',
    },
  ],
};
