import os
import re
from typing import Optional

import httpx


CHECKAUTO_BASE_URL = os.getenv("CHECKAUTO_BASE_URL", "http://127.0.0.1:11211").rstrip("/")
CHECKAUTO_WIDGET_URL = f"{CHECKAUTO_BASE_URL}/api/integrations/jiraauto/widget"
CHECKAUTO_TIMEOUT_SECONDS = 2.5
_MONTH_PATTERN = re.compile(r"^\d{4}-(0[1-9]|1[0-2])$")


class CheckautoIntegrationError(Exception):
    def __init__(self, status_code: int, code: str, message: str):
        super().__init__(message)
        self.status_code = status_code
        self.code = code
        self.message = message


def validate_checkauto_month(month: Optional[str]) -> Optional[str]:
    if month is None or not month.strip():
        return None
    normalized = month.strip()
    if not _MONTH_PATTERN.fullmatch(normalized):
        raise CheckautoIntegrationError(400, "invalid_month", "month는 YYYY-MM 형식이어야 합니다.")
    return normalized


def _validate_widget_payload(payload: object) -> dict:
    if not isinstance(payload, dict):
        raise CheckautoIntegrationError(502, "invalid_response", "checkauto 응답이 객체 형식이 아닙니다.")
    if payload.get("schema_version") != 1:
        raise CheckautoIntegrationError(502, "invalid_response", "지원하지 않는 checkauto 응답 버전입니다.")
    if not isinstance(payload.get("summary"), dict) or not isinstance(payload.get("items"), list):
        raise CheckautoIntegrationError(502, "invalid_response", "checkauto 응답에 필수 데이터가 없습니다.")
    if not isinstance(payload.get("generated_at"), str) or not isinstance(payload.get("target_month"), str):
        raise CheckautoIntegrationError(502, "invalid_response", "checkauto 응답의 생성 시각 또는 대상 월이 올바르지 않습니다.")
    return payload


async def fetch_checkauto_widget(month: Optional[str], limit: int) -> dict:
    normalized_month = validate_checkauto_month(month)
    params: dict[str, str | int] = {"limit": limit}
    if normalized_month:
        params["month"] = normalized_month

    try:
        async with httpx.AsyncClient(timeout=CHECKAUTO_TIMEOUT_SECONDS) as client:
            response = await client.get(CHECKAUTO_WIDGET_URL, params=params)
    except (httpx.ConnectError, httpx.ConnectTimeout, httpx.ReadTimeout) as exc:
        raise CheckautoIntegrationError(
            503,
            "checkauto_unavailable",
            "checkauto에 연결할 수 없습니다. 서비스 실행 상태를 확인해 주세요.",
        ) from exc
    except httpx.HTTPError as exc:
        raise CheckautoIntegrationError(
            502,
            "checkauto_request_failed",
            "checkauto 요청 중 통신 오류가 발생했습니다.",
        ) from exc

    if response.status_code != 200:
        raise CheckautoIntegrationError(
            502,
            "checkauto_upstream_error",
            f"checkauto가 HTTP {response.status_code} 응답을 반환했습니다.",
        )
    try:
        payload = response.json()
    except ValueError as exc:
        raise CheckautoIntegrationError(
            502,
            "invalid_response",
            "checkauto 응답을 JSON으로 해석할 수 없습니다.",
        ) from exc
    return _validate_widget_payload(payload)
