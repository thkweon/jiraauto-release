const TOUR_KEY_PREFIX = 'tour_';

export const completionKey = (id: string, version: number) => `${TOUR_KEY_PREFIX}${id}_v${version}`;

export const isTourCompleted = (id: string, version: number) => (
  localStorage.getItem(completionKey(id, version)) === 'done'
);

export const markTourCompleted = (id: string, version: number) => {
  localStorage.setItem(completionKey(id, version), 'done');
};

export const resetAllTours = () => {
  Object.keys(localStorage)
    .filter(key => key.startsWith(TOUR_KEY_PREFIX))
    .forEach(key => localStorage.removeItem(key));
};
