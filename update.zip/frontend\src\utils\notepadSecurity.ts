export interface NotepadPageLock {
  salt: string;
  verifier: string;
  iv: string;
  ciphertext: string;
  previousSalt?: string;
  previousVerifier?: string;
}

interface DerivedPasswordMaterial {
  verifier: Uint8Array;
  encryptionKey: Uint8Array;
}

export interface UnlockedNotepadPage {
  content: string;
  encryptionKey: Uint8Array;
}

const PBKDF2_ITERATIONS = 150_000;
const encoder = new TextEncoder();
const decoder = new TextDecoder();

const bytesToBase64 = (bytes: Uint8Array) => {
  let binary = '';
  for (let index = 0; index < bytes.length; index += 0x8000) {
    binary += String.fromCharCode(...bytes.subarray(index, index + 0x8000));
  }
  return btoa(binary);
};

const base64ToBytes = (value: string) => {
  const binary = atob(value);
  return Uint8Array.from(binary, character => character.charCodeAt(0));
};

const equalBytes = (left: Uint8Array, right: Uint8Array) => {
  if (left.length !== right.length) return false;
  let difference = 0;
  for (let index = 0; index < left.length; index += 1) difference |= left[index] ^ right[index];
  return difference === 0;
};

const derivePasswordMaterial = async (password: string, salt: Uint8Array): Promise<DerivedPasswordMaterial> => {
  const passwordKey = await crypto.subtle.importKey(
    'raw',
    encoder.encode(password),
    'PBKDF2',
    false,
    ['deriveBits'],
  );
  const material = new Uint8Array(await crypto.subtle.deriveBits({
    name: 'PBKDF2',
    hash: 'SHA-256',
    salt: salt as BufferSource,
    iterations: PBKDF2_ITERATIONS,
  }, passwordKey, 512));
  return {
    verifier: material.slice(0, 32),
    encryptionKey: material.slice(32),
  };
};

const importEncryptionKey = (key: Uint8Array) => crypto.subtle.importKey(
  'raw',
  key as BufferSource,
  { name: 'AES-GCM' },
  false,
  ['encrypt', 'decrypt'],
);

const encryptContent = async (content: string, encryptionKey: Uint8Array) => {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const key = await importEncryptionKey(encryptionKey);
  const ciphertext = new Uint8Array(await crypto.subtle.encrypt(
    { name: 'AES-GCM', iv: iv as BufferSource },
    key,
    encoder.encode(content),
  ));
  return { iv: bytesToBase64(iv), ciphertext: bytesToBase64(ciphertext) };
};

export const createNotepadPageLock = async (
  password: string,
  content: string,
  previous?: Pick<NotepadPageLock, 'salt' | 'verifier'>,
): Promise<NotepadPageLock> => {
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const material = await derivePasswordMaterial(password, salt);
  const encrypted = await encryptContent(content, material.encryptionKey);
  return {
    salt: bytesToBase64(salt),
    verifier: bytesToBase64(material.verifier),
    ...encrypted,
    ...(previous ? {
      previousSalt: previous.salt,
      previousVerifier: previous.verifier,
    } : {}),
  };
};

export const unlockNotepadPage = async (
  lock: NotepadPageLock,
  password: string,
): Promise<UnlockedNotepadPage | null> => {
  const material = await derivePasswordMaterial(password, base64ToBytes(lock.salt));
  if (!equalBytes(material.verifier, base64ToBytes(lock.verifier))) return null;
  try {
    const key = await importEncryptionKey(material.encryptionKey);
    const content = await crypto.subtle.decrypt(
      { name: 'AES-GCM', iv: base64ToBytes(lock.iv) as BufferSource },
      key,
      base64ToBytes(lock.ciphertext),
    );
    return { content: decoder.decode(content), encryptionKey: material.encryptionKey };
  } catch {
    return null;
  }
};

export const encryptUnlockedNotepadPage = async (
  lock: NotepadPageLock,
  content: string,
  encryptionKey: Uint8Array,
): Promise<NotepadPageLock> => ({
  ...lock,
  ...await encryptContent(content, encryptionKey),
});

export const matchesPreviousNotepadPassword = async (lock: NotepadPageLock, password: string) => {
  if (!lock.previousSalt || !lock.previousVerifier) return false;
  const material = await derivePasswordMaterial(password, base64ToBytes(lock.previousSalt));
  return equalBytes(material.verifier, base64ToBytes(lock.previousVerifier));
};
