export interface DateRangeUpdate {
  startDate: string;
  endDate: string;
}

const isAfterDate = (left: string, right: string) => Boolean(left && right && left > right);

export const updateStartDateWithinRange = (nextStartDate: string, currentEndDate: string): DateRangeUpdate => ({
  startDate: nextStartDate,
  endDate: isAfterDate(nextStartDate, currentEndDate) ? nextStartDate : currentEndDate,
});

export const updateEndDateWithinRange = (currentStartDate: string, nextEndDate: string): DateRangeUpdate => ({
  startDate: currentStartDate,
  endDate: isAfterDate(currentStartDate, nextEndDate) ? currentStartDate : nextEndDate,
});
