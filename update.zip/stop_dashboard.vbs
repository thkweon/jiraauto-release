Option Explicit

Dim WshShell, fso, isSilent, backendResult, frontendResult, message
Set WshShell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")

isSilent = False
If WScript.Arguments.Count > 0 Then
    isSilent = (LCase(WScript.Arguments(0)) = "/silent")
End If

backendResult = StopPortProcess(8000, "python", "Backend")
frontendResult = StopPortProcess(5173, "node", "Frontend")

If Not isSilent Then
    message = "Jira Dashboard stop command completed." & vbCrLf & vbCrLf & _
              "Backend (port 8000): " & backendResult & vbCrLf & _
              "Frontend (port 5173): " & frontendResult
    MsgBox message, 64, "Jira Dashboard Stopped"
End If

Function StopPortProcess(portNumber, expectedProcess, processLabel)
    Dim q, psCommand, commandLine, exitCode
    q = Chr(34)

    psCommand = "$ErrorActionPreference = 'SilentlyContinue'; " & _
        "$connections = Get-NetTCPConnection -LocalPort " & portNumber & " -State Listen; " & _
        "$processIds = @($connections | Select-Object -ExpandProperty OwningProcess -Unique); " & _
        "if ($processIds.Count -eq 0) { exit 1 }; " & _
        "$stopped = 0; $skipped = 0; " & _
        "foreach ($processId in $processIds) { " & _
        "$process = Get-Process -Id $processId; " & _
        "if ($null -eq $process) { continue }; " & _
        "if ($process.ProcessName -notlike '" & expectedProcess & "*') { $skipped++; continue }; " & _
        "Stop-Process -Id $processId -Force; " & _
        "if ($?) { $stopped++ } }; " & _
        "if ($stopped -gt 0) { exit 0 }; " & _
        "if ($skipped -gt 0) { exit 2 }; exit 3"

    commandLine = "powershell.exe -NoProfile -ExecutionPolicy Bypass -Command " & q & psCommand & q
    exitCode = WshShell.Run(commandLine, 0, True)

    Select Case exitCode
        Case 0
            StopPortProcess = "Stopped"
        Case 1
            StopPortProcess = "Already stopped"
        Case 2
            StopPortProcess = "Skipped (listening process is not " & expectedProcess & ")"
        Case Else
            StopPortProcess = "Could not stop"
    End Select
End Function
