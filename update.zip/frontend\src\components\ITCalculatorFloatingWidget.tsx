import { useEffect, useMemo, useState } from 'react';
import type { FormEvent } from 'react';
import { Calculator, Copy } from 'lucide-react';
import { useFloatingWidgetLayout } from '../hooks/useFloatingWidgetLayout';
import {
  IT_CALCULATOR_WIDGET_SETTINGS_CHANGED_EVENT,
  loadITCalculatorWidgetSettings,
  saveITCalculatorWidgetSettings,
} from '../utils/itCalculatorWidget';
import type { ITCalculatorTool, ITCalculatorWidgetSettings } from '../utils/itCalculatorWidget';

type ResultRow = [label: string, value: string];

const TOOL_TITLES: Record<ITCalculatorTool, string> = {
  cidr: 'CIDR 계산기',
  radix: '진수 변환기',
  'data-size': '데이터 용량 변환기',
  'unix-timestamp': 'Unix Timestamp 변환기',
  'transfer-time': '전송 시간 계산기',
};
const TOOL_OPTIONS = Object.entries(TOOL_TITLES) as Array<[ITCalculatorTool, string]>;
const INITIAL_UNIX_TIMESTAMP = Math.floor(Date.now() / 1000).toString();

function ResultRows({ rows, compact = false }: { rows: ResultRow[]; compact?: boolean }) {
  const copyValue = (value: string) => {
    void navigator.clipboard.writeText(value);
  };

  return (
    <div className={`it-calculator-results${compact ? ' compact' : ''}`}>
      {rows.map(([label, value]) => (
        <div className="it-calculator-result" key={label}>
          <span>{label}</span>
          <strong title={value}>{value}</strong>
          <button type="button" onClick={() => copyValue(value)} title={`${label} 복사`}>
            <Copy size={13} />
          </button>
        </div>
      ))}
    </div>
  );
}

const numberToIPv4 = (value: number) => [24, 16, 8, 0]
  .map(shift => (value >>> shift) & 255)
  .join('.');

const calculateCIDR = (input: string): ResultRow[] | null => {
  const match = input.trim().match(/^(\d{1,3}(?:\.\d{1,3}){3})\/(\d|[12]\d|3[0-2])$/);
  if (!match) return null;
  const octets = match[1].split('.').map(Number);
  if (octets.some(octet => octet > 255)) return null;
  const prefix = Number(match[2]);
  const ip = octets.reduce((value, octet) => ((value * 256) + octet) >>> 0, 0);
  const mask = prefix === 0 ? 0 : (0xffffffff << (32 - prefix)) >>> 0;
  const network = (ip & mask) >>> 0;
  const broadcast = (network | (~mask >>> 0)) >>> 0;
  const totalHosts = 2 ** (32 - prefix);
  const usableHosts = prefix >= 31 ? totalHosts : totalHosts - 2;
  const firstHost = prefix >= 31 ? network : network + 1;
  const lastHost = prefix >= 31 ? broadcast : broadcast - 1;
  return [
    ['네트워크', numberToIPv4(network)],
    ['브로드캐스트', numberToIPv4(broadcast)],
    ['서브넷 마스크', numberToIPv4(mask)],
    ['와일드카드', numberToIPv4(~mask >>> 0)],
    ['사용 가능 범위', `${numberToIPv4(firstHost)} – ${numberToIPv4(lastHost)}`],
    ['전체 호스트', totalHosts.toLocaleString('ko-KR')],
    ['사용 가능 호스트', usableHosts.toLocaleString('ko-KR')],
    ['이진수 IP', octets.map(octet => octet.toString(2).padStart(8, '0')).join('.')],
  ];
};

function CIDRCalculator() {
  const [input, setInput] = useState('192.168.0.1/24');
  const [submittedInput, setSubmittedInput] = useState(input);
  const rows = useMemo(() => calculateCIDR(submittedInput), [submittedInput]);

  return (
    <>
      <form className="it-calculator-form" onSubmit={event => {
        event.preventDefault();
        setSubmittedInput(input);
      }}>
        <input className="glass-input" value={input} onChange={event => setInput(event.target.value)} aria-label="IPv4 CIDR" />
        <button type="submit" className="btn-primary">계산</button>
      </form>
      {rows ? <ResultRows rows={rows} /> : <p className="it-calculator-error">IPv4/CIDR 형식으로 입력해 주세요.</p>}
    </>
  );
}

const RADIXES = [2, 8, 10, 16] as const;

const parseRadixValue = (rawValue: string, radix: number): bigint | null => {
  const trimmed = rawValue.trim();
  const negative = trimmed.startsWith('-');
  const unsigned = (negative ? trimmed.slice(1) : trimmed).replace(/^0[xob]/i, '');
  const patterns: Record<number, RegExp> = {
    2: /^[01]+$/,
    8: /^[0-7]+$/,
    10: /^\d+$/,
    16: /^[\da-f]+$/i,
  };
  if (!patterns[radix].test(unsigned)) return null;
  try {
    const prefixes: Record<number, string> = { 2: '0b', 8: '0o', 10: '', 16: '0x' };
    const value = BigInt(`${prefixes[radix]}${unsigned}`);
    return negative ? -value : value;
  } catch {
    return null;
  }
};

function RadixCalculator() {
  const [input, setInput] = useState('255');
  const [radix, setRadix] = useState(10);
  const [submitted, setSubmitted] = useState({ input, radix });
  const value = useMemo(() => parseRadixValue(submitted.input, submitted.radix), [submitted]);
  const rows = value === null ? null : RADIXES.map<ResultRow>(base => [
    `${base}진수`,
    `${value < 0 ? '-' : ''}${(value < 0 ? -value : value).toString(base).toUpperCase()}`,
  ]);

  return (
    <>
      <form className="it-calculator-form it-calculator-form-with-select" onSubmit={event => {
        event.preventDefault();
        setSubmitted({ input, radix });
      }}>
        <input className="glass-input" value={input} onChange={event => setInput(event.target.value)} aria-label="변환할 숫자" />
        <select className="glass-input" value={radix} onChange={event => setRadix(Number(event.target.value))} aria-label="입력 진수">
          {RADIXES.map(base => <option value={base} key={base}>{base}진수</option>)}
        </select>
        <button type="submit" className="btn-primary">변환</button>
      </form>
      {rows ? <ResultRows rows={rows} /> : <p className="it-calculator-error">선택한 진수에 맞는 숫자를 입력해 주세요.</p>}
    </>
  );
}

const DATA_UNITS = [
  ['B', 1],
  ['KB', 1000],
  ['KiB', 1024],
  ['MB', 1000 ** 2],
  ['MiB', 1024 ** 2],
  ['GB', 1000 ** 3],
  ['GiB', 1024 ** 3],
  ['TB', 1000 ** 4],
  ['TiB', 1024 ** 4],
] as const;

const formatNumber = (value: number) => new Intl.NumberFormat('ko-KR', {
  maximumFractionDigits: 6,
}).format(value);

function DataSizeCalculator() {
  const [input, setInput] = useState('1');
  const [unit, setUnit] = useState('GB');
  const numericValue = Number(input);
  const sourceUnit = DATA_UNITS.find(([name]) => name === unit);
  const bytes = sourceUnit && Number.isFinite(numericValue) && numericValue >= 0
    ? numericValue * sourceUnit[1]
    : null;
  const rows = bytes === null ? null : DATA_UNITS.map<ResultRow>(([name, factor]) => [
    name,
    formatNumber(bytes / factor),
  ]);

  return (
    <>
      <div className="it-calculator-form it-calculator-form-value-unit">
        <input className="glass-input" type="number" min="0" step="any" value={input} onChange={event => setInput(event.target.value)} aria-label="데이터 용량" />
        <select className="glass-input" value={unit} onChange={event => setUnit(event.target.value)} aria-label="데이터 용량 단위">
          {DATA_UNITS.map(([name]) => <option value={name} key={name}>{name}</option>)}
        </select>
      </div>
      <p className="it-calculator-hint">SI(GB)는 1,000, IEC(GiB)는 1,024 기준입니다.</p>
      {rows ? <ResultRows rows={rows} compact /> : <p className="it-calculator-error">0 이상의 용량을 입력해 주세요.</p>}
    </>
  );
}

const timestampRows = (rawValue: string): ResultRow[] | null => {
  const value = Number(rawValue);
  if (!Number.isFinite(value)) return null;
  const milliseconds = Math.abs(value) >= 1e12 ? value : value * 1000;
  const date = new Date(milliseconds);
  if (Number.isNaN(date.getTime())) return null;
  return [
    ['Unix 초', Math.floor(milliseconds / 1000).toString()],
    ['Unix 밀리초', Math.floor(milliseconds).toString()],
    ['로컬 시간', date.toLocaleString('ko-KR')],
    ['UTC', date.toUTCString()],
    ['ISO 8601', date.toISOString()],
  ];
};

function UnixTimestampCalculator() {
  const [input, setInput] = useState(INITIAL_UNIX_TIMESTAMP);
  const [submittedInput, setSubmittedInput] = useState(INITIAL_UNIX_TIMESTAMP);
  const rows = useMemo(() => timestampRows(submittedInput), [submittedInput]);

  return (
    <>
      <form className="it-calculator-form" onSubmit={(event: FormEvent) => {
        event.preventDefault();
        setSubmittedInput(input);
      }}>
        <input className="glass-input" value={input} onChange={event => setInput(event.target.value)} aria-label="Unix Timestamp" />
        <button type="submit" className="btn-primary">변환</button>
      </form>
      <p className="it-calculator-hint">초·밀리초 값을 자동으로 구분합니다.</p>
      {rows ? <ResultRows rows={rows} /> : <p className="it-calculator-error">유효한 Timestamp를 입력해 주세요.</p>}
    </>
  );
}

const TRANSFER_SIZE_UNITS = [
  ['MB', 1024 ** 2],
  ['GB', 1024 ** 3],
  ['TB', 1024 ** 4],
] as const;
const SPEED_UNITS = [
  ['Mbps', 1e6],
  ['Gbps', 1e9],
] as const;

const formatDuration = (seconds: number) => {
  if (seconds < 1) return `${Math.round(seconds * 1000)}ms`;
  const totalSeconds = Math.ceil(seconds);
  const days = Math.floor(totalSeconds / 86400);
  const hours = Math.floor((totalSeconds % 86400) / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const remainder = totalSeconds % 60;
  return [days && `${days}일`, hours && `${hours}시간`, minutes && `${minutes}분`, `${remainder}초`]
    .filter(Boolean)
    .join(' ');
};

function TransferTimeCalculator() {
  const [size, setSize] = useState('1');
  const [sizeUnit, setSizeUnit] = useState('GB');
  const [speed, setSpeed] = useState('100');
  const [speedUnit, setSpeedUnit] = useState('Mbps');
  const sizeFactor = TRANSFER_SIZE_UNITS.find(([name]) => name === sizeUnit)?.[1];
  const speedFactor = SPEED_UNITS.find(([name]) => name === speedUnit)?.[1];
  const seconds = Number(size) > 0 && Number(speed) > 0 && sizeFactor && speedFactor
    ? (Number(size) * sizeFactor * 8) / (Number(speed) * speedFactor)
    : null;
  const rows: ResultRow[] | null = seconds === null ? null : [
    ['예상 시간', formatDuration(seconds)],
    ['총 초', `${formatNumber(seconds)}초`],
    ['데이터 크기', `${size} ${sizeUnit}`],
    ['전송 속도', `${speed} ${speedUnit}`],
  ];

  return (
    <>
      <div className="it-calculator-transfer-inputs">
        <label><span>데이터 크기</span><div><input className="glass-input" type="number" min="0" step="any" value={size} onChange={event => setSize(event.target.value)} /><select className="glass-input" value={sizeUnit} onChange={event => setSizeUnit(event.target.value)}>{TRANSFER_SIZE_UNITS.map(([name]) => <option key={name}>{name}</option>)}</select></div></label>
        <label><span>전송 속도</span><div><input className="glass-input" type="number" min="0" step="any" value={speed} onChange={event => setSpeed(event.target.value)} /><select className="glass-input" value={speedUnit} onChange={event => setSpeedUnit(event.target.value)}>{SPEED_UNITS.map(([name]) => <option key={name}>{name}</option>)}</select></div></label>
      </div>
      <p className="it-calculator-hint">프로토콜 오버헤드를 제외한 이론상 전송 시간입니다.</p>
      {rows ? <ResultRows rows={rows} /> : <p className="it-calculator-error">0보다 큰 용량과 속도를 입력해 주세요.</p>}
    </>
  );
}

function CalculatorTool({ tool }: { tool: ITCalculatorTool }) {
  if (tool === 'radix') return <RadixCalculator />;
  if (tool === 'data-size') return <DataSizeCalculator />;
  if (tool === 'unix-timestamp') return <UnixTimestampCalculator />;
  if (tool === 'transfer-time') return <TransferTimeCalculator />;
  return <CIDRCalculator />;
}

export default function ITCalculatorFloatingWidget() {
  const [settings, setSettings] = useState<ITCalculatorWidgetSettings>(loadITCalculatorWidgetSettings);
  const { ref: layoutRef, ...layout } = useFloatingWidgetLayout(
    'it-calculator',
    settings.placement,
    settings.enabled,
    'double',
  );

  useEffect(() => {
    const syncSettings = () => setSettings(loadITCalculatorWidgetSettings());
    window.addEventListener(IT_CALCULATOR_WIDGET_SETTINGS_CHANGED_EVENT, syncSettings);
    window.addEventListener('storage', syncSettings);
    return () => {
      window.removeEventListener(IT_CALCULATOR_WIDGET_SETTINGS_CHANGED_EVENT, syncSettings);
      window.removeEventListener('storage', syncSettings);
    };
  }, []);

  const selectedTool = settings.enabledTools[0] || 'cidr';
  if (!settings.enabled) return null;

  return (
    <section
      ref={layoutRef}
      className={`it-calculator-floating-widget floating-widget-responsive it-calculator-placement-${settings.placement}`}
      data-floating-side={layout.side}
      data-floating-block={layout.block}
      data-floating-stacked={layout.stacked || undefined}
      hidden={layout.hidden}
      aria-hidden={layout.hidden || undefined}
      aria-label="IT 계산기"
      style={layout.style}
    >
      <header className="it-calculator-header">
        <Calculator size={18} />
        <strong>IT 계산기</strong>
      </header>
      <div className="it-calculator-tool-heading">
        <select
          className="glass-input it-calculator-tool-select"
          value={selectedTool}
          aria-label="계산기 모드"
          onChange={event => {
            const nextSettings: ITCalculatorWidgetSettings = {
              ...settings,
              enabledTools: [event.target.value as ITCalculatorTool],
            };
            setSettings(nextSettings);
            saveITCalculatorWidgetSettings(nextSettings);
          }}
        >
          {TOOL_OPTIONS.map(([value, label]) => (
            <option value={value} key={value}>{label}</option>
          ))}
        </select>
      </div>
      <CalculatorTool tool={selectedTool} />
    </section>
  );
}
