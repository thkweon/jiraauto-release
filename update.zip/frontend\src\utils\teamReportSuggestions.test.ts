import { describe, expect, it } from 'vitest';
import { dedupeSuggestions, type JiraUserSuggestion } from './teamReportSuggestions';

const suggestion = (overrides: Partial<JiraUserSuggestion> = {}): JiraUserSuggestion => ({
  id: 'account-1',
  accountId: 'account-1',
  display: 'mtp2259',
  name: 'mtp2259',
  instanceId: 1,
  instanceName: 'Jira A',
  ...overrides,
});

describe('dedupeSuggestions', () => {
  it('동일 표시 이름의 여러 인스턴스 결과에서 첫 계정 하나를 대표값으로 유지한다', () => {
    const result = dedupeSuggestions([
      suggestion(),
      suggestion({ id: 'account-2', accountId: 'account-2', instanceId: 2, instanceName: 'Jira B' }),
    ]);

    expect(result).toHaveLength(1);
    expect(result[0]).toMatchObject({
      accountId: 'account-1',
      display: 'mtp2259',
      instanceId: 1,
      instanceName: 'Jira A',
    });
    expect(result[0].allInstances).toEqual([
      { accountId: 'account-1', instanceId: 1, instanceName: 'Jira A' },
      { accountId: 'account-2', instanceId: 2, instanceName: 'Jira B' },
    ]);
  });

  it('단일 인스턴스 결과를 변경하지 않는다', () => {
    const result = dedupeSuggestions([suggestion()]);

    expect(result).toHaveLength(1);
    expect(result[0].accountId).toBe('account-1');
    expect(result[0].allInstances).toHaveLength(1);
  });

  it('동일 인스턴스의 반복 결과를 allInstances에 중복 저장하지 않는다', () => {
    const result = dedupeSuggestions([suggestion(), suggestion()]);

    expect(result).toHaveLength(1);
    expect(result[0].allInstances).toHaveLength(1);
  });

  it('accountId가 같아도 인스턴스가 다르면 인스턴스 메타데이터는 모두 보존한다', () => {
    const [user] = dedupeSuggestions([
      suggestion(),
      suggestion({ instanceId: 2, instanceName: 'Jira B' }),
    ]);

    expect(user.accountId).toBe('account-1');
    expect(user.instanceId).toBe(1);
    expect(user.allInstances).toHaveLength(2);
  });

  it('표시 이름이 다른 사용자는 별도 결과로 유지한다', () => {
    const result = dedupeSuggestions([
      suggestion(),
      suggestion({ id: 'account-2', accountId: 'account-2', display: 'another-user', name: 'another-user' }),
    ]);

    expect(result.map(user => user.display)).toEqual(['mtp2259', 'another-user']);
  });
});
