import { createContext } from 'react';
import type {
  FloatingWidgetBlock,
  FloatingWidgetHiddenReason,
  FloatingWidgetKind,
  FloatingWidgetSide,
} from '../utils/floatingWidgetLayout';

export interface RuntimeHiddenWidget {
  reason: FloatingWidgetHiddenReason;
}

export interface FloatingWidgetGeometry {
  side: FloatingWidgetSide;
  block: FloatingWidgetBlock;
  height: number;
}

export interface FloatingWidgetLayoutContextValue {
  viewportWidth: number;
  viewportHeight: number;
  hiddenWidgets: Partial<Record<FloatingWidgetKind, RuntimeHiddenWidget>>;
  constrainToSlots: Partial<Record<FloatingWidgetKind, boolean>>;
  stackTopByKind: Partial<Record<FloatingWidgetKind, number>>;
  reportHidden: (
    kind: FloatingWidgetKind,
    hidden: boolean,
    reason?: FloatingWidgetHiddenReason,
  ) => void;
  reportGeometry: (
    kind: FloatingWidgetKind,
    geometry?: FloatingWidgetGeometry,
  ) => void;
}

export const FloatingWidgetLayoutContext = createContext<FloatingWidgetLayoutContextValue | null>(null);
