export type UptimeKumaPlacement =
  | 'left-top-middle'
  | 'left-middle-bottom'
  | 'right-top-middle'
  | 'right-middle-bottom';
export type UptimeKumaOccupiedPosition =
  | 'left-top'
  | 'left-middle'
  | 'left-bottom'
  | 'right-top'
  | 'right-middle'
  | 'right-bottom';

export interface UptimeKumaWidgetSettings {
  enabled: boolean;
  placement: UptimeKumaPlacement;
  baseUrl: string;
  verifySsl: boolean;
  refreshSeconds: 15 | 30 | 60 | 300;
  hideUp: boolean;
}

export interface UptimeKumaMonitor {
  id: string;
  name: string;
  vault: string;
  type: string;
  status: 'up' | 'down' | 'pending' | 'maintenance';
  response_time_ms: number | null;
  uptime_24h: number | null;
  certificate_valid: boolean | null;
  certificate_days_remaining: number | null;
  dashboard_url: string;
}

export interface UptimeKumaSummaryResponse {
  connected: boolean;
  base_url: string;
  updated_at: string;
  summary: { total: number; up: number; down: number; pending: number; maintenance: number };
  monitors: UptimeKumaMonitor[];
}

export const UPTIME_KUMA_WIDGET_SETTINGS_STORAGE_KEY = 'jiraautoUptimeKumaWidgetSettings';
export const UPTIME_KUMA_WIDGET_SETTINGS_CHANGED_EVENT = 'uptimeKumaWidgetSettingsChanged';
export const UPTIME_KUMA_PLACEMENTS: UptimeKumaPlacement[] = [
  'left-top-middle',
  'left-middle-bottom',
  'right-top-middle',
  'right-middle-bottom',
];

const DEFAULT_SETTINGS: UptimeKumaWidgetSettings = {
  enabled: false,
  placement: 'left-top-middle',
  baseUrl: '',
  verifySsl: true,
  refreshSeconds: 30,
  hideUp: false,
};

export const getUptimeKumaOccupiedPositions = (placement: UptimeKumaPlacement): UptimeKumaOccupiedPosition[] => {
  const [side, first, second] = placement.split('-');
  return [
    `${side}-${first}` as UptimeKumaOccupiedPosition,
    `${side}-${second}` as UptimeKumaOccupiedPosition,
  ];
};

export const loadUptimeKumaWidgetSettings = (): UptimeKumaWidgetSettings => {
  try {
    const value = JSON.parse(localStorage.getItem(UPTIME_KUMA_WIDGET_SETTINGS_STORAGE_KEY) || '{}') as Partial<UptimeKumaWidgetSettings>;
    return {
      enabled: typeof value.enabled === 'boolean' ? value.enabled : DEFAULT_SETTINGS.enabled,
      placement: UPTIME_KUMA_PLACEMENTS.includes(value.placement as UptimeKumaPlacement)
        ? value.placement as UptimeKumaPlacement
        : DEFAULT_SETTINGS.placement,
      baseUrl: typeof value.baseUrl === 'string' && value.baseUrl.trim() ? value.baseUrl.trim() : DEFAULT_SETTINGS.baseUrl,
      verifySsl: typeof value.verifySsl === 'boolean' ? value.verifySsl : DEFAULT_SETTINGS.verifySsl,
      refreshSeconds: [15, 30, 60, 300].includes(Number(value.refreshSeconds))
        ? Number(value.refreshSeconds) as UptimeKumaWidgetSettings['refreshSeconds']
        : DEFAULT_SETTINGS.refreshSeconds,
      hideUp: typeof value.hideUp === 'boolean' ? value.hideUp : DEFAULT_SETTINGS.hideUp,
    };
  } catch {
    return DEFAULT_SETTINGS;
  }
};

export const saveUptimeKumaWidgetSettings = (settings: UptimeKumaWidgetSettings) => {
  localStorage.setItem(UPTIME_KUMA_WIDGET_SETTINGS_STORAGE_KEY, JSON.stringify(settings));
  window.dispatchEvent(new CustomEvent(UPTIME_KUMA_WIDGET_SETTINGS_CHANGED_EVENT, { detail: settings }));
};
