interface DashboardFilterInstance {
  id: number;
}

interface DashboardFilterIssue {
  instance_id: number;
  fields?: {
    project?: {
      key?: string;
    };
  };
}

export const normalizeInstanceFilter = (
  currentFilter: string,
  instances: DashboardFilterInstance[],
) => instances.length === 0 || currentFilter === 'all' || instances.some(instance => String(instance.id) === currentFilter)
  ? currentFilter
  : 'all';

export const normalizeProjectFilter = (
  currentFilter: string,
  instanceFilter: string,
  issues: DashboardFilterIssue[],
) => {
  if (currentFilter === 'all') return currentFilter;
  const projectExists = issues.some(issue => (
    (instanceFilter === 'all' || String(issue.instance_id) === instanceFilter)
    && issue.fields?.project?.key === currentFilter
  ));
  return projectExists ? currentFilter : 'all';
};
