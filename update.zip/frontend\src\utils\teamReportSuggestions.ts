export interface JiraUserSuggestion {
  id: string;
  display: string;
  accountId?: string;
  name?: string;
  key?: string;
  instanceId?: number;
  instanceName?: string;
  allInstances?: JiraUserInstance[];
}

export interface JiraUserInstance {
  accountId: string;
  instanceId?: number;
  instanceName?: string;
}

const instanceKey = (instance: JiraUserInstance) =>
  `${instance.instanceId ?? ''}:${instance.instanceName ?? ''}:${instance.accountId}`;

export const dedupeSuggestions = (
  users: JiraUserSuggestion[],
): JiraUserSuggestion[] => {
  const suggestionsByDisplayName = new Map<string, JiraUserSuggestion>();

  users.forEach(user => {
    const displayName = user.display.trim();
    if (!displayName || !user.accountId) return;

    const instance: JiraUserInstance = {
      accountId: user.accountId,
      instanceId: user.instanceId,
      instanceName: user.instanceName,
    };

    const existing = suggestionsByDisplayName.get(displayName);
    if (!existing) {
      suggestionsByDisplayName.set(displayName, {
        ...user,
        display: displayName,
        allInstances: [instance],
      });
      return;
    }

    if (!existing.allInstances?.some(item => instanceKey(item) === instanceKey(instance))) {
      existing.allInstances = [...(existing.allInstances || []), instance];
    }
  });

  return Array.from(suggestionsByDisplayName.values());
};
