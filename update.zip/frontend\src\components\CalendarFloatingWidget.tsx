import { useEffect, useState } from 'react';
import type { CSSProperties } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import {
  CALENDAR_WIDGET_SETTINGS_CHANGED_EVENT,
  loadCalendarWidgetSettings,
} from '../utils/calendarWidget';
import type { CalendarWidgetSettings } from '../utils/calendarWidget';
import useFloatingFollowOffset from '../hooks/useFloatingFollowOffset';
import { CALENDAR_EVENT_SOURCES, loadCalendarEvents } from '../utils/calendarEvents';
import type { CalendarEvent } from '../utils/calendarEvents';

const WEEKDAYS = ['일', '월', '화', '수', '목', '금', '토'];

const startOfMonth = (date: Date) => new Date(date.getFullYear(), date.getMonth(), 1);

const isSameDate = (left: Date, right: Date) =>
  left.getFullYear() === right.getFullYear()
  && left.getMonth() === right.getMonth()
  && left.getDate() === right.getDate();

const getCalendarDates = (month: Date) => {
  const firstDay = startOfMonth(month);
  const gridStart = new Date(firstDay);
  gridStart.setDate(firstDay.getDate() - firstDay.getDay());

  return Array.from({ length: 42 }, (_, index) => {
    const date = new Date(gridStart);
    date.setDate(gridStart.getDate() + index);
    return date;
  });
};

const toDateKey = (date: Date) => [
  date.getFullYear(),
  String(date.getMonth() + 1).padStart(2, '0'),
  String(date.getDate()).padStart(2, '0'),
].join('-');

const isContinuousEvent = (event: CalendarEvent) => Boolean(event.endDate && event.endDate > event.date);

const getEventDisplayPriority = (event: CalendarEvent) => {
  if (event.sourceId === 'd-day') return 0;
  if (isContinuousEvent(event)) return 1;
  return 2;
};

const assignContinuousEventLanes = (events: CalendarEvent[]) => {
  const laneEndDates: string[] = [];
  const lanes = new Map<string, number>();
  events
    .filter(isContinuousEvent)
    .sort((left, right) => (
      left.date.localeCompare(right.date)
      || (left.endDate || left.date).localeCompare(right.endDate || right.date)
      || left.id.localeCompare(right.id)
    ))
    .forEach(event => {
      const availableLane = laneEndDates.findIndex(endDate => endDate < event.date);
      const lane = availableLane >= 0 ? availableLane : laneEndDates.length;
      laneEndDates[lane] = event.endDate || event.date;
      lanes.set(event.id, Math.min(lane, 2));
    });
  return lanes;
};

export default function CalendarFloatingWidget() {
  const [settings, setSettings] = useState<CalendarWidgetSettings>(loadCalendarWidgetSettings);
  const [calendarEvents, setCalendarEvents] = useState<CalendarEvent[]>([]);
  const [visibleMonth, setVisibleMonth] = useState(() => startOfMonth(new Date()));
  const followOffset = useFloatingFollowOffset();
  const today = new Date();
  const dates = getCalendarDates(visibleMonth);
  const continuousEventLanes = assignContinuousEventLanes(calendarEvents);

  useEffect(() => {
    const syncSettings = () => setSettings(loadCalendarWidgetSettings());
    window.addEventListener(CALENDAR_WIDGET_SETTINGS_CHANGED_EVENT, syncSettings);
    window.addEventListener('storage', syncSettings);
    return () => {
      window.removeEventListener(CALENDAR_WIDGET_SETTINGS_CHANGED_EVENT, syncSettings);
      window.removeEventListener('storage', syncSettings);
    };
  }, []);

  useEffect(() => {
    let active = true;
    const visibleDates = getCalendarDates(visibleMonth);
    const rangeEnd = new Date(visibleDates[visibleDates.length - 1]);
    rangeEnd.setDate(rangeEnd.getDate() + 1);
    const syncEvents = async () => {
      if (!settings.enabled) {
        setCalendarEvents([]);
        return;
      }
      const events = await loadCalendarEvents(
        {
          start: toDateKey(visibleDates[0]),
          end: toDateKey(rangeEnd),
          outlookCalendarFolder: settings.outlookCalendarFolder,
        },
        settings.enabledEventSources,
      );
      if (active) setCalendarEvents(events);
    };
    const changedSources = CALENDAR_EVENT_SOURCES.filter(source => source.changedEvent);
    changedSources.forEach(source => window.addEventListener(source.changedEvent!, syncEvents));
    window.addEventListener('storage', syncEvents);
    void syncEvents();
    const refreshTimer = window.setInterval(syncEvents, 60_000);
    return () => {
      active = false;
      changedSources.forEach(source => window.removeEventListener(source.changedEvent!, syncEvents));
      window.removeEventListener('storage', syncEvents);
      window.clearInterval(refreshTimer);
    };
  }, [
    settings.enabled,
    settings.enabledEventSources,
    settings.outlookCalendarFolder,
    visibleMonth,
  ]);

  if (!settings.enabled) return null;

  const moveMonth = (offset: number) => {
    setVisibleMonth(current => new Date(current.getFullYear(), current.getMonth() + offset, 1));
  };

  return (
    <section
      className={`calendar-floating-widget calendar-widget-position-${settings.position}`}
      aria-label="월간 달력"
      style={{ '--widget-follow-offset': `${followOffset}px` } as CSSProperties}
    >
      <div className="calendar-widget-header">
        <strong>{visibleMonth.getFullYear()}년 {visibleMonth.getMonth() + 1}월</strong>
        <div className="calendar-widget-navigation">
          <button type="button" onClick={() => moveMonth(-1)} aria-label="이전 달">
            <ChevronLeft size={16} />
          </button>
          <button
            type="button"
            className="calendar-widget-today-button"
            onClick={() => setVisibleMonth(startOfMonth(new Date()))}
          >
            오늘
          </button>
          <button type="button" onClick={() => moveMonth(1)} aria-label="다음 달">
            <ChevronRight size={16} />
          </button>
        </div>
      </div>

      <div className="calendar-widget-weekdays" aria-hidden="true">
        {WEEKDAYS.map(day => <span key={day}>{day}</span>)}
      </div>
      <div className="calendar-widget-days">
        {dates.map(date => {
          const outsideMonth = date.getMonth() !== visibleMonth.getMonth();
          const todayDate = isSameDate(date, today);
          const dateKey = toDateKey(date);
          const dayEvents = calendarEvents
            .filter(event => (
              event.date <= dateKey
              && (event.endDate || event.date) >= dateKey
              && settings.enabledEventSources.includes(event.sourceId)
            ))
            .sort((left, right) => getEventDisplayPriority(left) - getEventDisplayPriority(right));
          const visibleEvents = dayEvents.slice(0, 3);
          const continuousEvents = visibleEvents.filter(isContinuousEvent);
          const pointEvents = visibleEvents.filter(event => !isContinuousEvent(event));
          const tooltipId = `calendar-events-${dateKey}`;
          return (
            <div
              key={dateKey}
              className={[
                'calendar-widget-day-cell',
                date.getDay() === 0 ? 'week-edge-left' : '',
                date.getDay() === 6 ? 'week-edge-right' : '',
              ].filter(Boolean).join(' ')}
            >
              <span
                className={[
                  'calendar-widget-day',
                  outsideMonth ? 'outside-month' : '',
                  todayDate ? 'today' : '',
                  date.getDay() === 0 ? 'sunday' : '',
                  date.getDay() === 6 ? 'saturday' : '',
                  dayEvents.length > 0 ? 'has-events' : '',
                ].filter(Boolean).join(' ')}
                aria-current={todayDate ? 'date' : undefined}
                aria-describedby={dayEvents.length > 0 ? tooltipId : undefined}
                tabIndex={dayEvents.length > 0 ? 0 : -1}
              >
                {date.getDate()}
              </span>
              {visibleEvents.length > 0 && (
                <span className="calendar-widget-event-markers" aria-hidden="true">
                  {continuousEvents.map(event => {
                    const startsHere = event.date === dateKey;
                    const endsHere = event.endDate === dateKey;
                    return (
                      <i
                        className={[
                          'calendar-widget-event-line',
                          startsHere ? 'range-start' : '',
                          endsHere ? 'range-end' : '',
                        ].filter(Boolean).join(' ')}
                        key={event.id}
                        style={{
                          backgroundColor: settings.eventSourceLineColors[event.sourceId]
                            || settings.eventSourceColors[event.sourceId]
                            || event.color,
                          '--calendar-event-line-lane': continuousEventLanes.get(event.id) || 0,
                        } as CSSProperties}
                      />
                    );
                  })}
                  {pointEvents.length > 0 && (
                    <span className="calendar-widget-event-point-row">
                      {pointEvents.map(event => (
                        <i
                          className="calendar-widget-event-dot"
                          key={event.id}
                          style={{ backgroundColor: settings.eventSourceColors[event.sourceId] || event.color }}
                        />
                      ))}
                    </span>
                  )}
                </span>
              )}
              {dayEvents.length > 0 && (
                <div className="calendar-widget-event-tooltip" id={tooltipId} role="tooltip">
                  <strong>{date.getMonth() + 1}월 {date.getDate()}일 일정</strong>
                  {dayEvents.map(event => (
                    <div className="calendar-widget-event-tooltip-item" key={event.id}>
                      <i
                        style={{
                          backgroundColor: isContinuousEvent(event)
                            ? settings.eventSourceLineColors[event.sourceId]
                              || settings.eventSourceColors[event.sourceId]
                              || event.color
                            : settings.eventSourceColors[event.sourceId] || event.color,
                        }}
                        aria-hidden="true"
                      />
                      <span>{event.title}</span>
                      {event.detail && <small>{event.detail}</small>}
                    </div>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </section>
  );
}
