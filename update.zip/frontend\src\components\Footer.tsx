import React, { useState } from 'react';
import { RefreshCw } from 'lucide-react';

const API_BASE = 'http://localhost:8000/api';
const REMOTE_VERSION_URL = 'https://raw.githubusercontent.com/thkweon/jiraauto-release/main/version.json';

// 간단한 버전 비교 함수
const compareVersions = (v1: string, v2: string) => {
  const parts1 = v1.split('.').map(Number);
  const parts2 = v2.split('.').map(Number);
  for (let i = 0; i < Math.max(parts1.length, parts2.length); i++) {
    const p1 = parts1[i] || 0;
    const p2 = parts2[i] || 0;
    if (p1 > p2) return 1;
    if (p1 < p2) return -1;
  }
  return 0;
};

export default function Footer() {
  const [isUpdating, setIsUpdating] = useState(false);

  const handleManualUpdate = async () => {
    setIsUpdating(true);
    try {
      // 1. 버전 확인
      const localRes = await fetch(`${API_BASE}/local-version`);
      const localData = await localRes.json();
      const localVersion = localData.version || '0.0.0';

      const remoteRes = await fetch(REMOTE_VERSION_URL, { cache: 'no-store' });
      const remoteData = await remoteRes.json();
      const remoteVersion = remoteData.version;

      if (!remoteVersion) {
        alert('원격 업데이트 서버에 접근할 수 없습니다.');
        setIsUpdating(false);
        return;
      }

      if (compareVersions(remoteVersion, localVersion) <= 0) {
        alert(`현재 최신 버전(v${localVersion})을 사용 중입니다.\n업데이트할 내용이 없습니다.`);
        setIsUpdating(false);
        return;
      }

      if (!window.confirm(`새로운 버전(v${remoteVersion})이 발견되었습니다.\n지금 업데이트를 진행하시겠습니까?`)) {
        setIsUpdating(false);
        return;
      }

      // 2. 업데이트 실행
      await fetch(`${API_BASE}/trigger-update`, { method: 'POST' });
      
      setTimeout(() => {
        alert('업데이트 패치를 위해 서버가 재시작됩니다. 잠시 후 창이 닫히거나 새로고침 될 수 있습니다.');
      }, 500);

    } catch (err) {
      console.error('Update check/trigger failed', err);
      alert('업데이트 확인 또는 실행에 실패했습니다.');
      setIsUpdating(false);
    }
  };

  return (
    <footer style={{
      textAlign: 'center',
      padding: '40px 20px 30px',
      marginTop: 'auto', // 하단 고정을 위한 margin
      color: 'var(--text-secondary, #888)',
      fontSize: '13px',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: '12px'
    }}>
      <div>
        &copy; 2026 <strong>Security Operation(mtp2259)</strong>. All rights reserved.
      </div>
      <button 
        onClick={handleManualUpdate}
        disabled={isUpdating}
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: '6px',
          background: 'transparent',
          border: '1px solid var(--border-color, #444)',
          padding: '6px 12px',
          borderRadius: '6px',
          color: 'var(--text-secondary, #aaa)',
          cursor: isUpdating ? 'wait' : 'pointer',
          fontSize: '12px',
          transition: 'all 0.2s ease',
          opacity: isUpdating ? 0.6 : 1
        }}
        onMouseOver={(e) => { 
          if (!isUpdating) { 
            e.currentTarget.style.background = 'rgba(255,255,255,0.05)'; 
            e.currentTarget.style.color = '#ccc'; 
          } 
        }}
        onMouseOut={(e) => { 
          if (!isUpdating) { 
            e.currentTarget.style.background = 'transparent'; 
            e.currentTarget.style.color = 'var(--text-secondary, #aaa)'; 
          } 
        }}
      >
        <RefreshCw size={14} className={isUpdating ? "spin" : ""} />
        {isUpdating ? '업데이트 확인 중...' : '수동 업데이트 확인'}
      </button>
      <style>{`
        @keyframes spin { 100% { transform: rotate(360deg); } }
        .spin { animation: spin 1s linear infinite; }
      `}</style>
    </footer>
  );
}
