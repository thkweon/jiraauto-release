@echo off
setlocal

echo [1/3] Backend setting up...
cd /d "%~dp0backend"
if not exist venv (
    python -m venv venv
)

set "LICENSE_PROVIDER=server"
set "LICENSE_SERVER_URL=https://license.shadowspace.i234.me"
set "LICENSE_SERVER_VERIFY_TLS=N"
set "LICENSE_GATE_ENABLED=Y"
set "JIRAAUTO_APP_VERSION=1.0.0"
set "JIRAAUTO_APP_CHANNEL=stable"

venv\Scripts\pip install -r requirements.txt
start "Jira Backend" cmd /k "venv\Scripts\python.exe main.py"

echo [2/3] Frontend setting up...
cd /d "%~dp0frontend"
if not exist node_modules (
    npm install
)
start "Jira Frontend" cmd /k "npm.cmd run dev"

echo [3/3] Done.
echo Dashboard: http://localhost:5173
echo Backend API: http://localhost:8000
pause
