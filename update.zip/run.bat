@echo off
setlocal enabledelayedexpansion

:: ============================================================
:: [0/3] Check and install dependencies
:: ============================================================

set "HAVE_WINGET=0"
where winget >nul 2>&1 && set "HAVE_WINGET=1"

set "NEEDS_RESTART=0"

where python >nul 2>&1
if errorlevel 1 (
    if "!HAVE_WINGET!"=="1" (
        echo [0/3] Python not found. Installing via winget...
        winget install Python.Python.3 --silent --accept-source-agreements --accept-package-agreements
    ) else (
        echo [0/3] Python not found. Downloading installer...
        powershell -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $ProgressPreference='SilentlyContinue'; [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; $ts=[datetime]::Now.ToString('yyyyMMddHHmmss'); $out=$env:TEMP+'\python_inst_'+$ts+'.exe'; Write-Host 'Downloading Python 3.14.5...'; Invoke-WebRequest -Uri 'https://www.python.org/ftp/python/3.14.5/python-3.14.5-amd64.exe' -OutFile $out -UseBasicParsing; Write-Host 'Installing...'; $maxRetry=5; $retry=0; do { $p=Start-Process -Wait -PassThru -FilePath $out -ArgumentList '/passive InstallAllUsers=1 PrependPath=1 Include_launcher=0'; if($p.ExitCode -eq 1618){$retry++; Write-Host ('Windows Installer busy, retrying in 15s... ('+$retry+'/'+$maxRetry+')'); Start-Sleep 15} } while($p.ExitCode -eq 1618 -and $retry -lt $maxRetry); if($p.ExitCode -ne 0){throw 'Python installer failed with exit code '+$p.ExitCode}"
    )
    if errorlevel 1 (
        echo [ERROR] Python installation failed. Install manually: https://www.python.org
        pause
        exit /b 1
    )
    set "NEEDS_RESTART=1"
)

where node >nul 2>&1
if errorlevel 1 (
    if "!HAVE_WINGET!"=="1" (
        echo [0/3] Node.js not found. Installing via winget...
        winget install OpenJS.NodeJS.LTS --silent --accept-source-agreements --accept-package-agreements
    ) else (
        echo [0/3] Node.js not found. Downloading installer...
        powershell -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $ProgressPreference='SilentlyContinue'; [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; $ts=[datetime]::Now.ToString('yyyyMMddHHmmss'); $out=$env:TEMP+'\node_inst_'+$ts+'.msi'; Write-Host 'Downloading Node.js v24.16.0...'; Invoke-WebRequest -Uri 'https://nodejs.org/dist/v24.16.0/node-v24.16.0-x64.msi' -OutFile $out -UseBasicParsing; Write-Host 'Installing...'; $maxRetry=5; $retry=0; do { $p=Start-Process -Wait -PassThru msiexec -ArgumentList @('/i',$out,'/quiet','/norestart','ADDLOCAL=ALL'); if($p.ExitCode -eq 1618){$retry++; Write-Host ('Windows Installer busy, retrying in 15s... ('+$retry+'/'+$maxRetry+')'); Start-Sleep 15} } while($p.ExitCode -eq 1618 -and $retry -lt $maxRetry); if($p.ExitCode -ne 0){throw 'Node.js installer failed with exit code '+$p.ExitCode}"
    )
    if errorlevel 1 (
        echo [ERROR] Node.js installation failed. Install manually: https://nodejs.org
        pause
        exit /b 1
    )
    set "NEEDS_RESTART=1"
)

if "!NEEDS_RESTART!"=="1" (
    echo.
    echo Installation complete. Restarting in a new window...
    start "Jira Auto" cmd /k "%~f0"
    exit /b 0
)

:: ============================================================
:: [1/3] Backend
:: ============================================================

echo [1/3] Backend setting up...
cd /d "%~dp0backend"
if not exist venv (
    python -m venv venv
)

set "LICENSE_PROVIDER=server"
set "LICENSE_SERVER_URL=https://license.shadowspace.i234.me"
set "LICENSE_SERVER_VERIFY_TLS=N"
set "LICENSE_GATE_ENABLED=Y"
set "JIRAAUTO_APP_VERSION=1.0.0"
set "JIRAAUTO_APP_CHANNEL=stable"

venv\Scripts\pip install -r requirements.txt

:: ============================================================
:: [2/3] Frontend
:: ============================================================

echo [2/3] Frontend setting up...
cd /d "%~dp0frontend"
if not exist node_modules (
    npm install
)

echo [3/3] Environment ready.
echo Run start_dashboard.vbs to launch the dashboard in the background.
pause