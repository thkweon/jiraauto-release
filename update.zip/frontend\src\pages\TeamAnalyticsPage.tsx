import { useState, useEffect, useMemo, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Legend } from 'recharts';
import { Settings } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';
import '../TeamStyles.css';

const API_BASE = 'http://localhost:8000/api';
const COLORS = ['#0984e3', '#00b894', '#fdcb6e', '#e17055', '#6c5ce7', '#e84393', '#00cec9', '#55efc4'];
const PRIORITY_COLORS: Record<string, string> = {
  Blocker: '#d63031', Critical: '#e17055', High: '#fdcb6e',
  Medium: '#0984e3', Low: '#00b894', Minor: '#55efc4',
};

const CHART_DEFS = [
  { key: 'status',          label: '상태별 이슈 비율' },
  { key: 'activeWorkload',  label: '활성 업무 부하' },
  { key: 'completionRate',  label: '담당자별 완료율' },
  { key: 'velocity',        label: '주간 처리량' },
  { key: 'aging',           label: '미완료 이슈 노후화' },
  { key: 'priority',        label: '우선순위별 미완료 현황' },
  { key: 'issueType',       label: '이슈 타입 구성비' },
  { key: 'wip',             label: 'WIP 집중도' },
] as const;

type ChartKey = typeof CHART_DEFS[number]['key'];
const DEFAULT_VISIBLE = Object.fromEntries(CHART_DEFS.map(c => [c.key, true])) as Record<ChartKey, boolean>;
const DONE_NAMES = ['Done', 'Closed', 'Resolved', '완료', '닫힘', '해결됨'];
const ANALYTICS_DATE_PRESET_KEY = 'teamAnalyticsDatePreset';
const ANALYTICS_START_DATE_KEY = 'teamAnalyticsStartDate';
const ANALYTICS_END_DATE_KEY = 'teamAnalyticsEndDate';

const isDone = (i: any) => i.fields?.status?.statusCategory?.key === 'done' || DONE_NAMES.includes(i.fields?.status?.name);
const isInProgress = (i: any) => i.fields?.status?.statusCategory?.key === 'indeterminate';
const assigneeName = (i: any) => i.team_member_id || i.fields?.assignee?.displayName || i.fields?.assignee?.name || '미지정';

export default function TeamAnalyticsPage() {
  const { theme } = useTheme();
  const [issues, setIssues] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [datePreset, setDatePreset] = useState(() => localStorage.getItem(ANALYTICS_DATE_PRESET_KEY) || '30');
  const [startDate, setStartDate] = useState(() => localStorage.getItem(ANALYTICS_START_DATE_KEY) || '');
  const [endDate, setEndDate] = useState(() => localStorage.getItem(ANALYTICS_END_DATE_KEY) || '');
  const [showSettings, setShowSettings] = useState(false);
  const [visible, setVisible] = useState<Record<ChartKey, boolean>>(() => {
    try {
      const saved = localStorage.getItem('analyticsChartVisibility');
      return saved ? { ...DEFAULT_VISIBLE, ...JSON.parse(saved) } : DEFAULT_VISIBLE;
    } catch { return DEFAULT_VISIBLE; }
  });
  const settingsRef = useRef<HTMLDivElement>(null);

  const role = localStorage.getItem('teamRole');
  const leaderUrl = localStorage.getItem('teamLeaderUrl');
  const incompleteBarColor = theme === 'dark' ? 'rgba(209, 213, 219, 0.82)' : 'rgba(75, 85, 99, 0.72)';
  const settingsButtonBg = showSettings
    ? 'var(--accent-primary, #0984e3)'
    : theme === 'dark'
      ? 'rgba(31, 32, 40, 0.86)'
      : 'rgba(255,255,255,0.7)';
  const settingsButtonBorder = theme === 'dark'
    ? '1px solid rgba(255,255,255,0.12)'
    : '1px solid rgba(0,0,0,0.1)';

  useEffect(() => { fetchData(); }, []);

  useEffect(() => {
    localStorage.setItem('analyticsChartVisibility', JSON.stringify(visible));
  }, [visible]);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (settingsRef.current && !settingsRef.current.contains(e.target as Node)) setShowSettings(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const fetchData = async () => {
    try {
      const baseUrl = role === 'leader' ? API_BASE : `${leaderUrl}/api`;
      const res = await fetch(`${baseUrl}/team/issues?include_closed=true`);
      const data = await res.json();
      setIssues(data.issues || []);
    } catch (e) { console.error(e); }
    setLoading(false);
  };

  const withinPeriod = (dateStr: string) => {
    if (!dateStr) return true;
    const issueDate = new Date(dateStr).getTime();
    if (!Number.isFinite(issueDate)) return true;

    if (datePreset === 'custom') {
      if (startDate && issueDate < new Date(startDate).getTime()) return false;
      if (endDate && issueDate > new Date(endDate).getTime() + 86400000) return false;
      return true;
    }

    if (datePreset === 'all') return true;

    const days = parseInt(datePreset);
    if (!Number.isFinite(days)) return true;
    return issueDate >= Date.now() - days * 86400000;
  };

  const activeIssues = useMemo(() => issues.filter(i => withinPeriod(i.fields?.created)), [issues, datePreset, startDate, endDate]);
  const openIssues   = useMemo(() => issues.filter(i => !isDone(i)), [issues]);

  // KPI
  const kpi = useMemo(() => {
    const total = activeIssues.length;
    const doneList = activeIssues.filter(isDone);
    const completionRate = total ? Math.round(doneList.length / total * 100) : 0;
    const wip = activeIssues.filter(isInProgress).length;
    const resolved = doneList.filter(i => i.fields?.resolutiondate && i.fields?.created);
    const avgDays = resolved.length
      ? Math.round(resolved.reduce((s, i) => s + (new Date(i.fields.resolutiondate).getTime() - new Date(i.fields.created).getTime()), 0) / resolved.length / 86400000)
      : null;
    return { total, completionRate, wip, avgDays };
  }, [activeIssues]);

  // 1. 상태별 이슈 비율
  const statusData = useMemo(() => {
    const map: Record<string, number> = {};
    activeIssues.forEach(i => { const s = i.fields?.status?.name || 'Unknown'; map[s] = (map[s] || 0) + 1; });
    return Object.entries(map).map(([name, value]) => ({ name, value }));
  }, [activeIssues]);

  // 2. 활성 업무 부하
  const activeWorkloadData = useMemo(() => {
    const map: Record<string, number> = {};
    activeIssues.filter(i => !isDone(i)).forEach(i => { const m = assigneeName(i); map[m] = (map[m] || 0) + 1; });
    return Object.entries(map).map(([name, 이슈수]) => ({ name, 이슈수 })).sort((a, b) => b.이슈수 - a.이슈수);
  }, [activeIssues]);

  // 3. 담당자별 완료율
  const completionRateData = useMemo(() => {
    const map: Record<string, { done: number; total: number }> = {};
    activeIssues.forEach(i => {
      const m = assigneeName(i);
      if (!map[m]) map[m] = { done: 0, total: 0 };
      map[m].total++;
      if (isDone(i)) map[m].done++;
    });
    return Object.entries(map)
      .map(([name, { done, total }]) => ({ name, 완료: done, 미완료: total - done, rate: Math.round(done / total * 100) }))
      .sort((a, b) => b.rate - a.rate);
  }, [activeIssues]);

  // 4. 주간 처리량 (최근 8주)
  const velocityData = useMemo(() => {
    const weeks = Array.from({ length: 8 }, (_, w) => {
      const end = new Date(); end.setDate(end.getDate() - (7 - w) * 7); end.setHours(23, 59, 59, 999);
      const start = new Date(end); start.setDate(start.getDate() - 6); start.setHours(0, 0, 0, 0);
      return { label: `${start.getMonth() + 1}/${start.getDate()}`, start, end, 완료: 0 };
    });
    issues.filter(isDone).forEach(i => {
      const rd = i.fields?.resolutiondate ? new Date(i.fields.resolutiondate) : null;
      if (!rd) return;
      const w = weeks.find(w => rd >= w.start && rd <= w.end);
      if (w) w.완료++;
    });
    return weeks.map(({ label, 완료 }) => ({ week: label, 완료 }));
  }, [issues]);

  // 5. 미완료 이슈 노후화 (날짜 필터 무관 — 현재 열린 이슈 전체)
  const agingData = useMemo(() => {
    const buckets = [
      { name: '7일 이내', 이슈수: 0, fill: '#00b894' },
      { name: '7~30일',  이슈수: 0, fill: '#fdcb6e' },
      { name: '30~90일', 이슈수: 0, fill: '#e17055' },
      { name: '90일+',   이슈수: 0, fill: '#d63031' },
    ];
    const now = Date.now();
    openIssues.forEach(i => {
      const days = (now - new Date(i.fields?.created).getTime()) / 86400000;
      if (days < 7) buckets[0].이슈수++;
      else if (days < 30) buckets[1].이슈수++;
      else if (days < 90) buckets[2].이슈수++;
      else buckets[3].이슈수++;
    });
    return buckets;
  }, [openIssues]);

  // 6. 우선순위별 미완료
  const priorityData = useMemo(() => {
    const map: Record<string, number> = {};
    openIssues.forEach(i => { const p = i.fields?.priority?.name || '없음'; map[p] = (map[p] || 0) + 1; });
    const order = ['Blocker', 'Critical', 'High', 'Medium', 'Low', 'Minor', '없음'];
    return Object.entries(map)
      .map(([name, 이슈수]) => ({ name, 이슈수 }))
      .sort((a, b) => (order.indexOf(a.name) + 99) % 100 - (order.indexOf(b.name) + 99) % 100);
  }, [openIssues]);

  // 7. 이슈 타입 구성비
  const issueTypeData = useMemo(() => {
    const map: Record<string, number> = {};
    activeIssues.forEach(i => { const t = i.fields?.issuetype?.name || 'Unknown'; map[t] = (map[t] || 0) + 1; });
    return Object.entries(map).map(([name, value]) => ({ name, value }));
  }, [activeIssues]);

  // 8. WIP 집중도 (현재 In Progress)
  const wipData = useMemo(() => {
    const map: Record<string, number> = {};
    issues.filter(isInProgress).forEach(i => { const m = assigneeName(i); map[m] = (map[m] || 0) + 1; });
    return Object.entries(map).map(([name, 진행중]) => ({ name, 진행중 })).sort((a, b) => b.진행중 - a.진행중);
  }, [issues]);

  const toggleChart = (key: ChartKey) => setVisible(v => ({ ...v, [key]: !v[key] }));
  const visibleCount = Object.values(visible).filter(Boolean).length;

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (!active || !payload?.length) return null;
    const tooltipValueColor = (color?: string) => {
      if (!color) return 'var(--text-primary)';
      const normalized = String(color).replace(/\s+/g, '').toLowerCase();
      if (normalized.includes('rgba(0,0,0') || normalized === '#ccc' || normalized === '#ddd' || normalized === '#eee') {
        return 'var(--text-primary)';
      }
      return color;
    };

    return (
      <div style={{ background: 'var(--card-bg)', color: 'var(--text-primary)', backdropFilter: 'blur(10px)', padding: '10px 15px', borderRadius: 12, boxShadow: '0 8px 24px rgba(0,0,0,0.28)', border: '1px solid rgba(127, 140, 141, 0.32)' }}>
        <p style={{ margin: '0 0 5px', fontWeight: 700, fontSize: 13, color: 'var(--text-primary)' }}>{label || payload[0].name}</p>
        {payload.map((p: any, i: number) => (
          <p key={i} style={{ margin: 0, fontSize: 13, fontWeight: 700, color: tooltipValueColor(p.color) }}>{p.name}: {p.value}건</p>
        ))}
      </div>
    );
  };

  if (loading) return <div style={{ padding: 40, textAlign: 'center' }}>데이터를 불러오는 중입니다...</div>;
  if (issues.length === 0) return (
    <div className="glass-container" style={{ textAlign: 'center', padding: '100px 20px', color: 'var(--text-secondary)' }}>
      <h2 style={{ color: 'var(--text-primary)', marginBottom: 15 }}>통계 데이터가 없습니다.</h2>
      <p>팀에 할당된 활성 이슈가 없거나 네트워크 연결을 확인해주세요.</p>
    </div>
  );

  return (
    <div className="glass-container">

      {/* 상단 컨트롤 */}
      <div style={{ display: 'flex', justifyContent: 'flex-end', alignItems: 'center', marginBottom: 20, gap: 12 }}>
        <div style={{ display: 'flex', alignItems: 'center', background: 'rgba(0,0,0,0.03)', padding: '4px 12px', borderRadius: 12, gap: 8 }}>
          <span style={{ fontSize: 13, fontWeight: 700, color: 'var(--text-secondary)' }}>조회 기간</span>
          <select
            className="glass-input"
            style={{ width: 'auto', padding: '6px 12px', border: '1px solid rgba(127, 140, 141, 0.24)', background: 'var(--card-bg)', color: 'var(--text-primary)' }}
            value={datePreset}
            onChange={e => {
              setDatePreset(e.target.value);
              localStorage.setItem(ANALYTICS_DATE_PRESET_KEY, e.target.value);
            }}
          >
            <option value="1">1일</option>
            <option value="7">7일</option>
            <option value="14">14일</option>
            <option value="30">30일</option>
            <option value="90">90일</option>
            <option value="all">전체</option>
            <option value="custom">직접입력</option>
          </select>
          {datePreset === 'custom' && (
            <div style={{ display: 'flex', alignItems: 'center', gap: 5, marginLeft: 5, flexShrink: 0 }}>
              <input
                type="date"
                className="glass-input"
                style={{ padding: '6px', fontSize: 12 }}
                value={startDate}
                onChange={e => {
                  setStartDate(e.target.value);
                  localStorage.setItem(ANALYTICS_START_DATE_KEY, e.target.value);
                }}
              />
              <span style={{ color: '#ccc' }}>~</span>
              <input
                type="date"
                className="glass-input"
                style={{ padding: '6px', fontSize: 12 }}
                value={endDate}
                onChange={e => {
                  setEndDate(e.target.value);
                  localStorage.setItem(ANALYTICS_END_DATE_KEY, e.target.value);
                }}
              />
            </div>
          )}
        </div>

        {/* 차트 설정 토글 */}
        <div ref={settingsRef} style={{ position: 'relative' }}>
          <button
            onClick={() => setShowSettings(s => !s)}
            style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '8px 14px', borderRadius: 12, border: settingsButtonBorder, background: settingsButtonBg, color: showSettings ? '#fff' : 'var(--text-primary)', cursor: 'pointer', fontSize: 13, fontWeight: 600, transition: 'all 0.2s' }}
          >
            <Settings size={14} />
            차트 설정 {visibleCount}/{CHART_DEFS.length}
          </button>

          <AnimatePresence>
            {showSettings && (
              <motion.div
                initial={{ opacity: 0, y: -8, scale: 0.97 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: -8, scale: 0.97 }}
                transition={{ duration: 0.15 }}
                style={{ position: 'absolute', right: 0, top: 'calc(100% + 8px)', background: 'var(--card-bg)', color: 'var(--text-primary)', backdropFilter: 'blur(20px)', borderRadius: 16, boxShadow: '0 12px 40px rgba(0,0,0,0.18)', border: '1px solid rgba(127, 140, 141, 0.24)', padding: '16px 20px', width: 260, zIndex: 1000 }}
              >
                <p style={{ margin: '0 0 12px', fontSize: 11, fontWeight: 700, color: 'var(--text-secondary)', textTransform: 'uppercase', letterSpacing: '0.06em' }}>표시할 차트 선택</p>
                {CHART_DEFS.map(chart => (
                  <div
                    key={chart.key}
                    onClick={() => toggleChart(chart.key)}
                    style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '9px 0', borderBottom: '1px solid rgba(0,0,0,0.05)', cursor: 'pointer', userSelect: 'none' }}
                  >
                    <span style={{ fontSize: 13, color: 'var(--text-primary)' }}>{chart.label}</span>
                    <div style={{ width: 38, height: 22, borderRadius: 11, background: visible[chart.key] ? 'var(--accent-primary, #0984e3)' : 'rgba(0,0,0,0.13)', transition: 'background 0.2s', position: 'relative', flexShrink: 0 }}>
                      <div style={{ position: 'absolute', top: 3, left: visible[chart.key] ? 19 : 3, width: 16, height: 16, borderRadius: '50%', background: '#fff', transition: 'left 0.2s', boxShadow: '0 1px 4px rgba(0,0,0,0.25)' }} />
                    </div>
                  </div>
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* KPI 요약 */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16, marginBottom: 28 }}>
        {[
          { label: '조회 기간 이슈',    value: kpi.total,          unit: '건',  color: '#0984e3' },
          { label: '완료율',            value: kpi.completionRate, unit: '%',   color: '#00b894' },
          { label: '현재 진행 중 (WIP)', value: kpi.wip,            unit: '건',  color: '#6c5ce7' },
          { label: '평균 완료 소요일',  value: kpi.avgDays ?? '-',  unit: kpi.avgDays != null ? '일' : '', color: '#fdcb6e' },
        ].map((item, idx) => (
          <motion.div key={item.label} className="glass-panel" initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: idx * 0.05 }}
            style={{ padding: '20px', textAlign: 'center' }}>
            <div style={{ fontSize: 30, fontWeight: 800, color: item.color, lineHeight: 1 }}>
              {item.value}<span style={{ fontSize: 14, fontWeight: 600, marginLeft: 3 }}>{item.unit}</span>
            </div>
            <div style={{ fontSize: 12, color: 'var(--text-secondary)', marginTop: 6, fontWeight: 600 }}>{item.label}</div>
          </motion.div>
        ))}
      </div>

      {/* 차트 그리드 */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(420px, 1fr))', gap: 20 }}>

        {visible.status && (
          <motion.div className="glass-panel" initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }}>
            <h3 style={{ marginTop: 0, marginBottom: 20 }}>상태별 이슈 비율</h3>
            <ResponsiveContainer width="100%" height={280}>
              <PieChart>
                <Pie data={statusData} cx="50%" cy="50%" innerRadius={70} outerRadius={100} paddingAngle={4} dataKey="value" stroke="none">
                  {statusData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                </Pie>
                <Tooltip content={<CustomTooltip />} />
                <Legend iconType="circle" wrapperStyle={{ fontSize: 12 }} />
              </PieChart>
            </ResponsiveContainer>
          </motion.div>
        )}

        {visible.activeWorkload && (
          <motion.div className="glass-panel" initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }}>
            <h3 style={{ marginTop: 0, marginBottom: 20 }}>활성 업무 부하 <span style={{ fontSize: 12, fontWeight: 400, color: 'var(--text-secondary)' }}>완료 제외</span></h3>
            <ResponsiveContainer width="100%" height={280}>
              <BarChart data={activeWorkloadData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(0,0,0,0.05)" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 12 }} />
                <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12 }} allowDecimals={false} />
                <Tooltip content={<CustomTooltip />} cursor={{ fill: 'rgba(0,0,0,0.02)' }} />
                <Bar dataKey="이슈수" fill="#0984e3" radius={[6, 6, 0, 0]} maxBarSize={52} />
              </BarChart>
            </ResponsiveContainer>
          </motion.div>
        )}

        {visible.completionRate && (
          <motion.div className="glass-panel" initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }}>
            <h3 style={{ marginTop: 0, marginBottom: 20 }}>담당자별 완료율</h3>
            <ResponsiveContainer width="100%" height={280}>
              <BarChart data={completionRateData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(0,0,0,0.05)" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 12 }} />
                <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12 }} allowDecimals={false} />
                <Tooltip content={<CustomTooltip />} cursor={{ fill: 'rgba(0,0,0,0.02)' }} />
                <Bar dataKey="완료" stackId="a" fill="#00b894" maxBarSize={52} />
                <Bar dataKey="미완료" stackId="a" fill={incompleteBarColor} radius={[6, 6, 0, 0]} maxBarSize={52} />
                <Legend iconType="circle" wrapperStyle={{ fontSize: 12 }} />
              </BarChart>
            </ResponsiveContainer>
          </motion.div>
        )}

        {visible.velocity && (
          <motion.div className="glass-panel" initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }}>
            <h3 style={{ marginTop: 0, marginBottom: 20 }}>주간 처리량 <span style={{ fontSize: 12, fontWeight: 400, color: 'var(--text-secondary)' }}>최근 8주</span></h3>
            <ResponsiveContainer width="100%" height={280}>
              <BarChart data={velocityData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(0,0,0,0.05)" />
                <XAxis dataKey="week" axisLine={false} tickLine={false} tick={{ fontSize: 11 }} />
                <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12 }} allowDecimals={false} />
                <Tooltip content={<CustomTooltip />} cursor={{ fill: 'rgba(0,0,0,0.02)' }} />
                <Bar dataKey="완료" fill="#6c5ce7" radius={[6, 6, 0, 0]} maxBarSize={52} />
              </BarChart>
            </ResponsiveContainer>
          </motion.div>
        )}

        {visible.aging && (
          <motion.div className="glass-panel" initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }}>
            <h3 style={{ marginTop: 0, marginBottom: 4 }}>미완료 이슈 노후화</h3>
            <p style={{ margin: '0 0 16px', fontSize: 12, color: 'var(--text-secondary)' }}>현재 열린 이슈 {openIssues.length}건 기준 (날짜 필터 무관)</p>
            <ResponsiveContainer width="100%" height={260}>
              <BarChart data={agingData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(0,0,0,0.05)" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 12 }} />
                <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12 }} allowDecimals={false} />
                <Tooltip content={<CustomTooltip />} cursor={{ fill: 'rgba(0,0,0,0.02)' }} />
                <Bar dataKey="이슈수" radius={[6, 6, 0, 0]} maxBarSize={64}>
                  {agingData.map((entry, i) => <Cell key={i} fill={entry.fill} />)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </motion.div>
        )}

        {visible.priority && (
          <motion.div className="glass-panel" initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }}>
            <h3 style={{ marginTop: 0, marginBottom: 4 }}>우선순위별 미완료 현황</h3>
            <p style={{ margin: '0 0 16px', fontSize: 12, color: 'var(--text-secondary)' }}>현재 열린 이슈 기준 (날짜 필터 무관)</p>
            <ResponsiveContainer width="100%" height={260}>
              <BarChart data={priorityData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(0,0,0,0.05)" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 12 }} />
                <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12 }} allowDecimals={false} />
                <Tooltip content={<CustomTooltip />} cursor={{ fill: 'rgba(0,0,0,0.02)' }} />
                <Bar dataKey="이슈수" radius={[6, 6, 0, 0]} maxBarSize={64}>
                  {priorityData.map((entry, i) => <Cell key={i} fill={PRIORITY_COLORS[entry.name] || COLORS[i % COLORS.length]} />)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </motion.div>
        )}

        {visible.issueType && (
          <motion.div className="glass-panel" initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }}>
            <h3 style={{ marginTop: 0, marginBottom: 20 }}>이슈 타입 구성비</h3>
            <ResponsiveContainer width="100%" height={280}>
              <PieChart>
                <Pie data={issueTypeData} cx="50%" cy="50%" innerRadius={70} outerRadius={100} paddingAngle={4} dataKey="value" stroke="none">
                  {issueTypeData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                </Pie>
                <Tooltip content={<CustomTooltip />} />
                <Legend iconType="circle" wrapperStyle={{ fontSize: 12 }} />
              </PieChart>
            </ResponsiveContainer>
          </motion.div>
        )}

        {visible.wip && (
          <motion.div className="glass-panel" initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }}>
            <h3 style={{ marginTop: 0, marginBottom: 4 }}>WIP 집중도</h3>
            <p style={{ margin: '0 0 16px', fontSize: 12, color: 'var(--text-secondary)' }}>현재 "진행 중" 상태 이슈 기준</p>
            <ResponsiveContainer width="100%" height={260}>
              <BarChart data={wipData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(0,0,0,0.05)" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 12 }} />
                <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12 }} allowDecimals={false} />
                <Tooltip content={<CustomTooltip />} cursor={{ fill: 'rgba(0,0,0,0.02)' }} />
                <Bar dataKey="진행중" fill="#e84393" radius={[6, 6, 0, 0]} maxBarSize={52} />
              </BarChart>
            </ResponsiveContainer>
          </motion.div>
        )}

      </div>
    </div>
  );
}
