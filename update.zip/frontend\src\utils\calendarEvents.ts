import {
  D_DAY_WIDGET_SETTINGS_CHANGED_EVENT,
  getDDayDifference,
  loadDDayWidgetSettings,
} from './dDayWidget';

const API_BASE = 'http://localhost:8000/api';

export type CalendarEventSourceId = 'd-day' | 'outlook';

export interface CalendarEvent {
  id: string;
  sourceId: CalendarEventSourceId;
  date: string;
  endDate?: string;
  title: string;
  detail?: string;
  color: string;
}

export interface CalendarEventLoadContext {
  start: string;
  end: string;
  outlookCalendarFolder: {
    entryId: string;
    storeId: string;
  } | null;
}

export interface CalendarEventSource {
  id: CalendarEventSourceId;
  label: string;
  changedEvent?: string;
  load: (context: CalendarEventLoadContext) => CalendarEvent[] | Promise<CalendarEvent[]>;
}

interface OutlookCalendarEvent {
  id: string;
  date: string;
  end_date: string;
  title: string;
  start_at: string;
  end_at: string;
  all_day: boolean;
  location: string;
}

const getDDayLabel = (targetDate: string) => {
  const difference = getDDayDifference(targetDate);
  if (difference === 0) return 'D-DAY';
  return difference > 0 ? `D-${difference}` : `D+${Math.abs(difference)}`;
};

const dDayEventSource: CalendarEventSource = {
  id: 'd-day',
  label: 'D-DAY',
  changedEvent: D_DAY_WIDGET_SETTINGS_CHANGED_EVENT,
  load: () => loadDDayWidgetSettings().items.map(item => ({
    id: `d-day:${item.id}`,
    sourceId: 'd-day',
    date: item.targetDate,
    title: item.title,
    detail: getDDayLabel(item.targetDate),
    color: '#dc2626',
  })),
};

const outlookEventSource: CalendarEventSource = {
  id: 'outlook',
  label: 'Outlook',
  load: async context => {
    if (!context.outlookCalendarFolder) return [];
    const query = new URLSearchParams({
      start: context.start,
      end: context.end,
      folder_id: context.outlookCalendarFolder.entryId,
      store_id: context.outlookCalendarFolder.storeId,
    });
    const response = await fetch(`${API_BASE}/calendar/outlook/events?${query}`);
    if (!response.ok) throw new Error(`Outlook calendar request failed (${response.status})`);
    const payload = await response.json() as { events?: OutlookCalendarEvent[] };
    return (payload.events || []).map(item => {
      const timeLabel = item.all_day ? '종일' : item.start_at.slice(11, 16);
      return {
        id: `outlook:${item.id}`,
        sourceId: 'outlook',
        date: item.date,
        endDate: item.end_date,
        title: item.title,
        detail: item.location ? `${timeLabel} · ${item.location}` : timeLabel,
        color: '#2563eb',
      };
    });
  },
};

export const CALENDAR_EVENT_SOURCES: CalendarEventSource[] = [dDayEventSource, outlookEventSource];

export const loadCalendarEvents = async (
  context: CalendarEventLoadContext,
  enabledSourceIds: string[],
) => {
  const enabledSources = CALENDAR_EVENT_SOURCES.filter(source => enabledSourceIds.includes(source.id));
  const sourceResults = await Promise.all(enabledSources.map(async source => {
    try {
      return await source.load(context);
    } catch (error) {
      console.warn(`Calendar event source '${source.id}' could not be loaded`, error);
      return [];
    }
  }));
  return sourceResults.flat();
};
