import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { Copy, CheckCircle, RefreshCcw, ShieldAlert } from 'lucide-react';
import { motion } from 'framer-motion';
import '../TeamStyles.css';

const API_BASE = 'http://localhost:8000/api';

interface TeamMember {
  id: string | number;
  name: string;
  last_sync: string;
}

export default function TeamManagePage() {
  const navigate = useNavigate();
  const [generatedCode, setGeneratedCode] = useState('');
  const [copied, setCopied] = useState(false);
  const [members, setMembers] = useState<TeamMember[]>([]);

  const fetchInviteCode = useCallback(async () => {
    try {
      const res = await fetch(`${API_BASE}/team/invite`);
      const data = await res.json();
      setGeneratedCode(data.invite_code);
    } catch {
      // The page can remain usable while the invite code is temporarily unavailable.
    }
  }, []);

  const fetchMembers = useCallback(async () => {
    try {
      const res = await fetch(`${API_BASE}/team/members`);
      const data = await res.json();
      setMembers(data.members || []);
    } catch {
      // Keep the current member list on transient request failures.
    }
  }, []);

  useEffect(() => {
    if (localStorage.getItem('teamRole') !== 'leader') navigate('/');
    const timer = window.setTimeout(() => {
      void fetchInviteCode();
      void fetchMembers();
    }, 0);
    return () => window.clearTimeout(timer);
  }, [fetchInviteCode, fetchMembers, navigate]);

  const handleDisband = () => {
    if (window.confirm('팀을 해체하시겠습니까? (팀장 권한이 해제되며 데이터는 유지됩니다)')) {
      localStorage.removeItem('teamRole');
      window.dispatchEvent(new Event('teamRoleChanged'));
      navigate('/');
    }
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(generatedCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="glass-container">
      <div style={{display:'flex', justifyContent:'flex-end', alignItems:'center', marginBottom: 20}}>
        <button className="btn-glass" onClick={handleDisband} style={{color: '#d63031', borderColor: 'rgba(214,48,49,0.3)', display: 'flex', alignItems: 'center', gap: 8}}>
          <ShieldAlert size={16}/> 팀 해체
        </button>
      </div>

      <div className="widget-grid">
        <motion.div className="glass-panel" initial={{opacity:0, scale:0.95}} animate={{opacity:1, scale:1}}>
          <h3 style={{marginTop:0, display:'flex', alignItems:'center', gap:8}}>🔑 초대 코드</h3>
          <p style={{fontSize: 13, color: 'var(--text-secondary)'}}>팀원에게 전달하여 팀에 가입하도록 안내하세요.</p>
          <div style={{ display: 'flex', gap: '10px', marginTop: 15 }}>
            <input type="text" className="glass-input" value={generatedCode} readOnly />
            <button className="btn-premium" onClick={copyToClipboard} style={{ display: 'flex', gap: '5px', alignItems: 'center', padding: '0 20px' }}>
              {copied ? <CheckCircle size={16} /> : <Copy size={16} />}
            </button>
          </div>
        </motion.div>

        <motion.div className="glass-panel" style={{gridColumn: '1 / -1'}} initial={{opacity:0, y:20}} animate={{opacity:1, y:0}} transition={{delay: 0.1}}>
          <div style={{display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom: 20}}>
            <h3 style={{margin:0}}>👥 동기화된 팀원 현황</h3>
            <button className="btn-glass" onClick={fetchMembers} style={{padding: '8px 15px', display:'flex', alignItems:'center', gap:5}}><RefreshCcw size={14}/> 새로고침</button>
          </div>
          {members.length === 0 ? <p style={{fontSize:14, color:'var(--text-secondary)', textAlign:'center', padding:20}}>아직 동기화된 팀원이 없습니다.</p> : (
            <div style={{display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(250px, 1fr))', gap: 15}}>
              {members.map(m => (
                <div key={m.id} style={{padding: '15px', background: 'rgba(0,0,0,0.03)', borderRadius: '12px', border: '1px solid rgba(0,0,0,0.05)'}}>
                  <strong style={{fontSize: 16, display:'block', marginBottom: 5}}>{m.name}</strong>
                  <span style={{fontSize: 12, color: 'var(--text-secondary)'}}>최근: {new Date(m.last_sync).toLocaleString()}</span>
                </div>
              ))}
            </div>
          )}
        </motion.div>
      </div>
    </div>
  );
}
