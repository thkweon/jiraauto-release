import { describe, expect, it } from 'vitest';
import { normalizeInstanceFilter, normalizeProjectFilter } from './dashboardFilters';

const issues = [
  { instance_id: 1, fields: { project: { key: 'ALPHA' } } },
  { instance_id: 2, fields: { project: { key: 'BETA' } } },
];

describe('dashboard filters', () => {
  it('keeps an available instance filter', () => {
    expect(normalizeInstanceFilter('2', [{ id: 1 }, { id: 2 }])).toBe('2');
  });

  it('resets a missing instance filter', () => {
    expect(normalizeInstanceFilter('3', [{ id: 1 }, { id: 2 }])).toBe('all');
  });

  it('keeps the current instance until an instance list is available', () => {
    expect(normalizeInstanceFilter('3', [])).toBe('3');
  });

  it('keeps a project available for the selected instance', () => {
    expect(normalizeProjectFilter('BETA', '2', issues)).toBe('BETA');
  });

  it('resets a project unavailable for the selected instance', () => {
    expect(normalizeProjectFilter('ALPHA', '2', issues)).toBe('all');
  });
});
