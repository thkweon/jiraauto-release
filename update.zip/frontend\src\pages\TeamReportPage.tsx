﻿import { useEffect, useMemo, useRef, useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Cell } from 'recharts';
import { useCallback } from 'react';
import { Download, Search, Settings, ClipboardCopy, FileText, RotateCcw } from 'lucide-react';
import '../App.css';
import '../TeamStyles.css';
import { updateEndDateWithinRange, updateStartDateWithinRange } from '../utils/dateRange';
import { formatJiraInstanceName, type JiraDeploymentType } from '../utils/jiraInstance';

const API_BASE = 'http://localhost:8000/api';
const COLORS = ['#0984e3', '#00b894', '#fdcb6e', '#e17055', '#6c5ce7', '#e84393', '#00cec9', '#55efc4'];

interface JiraUserSuggestion {
  id: string;
  display: string;
  accountId?: string;
  name?: string;
  key?: string;
  instanceId?: number;
  instanceName?: string;
}

interface TeamReportMember {
  accountId: string;
  displayName: string;
  name?: string;
  key?: string;
  instanceId?: number;
  instanceName?: string;
}

interface TeamReportLastResultRef {
  resultId: string;
  lastRunAt: string;
  datePreset: string;
  startDate: string;
  endDate: string;
  instanceFilter: string;
  members: TeamReportMember[];
  selectedAuthorId?: string;
  worklogSortKey?: WorklogSortKey;
  worklogSortDirection?: SortDirection;
  reportMode?: 'standard' | 'delegated';
}

interface JiraInstanceInfo {
  id: number;
  name: string;
  base_url: string;
  deployment_type: JiraDeploymentType;
}

interface ReportRow extends TeamReportMember {
  totalSeconds: number;
  hours: number;
  issueCount: number;
  worklogCount: number;
  ratio: number;
}

interface RawWorklogRow {
  worklogId?: string;
  accountId: string;
  authorDisplayName: string;
  authorAccountId: string;
  started: string;
  timeSpentSeconds: number;
  timeSpent?: string;
  issueKey: string;
  issueComponents?: string[];
  issueSummary: string;
  issueAssignee: string;
  issueReporter: string;
  issueStatus: string;
  issueCreated: string;
  instance_name: string;
  issueUrl: string;
}

interface TeamReportResultMember extends TeamReportMember {
  totalSeconds?: number;
  issueCount?: number;
  worklogCount?: number;
}

interface TeamReportResult {
  members?: TeamReportResultMember[];
  worklogs?: RawWorklogRow[];
  delegateStatuses?: DelegateStatus[];
  resultId?: string;
}

interface MappedMember {
  id: string;
  name: string;
  member_url?: string;
  effective_member_url?: string;
  is_local_leader?: boolean;
}

type WorklogSortKey = 'seconds' | 'started' | 'issueKey';
type SortDirection = 'asc' | 'desc';

interface TeamReportJobStatus {
  jobId?: string;
  status?: 'queued' | 'running' | 'done' | 'error';
  stage?: string;
  message?: string;
  progress?: number;
  scannedIssues?: number;
  scannedWorklogs?: number;
  candidateIssues?: number;
  processedIssues?: number;
  totalCandidateIssues?: number;
  currentInstance?: string;
  resultId?: string;
  result?: TeamReportResult;
  delegateStatuses?: DelegateStatus[];
}

interface DelegateStatus {
  memberId: string;
  memberUrl?: string;
  displayName?: string;
  status: string;
  message?: string;
  lastSeenAt?: string;
  local?: boolean;
}

type UnknownRecord = Record<string, unknown>;

const asRecord = (value: unknown): UnknownRecord | null =>
  typeof value === 'object' && value !== null ? value as UnknownRecord : null;

const normalizeJiraUserSuggestion = (value: unknown): JiraUserSuggestion | null => {
  // Jira Cloud returns accountId, but the installed Jira Server returns key/name.
  // The report stores the best worklog-author identifier in the accountId field
  // to preserve the existing minimal [{accountId, displayName}] storage shape.
  const user = asRecord(value);
  if (!user) return null;
  const accountId = [user.accountId, user.key, user.name].find(item => typeof item === 'string') as string | undefined;
  const display = [user.displayName, user.name, user.key, accountId].find(item => typeof item === 'string') as string | undefined;
  if (!accountId || !display) return null;
  return {
    id: accountId,
    display,
    accountId,
    name: typeof user.name === 'string' ? user.name : undefined,
    key: typeof user.key === 'string' ? user.key : undefined,
    instanceId: typeof user.instance_id === 'number' ? user.instance_id : undefined,
    instanceName: typeof user.instance_name === 'string' ? user.instance_name : undefined,
  };
};

interface ReportTooltipProps {
  active?: boolean;
  payload?: Array<{ value?: string | number }>;
  label?: string;
}

const ReportTooltip = ({ active, payload, label }: ReportTooltipProps) => {
  if (!active || !payload?.length) return null;
  return (
    <div style={{ background: 'var(--card-bg)', color: 'var(--text-primary)', padding: '10px 15px', borderRadius: 12, boxShadow: '0 8px 24px rgba(0,0,0,0.28)', border: '1px solid rgba(127, 140, 141, 0.32)' }}>
      <p style={{ margin: '0 0 5px', fontWeight: 700, fontSize: 13 }}>{label}</p>
      <p style={{ margin: 0, fontSize: 13, fontWeight: 700, color: '#0984e3' }}>{payload[0].value}시간</p>
    </div>
  );
};

const inferLoginFromDisplayName = (displayName?: string) => {
  const match = String(displayName || '').match(/\(([^)]+)\)/);
  return match?.[1] || '';
};

const loadMembers = (storageKey: string): TeamReportMember[] => {
  try {
    const parsed = JSON.parse(localStorage.getItem(storageKey) || '[]');
    return Array.isArray(parsed)
      ? parsed.filter(member => member?.accountId && member?.displayName).map(member => ({
          accountId: member.accountId,
          displayName: member.displayName,
          name: member.name || inferLoginFromDisplayName(member.displayName),
          key: member.key,
          instanceId: member.instanceId,
          instanceName: member.instanceName,
        }))
      : [];
  } catch {
    localStorage.removeItem(storageKey);
    return [];
  }
};

const mergeMemberIdentity = (primary: TeamReportMember[], fallback: TeamReportMember[]) => {
  const fallbackByAccountId = new Map(fallback.map(member => [member.accountId, member]));
  return primary.map(member => {
    const saved = fallbackByAccountId.get(member.accountId);
    return {
      ...member,
      name: member.name || saved?.name,
      key: member.key || saved?.key,
      instanceId: member.instanceId ?? saved?.instanceId,
      instanceName: member.instanceName || saved?.instanceName,
    };
  });
};

const csvEscape = (value: string | number) => `"${String(value).replace(/"/g, '""')}"`;

const secondsToHours = (seconds: number) => Math.round((seconds / 3600) * 100) / 100;
const normalizeIdentifier = (value?: string) => String(value || '').trim().toLowerCase();
const NO_COMPONENT_FILTER = '__no_component__';

export default function TeamReportPage() {
  const [leaderAccountId, setLeaderAccountId] = useState('unknown');
  const [members, setMembers] = useState<TeamReportMember[]>([]);
  const [instanceList, setInstanceList] = useState<JiraInstanceInfo[]>([]);
  const [instanceFilter, setInstanceFilter] = useState(() =>
    localStorage.getItem('teamReportInstanceFilter') ||
    localStorage.getItem('instanceFilter') ||
    'all'
  );
  const [memberQuery, setMemberQuery] = useState('');
  const [memberSuggestions, setMemberSuggestions] = useState<JiraUserSuggestion[]>([]);
  const [memberSearchLoading, setMemberSearchLoading] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [delegatedMode, setDelegatedMode] = useState(() => localStorage.getItem('teamReportDelegatedMode') === 'true');
  const [mappedMembers, setMappedMembers] = useState<MappedMember[]>([]);
  const [delegateStatuses, setDelegateStatuses] = useState<DelegateStatus[]>([]);
  const [datePreset, setDatePreset] = useState(() => localStorage.getItem('teamReportDatePreset') || '30');
  const [startDate, setStartDate] = useState(() => localStorage.getItem('teamReportStartDate') || '');
  const [endDate, setEndDate] = useState(() => localStorage.getItem('teamReportEndDate') || '');
  const [loading, setLoading] = useState(false);
  const [loadingStatus, setLoadingStatus] = useState<TeamReportJobStatus | null>(null);
  const [error, setError] = useState('');
  const [rows, setRows] = useState<ReportRow[]>([]);
  const [reportMembers, setReportMembers] = useState<TeamReportMember[]>([]);
  const [rawWorklogs, setRawWorklogs] = useState<RawWorklogRow[]>([]);
  const [selectedAuthorId, setSelectedAuthorId] = useState<string>('all');
  const [worklogInstanceFilter, setWorklogInstanceFilter] = useState('all');
  const [worklogComponentFilter, setWorklogComponentFilter] = useState('all');
  const [worklogSortKey, setWorklogSortKey] = useState<WorklogSortKey>('seconds');
  const [worklogSortDirection, setWorklogSortDirection] = useState<SortDirection>('desc');
  const [lastRunAt, setLastRunAt] = useState<Date | null>(null);
  const [currentResultId, setCurrentResultId] = useState('');
  const [lastResultMode, setLastResultMode] = useState<'standard' | 'delegated'>('standard');
  const [copyMessage, setCopyMessage] = useState('');
  const chartRef = useRef<HTMLDivElement>(null);
  const worklogTableRef = useRef<HTMLDivElement>(null);
  const isLeader = localStorage.getItem('teamRole') === 'leader';

  const storageKey = `teamReportMembers:${leaderAccountId}`;
  const lastResultRefKey = `teamReportLastResultRef:${leaderAccountId}`;
  const hasResult = rows.some(row => row.totalSeconds > 0);

  const persistLastResultRef = useCallback((
    resultId: string,
    runAt: Date,
    sourceMembers: TeamReportMember[],
    reportMode: 'standard' | 'delegated' = lastResultMode,
  ) => {
    const ref: TeamReportLastResultRef = {
      resultId,
      lastRunAt: runAt.toISOString(),
      datePreset,
      startDate,
      endDate,
      instanceFilter,
      members: sourceMembers.map(member => ({
        accountId: member.accountId,
        displayName: member.displayName,
        name: member.name,
        key: member.key,
        instanceId: member.instanceId,
        instanceName: member.instanceName,
      })),
      selectedAuthorId,
      worklogSortKey,
      worklogSortDirection,
      reportMode,
    };
    localStorage.setItem(lastResultRefKey, JSON.stringify(ref));
  }, [
    datePreset,
    endDate,
    instanceFilter,
    lastResultMode,
    lastResultRefKey,
    selectedAuthorId,
    startDate,
    worklogSortDirection,
    worklogSortKey,
  ]);
  const selectedAuthor = selectedAuthorId === 'all' ? null : rows.find(row => row.accountId === selectedAuthorId) || members.find(member => member.accountId === selectedAuthorId);
  const canFetchReport = delegatedMode && isLeader ? !loading : members.length > 0 && !loading;
  const connectedMappedMemberCount = mappedMembers.filter(member => member.effective_member_url || member.member_url || member.is_local_leader).length;

  const handleStartDateChange = (value: string) => {
    const next = updateStartDateWithinRange(value, endDate);
    setStartDate(next.startDate);
    setEndDate(next.endDate);
    localStorage.setItem('teamReportStartDate', next.startDate);
    localStorage.setItem('teamReportEndDate', next.endDate);
  };

  const handleEndDateChange = (value: string) => {
    const next = updateEndDateWithinRange(startDate, value);
    setStartDate(next.startDate);
    setEndDate(next.endDate);
    localStorage.setItem('teamReportStartDate', next.startDate);
    localStorage.setItem('teamReportEndDate', next.endDate);
  };

  useEffect(() => {
    const fetchInitialContext = async () => {
      try {
        const [meRes, configRes] = await Promise.all([
          fetch(`${API_BASE}/me`),
          fetch(`${API_BASE}/config`),
        ]);
        const data = await meRes.json();
        const config = await configRes.json();
        setInstanceList(config.instances || []);
        setInstanceFilter(
          localStorage.getItem('teamReportInstanceFilter') ||
          localStorage.getItem('instanceFilter') ||
          'all'
        );
        const first = Object.values(data as Record<string, { accountId?: string; name?: string; key?: string }>)[0];
        setLeaderAccountId(first?.accountId || first?.name || first?.key || 'unknown');
      } catch {
        setLeaderAccountId('unknown');
      }
    };
    fetchInitialContext();
  }, []);

  useEffect(() => {
    if (!leaderAccountId) return;
    const timer = window.setTimeout(() => {
      setMembers(loadMembers(storageKey));
    }, 0);
    return () => window.clearTimeout(timer);
  }, [leaderAccountId, storageKey]);

  useEffect(() => {
    localStorage.setItem('teamReportDelegatedMode', delegatedMode ? 'true' : 'false');
  }, [delegatedMode]);

  useEffect(() => {
    if (!isLeader || (!settingsOpen && !delegatedMode)) return;
    let cancelled = false;
    const fetchMappedMembers = async () => {
      try {
        const res = await fetch(`${API_BASE}/team/members`);
        const data = await res.json().catch(() => ({}));
        if (!cancelled) setMappedMembers(data.members || []);
      } catch {
        if (!cancelled) setMappedMembers([]);
      }
    };
    const timer = window.setTimeout(() => {
      void fetchMappedMembers();
    }, 0);
    return () => {
      cancelled = true;
      window.clearTimeout(timer);
    };
  }, [isLeader, settingsOpen, delegatedMode]);

  useEffect(() => {
    if (!leaderAccountId || leaderAccountId === 'unknown') return;
    const restoreLastResult = async () => {
      const savedRef = localStorage.getItem(lastResultRefKey);
      if (!savedRef) return;
      try {
        const parsed = JSON.parse(savedRef) as TeamReportLastResultRef;
        if (!parsed?.resultId || !Array.isArray(parsed.members)) return;
        const res = await fetch(`${API_BASE}/team/report/results/${parsed.resultId}`);
        const data = await res.json().catch(() => ({}));
        if (!res.ok) {
          localStorage.removeItem(lastResultRefKey);
          setError('최근 조회 결과가 만료되었습니다. 다시 조회해 주세요.');
          return;
        }
        const savedMembers = loadMembers(storageKey);
        const restoredMembers = mergeMemberIdentity(parsed.members, savedMembers);
        setDatePreset(parsed.datePreset || '30');
        setStartDate(parsed.startDate || '');
        setEndDate(parsed.endDate || '');
        const restoredInstanceFilter = parsed.instanceFilter || 'all';
        setInstanceFilter(restoredInstanceFilter);
        localStorage.setItem('teamReportInstanceFilter', restoredInstanceFilter);
        const restoredMode = parsed.reportMode || 'standard';
        if (restoredMode !== 'delegated') setMembers(restoredMembers);
        setLastResultMode(restoredMode);
        setSelectedAuthorId(parsed.selectedAuthorId || 'all');
        setWorklogSortKey(parsed.worklogSortKey || 'seconds');
        setWorklogSortDirection(parsed.worklogSortDirection || 'desc');
        setCurrentResultId(parsed.resultId);
        applyReportData(data, restoredMembers, parsed.lastRunAt ? new Date(parsed.lastRunAt) : new Date());
      } catch {
        localStorage.removeItem(lastResultRefKey);
      }
    };
    restoreLastResult();
  }, [leaderAccountId, lastResultRefKey, storageKey]);

  const persistMembers = (next: TeamReportMember[]) => {
    setMembers(next);
    if (lastResultMode === 'standard') setReportMembers(next);
    // Existing browser persistence in this app uses localStorage. The leader id in
    // the key keeps selected report members from leaking across Jira accounts.
    localStorage.setItem(storageKey, JSON.stringify(next.map(member => ({
      accountId: member.accountId,
      displayName: member.displayName,
      name: member.name,
      key: member.key,
      instanceId: member.instanceId,
      instanceName: member.instanceName,
    }))));
  };

  useEffect(() => {
    if (!currentResultId || !lastRunAt) return;
    persistLastResultRef(currentResultId, lastRunAt, reportMembers.length ? reportMembers : members, lastResultMode);
  }, [currentResultId, lastRunAt, members, persistLastResultRef, reportMembers, lastResultMode, selectedAuthorId, worklogSortKey, worklogSortDirection]);

  const addMember = (member: TeamReportMember) => {
    if (members.some(existing => existing.accountId === member.accountId)) return;
    persistMembers([...members, member]);
    setMemberQuery('');
    setMemberSuggestions([]);
  };

  const removeMember = (accountId: string) => {
    persistMembers(members.filter(member => member.accountId !== accountId));
  };

  const deleteMappedMember = async (memberId: string) => {
    if (!memberId || !window.confirm(`${memberId} 팀원 매핑을 삭제할까요?`)) return;
    try {
      const res = await fetch(`${API_BASE}/team/members/${encodeURIComponent(memberId)}`, { method: 'DELETE' });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data?.detail || '팀원 매핑을 삭제하지 못했습니다.');
      setMappedMembers(current => current.filter(member => member.id !== memberId));
      setDelegateStatuses(current => current.filter(status => status.memberId !== memberId));
    } catch (error: unknown) {
      setError(error instanceof Error && error.message ? error.message : '팀원 매핑을 삭제하지 못했습니다.');
    }
  };

  const searchUsersForContext = useCallback(async (query: string): Promise<JiraUserSuggestion[]> => {
    if (!query.trim()) return [];
    try {
      const params = new URLSearchParams({ query: query.trim() });
      if (instanceFilter !== 'all') params.set('instance_id', instanceFilter);
      const res = await fetch(`${API_BASE}/users/search?${params.toString()}`);
      const data = await res.json();
      const users = Array.isArray(data) ? data : (data.users || []);
      return users.map(normalizeJiraUserSuggestion).filter(Boolean) as JiraUserSuggestion[];
    } catch {
      return [];
    }
  }, [instanceFilter]);

  useEffect(() => {
    let cancelled = false;
    const timer = window.setTimeout(async () => {
      if (memberQuery.trim().length < 1) {
        setMemberSuggestions([]);
        setMemberSearchLoading(false);
        return;
      }
      setMemberSearchLoading(true);
      const users = await searchUsersForContext(memberQuery);
      if (!cancelled) {
        setMemberSuggestions(users.filter(user => !members.some(member => member.accountId === user.accountId)));
        setMemberSearchLoading(false);
      }
    }, 180);
    return () => {
      cancelled = true;
      window.clearTimeout(timer);
    };
  }, [memberQuery, members, searchUsersForContext]);

  const resolvedPeriod = useMemo(() => {
    if (datePreset === 'custom') return { start: startDate, end: endDate };
    if (datePreset === 'all') return { start: '', end: '' };
    const start = new Date();
    start.setDate(start.getDate() - parseInt(datePreset));
    return { start: start.toISOString().split('T')[0], end: '' };
  }, [datePreset, startDate, endDate]);

  function applyReportData(data: TeamReportResult, sourceMembers: TeamReportMember[], runAt: Date) {
    const resultMembers = data.members || [];
    const totalSeconds = resultMembers.reduce((sum, member) => sum + Number(member.totalSeconds || 0), 0);
    const nextRows = sourceMembers.map(member => {
      const found = resultMembers.find(item => item.accountId === member.accountId);
      const seconds = Number(found?.totalSeconds || 0);
      return {
        ...member,
        totalSeconds: seconds,
        hours: secondsToHours(seconds),
        issueCount: Number(found?.issueCount || 0),
        worklogCount: Number(found?.worklogCount || 0),
        ratio: totalSeconds ? Math.round(seconds / totalSeconds * 1000) / 10 : 0,
      };
    }).sort((a, b) => b.totalSeconds - a.totalSeconds);
    setReportMembers(sourceMembers);
    setRows(nextRows);
    setRawWorklogs(data.worklogs || []);
    setDelegateStatuses(data.delegateStatuses || []);
    setLastRunAt(runAt);
  }

  const sourceMembersFromResult = (data: TeamReportResult): TeamReportMember[] => {
    const resultMembers = Array.isArray(data.members) ? data.members : [];
    return resultMembers.map(member => ({
      accountId: member.accountId,
      displayName: member.displayName || member.name || member.key || member.accountId,
      name: member.name,
      key: member.key,
      instanceId: member.instanceId,
      instanceName: member.instanceName,
    })).filter((member: TeamReportMember) => member.accountId && member.displayName);
  };

  const clearReportScreen = async () => {
    const savedRef = localStorage.getItem(lastResultRefKey);
    localStorage.removeItem(lastResultRefKey);
    setRows([]);
    setReportMembers([]);
    setRawWorklogs([]);
    setLastRunAt(null);
    setCurrentResultId('');
    setSelectedAuthorId('all');
    setWorklogInstanceFilter('all');
    setWorklogComponentFilter('all');
    setCopyMessage('');
    setError('');
    setLoadingStatus(null);
    setDelegateStatuses([]);
    if (savedRef) {
      try {
        const parsed = JSON.parse(savedRef);
        if (parsed?.resultId) {
          await fetch(`${API_BASE}/team/report/results/${parsed.resultId}`, { method: 'DELETE' });
        }
      } catch {
        // Result cache cleanup is best-effort; the server TTL will remove stale data.
      }
    }
  };

  const fetchReport = async () => {
    if (!canFetchReport) return;
    setLoading(true);
    setLoadingStatus({ status: 'queued', stage: 'queued', message: '조회 대기 중', progress: 0 });
    setError('');
    setCopyMessage('');
    setDelegateStatuses([]);
    try {
      const endpoint = delegatedMode && isLeader
        ? `${API_BASE}/team/report/delegated-worklogs/jobs`
        : `${API_BASE}/team/report/worklogs/jobs`;
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json; charset=utf-8' },
        body: JSON.stringify(delegatedMode && isLeader ? {
          start_date: resolvedPeriod.start || null,
          end_date: resolvedPeriod.end || null,
          instance_ids: instanceFilter === 'all' ? null : [Number(instanceFilter)],
        } : {
          accountIds: members.map(member => member.accountId),
          members: members.map(member => ({
            accountId: member.accountId,
            displayName: member.displayName,
            name: member.name,
            key: member.key,
            instanceId: member.instanceId,
            instanceName: member.instanceName,
          })),
          start_date: resolvedPeriod.start || null,
          end_date: resolvedPeriod.end || null,
          instance_ids: instanceFilter === 'all' ? null : [Number(instanceFilter)],
        }),
      });
      const created = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(created?.detail || '팀 보고서 조회를 시작하지 못했습니다.');
      const jobId = created.jobId;
      if (!jobId) throw new Error('팀 보고서 작업 ID를 받지 못했습니다.');

      let completed: TeamReportJobStatus | null = null;
      while (!completed) {
        await new Promise(resolve => window.setTimeout(resolve, 700));
        const jobEndpoint = delegatedMode && isLeader
          ? `${API_BASE}/team/report/delegated-worklogs/jobs/${jobId}`
          : `${API_BASE}/team/report/worklogs/jobs/${jobId}`;
        const jobRes = await fetch(jobEndpoint);
        const job = await jobRes.json().catch(() => ({}));
        if (!jobRes.ok) throw new Error(job?.detail || '팀 보고서 진행 상태를 확인하지 못했습니다.');
        setLoadingStatus(job);
        if (job.delegateStatuses) setDelegateStatuses(job.delegateStatuses);
        if (job.status === 'error') throw new Error(job.message || '팀 보고서 조회에 실패했습니다.');
        if (job.status === 'done') completed = job;
      }

      const data = completed.result;
      if (!data) throw new Error('팀 보고서 결과를 받지 못했습니다.');
      const runAt = new Date();
      const sourceMembers = delegatedMode && isLeader ? sourceMembersFromResult(data) : members;
      const reportMode = delegatedMode && isLeader ? 'delegated' : 'standard';
      setLastResultMode(reportMode);
      applyReportData(data, sourceMembers, runAt);
      setSelectedAuthorId('all');
      setWorklogInstanceFilter('all');
      setWorklogComponentFilter('all');
      if (data.resultId) {
        setCurrentResultId(data.resultId);
        persistLastResultRef(data.resultId, runAt, sourceMembers, reportMode);
      }
    } catch (error: unknown) {
      setRows([]);
      setRawWorklogs([]);
      setError(error instanceof Error && error.message ? error.message : '팀 보고서 데이터를 불러오지 못했습니다.');
    } finally {
      setLoading(false);
      setLoadingStatus(null);
    }
  };
  const periodLabel = () => {
    if (datePreset === 'custom') return `${startDate || '시작일 없음'}~${endDate || '종료일 없음'}`;
    if (datePreset === 'all') return '전체';
    return `최근 ${datePreset}일`;
  };

  const fileSuffix = () => {
    const period = datePreset === 'custom' ? `${startDate || 'all'}_${endDate || 'all'}` : datePreset === 'all' ? 'all' : `${datePreset}d`;
    const account = instanceFilter === 'all' ? 'all-accounts' : `account-${instanceFilter}`;
    const author = selectedAuthor ? `_${selectedAuthor.accountId}` : '';
    const stamp = new Date().toISOString().replace(/[-:T]/g, '').slice(0, 12);
    return `${period}_${account}${author}_${stamp}`;
  };

  const worklogExportHeaders = ['Jira 계정', 'Jira 티켓 번호', '컴포넌트', '요약', '담당자', '보고자', '상태', '생성일', 'worklog 작성자', 'worklog author ID', 'worklog 기록일', '작업시간(시간)', '원본 timeSpentSeconds', 'Jira 링크'];
  const worklogExportRow = (row: RawWorklogRow) => [
    row.instance_name || '-',
    row.issueKey,
    (row.issueComponents || []).join(', ') || '-',
    row.issueSummary,
    row.issueAssignee,
    row.issueReporter,
    row.issueStatus,
    formatDate(row.issueCreated),
    row.authorDisplayName,
    row.authorAccountId,
    formatDate(row.started),
    secondsToHours(row.timeSpentSeconds),
    row.timeSpentSeconds,
    row.issueUrl,
  ];

  const buildTsv = () => [
    worklogExportHeaders.join('\t'),
    ...displayedWorklogs.map(row => worklogExportRow(row).join('\t')),
  ].join('\n');

  const buildCsv = () => [
    worklogExportHeaders.map(csvEscape).join(','),
    ...displayedWorklogs.map(row => worklogExportRow(row).map(csvEscape).join(',')),
  ].join('\r\n');

  const downloadBlob = (blob: Blob, filename: string) => {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  };

  const downloadCsv = () => {
    const csv = `\uFEFF${buildCsv()}`;
    downloadBlob(new Blob([csv], { type: 'text/csv;charset=utf-8;' }), `team-worklog_${fileSuffix()}.csv`);
  };

  const downloadExcel = () => {
    const escapeHtml = (value: string | number) => String(value)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
    const html = `\uFEFF<html><head><meta charset="utf-8" /></head><body><table><thead><tr>${
      worklogExportHeaders.map(header => `<th>${escapeHtml(header)}</th>`).join('')
    }</tr></thead><tbody>${
      displayedWorklogs.map(row => `<tr>${worklogExportRow(row).map(value => `<td>${escapeHtml(value)}</td>`).join('')}</tr>`).join('')
    }</tbody></table></body></html>`;
    downloadBlob(new Blob([html], { type: 'application/vnd.ms-excel;charset=utf-8;' }), `team-worklog_${fileSuffix()}.xls`);
  };

  const copyTable = async () => {
    await navigator.clipboard.writeText(buildTsv());
    setCopyMessage('표가 클립보드에 복사되었습니다.');
  };

  const downloadPng = async () => {
    const table = worklogTableRef.current;
    if (!table) return;
    await document.fonts?.ready;
    const width = Math.ceil(table.scrollWidth || 1200);
    const height = Math.ceil(table.scrollHeight || 600);
    const html = table.outerHTML
      .replace(/<button[^>]*>/g, '')
      .replace(/<\/button>/g, '');
    const source = `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}">
      <foreignObject width="100%" height="100%">
        <div xmlns="http://www.w3.org/1999/xhtml" style="font-family: Arial, 'Malgun Gothic', sans-serif; background: #fff; color: #111; padding: 16px; box-sizing: border-box;">
          ${html}
        </div>
      </foreignObject>
    </svg>`;
    const image = new Image();
    const svgUrl = URL.createObjectURL(new Blob([source], { type: 'image/svg+xml;charset=utf-8' }));
    image.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = width * 2;
      canvas.height = height * 2;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.scale(2, 2);
      ctx.drawImage(image, 0, 0);
      URL.revokeObjectURL(svgUrl);
      canvas.toBlob(blob => {
        if (blob) downloadBlob(blob, `team-worklog_${fileSuffix()}.png`);
      }, 'image/png');
    };
    image.src = svgUrl;
  };

  const formatDate = (value?: string) => {
    if (!value) return '-';
    const date = new Date(value);
    return Number.isNaN(date.getTime()) ? value : date.toLocaleString();
  };

  const worklogInstanceOptions = useMemo(() => Array.from(new Set(
    rawWorklogs.map(row => row.instance_name || '미분류')
  )).sort((a, b) => a.localeCompare(b, 'ko')), [rawWorklogs]);

  const worklogsForComponentFilter = useMemo(
    () => worklogInstanceFilter === 'all'
      ? rawWorklogs
      : rawWorklogs.filter(row => (row.instance_name || '미분류') === worklogInstanceFilter),
    [rawWorklogs, worklogInstanceFilter],
  );

  const worklogComponentOptions = useMemo(() => Array.from(new Set(
    worklogsForComponentFilter.flatMap(row => row.issueComponents || []).filter(component => component.trim())
  )).sort((a, b) => a.localeCompare(b, 'ko')), [worklogsForComponentFilter]);

  const hasWorklogsWithoutComponents = useMemo(
    () => worklogsForComponentFilter.some(row => !row.issueComponents?.length),
    [worklogsForComponentFilter],
  );

  const displayedWorklogs = useMemo(() => {
    const selected = normalizeIdentifier(selectedAuthorId);
    const authorFiltered = selectedAuthorId === 'all'
      ? rawWorklogs
      : rawWorklogs.filter(row => [row.accountId, row.authorAccountId].map(normalizeIdentifier).some(authorId => authorId === selected));
    const filtered = authorFiltered.filter(row => {
      if (worklogInstanceFilter !== 'all' && (row.instance_name || '미분류') !== worklogInstanceFilter) return false;
      if (worklogComponentFilter === 'all') return true;
      if (worklogComponentFilter === NO_COMPONENT_FILTER) return !row.issueComponents?.length;
      return (row.issueComponents || []).includes(worklogComponentFilter);
    });
    const direction = worklogSortDirection === 'asc' ? 1 : -1;
    return [...filtered].sort((a, b) => {
      if (worklogSortKey === 'seconds') return (a.timeSpentSeconds - b.timeSpentSeconds) * direction;
      if (worklogSortKey === 'started') return ((new Date(a.started).getTime() || 0) - (new Date(b.started).getTime() || 0)) * direction;
      return a.issueKey.localeCompare(b.issueKey) * direction;
    });
  }, [rawWorklogs, selectedAuthorId, worklogInstanceFilter, worklogComponentFilter, worklogSortKey, worklogSortDirection]);

  const displayedTotalSeconds = displayedWorklogs.reduce((sum, row) => sum + row.timeSpentSeconds, 0);
  const suspiciousThresholdSeconds = 16 * 3600;

  const toggleAuthorFilter = (row: ReportRow) => {
    setSelectedAuthorId(current => {
      const nextId = current === row.accountId ? 'all' : row.accountId;
      return nextId;
    });
  };

  return (
    <div className="glass-container" style={{ maxWidth: '1800px' }}>
      <div style={{ display: 'flex', justifyContent: 'flex-end', alignItems: 'center', marginBottom: 24, gap: 16, flexWrap: 'wrap' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
          <button className="btn-glass" onClick={clearReportScreen} disabled={loading || !lastRunAt} style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <RotateCcw size={16} /> 화면 초기화
          </button>
          <button className="btn-glass" onClick={() => setSettingsOpen(value => !value)} style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <Settings size={16} /> 팀원 설정
          </button>
        </div>
      </div>

      {(settingsOpen || members.length === 0) && (
        <div className="glass-panel" style={{ marginBottom: 20, padding: 20, position: 'relative', zIndex: 20, overflow: 'visible' }}>
          {isLeader && (
            <div style={{ marginBottom: 18, padding: 14, border: '1px solid rgba(127, 140, 141, 0.22)', borderRadius: 8 }}>
              <label style={{ display: 'flex', alignItems: 'center', gap: 10, fontWeight: 800, color: 'var(--text-primary)' }}>
                <input
                  type="checkbox"
                  checked={delegatedMode}
                  onChange={e => setDelegatedMode(e.target.checked)}
                />
                팀원 각자 권한으로 조회
              </label>
              {delegatedMode && (
                <div style={{ marginTop: 10, color: 'var(--text-secondary)', fontSize: 13 }}>
                  매핑된 팀원과 내 Jira 계정으로 조회합니다. 연결됨 {connectedMappedMemberCount}명 / 전체 {mappedMembers.length}명
                </div>
              )}
            </div>
          )}
          <div style={{ display: 'grid', gridTemplateColumns: 'minmax(280px, 1fr) minmax(280px, 1fr)', gap: 18 }}>
            <div>
              <div className="apple-meta-label" style={{ marginBottom: 8 }}>팀원 검색</div>
              <div className="create-assignee-search" style={{ zIndex: 30 }}>
                <input
                  className="glass-input"
                  value={memberQuery}
                  onChange={e => setMemberQuery(e.target.value)}
                  placeholder="이름으로 검색"
                  disabled={delegatedMode && isLeader}
                />
                {memberQuery.trim() && !(delegatedMode && isLeader) && (
                  <div className="create-assignee-suggestions" style={{ zIndex: 40 }}>
                    {memberSearchLoading ? (
                      <div className="create-assignee-suggestion muted">검색 중...</div>
                    ) : memberSuggestions.length ? (
                      memberSuggestions.map(user => (
                        <button
                          type="button"
                          key={user.accountId}
                          className="create-assignee-suggestion"
                          onClick={() => {
                            if (!user.accountId) return;
                            addMember({ accountId: user.accountId, displayName: user.display, name: user.name, key: user.key, instanceId: user.instanceId, instanceName: user.instanceName });
                          }}
                        >
                          {user.display}{user.instanceName ? ` · ${user.instanceName}` : ''}
                        </button>
                      ))
                    ) : (
                      <div className="create-assignee-suggestion muted">검색 결과가 없습니다.</div>
                    )}
                  </div>
                )}
              </div>
            </div>
            <div>
              <div className="apple-meta-label" style={{ marginBottom: 8 }}>선택된 팀원</div>
              <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                {delegatedMode && isLeader ? (
                  mappedMembers.length === 0 ? (
                    <span style={{ color: 'var(--text-secondary)', fontSize: 13 }}>매핑된 팀원이 없습니다.</span>
                  ) : mappedMembers.map(member => (
                    <span key={member.id} className="btn-glass" style={{ padding: '7px 10px', fontSize: 13, opacity: (member.effective_member_url || member.member_url || member.is_local_leader) ? 1 : 0.6, display: 'inline-flex', alignItems: 'center', gap: 6 }}>
                      {member.name}{member.is_local_leader ? ' (내 PC)' : (member.member_url ? '' : ' (미연결)')}
                      {!member.is_local_leader && (
                        <button
                          type="button"
                          onClick={event => {
                            event.stopPropagation();
                            deleteMappedMember(member.id);
                          }}
                          title="팀원 매핑 삭제"
                          style={{ border: 0, background: 'transparent', color: 'inherit', cursor: 'pointer', fontWeight: 900, padding: '0 2px', lineHeight: 1 }}
                        >
                          ×
                        </button>
                      )}
                    </span>
                  ))
                ) : members.length === 0 ? (
                  <span style={{ color: 'var(--text-secondary)', fontSize: 13 }}>저장된 팀원이 없습니다.</span>
                ) : members.map(member => (
                  <button key={member.accountId} className="btn-glass" onClick={() => removeMember(member.accountId)} style={{ padding: '7px 10px', fontSize: 13 }}>
                    {member.displayName}{member.instanceName ? ` · ${member.instanceName}` : ''} ×
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="glass-panel" style={{ marginBottom: 20, padding: 16 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, flexWrap: 'wrap' }}>
          <Search size={16} color="var(--text-secondary)" />
          <span style={{ fontSize: 13, fontWeight: 700, color: 'var(--text-secondary)' }}>계정</span>
          <select
            className="glass-input"
            style={{ width: 'auto', padding: '6px 12px' }}
            value={instanceFilter}
            onChange={e => {
              setInstanceFilter(e.target.value);
              localStorage.setItem('teamReportInstanceFilter', e.target.value);
            }}
          >
            <option value="all">모든 계정</option>
            {instanceList.map(inst => <option key={inst.id} value={inst.id}>{formatJiraInstanceName(inst.name, inst.deployment_type)}</option>)}
          </select>
          <span style={{ fontSize: 13, fontWeight: 700, color: 'var(--text-secondary)' }}>기간</span>
          <select className="glass-input" style={{ width: 'auto', padding: '6px 12px' }} value={datePreset} onChange={e => { setDatePreset(e.target.value); localStorage.setItem('teamReportDatePreset', e.target.value); }}>
            <option value="1">1일</option>
            <option value="7">7일</option>
            <option value="14">14일</option>
            <option value="30">30일</option>
            <option value="90">90일</option>
            <option value="all">전체</option>
            <option value="custom">직접입력</option>
          </select>
          {datePreset === 'custom' && (
            <div style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
              <input type="date" className="glass-input" style={{ padding: '6px', fontSize: 12, width: 'auto' }} value={startDate} onChange={e => handleStartDateChange(e.target.value)} />
              <span style={{ color: '#ccc' }}>~</span>
              <input type="date" className="glass-input" style={{ padding: '6px', fontSize: 12, width: 'auto' }} value={endDate} onChange={e => handleEndDateChange(e.target.value)} />
            </div>
          )}
          <button className="btn-premium" onClick={fetchReport} disabled={!canFetchReport} style={{ marginLeft: 'auto', padding: '8px 16px' }}>
            {loading ? '조회 중...' : '조회'}
          </button>
        </div>
      </div>

      {error && <div className="create-issue-error" style={{ marginBottom: 20, color: '#d63031', fontWeight: 700 }}>{error}</div>}
      {delegatedMode && isLeader && delegateStatuses.some(status => status.status !== 'success') && (
        <div className="glass-panel" style={{ marginBottom: 20, padding: 14, borderColor: 'rgba(214, 48, 49, 0.28)' }}>
          <div style={{ fontWeight: 800, color: 'var(--text-primary)', marginBottom: 8 }}>일부 팀원 조회 상태</div>
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
            {delegateStatuses.filter(status => status.status !== 'success').map(status => (
              <span key={`${status.memberId}-${status.status}`} style={{ fontSize: 12, color: '#d63031', fontWeight: 700 }}>
                {(status.displayName || status.memberId)}: {status.status}{status.message ? ` (${status.message})` : ''}
              </span>
            ))}
          </div>
        </div>
      )}
      {loading && (
        <div className="glass-panel" style={{ textAlign: 'center', marginTop: 40, padding: '48px 20px', color: 'var(--text-secondary)' }}>
          <div style={{ margin: '0 auto 16px auto', width: 38, height: 38, border: '4px solid rgba(0,0,0,0.1)', borderTopColor: 'var(--accent-color)', borderRadius: '50%', animation: 'spin 1s linear infinite' }} />
          <div style={{ fontWeight: 800, color: 'var(--text-primary)', marginBottom: 8 }}>
            {loadingStatus?.message || '보고서 데이터를 불러오는 중입니다'}
          </div>
          <div style={{ fontSize: 13 }}>
            {typeof loadingStatus?.progress === 'number' ? `${Math.min(100, Math.max(0, loadingStatus.progress))}%` : '진행 상태 확인 중'}
            {typeof loadingStatus?.scannedIssues === 'number' && ` · 이슈 ${loadingStatus.scannedIssues.toLocaleString()}건 확인`}
            {typeof loadingStatus?.scannedWorklogs === 'number' && ` · worklog ${loadingStatus.scannedWorklogs.toLocaleString()}건 확인`}
          </div>
          {typeof loadingStatus?.processedIssues === 'number' && typeof loadingStatus?.totalCandidateIssues === 'number' && loadingStatus.totalCandidateIssues > 0 && (
            <div style={{ fontSize: 12, marginTop: 6, color: 'var(--text-secondary)' }}>
              전체 후보 {loadingStatus.totalCandidateIssues.toLocaleString()}건 중 {Math.min(loadingStatus.processedIssues, loadingStatus.totalCandidateIssues).toLocaleString()}건 처리
            </div>
          )}
          {loadingStatus?.currentInstance && (
            <div style={{ fontSize: 12, marginTop: 6, color: 'var(--text-secondary)' }}>현재 계정: {loadingStatus.currentInstance}</div>
          )}
          <div style={{ maxWidth: 520, margin: '18px auto 0' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, fontWeight: 700, marginBottom: 8, color: 'var(--accent-color)' }}>
              <span>전체 진행률</span>
              <span>{typeof loadingStatus?.progress === 'number' ? `${Math.min(100, Math.max(0, loadingStatus.progress))}%` : '0%'}</span>
            </div>
            <div style={{ width: '100%', height: '8px', background: 'rgba(0,0,0,0.05)', borderRadius: '4px', overflow: 'hidden' }}>
              <div
                style={{
                  width: `${typeof loadingStatus?.progress === 'number' ? Math.min(100, Math.max(0, loadingStatus.progress)) : 0}%`,
                  height: '100%',
                  background: 'linear-gradient(90deg, #0984e3, #00cec9)',
                  transition: 'width 0.3s ease',
                }}
              />
            </div>
          </div>
        </div>
      )}

      {!loading && !lastRunAt && (
        <div className="glass-panel" style={{ textAlign: 'center', padding: '60px 20px', color: 'var(--text-secondary)' }}>팀원과 기간을 설정한 뒤 조회 버튼을 눌러주세요.</div>
      )}

      {!loading && lastRunAt && !hasResult && (
        <div className="glass-panel" style={{ textAlign: 'center', padding: '60px 20px', color: 'var(--text-secondary)' }}>선택한 기간에 집계할 worklog가 없습니다.</div>
      )}

      {!loading && hasResult && (
        <>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12, gap: 12, flexWrap: 'wrap' }}>
            <div style={{ color: 'var(--text-secondary)', fontSize: 13 }}>
              조회조건: {periodLabel()} · 팀원 {members.length}명 · 추출일시 {lastRunAt?.toLocaleString()}
            </div>
            <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
              <button className="btn-glass" onClick={downloadPng} disabled={displayedWorklogs.length === 0} style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '8px 12px' }}><Download size={14} /> PNG</button>
              <button className="btn-glass" onClick={downloadCsv} disabled={displayedWorklogs.length === 0} style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '8px 12px' }}><FileText size={14} /> CSV</button>
              <button className="btn-glass" onClick={downloadExcel} disabled={displayedWorklogs.length === 0} style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '8px 12px' }}><FileText size={14} /> Excel</button>
              <button className="btn-glass" onClick={copyTable} disabled={displayedWorklogs.length === 0} style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '8px 12px' }}><ClipboardCopy size={14} /> 표 복사</button>
            </div>
          </div>
          {copyMessage && <div style={{ color: '#078f55', fontSize: 13, fontWeight: 700, marginBottom: 12 }}>{copyMessage}</div>}

          <div className="glass-panel" style={{ marginBottom: 20 }} ref={chartRef}>
            <h3 style={{ marginTop: 0, marginBottom: 18 }}>팀원별 작업시간</h3>
            <ResponsiveContainer width="100%" height={Math.max(280, rows.length * 46)}>
              <BarChart data={rows} layout="vertical" margin={{ top: 10, right: 30, left: 20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="rgba(0,0,0,0.05)" />
                <XAxis type="number" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: 'var(--text-primary)' }} unit="h" />
                <YAxis type="category" dataKey="displayName" width={120} axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: 'var(--text-primary)' }} />
                <Tooltip content={<ReportTooltip />} cursor={{ fill: 'rgba(0,0,0,0.02)' }} />
                <Bar dataKey="hours" radius={[0, 6, 6, 0]} maxBarSize={32}>
                  {rows.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>

          <div className="glass-panel" style={{ padding: 0, overflow: 'hidden', marginBottom: 20 }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
              <thead>
                <tr style={{ background: 'rgba(0,0,0,0.04)', color: 'var(--text-primary)' }}>
                  {['팀원명', '총 작업시간(시간)', '이슈 수', '비율', '원본 seconds'].map(header => (
                    <th key={header} style={{ padding: '12px 14px', textAlign: 'left' }}>{header}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {rows.map(row => (
                  <tr
                    key={row.accountId}
                    onClick={() => toggleAuthorFilter(row)}
                    style={{
                      borderTop: '1px solid rgba(127, 140, 141, 0.18)',
                      cursor: 'pointer',
                      background: selectedAuthorId === row.accountId ? 'rgba(9, 132, 227, 0.12)' : 'transparent',
                    }}
                    title="클릭하면 이 팀원의 worklog만 표시합니다."
                  >
                    <td style={{ padding: '12px 14px', fontWeight: 700, color: 'var(--text-primary)' }}>{row.displayName}</td>
                    <td style={{ padding: '12px 14px' }}>{row.hours}</td>
                    <td style={{ padding: '12px 14px' }}>{row.issueCount}</td>
                    <td style={{ padding: '12px 14px' }}>{row.ratio}%</td>
                    <td style={{ padding: '12px 14px', color: 'var(--text-secondary)' }}>{row.totalSeconds}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="glass-panel" style={{ padding: 0, overflow: 'hidden' }}>
            <div style={{ padding: 16, display: 'flex', alignItems: 'center', gap: 10, flexWrap: 'wrap', borderBottom: '1px solid rgba(127, 140, 141, 0.18)' }}>
              <strong style={{ color: 'var(--text-primary)' }}>worklog 원천 데이터</strong>
              <span style={{ color: 'var(--text-secondary)', fontSize: 13 }}>
                현재: {selectedAuthor ? selectedAuthor.displayName : '전체'} · {displayedWorklogs.length}건 · {secondsToHours(displayedTotalSeconds)}시간
              </span>
              {selectedAuthor && (
                <button className="btn-glass" onClick={() => setSelectedAuthorId('all')} style={{ padding: '6px 10px', fontSize: 12 }}>전체 보기</button>
              )}
              <div style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', justifyContent: 'flex-end', gap: 10, flexWrap: 'wrap', minWidth: 0 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 10, flexWrap: 'nowrap', minWidth: 0 }}>
                  <span style={{ color: 'var(--text-secondary)', fontSize: 13, whiteSpace: 'nowrap' }}>필터</span>
                  <select
                    className="glass-input"
                    style={{ width: 'auto', maxWidth: 220, padding: '6px 12px' }}
                    value={worklogInstanceFilter}
                    onChange={e => {
                      setWorklogInstanceFilter(e.target.value);
                      setWorklogComponentFilter('all');
                    }}
                  >
                    <option value="all">계정 전체</option>
                    {worklogInstanceOptions.map(instanceName => <option key={instanceName} value={instanceName}>{instanceName}</option>)}
                  </select>
                  <select className="glass-input" style={{ width: 'auto', maxWidth: 'min(360px, 28vw)', padding: '6px 12px' }} value={worklogComponentFilter} onChange={e => setWorklogComponentFilter(e.target.value)}>
                    <option value="all">컴포넌트 전체</option>
                    {worklogComponentOptions.map(component => <option key={component} value={component}>{component}</option>)}
                    {hasWorklogsWithoutComponents && <option value={NO_COMPONENT_FILTER}>컴포넌트 없음</option>}
                  </select>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 10, flexWrap: 'nowrap' }}>
                  <span style={{ color: 'var(--text-secondary)', fontSize: 13, whiteSpace: 'nowrap' }}>정렬</span>
                  <select className="glass-input" style={{ width: 'auto', padding: '6px 12px' }} value={worklogSortKey} onChange={e => setWorklogSortKey(e.target.value as WorklogSortKey)}>
                    <option value="seconds">작업시간</option>
                    <option value="started">worklog 기록일</option>
                    <option value="issueKey">티켓 번호</option>
                  </select>
                  <select className="glass-input" style={{ width: 'auto', padding: '6px 12px' }} value={worklogSortDirection} onChange={e => setWorklogSortDirection(e.target.value as SortDirection)}>
                    <option value="desc">내림차순</option>
                    <option value="asc">오름차순</option>
                  </select>
                </div>
              </div>
            </div>
            <div ref={worklogTableRef} style={{ overflowX: 'auto', background: 'var(--card-bg)' }}>
              <table style={{ width: '100%', minWidth: 1650, borderCollapse: 'collapse', fontSize: 12 }}>
                <thead>
                  <tr style={{ background: 'rgba(0,0,0,0.04)', color: 'var(--text-primary)' }}>
                    {['계정', '티켓', '컴포넌트', '요약', '담당자', '보고자', '상태', '생성일', 'worklog 작성자', 'worklog 기록일', '작업시간', '원본 seconds'].map(header => (
                      <th key={header} style={{ padding: '10px 12px', textAlign: 'left', whiteSpace: 'nowrap' }}>{header}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {displayedWorklogs.map((worklog, idx) => {
                    const suspicious = worklog.timeSpentSeconds > suspiciousThresholdSeconds;
                    return (
                      <tr
                        key={`${worklog.instance_name}-${worklog.issueKey}-${worklog.worklogId || 'no-worklog-id'}-${worklog.accountId}-${worklog.started || 'no-started'}-${idx}`}
                        style={{
                          borderTop: '1px solid rgba(127, 140, 141, 0.18)',
                          background: suspicious ? 'rgba(214, 48, 49, 0.11)' : 'transparent',
                          color: 'var(--text-primary)',
                        }}
                      >
                        <td style={{ padding: '10px 12px', whiteSpace: 'nowrap' }}>{worklog.instance_name || '-'}</td>
                        <td style={{ padding: '10px 12px', whiteSpace: 'nowrap', fontWeight: 700 }}>
                          <a href={worklog.issueUrl} target="_blank" rel="noreferrer" style={{ color: 'var(--accent-color)' }}>{worklog.issueKey}</a>
                        </td>
                        <td style={{ padding: '10px 12px', minWidth: 160 }}>{(worklog.issueComponents || []).join(', ') || '-'}</td>
                        <td style={{ padding: '10px 12px', minWidth: 240 }}>{worklog.issueSummary}</td>
                        <td style={{ padding: '10px 12px', whiteSpace: 'nowrap' }}>{worklog.issueAssignee || '-'}</td>
                        <td style={{ padding: '10px 12px', whiteSpace: 'nowrap' }}>{worklog.issueReporter || '-'}</td>
                        <td style={{ padding: '10px 12px', whiteSpace: 'nowrap' }}>{worklog.issueStatus || '-'}</td>
                        <td style={{ padding: '10px 12px', whiteSpace: 'nowrap' }}>{formatDate(worklog.issueCreated)}</td>
                        <td style={{ padding: '10px 12px', whiteSpace: 'nowrap' }}>{worklog.authorDisplayName} <span style={{ color: 'var(--text-secondary)' }}>({worklog.authorAccountId})</span></td>
                        <td style={{ padding: '10px 12px', whiteSpace: 'nowrap' }}>{formatDate(worklog.started)}</td>
                        <td style={{ padding: '10px 12px', whiteSpace: 'nowrap', fontWeight: suspicious ? 800 : 600, color: suspicious ? '#d63031' : 'var(--text-primary)' }}>
                          {suspicious ? '⚠ ' : ''}{secondsToHours(worklog.timeSpentSeconds)}시간
                        </td>
                        <td style={{ padding: '10px 12px', whiteSpace: 'nowrap', color: 'var(--text-secondary)' }}>{worklog.timeSpentSeconds}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}
    </div>
  );
}

