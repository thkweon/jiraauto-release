import { describe, expect, it } from 'vitest';
import {
  calculateFloatingWidgetStackTops,
  calculateFloatingWidgetLayout,
  FLOATING_WIDGET_SAFE_AREAS,
  parseFloatingWidgetPlacement,
} from './floatingWidgetLayout';

describe('floating widget layout', () => {
  it('preserves the 1920x1080 reference scale', () => {
    const calendar = calculateFloatingWidgetLayout({
      viewportWidth: 1920,
      viewportHeight: 1080,
      kind: 'calendar',
      placement: 'left-top',
    });
    const calculator = calculateFloatingWidgetLayout({
      viewportWidth: 1920,
      viewportHeight: 1080,
      kind: 'it-calculator',
      placement: 'right-middle-bottom',
      variant: 'double',
    });

    expect(calendar.visible).toBe(true);
    expect(calendar.scale).toBe(1);
    expect(calendar.width).toBe(286);
    expect(calculator.visible).toBe(true);
    expect(calculator.scale).toBe(1);
    expect(calculator.height).toBe(560);
  });

  it('keeps left and right safe areas asymmetric', () => {
    expect(FLOATING_WIDGET_SAFE_AREAS.left.singleTop).toBe(8);
    expect(FLOATING_WIDGET_SAFE_AREAS.right.singleTop).toBe(40);
    expect(FLOATING_WIDGET_SAFE_AREAS.left.singleBottom).toBe(24);
    expect(FLOATING_WIDGET_SAFE_AREAS.right.singleBottom).toBe(90);
    expect(FLOATING_WIDGET_SAFE_AREAS.right.doubleBottom).toBe(102);
  });

  it('parses one-slot and two-slot placements', () => {
    expect(parseFloatingWidgetPlacement('left-middle')).toEqual({ side: 'left', block: 'middle' });
    expect(parseFloatingWidgetPlacement('right-top-middle')).toEqual({ side: 'right', block: 'top-middle' });
  });

  it('hides wide widgets before they cover the dashboard hard minimum', () => {
    const calendar = calculateFloatingWidgetLayout({
      viewportWidth: 1536,
      viewportHeight: 864,
      kind: 'calendar',
      placement: 'left-top',
    });
    const quickLink = calculateFloatingWidgetLayout({
      viewportWidth: 1200,
      viewportHeight: 768,
      kind: 'quick-link',
      placement: 'right-middle',
    });

    expect(calendar.visible).toBe(false);
    expect(calendar.hiddenReason).toBe('horizontal-space');
    expect(quickLink.visible).toBe(false);
    expect(quickLink.hiddenReason).toBe('horizontal-space');
  });

  it('caps growth on large viewports', () => {
    const calendar = calculateFloatingWidgetLayout({
      viewportWidth: 3840,
      viewportHeight: 2160,
      kind: 'calendar',
      placement: 'left-bottom',
    });

    expect(calendar.scale).toBe(1.3);
  });

  it('keeps reference sizing when browser chrome reduces usable height', () => {
    const notepad = calculateFloatingWidgetLayout({
      viewportWidth: 1920,
      viewportHeight: 900,
      kind: 'notepad',
      placement: 'left-middle',
      variant: 'single',
    });

    expect(notepad.visible).toBe(true);
    expect(notepad.scale).toBe(1);
    expect(notepad.width).toBe(360);
  });

  it('hides packed widgets when their logical slots can no longer fit', () => {
    const notepad = calculateFloatingWidgetLayout({
      viewportWidth: 1920,
      viewportHeight: 900,
      kind: 'notepad',
      placement: 'right-bottom',
      variant: 'single',
      constrainToSlots: true,
    });

    expect(notepad.visible).toBe(false);
    expect(notepad.hiddenReason).toBe('vertical-space');
  });

  it('hides a standalone notepad when the side rail is too narrow', () => {
    const notepad = calculateFloatingWidgetLayout({
      viewportWidth: 1600,
      viewportHeight: 1080,
      kind: 'notepad',
      placement: 'left-middle',
      variant: 'single',
    });

    expect(notepad.visible).toBe(false);
    expect(notepad.hiddenReason).toBe('horizontal-space');
  });

  it('keeps the narrow quick-link rail longer than the notepad', () => {
    const compactQuickLink = calculateFloatingWidgetLayout({
      viewportWidth: 1700,
      viewportHeight: 900,
      kind: 'quick-link',
      placement: 'left-middle',
    });
    const compactNotepad = calculateFloatingWidgetLayout({
      viewportWidth: 1700,
      viewportHeight: 900,
      kind: 'notepad',
      placement: 'left-middle',
      variant: 'single',
    });
    const tabletQuickLink = calculateFloatingWidgetLayout({
      viewportWidth: 1200,
      viewportHeight: 900,
      kind: 'quick-link',
      placement: 'left-middle',
    });
    const restoredQuickLink = calculateFloatingWidgetLayout({
      viewportWidth: 1920,
      viewportHeight: 900,
      kind: 'quick-link',
      placement: 'left-middle',
    });
    const restoredNotepad = calculateFloatingWidgetLayout({
      viewportWidth: 1920,
      viewportHeight: 900,
      kind: 'notepad',
      placement: 'left-middle',
      variant: 'single',
    });

    expect(compactQuickLink.visible).toBe(true);
    expect(compactNotepad.visible).toBe(false);
    expect(tabletQuickLink.visible).toBe(false);
    expect(restoredQuickLink.visible).toBe(true);
    expect(restoredNotepad.visible).toBe(true);
  });

  it('hides the expanded world-time clock before the compact local clock', () => {
    const localClock = calculateFloatingWidgetLayout({
      viewportWidth: 1700,
      viewportHeight: 900,
      kind: 'clock',
      placement: 'left-top',
    });
    const worldTimeClock = calculateFloatingWidgetLayout({
      viewportWidth: 1700,
      viewportHeight: 900,
      kind: 'clock',
      placement: 'left-top',
      variant: 'world-time',
    });
    const restoredWorldTimeClock = calculateFloatingWidgetLayout({
      viewportWidth: 1920,
      viewportHeight: 900,
      kind: 'clock',
      placement: 'left-top',
      variant: 'world-time',
    });

    expect(localClock.visible).toBe(true);
    expect(worldTimeClock.visible).toBe(false);
    expect(restoredWorldTimeClock.visible).toBe(true);
  });

  it('distributes three rendered widgets with equal gaps inside each side safe area', () => {
    const widgetHeights = [
      { kind: 'clock' as const, block: 'top' as const, height: 104 },
      { kind: 'calendar' as const, block: 'middle' as const, height: 288 },
      { kind: 'notepad' as const, block: 'bottom' as const, height: 288 },
    ];
    const left = calculateFloatingWidgetStackTops(1080, widgetHeights.map(widget => ({
      ...widget,
      side: 'left' as const,
    })));
    const right = calculateFloatingWidgetStackTops(1080, widgetHeights.map(widget => ({
      ...widget,
      side: 'right' as const,
    })));

    expect(left).toEqual({ clock: 8, calendar: 296, notepad: 768 });
    expect(right).toEqual({ clock: 40, calendar: 279, notepad: 702 });
    expect(1080 - (right.notepad! + 288)).toBe(90);
  });

  it('preserves double-widget start and end safe areas while equalizing the gap', () => {
    const left = calculateFloatingWidgetStackTops(1080, [
      { kind: 'it-calculator', side: 'left', block: 'top-middle', height: 560 },
      { kind: 'notepad', side: 'left', block: 'bottom', height: 288 },
    ]);
    const right = calculateFloatingWidgetStackTops(1080, [
      { kind: 'calendar', side: 'right', block: 'top', height: 288 },
      { kind: 'notepad', side: 'right', block: 'middle-bottom', height: 560 },
    ]);

    expect(left).toEqual({ 'it-calculator': 8, notepad: 768 });
    expect(right).toEqual({ calendar: 40, notepad: 418 });
    expect(1080 - (right.notepad! + 560)).toBe(102);
  });
});
