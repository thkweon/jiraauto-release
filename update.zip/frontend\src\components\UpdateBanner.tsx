import React, { useState, useEffect } from 'react';

const API_BASE = 'http://localhost:8000/api';
const REMOTE_VERSION_URL = 'https://raw.githubusercontent.com/thkweon/jiraauto-release/main/version.json';
const CHECK_INTERVAL_MS = 6 * 60 * 60 * 1000; // 6시간

// 간단한 버전 비교 함수 (v1 > v2 이면 1, 같으면 0, 작으면 -1)
const compareVersions = (v1: string, v2: string) => {
  const parts1 = v1.split('.').map(Number);
  const parts2 = v2.split('.').map(Number);
  for (let i = 0; i < Math.max(parts1.length, parts2.length); i++) {
    const p1 = parts1[i] || 0;
    const p2 = parts2[i] || 0;
    if (p1 > p2) return 1;
    if (p1 < p2) return -1;
  }
  return 0;
};

export default function UpdateBanner() {
  const [hasUpdate, setHasUpdate] = useState(false);
  const [remoteVersion, setRemoteVersion] = useState('');
  const [isUpdating, setIsUpdating] = useState(false);

  useEffect(() => {
    let cancelled = false;

    const checkForUpdates = async () => {
      try {
        // 1. 로컬 버전 확인
        const localRes = await fetch(`${API_BASE}/local-version`);
        const localData = await localRes.json();
        const localVersion = localData.version || '0.0.0';

        // 2. 원격 버전 확인
        const remoteRes = await fetch(REMOTE_VERSION_URL, { cache: 'no-store' });
        const remoteData = await remoteRes.json();
        const latestVersion = remoteData.version;

        if (!cancelled && latestVersion && compareVersions(latestVersion, localVersion) > 0) {
          setHasUpdate(true);
          setRemoteVersion(latestVersion);
        }
      } catch (err) {
        console.error('Failed to check for updates', err);
      }
    };

    checkForUpdates();
    const interval = setInterval(checkForUpdates, CHECK_INTERVAL_MS);
    return () => {
      cancelled = true;
      clearInterval(interval);
    };
  }, []);

  const handleUpdate = async () => {
    setIsUpdating(true);
    try {
      await fetch(`${API_BASE}/trigger-update`, { method: 'POST' });
      // 업데이트 백그라운드 스크립트가 실행되고 파이썬 서버가 죽을 시간을 줍니다.
      // 이후 페이지 리로드를 유도하거나 연결 끊김 UI가 나올 수 있습니다.
      setTimeout(() => {
        alert('업데이트 패치를 위해 서버가 재시작됩니다. 잠시 후 창이 닫히거나 새로고침 될 수 있습니다.');
      }, 1000);
    } catch (err) {
      console.error('Update trigger failed', err);
      setIsUpdating(false);
      alert('업데이트 실행에 실패했습니다.');
    }
  };

  if (!hasUpdate) return null;

  return (
    <div style={{
      background: 'linear-gradient(90deg, #1d4ed8, #4f46e5)',
      color: 'white',
      padding: '10px 20px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: '15px',
      fontSize: '14px',
      fontWeight: 500,
      zIndex: 9999,
      position: 'relative'
    }}>
      <span>🚀 새로운 업데이트(v{remoteVersion})가 출시되었습니다!</span>
      <button 
        onClick={handleUpdate}
        disabled={isUpdating}
        style={{
          background: 'rgba(255,255,255,0.2)',
          border: '1px solid rgba(255,255,255,0.4)',
          borderRadius: '4px',
          padding: '4px 12px',
          color: 'white',
          cursor: isUpdating ? 'wait' : 'pointer',
          fontWeight: 600,
          transition: 'all 0.2s ease'
        }}
        onMouseOver={(e) => e.currentTarget.style.background = 'rgba(255,255,255,0.3)'}
        onMouseOut={(e) => e.currentTarget.style.background = 'rgba(255,255,255,0.2)'}
      >
        {isUpdating ? '업데이트 준비 중...' : '지금 업데이트'}
      </button>
    </div>
  );
}
