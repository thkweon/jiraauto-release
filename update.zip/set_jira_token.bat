@echo off
setlocal enabledelayedexpansion
title Jira Multi-Account Manager

:: --- Legacy Migration Start ---
:: 단일 계정용 레거시 변수가 있으면 자동으로 빈 슬롯에 마이그레이션
if defined JIRA_BASE_URL (
    if defined JIRA_TOKEN (
        echo [System] Legacy connection found. Migrating to slot...
        set "target_slot="
        for /L %%i in (1,1,10) do (
            if not defined JIRA_BASE_URL_%%i (
                if not defined target_slot (
                    set "target_slot=%%i"
                )
            )
        )
        
        if defined target_slot (
            setx JIRA_BASE_URL_!target_slot! "%JIRA_BASE_URL%" >nul
            setx JIRA_TOKEN_!target_slot! "%JIRA_TOKEN%" >nul
            :: 레거시 변수 삭제 (빈 값으로 덮어씌움)
            setx JIRA_BASE_URL "" >nul
            setx JIRA_TOKEN "" >nul
            echo [Success] Migrated legacy account to Slot !target_slot!.
            echo Please RESTART this script to see changes.
            pause
            exit /b
        )
    )
)
:: --- Legacy Migration End ---

:MENU
cls
echo ==========================================
echo      Jira Multi-Account Manager
echo ==========================================
echo.
echo [Current Accounts]
set count=0
for /L %%i in (1,1,10) do (
    set "var_name=JIRA_BASE_URL_%%i"
    if defined !var_name! (
        set /a count+=1
        echo  %%i. !var_name! = !!var_name!!
    )
)

if %count% equ 0 (
    echo  (No accounts registered)
)
echo.
echo ==========================================
echo  1. Add/Update Account
echo  2. Remove Account
echo  3. Time Tracking Automation Settings
echo  4. Exit
echo ==========================================
set /p choice="Select option (1-4): "

if "%choice%"=="1" goto ADD
if "%choice%"=="2" goto REMOVE
if "%choice%"=="3" goto SET_TRACKING
if "%choice%"=="4" exit /b
goto MENU

:SET_TRACKING
echo.
echo [Time Tracking Automation Settings]
echo.
echo Current Settings:
echo  - Enabled: %JIRA_AUTO_TIME_TRACKING%
echo  - Projects: %JIRA_TRACKING_PROJECTS%
echo.
echo 1. Enable/Disable (Y/N)
echo 2. Set Target Projects (e.g. SSO,JIRA,DEV)
echo 3. Back to Menu
echo.
set /p t_choice="Select (1-3): "

if "%t_choice%"=="1" (
    set /p t_enabled="Enable Time Tracking Automation? (Y/N): "
    setx JIRA_AUTO_TIME_TRACKING "!t_enabled!" >nul
    echo [Success] Updated JIRA_AUTO_TIME_TRACKING to !t_enabled!
    pause
    goto SET_TRACKING
)
if "%t_choice%"=="2" (
    echo Enter project keys separated by commas.
    set /p t_projects="Projects (e.g. SSO,JIRA): "
    setx JIRA_TRACKING_PROJECTS "!t_projects!" >nul
    echo [Success] Updated JIRA_TRACKING_PROJECTS to !t_projects!
    pause
    goto SET_TRACKING
)
goto MENU

:ADD
echo.
echo [Add New Jira Account]
set /p slot="Enter slot number (1-10): "
if "%slot%"=="" goto MENU

echo.
echo Please enter only the Jira domain name.
echo (Example: jira.company.com)
set /p domain="Domain: "
if "%domain%"=="" goto MENU

set "full_url=https://%domain%"

echo.
echo Please enter your Jira Bearer Token.
set /p token="Token: "
if "%token%"=="" goto MENU

:: 시스템 환경 변수로 등록
setx JIRA_BASE_URL_%slot% "%full_url%" >nul
setx JIRA_TOKEN_%slot% "%token%" >nul

echo.
echo ==========================================
echo [Success] Account %slot% registered!
echo.
echo URL: %full_url%
echo.
echo * NOTE: Changes take effect after restarting
echo   the backend terminal or dashboard.
echo ==========================================
pause
goto MENU

:REMOVE
echo.
echo [Remove Jira Account]
set /p slot="Enter slot number to remove (1-10): "
if "%slot%"=="" goto MENU

:: 환경 변수 삭제 (빈 값으로 setx)
setx JIRA_BASE_URL_%slot% "" >nul
setx JIRA_TOKEN_%slot% "" >nul

echo.
echo ==========================================
echo [Success] Account %slot% removed!
echo.
echo * NOTE: Restart backend to apply changes.
echo ==========================================
pause
goto MENU
