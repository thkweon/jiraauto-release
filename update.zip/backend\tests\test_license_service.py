from datetime import datetime, timedelta, timezone

import license_service


def _iso_from_now(days: int) -> str:
    return (datetime.now(timezone.utc) + timedelta(days=days)).isoformat()


def _init_store(monkeypatch, tmp_path) -> None:
    monkeypatch.setattr(license_service, "DB_PATH", str(tmp_path / "license-test.db"))
    license_service.init_license_store()


def test_current_license_enforces_product_expiration(monkeypatch, tmp_path):
    _init_store(monkeypatch, tmp_path)
    license_service.store_license_state(
        {
            "licensed": True,
            "status": "active",
            "provider": "server",
            "license_expires_at": _iso_from_now(-1),
            "token_expires_at": _iso_from_now(30),
            "expires_at": _iso_from_now(30),
        }
    )

    current = license_service.current_license()

    assert current["licensed"] is False
    assert current["status"] == "expired"


def test_current_license_enforces_online_validation_expiration(monkeypatch, tmp_path):
    _init_store(monkeypatch, tmp_path)
    license_service.store_license_state(
        {
            "licensed": True,
            "status": "active",
            "provider": "server",
            "license_expires_at": "9999-12-31T23:59:59Z",
            "token_expires_at": _iso_from_now(-1),
            "expires_at": _iso_from_now(-1),
        }
    )

    current = license_service.current_license()

    assert current["licensed"] is False
    assert current["status"] == "token_expired"


def test_current_license_keeps_legacy_expiration_fallback(monkeypatch, tmp_path):
    _init_store(monkeypatch, tmp_path)
    license_service.store_license_state(
        {
            "licensed": True,
            "status": "active",
            "provider": "server",
            "expires_at": _iso_from_now(-1),
        }
    )

    current = license_service.current_license()

    assert current["licensed"] is False
    assert current["status"] == "expired"


def test_license_summary_exposes_separate_expiration_fields():
    summary = license_service.license_summary(
        {
            "licensed": True,
            "status": "active",
            "expires_at": "legacy",
            "license_expires_at": "product",
            "token_expires_at": "token",
            "refresh_after": "refresh",
        }
    )

    assert summary["expires_at"] == "legacy"
    assert summary["license_expires_at"] == "product"
    assert summary["token_expires_at"] == "token"
    assert summary["refresh_after"] == "refresh"


def test_refresh_preserves_product_expiration_when_omitted(monkeypatch, tmp_path):
    _init_store(monkeypatch, tmp_path)
    product_expiry = "9999-12-31T23:59:59Z"
    license_service.store_license_state(
        {
            "licensed": True,
            "status": "active",
            "provider": "server",
            "license_id": "lic_test",
            "activation_id": "act_test",
            "license_token": "old-token",
            "license_expires_at": product_expiry,
            "token_expires_at": _iso_from_now(30),
            "expires_at": _iso_from_now(30),
        }
    )
    monkeypatch.setattr(
        license_service,
        "_request_license_server",
        lambda *args, **kwargs: {
            "licensed": True,
            "status": "active",
            "license_id": "lic_test",
            "activation_id": "act_test",
            "license_token": "new-token",
            "token_expires_at": _iso_from_now(30),
            "expires_at": _iso_from_now(30),
        },
    )

    refreshed = license_service.refresh_license()

    assert refreshed["license_expires_at"] == product_expiry
    assert license_service.current_license()["license_expires_at"] == product_expiry
