import { Clock3, RefreshCw, TriangleAlert } from 'lucide-react';
import { useCallback, useEffect, useState } from 'react';
import { useFloatingWidgetLayout } from '../hooks/useFloatingWidgetLayout';
import {
  loadWorklogSummaryWidgetSettings,
  WORKLOG_SUMMARY_WIDGET_SETTINGS_CHANGED_EVENT,
} from '../utils/worklogSummaryWidget';
import type {
  WorklogSummaryPeriod,
  WorklogSummaryResponse,
  WorklogSummaryWidgetSettings,
} from '../utils/worklogSummaryWidget';

const API_BASE = 'http://localhost:8000/api';
const PERIOD_LABELS: Record<WorklogSummaryPeriod, string> = { day: '오늘', week: '이번 주', month: '이번 달' };
const PERIOD_COLORS: Record<WorklogSummaryPeriod, string> = {
  day: '#2563eb',
  week: '#059669',
  month: '#7c3aed',
};

const formatDuration = (seconds: number) => {
  const totalMinutes = Math.round(seconds / 60);
  const hours = Math.floor(totalMinutes / 60);
  const minutes = totalMinutes % 60;
  if (hours && minutes) return `${hours}시간 ${minutes}분`;
  if (hours) return `${hours}시간`;
  return `${minutes}분`;
};

const formatRange = (start: string, end: string) => {
  const format = (value: string) => {
    const [, month, day] = value.split('-');
    return `${Number(month)}.${Number(day)}`;
  };
  return start === end ? format(start) : `${format(start)}~${format(end)}`;
};

const targetSecondsForPeriod = (period: WorklogSummaryPeriod, start: string, end: string) => {
  if (period === 'day') return 8 * 60 * 60;
  const current = new Date(`${start}T00:00:00`);
  const last = new Date(`${end}T00:00:00`);
  let weekdays = 0;
  while (current <= last) {
    const day = current.getDay();
    if (day !== 0 && day !== 6) weekdays += 1;
    current.setDate(current.getDate() + 1);
  }
  return Math.max(1, weekdays) * 8 * 60 * 60;
};

const readError = async (response: Response) => {
  const data = await response.json().catch(() => ({}));
  return data.detail?.message || data.detail || '업무 기록을 불러오지 못했습니다.';
};

export default function WorklogSummaryFloatingWidget() {
  const [settings, setSettings] = useState<WorklogSummaryWidgetSettings>(loadWorklogSummaryWidgetSettings);
  const [data, setData] = useState<WorklogSummaryResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const { ref: layoutRef, ...layout } = useFloatingWidgetLayout(
    'worklog-summary', settings.position, settings.enabled, 'default',
  );

  useEffect(() => {
    const sync = () => setSettings(loadWorklogSummaryWidgetSettings());
    window.addEventListener(WORKLOG_SUMMARY_WIDGET_SETTINGS_CHANGED_EVENT, sync);
    window.addEventListener('storage', sync);
    return () => {
      window.removeEventListener(WORKLOG_SUMMARY_WIDGET_SETTINGS_CHANGED_EVENT, sync);
      window.removeEventListener('storage', sync);
    };
  }, []);

  const load = useCallback(async (signal?: AbortSignal, minimumLoadingMs = 0) => {
    if (!settings.enabled || settings.periods.length === 0) return;
    const loadingStartedAt = performance.now();
    setLoading(true);
    try {
      const response = await fetch(`${API_BASE}/widgets/worklog-summary`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          periods: settings.periods,
          instance_id: settings.accountScope === 'instance' ? settings.instanceId : null,
          cache_minutes: settings.cacheMinutes,
        }),
        signal,
      });
      if (!response.ok) throw new Error(await readError(response));
      setData(await response.json());
      setError('');
    } catch (reason) {
      if ((reason as Error).name !== 'AbortError') setError((reason as Error).message);
    } finally {
      const remainingLoadingMs = minimumLoadingMs - (performance.now() - loadingStartedAt);
      if (remainingLoadingMs > 0 && !signal?.aborted) {
        await new Promise(resolve => window.setTimeout(resolve, remainingLoadingMs));
      }
      if (!signal?.aborted) setLoading(false);
    }
  }, [settings.accountScope, settings.cacheMinutes, settings.enabled, settings.instanceId, settings.periods]);

  useEffect(() => {
    if (!settings.enabled) return;
    const controller = new AbortController();
    void load(controller.signal);
    const intervalMinutes = Math.min(...settings.periods.map(period => settings.cacheMinutes[period]));
    const intervalMs = intervalMinutes * 60 * 1000;
    const timer = window.setInterval(() => void load(), intervalMs);
    return () => {
      controller.abort();
      window.clearInterval(timer);
    };
  }, [load, settings.cacheMinutes, settings.enabled, settings.periods]);

  if (!settings.enabled) return null;

  const scopeLabel = data?.scope === 'instance'
    ? data.instances[0]?.name || '선택 계정'
    : `전체 계정${data?.instances.length ? ` ${data.instances.length}개` : ''}`;

  return (
    <section
      ref={layoutRef}
      className={`worklog-summary-floating-widget floating-widget-responsive worklog-summary-position-${settings.position}`}
      data-floating-side={layout.side}
      data-floating-block={layout.block}
      data-floating-stacked={layout.stacked || undefined}
      hidden={layout.hidden}
      aria-hidden={layout.hidden || undefined}
      aria-label="내 업무 기록"
      style={layout.style}
    >
      <header className="worklog-summary-header">
        <span><Clock3 size={17} /><strong>내 업무 기록</strong></span>
        <button type="button" onClick={() => void load(undefined, 450)} disabled={loading} title="캐시 상태 확인">
          <RefreshCw size={14} className={loading ? 'spinning' : undefined} />
        </button>
      </header>
      <div className="worklog-summary-scope">{scopeLabel}</div>
      {error && <div className="worklog-summary-error"><TriangleAlert size={16} />{error}</div>}
      {!data && !error && <div className="worklog-summary-empty">업무 기록을 집계하고 있습니다.</div>}
      {data && (
        <div className="worklog-summary-bars">
          {settings.periods.map(periodKey => {
            const period = data.periods.find(item => item.period === periodKey);
            if (!period) return null;
            const targetSeconds = targetSecondsForPeriod(period.period, period.start_date, period.end_date);
            const achievement = Math.round(period.total_seconds / targetSeconds * 100);
            const width = period.total_seconds > 0 ? Math.min(100, Math.max(4, achievement)) : 0;
            return (
              <div
                className="worklog-summary-row"
                key={period.period}
                data-worklog-period={period.period}
                tabIndex={0}
              >
                <div className="worklog-summary-row-label">
                  <strong>{PERIOD_LABELS[period.period]}</strong>
                  <small>{formatRange(period.start_date, period.end_date)}</small>
                </div>
                <div className="worklog-summary-track">
                  <span style={{ width: `${width}%`, backgroundColor: PERIOD_COLORS[period.period] }} />
                </div>
                <strong className={`worklog-summary-achievement ${
                  achievement > 100 ? 'over-target' : achievement >= 80 ? 'on-target' : ''
                }`}>
                  {achievement}%
                </strong>
                <div className="worklog-summary-tooltip" role="tooltip">
                  <strong>{PERIOD_LABELS[period.period]} · {formatDuration(period.total_seconds)}</strong>
                  <span>목표 {formatDuration(targetSeconds)} · 달성률 {achievement}%</span>
                  <span>{period.worklog_count}건 · Jira {period.issue_count}개</span>
                  <small>{period.start_date} ~ {period.end_date}</small>
                </div>
              </div>
            );
          })}
        </div>
      )}
      <footer className="worklog-summary-footer">
        {data?.periods[0]
          ? `${new Date(data.periods[0].collected_at).toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit' })} 집계`
          : `최소 ${Math.min(...settings.periods.map(period => settings.cacheMinutes[period]))}분 캐시`}
      </footer>
    </section>
  );
}
