import { useEffect, useState } from 'react';
import type { CSSProperties } from 'react';
import {
  CLOCK_WIDGET_SETTINGS_CHANGED_EVENT,
  loadClockWidgetSettings,
} from '../utils/clockWidget';
import type { ClockWidgetSettings } from '../utils/clockWidget';
import useFloatingFollowOffset from '../hooks/useFloatingFollowOffset';

const formatTime = (date: Date) => date.toLocaleTimeString('ko-KR', {
  hour: '2-digit',
  minute: '2-digit',
  second: '2-digit',
  hour12: false,
});

const formatDate = (date: Date) => date.toLocaleDateString('ko-KR', {
  month: 'long',
  day: 'numeric',
  weekday: 'short',
});

export default function ClockFloatingWidget() {
  const [settings, setSettings] = useState<ClockWidgetSettings>(loadClockWidgetSettings);
  const [now, setNow] = useState(() => new Date());
  const followOffset = useFloatingFollowOffset();

  useEffect(() => {
    const timer = window.setInterval(() => setNow(new Date()), 1000);
    return () => window.clearInterval(timer);
  }, []);

  useEffect(() => {
    const syncSettings = () => setSettings(loadClockWidgetSettings());
    window.addEventListener(CLOCK_WIDGET_SETTINGS_CHANGED_EVENT, syncSettings);
    window.addEventListener('storage', syncSettings);
    return () => {
      window.removeEventListener(CLOCK_WIDGET_SETTINGS_CHANGED_EVENT, syncSettings);
      window.removeEventListener('storage', syncSettings);
    };
  }, []);

  if (!settings.enabled) return null;

  return (
    <section
      className={`clock-floating-widget clock-widget-position-${settings.position}`}
      aria-label={`현재 시각 ${formatTime(now)}`}
      style={{ '--widget-follow-offset': `${followOffset}px` } as CSSProperties}
    >
      {settings.dateDisplay === 'above' && <span>{formatDate(now)}</span>}
      <time dateTime={now.toISOString()}>{formatTime(now)}</time>
      {settings.dateDisplay === 'below' && <span>{formatDate(now)}</span>}
    </section>
  );
}
