import { useEffect, useState } from 'react';
import {
  CLOCK_WORLD_TIME_ZONES,
  CLOCK_WIDGET_SETTINGS_CHANGED_EVENT,
  loadClockWidgetSettings,
} from '../utils/clockWidget';
import type { ClockTimeFormat, ClockWidgetSettings, ClockWorldTimeZone } from '../utils/clockWidget';
import { useFloatingWidgetLayout } from '../hooks/useFloatingWidgetLayout';

const formatTime = (date: Date, timeFormat: ClockTimeFormat, timeZone?: ClockWorldTimeZone) => date.toLocaleTimeString('ko-KR', {
  hour: '2-digit',
  minute: '2-digit',
  second: '2-digit',
  hour12: timeFormat === '12',
  ...(timeZone ? { timeZone } : {}),
});

const formatDate = (date: Date) => date.toLocaleDateString('ko-KR', {
  month: 'long',
  day: 'numeric',
  weekday: 'short',
});

const formatUtcOffset = (date: Date, timeZone: ClockWorldTimeZone) => {
  const offset = new Intl.DateTimeFormat('en-US', {
    timeZone,
    timeZoneName: 'shortOffset',
  }).formatToParts(date).find(part => part.type === 'timeZoneName')?.value;
  if (!offset || offset === 'GMT') return 'UTC';
  return offset
    .replace('GMT', 'UTC')
    .replace(/([+-])0(\d)/, '$1$2')
    .replace(':00', '');
};

export default function ClockFloatingWidget() {
  const [settings, setSettings] = useState<ClockWidgetSettings>(loadClockWidgetSettings);
  const [now, setNow] = useState(() => new Date());
  const { ref: layoutRef, ...layout } = useFloatingWidgetLayout(
    'clock',
    settings.position,
    settings.enabled,
    settings.worldClockEnabled ? 'world-time' : 'default',
  );

  useEffect(() => {
    const timer = window.setInterval(() => setNow(new Date()), 1000);
    return () => window.clearInterval(timer);
  }, []);

  useEffect(() => {
    const syncSettings = () => setSettings(loadClockWidgetSettings());
    window.addEventListener(CLOCK_WIDGET_SETTINGS_CHANGED_EVENT, syncSettings);
    window.addEventListener('storage', syncSettings);
    return () => {
      window.removeEventListener(CLOCK_WIDGET_SETTINGS_CHANGED_EVENT, syncSettings);
      window.removeEventListener('storage', syncSettings);
    };
  }, []);

  if (!settings.enabled) return null;

  const localTime = formatTime(now, settings.timeFormat);
  return (
    <section
      ref={layoutRef}
      className={`clock-floating-widget floating-widget-responsive clock-widget-position-${settings.position}${settings.worldClockEnabled ? ' clock-widget-world-time-enabled' : ''}`}
      data-floating-side={layout.side}
      data-floating-block={layout.block}
      data-floating-stacked={layout.stacked || undefined}
      hidden={layout.hidden}
      aria-hidden={layout.hidden || undefined}
      aria-label={`현재 시각 ${localTime}`}
      style={layout.style}
    >
      {settings.dateDisplay === 'above' && <span>{formatDate(now)}</span>}
      <time className="clock-widget-local-time" dateTime={now.toISOString()}>{localTime}</time>
      {settings.dateDisplay === 'below' && <span>{formatDate(now)}</span>}
      {settings.worldClockEnabled && settings.worldTimeZones.length > 0 && (
        <div className="clock-widget-world-times">
          {settings.worldTimeZones.map(timeZone => (
            <div className="clock-widget-world-time" key={timeZone}>
              <span className="clock-widget-world-time-city">
                {CLOCK_WORLD_TIME_ZONES.find(option => option.value === timeZone)?.label ?? timeZone}
                {' '}
                <small>({formatUtcOffset(now, timeZone)})</small>
              </span>
              <time dateTime={now.toISOString()}>
                {formatTime(now, settings.timeFormat, timeZone)}
              </time>
            </div>
          ))}
        </div>
      )}
    </section>
  );
}
