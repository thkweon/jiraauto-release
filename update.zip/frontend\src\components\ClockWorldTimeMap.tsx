import { Check, MapPin, X } from 'lucide-react';
import { CLOCK_WORLD_TIME_ZONES } from '../utils/clockWidget';
import type { ClockWorldTimeZone } from '../utils/clockWidget';

interface ClockWorldTimeMapProps {
  selectedTimeZones: ClockWorldTimeZone[];
  disabled?: boolean;
  onChange: (timeZones: ClockWorldTimeZone[]) => void;
  onLimitReached: () => void;
}

const MAP_WIDTH = 1576;
const MAP_HEIGHT = 1102;
const MAP_EQUATOR_Y = 702.3;
const MAP_CUT_LONGITUDE = -30;
const MAP_MERCATOR_SCALE = MAP_WIDTH / (2 * Math.PI);

const toPacificMapPosition = (longitude: number, latitude: number) => {
  const mapLongitude = ((longitude - MAP_CUT_LONGITUDE) % 360 + 360) % 360;
  const boundedLatitude = Math.max(-84, Math.min(84, latitude));
  const latitudeRadians = boundedLatitude * Math.PI / 180;
  const mercatorY = Math.log(Math.tan(Math.PI / 4 + latitudeRadians / 2));
  return {
    x: mapLongitude / 360 * 100,
    y: (MAP_EQUATOR_Y - MAP_MERCATOR_SCALE * mercatorY) / MAP_HEIGHT * 100,
  };
};

export default function ClockWorldTimeMap({
  selectedTimeZones,
  disabled = false,
  onChange,
  onLimitReached,
}: ClockWorldTimeMapProps) {
  const toggleTimeZone = (timeZone: ClockWorldTimeZone) => {
    if (disabled) return;
    if (selectedTimeZones.includes(timeZone)) {
      onChange(selectedTimeZones.filter(value => value !== timeZone));
      return;
    }
    if (selectedTimeZones.length >= 5) {
      onLimitReached();
      return;
    }
    onChange([...selectedTimeZones, timeZone]);
  };

  return (
    <div className={`clock-world-map-picker${disabled ? ' disabled' : ''}`}>
      <div className="clock-world-map" role="group" aria-label="세계 지도에서 표시할 시간대 선택">
        <img
          className="clock-world-map-shape"
          src="https://upload.wikimedia.org/wikipedia/commons/c/c2/Blank_Map_Pacific_World.svg"
          alt=""
          aria-hidden="true"
        />

        {CLOCK_WORLD_TIME_ZONES.map(option => {
          const mapPosition = toPacificMapPosition(option.longitude, option.latitude);
          const selectedIndex = selectedTimeZones.indexOf(option.value);
          const selected = selectedIndex >= 0;
          return (
            <button
              className={`clock-world-map-marker${selected ? ' selected' : ''}`}
              type="button"
              key={option.value}
              style={{
                left: `${mapPosition.x}%`,
                top: `${mapPosition.y}%`,
              }}
              disabled={disabled}
              aria-pressed={selected}
              aria-label={`${option.label} 시간대${selected ? `, ${selectedIndex + 1}번째로 선택됨` : ' 선택'}`}
              title={`${option.label} (${option.value})`}
              onClick={() => toggleTimeZone(option.value)}
            >
              <span className="clock-world-map-pin">
                {selected ? <Check size={11} /> : <MapPin size={11} />}
              </span>
              <span className="clock-world-map-marker-label">{option.label}</span>
              {selected && <small>{selectedIndex + 1}</small>}
            </button>
          );
        })}
      </div>

      <div className="clock-world-map-selection" aria-label="선택한 세계 시간">
        {selectedTimeZones.map((timeZone, index) => {
          const label = CLOCK_WORLD_TIME_ZONES.find(option => option.value === timeZone)?.label ?? timeZone;
          return (
            <span key={timeZone}>
              <strong>{index + 1}</strong>
              {label}
              <button
                type="button"
                disabled={disabled}
                onClick={() => toggleTimeZone(timeZone)}
                aria-label={`${label} 시간대 삭제`}
                title="삭제"
              >
                <X size={12} />
              </button>
            </span>
          );
        })}
      </div>
      <p className="clock-world-map-help">
        지도에서 도시를 선택하세요. 최대 5개까지 등록할 수 있으며 서머타임은 도시별로 자동 반영됩니다.
        {' · '}
        <a
          href="https://commons.wikimedia.org/wiki/File:Blank_Map_Pacific_World.svg"
          target="_blank"
          rel="noreferrer"
        >
          지도: Dmthoth / CC BY-SA 3.0
        </a>
      </p>
    </div>
  );
}
