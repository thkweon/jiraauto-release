import { useCallback, useContext, useEffect, useLayoutEffect, useMemo, useRef } from 'react';
import type { CSSProperties } from 'react';
import { FloatingWidgetLayoutContext } from '../context/floatingWidgetLayoutContextValue';
import { calculateFloatingWidgetLayout } from '../utils/floatingWidgetLayout';
import type {
  FloatingWidgetKind,
  FloatingWidgetVariant,
} from '../utils/floatingWidgetLayout';

export const useFloatingWidgetRuntimeStatus = (kind: FloatingWidgetKind) => {
  const context = useContext(FloatingWidgetLayoutContext);
  return context?.hiddenWidgets[kind] || null;
};

export const useFloatingWidgetLayout = (
  kind: FloatingWidgetKind,
  placement: string,
  enabled: boolean,
  variant: FloatingWidgetVariant = 'default',
  focusProtected = false,
) => {
  const context = useContext(FloatingWidgetLayoutContext);
  if (!context) throw new Error('useFloatingWidgetLayout must be used inside FloatingWidgetLayoutProvider');
  const { reportGeometry, reportHidden, viewportHeight, viewportWidth } = context;
  const constrainToSlots = Boolean(context.constrainToSlots[kind]);
  const result = useMemo(() => calculateFloatingWidgetLayout({
    viewportWidth,
    viewportHeight,
    kind,
    placement,
    variant,
    constrainToSlots,
  }), [
    constrainToSlots,
    kind,
    placement,
    variant,
    viewportHeight,
    viewportWidth,
  ]);
  const runtimeHidden = enabled && !result.visible && !focusProtected;
  const elementRef = useRef<HTMLElement | null>(null);
  const setElementRef = useCallback((element: HTMLElement | null) => {
    elementRef.current = element;
  }, []);

  useLayoutEffect(() => {
    const element = elementRef.current;
    if (!element || !enabled || runtimeHidden || kind === 'quick-link') {
      reportGeometry(kind);
      return;
    }

    const reportCurrentGeometry = () => {
      const height = element.getBoundingClientRect().height;
      if (height > 0) reportGeometry(kind, { side: result.side, block: result.block, height });
    };
    reportCurrentGeometry();
    const observer = new ResizeObserver(reportCurrentGeometry);
    observer.observe(element);
    return () => {
      observer.disconnect();
      reportGeometry(kind);
    };
  }, [enabled, kind, reportGeometry, result.block, result.side, runtimeHidden]);

  useEffect(() => {
    reportHidden(kind, runtimeHidden, result.hiddenReason);
  }, [kind, reportHidden, result.hiddenReason, runtimeHidden]);

  useEffect(() => () => reportHidden(kind, false), [kind, reportHidden]);

  const stackTop = context.stackTopByKind[kind];

  return {
    hidden: runtimeHidden,
    hiddenReason: result.hiddenReason,
    side: result.side,
    block: result.block,
    ref: setElementRef,
    stacked: stackTop !== undefined,
    style: {
      '--floating-widget-scale': result.scale,
      ...(stackTop !== undefined ? { '--floating-widget-stack-top': `${stackTop}px` } : {}),
    } as CSSProperties,
  };
};
