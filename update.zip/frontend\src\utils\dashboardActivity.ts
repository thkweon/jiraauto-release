export const DASHBOARD_ACTIVITY_TYPES_STORAGE_KEY = 'jiraDashboardActivityTypes';

export type DashboardActivityType =
  | 'status'
  | 'people'
  | 'content'
  | 'comments'
  | 'fields'
  | 'time_tracking'
  | 'attachments'
  | 'new_issue';

export const DASHBOARD_ACTIVITY_OPTIONS: Array<{
  value: DashboardActivityType;
  label: string;
}> = [
  { value: 'status', label: '상태 변경' },
  { value: 'people', label: '담당자·보고자 변경' },
  { value: 'content', label: '제목·설명 수정' },
  { value: 'comments', label: '댓글 추가·수정·삭제' },
  { value: 'fields', label: '우선순위, 라벨, 컴포넌트 등 필드 변경' },
  { value: 'time_tracking', label: '작업시간 기록이나 예상시간 변경' },
  { value: 'attachments', label: '첨부파일 등 Jira가 이슈 업데이트로 처리하는 활동' },
  { value: 'new_issue', label: '신규 이슈 생성' },
];

const ALL_DASHBOARD_ACTIVITY_TYPES = DASHBOARD_ACTIVITY_OPTIONS.map(option => option.value);
const DASHBOARD_ACTIVITY_TYPE_SET = new Set<DashboardActivityType>(ALL_DASHBOARD_ACTIVITY_TYPES);

export const loadDashboardActivityTypes = (): DashboardActivityType[] => {
  const raw = localStorage.getItem(DASHBOARD_ACTIVITY_TYPES_STORAGE_KEY);
  if (raw === null) return [...ALL_DASHBOARD_ACTIVITY_TYPES];
  try {
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [...ALL_DASHBOARD_ACTIVITY_TYPES];
    return parsed.filter((value): value is DashboardActivityType => DASHBOARD_ACTIVITY_TYPE_SET.has(value));
  } catch {
    return [...ALL_DASHBOARD_ACTIVITY_TYPES];
  }
};

export const saveDashboardActivityTypes = (types: DashboardActivityType[]) => {
  localStorage.setItem(DASHBOARD_ACTIVITY_TYPES_STORAGE_KEY, JSON.stringify(types));
};
