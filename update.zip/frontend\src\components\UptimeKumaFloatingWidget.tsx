import { Activity, ExternalLink, RefreshCw, ShieldAlert } from 'lucide-react';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { useFloatingWidgetLayout } from '../hooks/useFloatingWidgetLayout';
import {
  loadUptimeKumaWidgetSettings,
  UPTIME_KUMA_WIDGET_SETTINGS_CHANGED_EVENT,
} from '../utils/uptimeKumaWidget';
import type { UptimeKumaSummaryResponse, UptimeKumaWidgetSettings } from '../utils/uptimeKumaWidget';

const API_BASE = 'http://localhost:8000/api';
const STATUS_LABELS = { up: '정상', down: '장애', pending: '확인 중', maintenance: '점검 중' } as const;

const readError = async (response: Response) => {
  try {
    const data = await response.json();
    return data.detail?.message || data.detail || 'Uptime Kuma 데이터를 불러오지 못했습니다.';
  } catch {
    return 'Uptime Kuma 데이터를 불러오지 못했습니다.';
  }
};

export default function UptimeKumaFloatingWidget() {
  const [settings, setSettings] = useState<UptimeKumaWidgetSettings>(loadUptimeKumaWidgetSettings);
  const [data, setData] = useState<UptimeKumaSummaryResponse | null>(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { ref: layoutRef, ...layout } = useFloatingWidgetLayout(
    'uptime-kuma', settings.placement, settings.enabled, 'double',
  );

  useEffect(() => {
    const sync = () => setSettings(loadUptimeKumaWidgetSettings());
    window.addEventListener(UPTIME_KUMA_WIDGET_SETTINGS_CHANGED_EVENT, sync);
    window.addEventListener('storage', sync);
    return () => {
      window.removeEventListener(UPTIME_KUMA_WIDGET_SETTINGS_CHANGED_EVENT, sync);
      window.removeEventListener('storage', sync);
    };
  }, []);

  const load = useCallback(async (signal?: AbortSignal) => {
    if (!settings.enabled) return;
    setLoading(true);
    try {
      const response = await fetch(`${API_BASE}/uptime-kuma/summary`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ base_url: settings.baseUrl, verify_ssl: settings.verifySsl }),
        signal,
      });
      if (!response.ok) throw new Error(await readError(response));
      setData(await response.json());
      setError('');
    } catch (reason) {
      if ((reason as Error).name !== 'AbortError') setError((reason as Error).message);
    } finally {
      if (!signal?.aborted) setLoading(false);
    }
  }, [settings.baseUrl, settings.enabled, settings.verifySsl]);

  useEffect(() => {
    if (!settings.enabled) return;
    const controller = new AbortController();
    void load(controller.signal);
    const timer = window.setInterval(() => void load(), settings.refreshSeconds * 1000);
    return () => {
      controller.abort();
      window.clearInterval(timer);
    };
  }, [load, settings.enabled, settings.refreshSeconds]);

  const monitors = useMemo(() => (
    settings.hideUp ? data?.monitors.filter(monitor => monitor.status !== 'up') || [] : data?.monitors || []
  ), [data?.monitors, settings.hideUp]);
  if (!settings.enabled) return null;

  const overallStatus = data?.summary.down ? 'down'
    : data?.summary.pending ? 'pending'
      : data?.summary.maintenance ? 'maintenance'
        : 'up';

  return (
    <section
      ref={layoutRef}
      className={`uptime-kuma-floating-widget floating-widget-responsive uptime-kuma-placement-${settings.placement}`}
      data-floating-side={layout.side}
      data-floating-block={layout.block}
      data-floating-stacked={layout.stacked || undefined}
      hidden={layout.hidden}
      aria-hidden={layout.hidden || undefined}
      aria-label="Uptime Kuma"
      style={layout.style}
    >
      <header className="uptime-kuma-header">
        <span><Activity size={18} /><strong>Uptime Kuma</strong></span>
        <span className={`uptime-kuma-overall-status status-${overallStatus}`}>{data ? STATUS_LABELS[overallStatus] : '연결 중'}</span>
      </header>
      {data && (
        <div className="uptime-kuma-summary">
          <span><strong>{data.summary.up}</strong> 정상</span>
          <span><strong>{data.summary.down}</strong> 장애</span>
          <span><strong>{data.summary.pending}</strong> 확인</span>
          <span><strong>{data.summary.maintenance}</strong> 점검</span>
        </div>
      )}
      {error && <div className="uptime-kuma-error"><ShieldAlert size={18} /><span>{error}</span></div>}
      {!data && !error ? <div className="uptime-kuma-empty">모니터 정보를 불러오는 중입니다.</div> : (
        <div className="uptime-kuma-monitor-list">
          {monitors.map(monitor => (
            <button
              type="button"
              className="uptime-kuma-monitor"
              key={`${monitor.vault}-${monitor.id}`}
              onClick={() => window.open(monitor.dashboard_url, '_blank', 'noopener,noreferrer')}
            >
              <span className={`uptime-kuma-status-dot status-${monitor.status}`} />
              <span className="uptime-kuma-monitor-name">
                <strong>{monitor.name}</strong>
                <small>{monitor.vault || monitor.type}</small>
              </span>
              <span className="uptime-kuma-monitor-metrics">
                <strong>{monitor.response_time_ms == null ? '-' : `${monitor.response_time_ms}ms`}</strong>
                <small>{monitor.uptime_24h == null ? '-' : `${(monitor.uptime_24h * 100).toFixed(2)}%`}</small>
              </span>
              {monitor.certificate_days_remaining != null && monitor.certificate_days_remaining <= 14
                ? <ShieldAlert className="uptime-kuma-cert-warning" size={15} />
                : <ExternalLink size={14} />}
            </button>
          ))}
          {data && monitors.length === 0 && <div className="uptime-kuma-empty">표시할 문제 모니터가 없습니다.</div>}
        </div>
      )}
      <footer className="uptime-kuma-footer">
        <small>{data ? `${new Date(data.updated_at).toLocaleTimeString('ko-KR')} 갱신` : settings.baseUrl}</small>
        <button type="button" onClick={() => void load()} disabled={loading} title="새로고침">
          <RefreshCw size={15} className={loading ? 'spinning' : undefined} />
        </button>
      </footer>
    </section>
  );
}
