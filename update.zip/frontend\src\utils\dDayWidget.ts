export type DDayWidgetPosition =
  | 'left-top'
  | 'left-middle'
  | 'left-bottom'
  | 'right-top'
  | 'right-middle'
  | 'right-bottom';

export interface DDayItem {
  id: string;
  title: string;
  targetDate: string;
}
export type DDaySortMode = 'auto' | 'manual';

export interface DDayWidgetSettings {
  enabled: boolean;
  position: DDayWidgetPosition;
  items: DDayItem[];
  sortMode: DDaySortMode;
}

export const D_DAY_WIDGET_SETTINGS_STORAGE_KEY = 'jiraautoDDayWidgetSettings';
export const D_DAY_WIDGET_SETTINGS_CHANGED_EVENT = 'dDayWidgetSettingsChanged';

const D_DAY_WIDGET_POSITIONS: DDayWidgetPosition[] = [
  'left-top',
  'left-middle',
  'left-bottom',
  'right-top',
  'right-middle',
  'right-bottom',
];

const DEFAULT_D_DAY_WIDGET_SETTINGS: DDayWidgetSettings = {
  enabled: false,
  position: 'left-bottom',
  items: [],
  sortMode: 'auto',
};

const parseLocalDate = (value: string) => {
  const [year, month, day] = value.split('-').map(Number);
  return new Date(year, month - 1, day);
};

export const getDDayDifference = (targetDate: string, referenceDate = new Date()) => {
  const today = new Date(referenceDate);
  today.setHours(0, 0, 0, 0);
  return Math.round((parseLocalDate(targetDate).getTime() - today.getTime()) / 86400000);
};

export const sortDDayItems = (items: DDayItem[], referenceDate = new Date()) => [...items].sort((left, right) => {
  const leftDifference = getDDayDifference(left.targetDate, referenceDate);
  const rightDifference = getDDayDifference(right.targetDate, referenceDate);
  const leftExpired = leftDifference < 0;
  const rightExpired = rightDifference < 0;
  if (leftExpired !== rightExpired) return leftExpired ? -1 : 1;
  const distanceDifference = Math.abs(leftDifference) - Math.abs(rightDifference);
  if (distanceDifference !== 0) return distanceDifference;
  if ((leftDifference >= 0) !== (rightDifference >= 0)) return leftDifference >= 0 ? -1 : 1;
  return left.targetDate.localeCompare(right.targetDate);
});

export const createDDayItemId = () => {
  if (typeof crypto !== 'undefined' && 'randomUUID' in crypto) return crypto.randomUUID();
  return `d-day-${Date.now()}-${Math.random().toString(36).slice(2)}`;
};

const normalizeItems = (value: unknown): DDayItem[] => {
  if (!Array.isArray(value)) return [];
  return value.flatMap(item => {
    if (!item || typeof item !== 'object') return [];
    const candidate = item as Partial<DDayItem>;
    if (typeof candidate.targetDate !== 'string' || !candidate.targetDate) return [];
    return [{
      id: typeof candidate.id === 'string' ? candidate.id : createDDayItemId(),
      title: typeof candidate.title === 'string' && candidate.title.trim() ? candidate.title : 'D-DAY',
      targetDate: candidate.targetDate,
    }];
  });
};

export const loadDDayWidgetSettings = (): DDayWidgetSettings => {
  try {
    const raw = localStorage.getItem(D_DAY_WIDGET_SETTINGS_STORAGE_KEY);
    if (!raw) return DEFAULT_D_DAY_WIDGET_SETTINGS;
    const value = JSON.parse(raw) as Partial<DDayWidgetSettings> & { title?: unknown; targetDate?: unknown };
    const items = normalizeItems(value.items);
    if (items.length === 0 && typeof value.targetDate === 'string' && value.targetDate) {
      items.push({
        id: createDDayItemId(),
        title: typeof value.title === 'string' && value.title.trim() ? value.title : 'D-DAY',
        targetDate: value.targetDate,
      });
    }
    return {
      enabled: typeof value.enabled === 'boolean' ? value.enabled : DEFAULT_D_DAY_WIDGET_SETTINGS.enabled,
      position: D_DAY_WIDGET_POSITIONS.includes(value.position as DDayWidgetPosition)
        ? value.position as DDayWidgetPosition
        : DEFAULT_D_DAY_WIDGET_SETTINGS.position,
      items,
      sortMode: value.sortMode === 'manual' ? 'manual' : DEFAULT_D_DAY_WIDGET_SETTINGS.sortMode,
    };
  } catch {
    return DEFAULT_D_DAY_WIDGET_SETTINGS;
  }
};

export const saveDDayWidgetSettings = (settings: DDayWidgetSettings) => {
  localStorage.setItem(D_DAY_WIDGET_SETTINGS_STORAGE_KEY, JSON.stringify(settings));
  window.dispatchEvent(new CustomEvent<DDayWidgetSettings>(
    D_DAY_WIDGET_SETTINGS_CHANGED_EVENT,
    { detail: settings },
  ));
};
