import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { LogOut, User, Server } from 'lucide-react';
import { motion } from 'framer-motion';
import '../TeamStyles.css';

export default function TeamInfoPage() {
  const navigate = useNavigate();
  const leaderUrl = localStorage.getItem('teamLeaderUrl');
  const memberId = localStorage.getItem('teamMemberId');

  useEffect(() => {
    if (localStorage.getItem('teamRole') !== 'member') navigate('/');
  }, [navigate]);

  const handleLeave = () => {
    if (window.confirm('팀을 탈퇴하시겠습니까? 더 이상 내 데이터가 팀장에게 동기화되지 않습니다.')) {
      localStorage.removeItem('teamRole');
      localStorage.removeItem('teamLeaderUrl');
      window.dispatchEvent(new Event('teamRoleChanged'));
      navigate('/');
    }
  };

  return (
    <div className="glass-container" style={{maxWidth: "600px", margin: "5vh auto 0 auto"}}>
      <motion.div className="glass-panel" initial={{scale: 0.9, opacity: 0}} animate={{scale: 1, opacity: 1}}>
        
        <div style={{display: 'flex', alignItems: 'center', gap: 15, marginBottom: 25}}>
          <div style={{width: 50, height: 50, borderRadius: '25px', background: 'linear-gradient(135deg, #a29bfe, #6c5ce7)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'white'}}>
            <User size={24} />
          </div>
          <div>
            <div style={{fontSize: 13, color: 'var(--text-secondary)', fontWeight: 600}}>식별자 (ID)</div>
            <div style={{fontSize: 20, fontWeight: 700}}>{memberId}</div>
          </div>
        </div>

        <div style={{display: 'flex', alignItems: 'center', gap: 15, marginBottom: 40}}>
          <div style={{width: 50, height: 50, borderRadius: '25px', background: 'rgba(0,0,0,0.05)', display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
            <Server size={24} color="var(--text-secondary)" />
          </div>
          <div style={{flex: 1, overflow: 'hidden'}}>
            <div style={{fontSize: 13, color: 'var(--text-secondary)', fontWeight: 600}}>접속 서버 (팀장)</div>
            <div style={{fontSize: 15, fontFamily: 'monospace', textOverflow: 'ellipsis', overflow: 'hidden', whiteSpace: 'nowrap'}}>{leaderUrl}</div>
          </div>
        </div>
        
        <button className="btn-glass" style={{width: '100%', color: '#d63031', borderColor: 'rgba(214,48,49,0.2)', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8}} onClick={handleLeave}>
          <LogOut size={18}/> 팀 탈퇴하기
        </button>
      </motion.div>
    </div>
  );
}
