Set WshShell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
strPath = fso.GetParentFolderName(WScript.ScriptFullName)

' ---------------------------------------------------------
' 1. 사전 점검 (Prerequisites Check)
' ---------------------------------------------------------
backendVenv = strPath & "\backend\venv"
frontendModules = strPath & "\frontend\node_modules"

If Not fso.FolderExists(backendVenv) Or Not fso.FolderExists(frontendModules) Then
    MsgBox "Required environment is not set up." & vbCrLf & _
           "Running 'run.bat' to install dependencies.", 48, "Environment Missing"
    WshShell.CurrentDirectory = strPath
    WshShell.Run "cmd /k run.bat", 1, False
    WScript.Quit
End If

Function IsBackendHealthy()
    On Error Resume Next
    statusCode = 0
    Set http = CreateObject("MSXML2.ServerXMLHTTP.6.0")
    http.open "GET", "http://127.0.0.1:8000/api/health", False
    http.setTimeouts 1000, 1000, 1000, 1000
    http.send
    If Err.Number = 0 Then
        statusCode = http.Status
    End If
    IsBackendHealthy = (statusCode = 200)
    Err.Clear
    On Error GoTo 0
End Function

' ---------------------------------------------------------
' 2. Backend 실행 (창 숨김)
' ---------------------------------------------------------
WshShell.CurrentDirectory = strPath & "\backend"
' cmd /c를 사용하여 가상환경 파이썬 실행
backendCmd = "cmd /c " & _
             "set LICENSE_PROVIDER=server&& " & _
             "set LICENSE_SERVER_URL=https://license.shadowspace.i234.me&& " & _
             "set LICENSE_SERVER_VERIFY_TLS=N&& " & _
             "set LICENSE_GATE_ENABLED=Y&& " & _
             "set JIRAAUTO_APP_VERSION=1.0.0&& " & _
             "set JIRAAUTO_APP_CHANNEL=stable&& " & _
             "set JIRAAUTO_ENV=production&& " & _
             "venv\Scripts\python.exe main.py > backend_start.log 2>&1"
WshShell.Run backendCmd, 0, False

backendReady = False
For i = 1 To 30
    WScript.Sleep 1000
    If IsBackendHealthy() Then
        backendReady = True
        Exit For
    End If
Next

If Not backendReady Then
    MsgBox "Backend did not start correctly." & vbCrLf & _
           "Running 'run.bat' to rebuild the environment." & vbCrLf & vbCrLf & _
           "Backend log: backend\backend_start.log", 48, "Backend Startup Failed"
    WshShell.CurrentDirectory = strPath
    WshShell.Run "cmd /k run.bat", 1, False
    WScript.Quit
End If

' ---------------------------------------------------------
' 3. Frontend 실행 (창 숨김)
' ---------------------------------------------------------
WshShell.CurrentDirectory = strPath & "\frontend"
' npm run dev 실행 (Node.js 경로 문제 방지를 위해 cmd /c 사용)
WshShell.Run "cmd /c npm run dev", 0, False

' ---------------------------------------------------------
' 4. 완료 알림
' ---------------------------------------------------------
MsgBox "Jira Dashboard has started in the background." & vbCrLf & _
       "1. Backend: http://localhost:8000" & vbCrLf & _
       "2. Frontend: http://localhost:5173" & vbCrLf & vbCrLf & _
       "Access the Dashboard in your browser.", 64, "Jira Dashboard Started"
