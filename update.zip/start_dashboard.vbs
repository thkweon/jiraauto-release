Set WshShell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
strPath = fso.GetParentFolderName(WScript.ScriptFullName)

' ---------------------------------------------------------
' 1. 사전 점검 (Prerequisites Check)
' ---------------------------------------------------------
backendVenv = strPath & "\backend\venv"
frontendModules = strPath & "\frontend\node_modules"

If Not fso.FolderExists(backendVenv) Or Not fso.FolderExists(frontendModules) Then
    MsgBox "Required environment is not set up." & vbCrLf & _
           "Please run 'run.bat' once to install dependencies before using background mode.", 48, "Environment Missing"
    WScript.Quit
End If

' ---------------------------------------------------------
' 2. Backend 실행 (창 숨김)
' ---------------------------------------------------------
WshShell.CurrentDirectory = strPath & "\backend"
' cmd /c를 사용하여 가상환경 파이썬 실행
backendCmd = "cmd /c " & _
             "set LICENSE_PROVIDER=server&& " & _
             "set LICENSE_SERVER_URL=https://license.shadowspace.i234.me&& " & _
             "set LICENSE_SERVER_VERIFY_TLS=N&& " & _
             "set LICENSE_GATE_ENABLED=Y&& " & _
             "set JIRAAUTO_APP_VERSION=1.0.0&& " & _
             "set JIRAAUTO_APP_CHANNEL=stable&& " & _
             "venv\Scripts\python.exe main.py"
WshShell.Run backendCmd, 0, False

' ---------------------------------------------------------
' 3. Frontend 실행 (창 숨김)
' ---------------------------------------------------------
WshShell.CurrentDirectory = strPath & "\frontend"
' npm run dev 실행 (Node.js 경로 문제 방지를 위해 cmd /c 사용)
WshShell.Run "cmd /c npm run dev", 0, False

' ---------------------------------------------------------
' 4. 완료 알림
' ---------------------------------------------------------
MsgBox "Jira Dashboard has started in the background." & vbCrLf & _
       "1. Backend: http://localhost:8000" & vbCrLf & _
       "2. Frontend: http://localhost:5173" & vbCrLf & vbCrLf & _
       "Access the Dashboard in your browser.", 64, "Jira Dashboard Started"
