import { useCallback, useEffect, useState } from 'react';
import type { ChangeEvent } from 'react';
import { RefreshCcw, Settings2, PlayCircle, ExternalLink } from 'lucide-react';
import { motion } from 'framer-motion';
import '../App.css';
import '../TeamStyles.css';

const API_BASE = 'http://localhost:8000/api';

export default function BulkTransitionPage() {
  const [issues, setIssues] = useState<any[]>([]);
  const [selectedKeys, setSelectedKeys] = useState<Set<string>>(new Set());
  const [transitions, setTransitions] = useState<any[]>([]);
  const [selectedTransition, setSelectedTransition] = useState('');
  const [loading, setLoading] = useState(false);
  const [initialLoading, setInitialLoading] = useState(true);
  const [progress, setProgress] = useState(0);
  const [instances, setInstances] = useState<any[]>([]);
  const [jiraUrl, setJiraUrl] = useState('');

  const fetchIssues = useCallback(async () => {
    try {
      const [resIssues, resConfig, resMe] = await Promise.all([
        fetch(`${API_BASE}/issues`),
        fetch(`${API_BASE}/config`),
        fetch(`${API_BASE}/me`)
      ]);
      const dataIssues = await resIssues.json();
      const dataConfig = await resConfig.json();
      const dataMe = await resMe.json();
      
      const trackingProjects = dataConfig.tracking_projects || [];
      setInstances(dataConfig.instances || []);
      setJiraUrl(dataConfig.jira_base_url || '');
      const myNames = Object.values(dataMe).flatMap((u: any) => [u.name, u.displayName, u.accountId]).filter(Boolean);

      const allIssues = dataIssues.issues || [];
      const filtered = allIssues.filter((i: any) => {
          const projectKey = i.fields?.project?.key;
          const assigneeName = i.fields?.assignee?.name;
          const assigneeDisplay = i.fields?.assignee?.displayName;
          const assigneeAccount = i.fields?.assignee?.accountId;

          // Check if project is in tracking_projects
          const isTrackingProject = trackingProjects.length === 0 || trackingProjects.includes(projectKey);

          // Check if assignee matches one of 'myNames'
          const isMyIssue = myNames.includes(assigneeName) || myNames.includes(assigneeDisplay) || myNames.includes(assigneeAccount);

          return isTrackingProject && isMyIssue;
      });

      setIssues(filtered);
    } catch(e) { console.error(e); } finally {
      setInitialLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchIssues();
  }, [fetchIssues]);

  const handleSelectAll = (e: ChangeEvent<HTMLInputElement>) => {
    if (e.target.checked) setSelectedKeys(new Set(issues.map(i => i.key)));
    else setSelectedKeys(new Set());
  };

  const handleSelect = (key: string) => {
    const next = new Set(selectedKeys);
    if (next.has(key)) next.delete(key);
    else next.add(key);
    setSelectedKeys(next);
  };

  useEffect(() => {
    if (selectedKeys.size > 0) {
      const key = Array.from(selectedKeys)[0];
      const issue = issues.find(i => i.key === key);
      if (issue) {
        fetch(`${API_BASE}/issues/${key}/transitions?instance_id=${issue.instance_id}`)
          .then(res => res.json())
          .then(data => setTransitions(data.transitions || []));
      }
    }
  }, [selectedKeys, issues]);

  const handleBulkTransition = async () => {
    if (selectedKeys.size === 0 || !selectedTransition) return;
    setLoading(true);
    setProgress(0);
    
    let currentProgress = 0;
    const progressInterval = setInterval(() => {
      currentProgress += (90 - currentProgress) * 0.15;
      setProgress(Math.round(currentProgress));
    }, 200);
    
    const keysArray = Array.from(selectedKeys);
    
    try {
        const issuesPayload = keysArray.map(key => {
            const issue = issues.find(i => i.key === key);
            return { key, instance_id: issue?.instance_id };
        });
        
        const selectedT = transitions.find(t => t.id === selectedTransition);
        const transitionName = selectedT ? selectedT.name : '';
        
        const res = await fetch(`${API_BASE}/issues/bulk/transitions`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ issues: issuesPayload, transition_name: transitionName })
        });
        
        const data = await res.json();
        
        clearInterval(progressInterval);
        setProgress(100);
        
        // Let the progress bar animation finish before showing alert
        setTimeout(() => {
            if (data.results) {
                const errors = data.results.filter((r: any) => !r.success);
                if (errors.length > 0) {
                    alert(`일부 티켓 상태 변경 실패:\n${errors.map((e: any) => `${e.key}: ${e.error}`).join('\n')}`);
                } else {
                    alert('선택한 티켓들의 일괄 상태 변경이 완료되었습니다.');
                }
            }
        }, 300);
        
    } catch(e) { 
        console.error(e); 
        clearInterval(progressInterval);
        setProgress(0);
        alert('요청 중 오류가 발생했습니다.');
    }
    
    setTimeout(() => {
      setLoading(false);
      setSelectedKeys(new Set());
      fetchIssues();
    }, 1000);
  };

  return (
    <div className="glass-container">
      <div style={{ display: 'flex', justifyContent: 'flex-end', alignItems: 'center', marginBottom: 20 }}>
        <button className="btn-glass" onClick={fetchIssues} style={{display:'flex', alignItems:'center', gap:6}}>
          <RefreshCcw size={16}/> 목록 갱신
        </button>
      </div>

      <motion.div className="glass-panel" initial={{opacity:0, y:-10}} animate={{opacity:1, y:0}} style={{ marginBottom: 30, display: 'flex', gap: 15, alignItems: 'center', flexWrap: 'wrap' }}>
        <div style={{display: 'flex', alignItems: 'center', gap: 10, flex: 1}}>
          <Settings2 size={20} color="var(--text-secondary)"/>
          <select className="glass-input" style={{flex: 1, maxWidth: '400px'}} value={selectedTransition} onChange={e => setSelectedTransition(e.target.value)}>
            <option value="">-- 일괄 적용할 새 상태 선택 --</option>
            {transitions.map(t => (
              <option key={t.id} value={t.id}>{t.name} (→ {t.to?.name})</option>
            ))}
          </select>
        </div>
        <button className="btn-premium" onClick={handleBulkTransition} disabled={loading || selectedKeys.size === 0 || !selectedTransition} style={{display: 'flex', alignItems: 'center', gap: 8, opacity: (loading || selectedKeys.size === 0 || !selectedTransition) ? 0.5 : 1}}>
          <PlayCircle size={18}/> 선택 항목 일괄 변경 ({selectedKeys.size}개)
        </button>
      </motion.div>

      {loading && (
        <motion.div initial={{opacity:0}} animate={{opacity:1}} style={{ marginBottom: 30 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, fontWeight: 700, marginBottom: 8, color: 'var(--accent-color)' }}>
            <span>상태 변경 진행 중...</span>
            <span>{progress}%</span>
          </div>
          <div style={{ width: '100%', height: '8px', background: 'rgba(0,0,0,0.05)', borderRadius: '4px', overflow: 'hidden' }}>
            <div style={{ width: `${progress}%`, height: '100%', background: 'linear-gradient(90deg, #0984e3, #00cec9)', transition: 'width 0.3s ease' }} />
          </div>
        </motion.div>
      )}

      <div className="glass-panel" style={{padding: 0, overflow: 'hidden'}}>
        <div style={{overflowX: 'auto'}}>
          <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left' }}>
            <thead>
              <tr style={{ background: 'rgba(0,0,0,0.03)', borderBottom: '1px solid rgba(0,0,0,0.08)' }}>
                <th style={{ padding: '15px 20px', width: '40px' }}><input type="checkbox" onChange={handleSelectAll} checked={issues.length > 0 && selectedKeys.size === issues.length} style={{cursor: 'pointer'}} /></th>
                <th style={{ padding: '15px 20px', fontWeight: 600, color: 'var(--text-secondary)', fontSize: 13 }}>Key</th>
                <th style={{ padding: '15px 20px', fontWeight: 600, color: 'var(--text-secondary)', fontSize: 13 }}>Summary</th>
                <th style={{ padding: '15px 20px', fontWeight: 600, color: 'var(--text-secondary)', fontSize: 13 }}>Status</th>
                <th style={{ padding: '15px 20px', fontWeight: 600, color: 'var(--text-secondary)', fontSize: 13 }}>Assignee</th>
              </tr>
            </thead>
            <tbody>
              {issues.map(issue => (
                <tr key={issue.key} style={{ borderBottom: '1px solid rgba(0,0,0,0.05)', transition: 'background 0.2s' }} className="hoverable-row">
                  <td style={{ padding: '12px 20px' }}><input type="checkbox" checked={selectedKeys.has(issue.key)} onChange={() => handleSelect(issue.key)} style={{cursor: 'pointer'}} /></td>
                  <td style={{ padding: '12px 20px', fontWeight: 600, fontSize: 13 }}>
                    <a href={`${instances.find(ins => ins.id === issue.instance_id)?.base_url || jiraUrl}/browse/${issue.key}`} target="_blank" rel="noreferrer" style={{textDecoration: 'none', color: '#0984e3', display: 'flex', alignItems: 'center', gap: 4}}>
                      {issue.key} <ExternalLink size={12} style={{opacity: 0.6}}/>
                    </a>
                  </td>
                  <td style={{ padding: '12px 20px', color: 'var(--text-primary)', fontSize: 13 }}>{issue.fields?.summary}</td>
                  <td style={{ padding: '12px 20px' }}><span className="status-badge" style={{background: 'rgba(9, 132, 227, 0.1)', color: '#0984e3', padding: '4px 10px'}}>{issue.fields?.status?.name}</span></td>
                  <td style={{ padding: '12px 20px', fontSize: 13 }}>{issue.fields?.assignee?.displayName || 'Unassigned'}</td>
                </tr>
              ))}
              {initialLoading ? (
                <tr>
                  <td colSpan={5} style={{padding: 80, textAlign: 'center', color: 'var(--text-secondary)'}}>
                    <div style={{margin: '0 auto 15px auto', width: 30, height: 30, border: '3px solid rgba(0,0,0,0.1)', borderTopColor: 'var(--accent-color)', borderRadius: '50%', animation: 'spin 1s linear infinite'}} />
                    데이터를 불러오는 중입니다...
                  </td>
                </tr>
              ) : issues.length === 0 ? (
                <tr>
                  <td colSpan={5} style={{padding: 80, textAlign: 'center', color: 'var(--text-secondary)'}}>
                    내 담당(어사인)으로 지정된 이슈가 없습니다.
                  </td>
                </tr>
              ) : null}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
