@echo off
setlocal
chcp 65001 > nul

:MENU
cls
echo =========================================
echo Jira Dashboard Project Backup ^& Release
echo =========================================
echo [1] Create Local Backup
echo [2] Release Update to GitHub
echo [3] Exit
echo =========================================
set "OPTION="
set /p OPTION="Select option (1, 2, or 3): "

if "%OPTION%"=="1" goto LOCAL_BACKUP
if "%OPTION%"=="2" goto RELEASE_UPDATE
if "%OPTION%"=="3" goto EOF
echo Invalid input.
pause
goto MENU

:LOCAL_BACKUP
echo.
echo [Starting Local Backup Mode]
set "TIMESTAMP=%date:-=%_%time::=%"
set "TIMESTAMP=%TIMESTAMP: =0%"
set "TIMESTAMP=%TIMESTAMP:.=%"
set "BACKUP_DIR=backup"
set "ARCHIVE_NAME=jiraauto_backup_%TIMESTAMP%.zip"
set "TEMP_DIR=%TEMP%\jiraauto_backup_%TIMESTAMP%"

if not exist "%BACKUP_DIR%" mkdir "%BACKUP_DIR%"
if exist "%TEMP_DIR%" rmdir /s /q "%TEMP_DIR%"
mkdir "%TEMP_DIR%"

echo [1/3] Copying files (excluding unwanted folders)...
robocopy . "%TEMP_DIR%" /E /XD node_modules venv __pycache__ backup .git .gsk .gemini patch temp_restore secrets tools /XF .env .gitignore CONTEXT.md run_dev.bat opencode.json remote_update.bat *.db *.db-shm *.db-wal *.log *.zip > nul

echo [2/3] Zipping files...
powershell -NoProfile -Command "Add-Type -AssemblyName System.IO.Compression.FileSystem; [System.IO.Compression.ZipFile]::CreateFromDirectory('%TEMP_DIR%', '%BACKUP_DIR%\%ARCHIVE_NAME%', [System.IO.Compression.CompressionLevel]::Optimal, $false);"

echo [3/3] Cleaning up...
rmdir /s /q "%TEMP_DIR%"

echo Backup completed successfully!
echo Archive saved to: %BACKUP_DIR%\%ARCHIVE_NAME%
echo =========================================
pause
goto MENU

:RELEASE_UPDATE
echo.
echo [Starting Release Update Mode]
if "%SHADOW_VAULT_URL%"=="" (
    echo [ERROR] SHADOW_VAULT_URL environment variable is not set.
    pause
    goto MENU
)
if "%SHADOW_VAULT_TOKEN%"=="" (
    echo [ERROR] SHADOW_VAULT_TOKEN environment variable is not set.
    pause
    goto MENU
)
if not exist "remote_update.bat" (
    echo [ERROR] remote_update.bat is missing.
    pause
    goto MENU
)

set /p NEW_VERSION="Enter version to deploy (e.g. 1.0.6): "
if "%NEW_VERSION%"=="" (
    echo Version cannot be empty.
    pause
    goto MENU
)

set /p MIN_REQUIRED_VERSION="Enter minimum required version (e.g. 1.0.0, press enter to skip): "

set "TEMP_DIR=%TEMP%\jiraauto_release"
if exist "%TEMP_DIR%" rmdir /s /q "%TEMP_DIR%"
mkdir "%TEMP_DIR%"

echo [1/5] Copying files to temp directory...
robocopy . "%TEMP_DIR%" /E /XD node_modules venv __pycache__ backup .git .gsk .gemini patch temp_restore secrets tools /XF .env .gitignore CONTEXT.md run_dev.bat opencode.json remote_update.bat *.db *.db-shm *.db-wal *.log *.zip > nul

echo [2/5] Creating update.zip...
if exist "update.zip" (
    del /f /q "update.zip"
    if exist "update.zip" (
        echo [ERROR] Cannot delete existing update.zip.
        echo The file is likely open in another program or locked.
        echo Please close it and try again.
        rmdir /s /q "%TEMP_DIR%"
        pause
        goto MENU
    )
)
powershell -NoProfile -Command "Add-Type -AssemblyName System.IO.Compression.FileSystem; [System.IO.Compression.ZipFile]::CreateFromDirectory('%TEMP_DIR%', '.\update.zip', [System.IO.Compression.CompressionLevel]::Optimal, $false);"

rmdir /s /q "%TEMP_DIR%"

echo [3/5] Generating SHA256 hash and version.json...
for /f "delims=" %%H in ('powershell -NoProfile -Command "(Get-FileHash '.\update.zip' -Algorithm SHA256).Hash"') do set "ZIP_HASH=%%H"
for /f "delims=" %%U in ('powershell -NoProfile -Command "(Get-FileHash '.\remote_update.bat' -Algorithm SHA256).Hash"') do set "UPDATER_HASH=%%U"

> version.json echo {
>> version.json echo   "version": "%NEW_VERSION%",
if not "%MIN_REQUIRED_VERSION%"=="" (
>> version.json echo   "min_required_version": "%MIN_REQUIRED_VERSION%",
)
>> version.json echo   "download_url": "https://raw.githubusercontent.com/thkweon/jiraauto-release/main/update.zip",
>> version.json echo   "sha256": "%ZIP_HASH%",
>> version.json echo   "updater_url": "https://raw.githubusercontent.com/thkweon/jiraauto-release/main/remote_update.bat",
>> version.json echo   "updater_sha256": "%UPDATER_HASH%"
>> version.json echo }

echo [4/5] Fetching GitHub token from Vault...
set "GITHUB_TMP_TOKEN="
for /f "delims=" %%i in ('powershell -NoProfile -Command "$headers = @{ 'X-Vault-Token' = $env:SHADOW_VAULT_TOKEN }; $response = Invoke-RestMethod -Uri 'https://%SHADOW_VAULT_URL%/v1/github-kv/data/jiraauto' -Headers $headers -Method Get -ErrorAction SilentlyContinue; if ($null -ne $response.data.data.token) { $response.data.data.token.Trim() }"') do (
    set "GITHUB_TMP_TOKEN=%%i"
)

if "%GITHUB_TMP_TOKEN%"=="" (
    echo [ERROR] Failed to fetch token from Vault. Check network or token validity.
    pause
    goto MENU
)

echo [5/5] Pushing to GitHub...
git add update.zip version.json remote_update.bat
git commit -m "Auto Release v%NEW_VERSION%"
git push https://%GITHUB_TMP_TOKEN%@github.com/thkweon/jiraauto-release.git main

set "GITHUB_TMP_TOKEN="

echo.
echo =========================================
echo Release successfully completed!
echo New version (v%NEW_VERSION%) is uploaded to GitHub.
echo =========================================
pause
goto MENU

:EOF
