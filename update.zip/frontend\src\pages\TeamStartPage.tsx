import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import '../TeamStyles.css';

const API_BASE = 'http://localhost:8000/api';

export default function TeamStartPage() {
  const navigate = useNavigate();
  const [inviteCode, setInviteCode] = useState('');
  const [memberId, setMemberId] = useState(() => localStorage.getItem('teamMemberId') || '');
  const [leaderName, setLeaderName] = useState(() => localStorage.getItem('teamLeaderDisplayName') || '');
  const [status, setStatus] = useState('');

  const updateRole = (role: string) => {
    localStorage.setItem('teamRole', role);
    window.dispatchEvent(new Event('teamRoleChanged'));
  };

  const handleStartAsLeader = async () => {
    const trimmedLeaderName = leaderName.trim();
    try {
      await fetch(`${API_BASE}/team/leader-name`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: trimmedLeaderName }),
      });
      await fetch(`${API_BASE}/team/leader-name/migrate`, { method: 'POST' });
      if (trimmedLeaderName) {
        localStorage.setItem('teamLeaderDisplayName', trimmedLeaderName);
      } else {
        localStorage.removeItem('teamLeaderDisplayName');
      }
    } catch(e) {
      setStatus('팀장 이름 설정을 저장하지 못했습니다.');
      return;
    }
    updateRole('leader');
    navigate('/team-manage');
  };

  const handleJoinAsMember = () => {
    if (!inviteCode.trim() || !memberId.trim()) {
      setStatus('초대 코드와 식별자를 모두 입력해주세요.');
      return;
    }
    try {
      const decoded = atob(inviteCode.trim());
      const data = JSON.parse(decoded);
      if (data.url) {
        localStorage.setItem('teamLeaderUrl', data.url);
        localStorage.setItem('teamMemberId', memberId);
        if (data.team_token) localStorage.setItem('teamToken', data.team_token);
        fetch(`${API_BASE}/team/member-context`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            member_id: memberId,
            leader_url: data.url,
            team_token: data.team_token || '',
          }),
        }).catch(() => {});
        updateRole('member');
        navigate('/team');
      } else {
        setStatus('유효하지 않은 초대 코드입니다.');
      }
    } catch(e) {
      setStatus('초대 코드 형식이 올바르지 않습니다.');
    }
  };

  return (
    <div className="glass-container">
      <div className="grid-2col">
        
        <motion.div whileHover={{ y: -5 }} className="glass-panel hoverable" style={{ display: 'flex', flexDirection: 'column' }}>
          <h3 style={{marginTop:0, fontSize: 22}}>🚀 팀장으로 시작하기</h3>
          <p style={{fontSize: 15, color: 'var(--text-secondary)', flex: 1, lineHeight: 1.6}}>
            내 PC를 팀 서버로 활용하여 팀을 개설합니다. 팀원들을 초대하고 현황을 통합하여 스마트하게 관리하세요.
          </p>
          <div style={{marginTop: 16}}>
            <input
              type="text"
              className="glass-input"
              value={leaderName}
              onChange={e => setLeaderName(e.target.value)}
              placeholder="팀장 표시 이름 (비워두면 Jira 계정 이름 사용)"
            />
          </div>
          <button className="btn-premium" style={{width: '100%', marginTop: 20}} onClick={handleStartAsLeader}>
            팀 개설하기
          </button>
        </motion.div>

        <motion.div whileHover={{ y: -5 }} className="glass-panel hoverable" style={{ display: 'flex', flexDirection: 'column' }}>
          <h3 style={{marginTop:0, fontSize: 22}}>🤝 팀원으로 가입하기</h3>
          <p style={{fontSize: 15, color: 'var(--text-secondary)', marginBottom: 20, lineHeight: 1.6}}>
            팀장이 공유한 초대 코드를 입력하여 팀에 소속됩니다. 데이터는 백그라운드에서 안전하게 동기화됩니다.
          </p>
          <div style={{marginBottom: 15}}>
            <input type="text" className="glass-input" value={inviteCode} onChange={e => setInviteCode(e.target.value)} placeholder="초대 코드 (eyA...)" />
          </div>
          <div style={{marginBottom: 20}}>
            <input type="text" className="glass-input" value={memberId} onChange={e => setMemberId(e.target.value)} placeholder="내 식별자 (예: 홍길동)" />
          </div>
          <button className="btn-glass" style={{width: '100%'}} onClick={handleJoinAsMember}>
            가입하기
          </button>
          {status && <div style={{color: '#ff7675', fontSize: 13, marginTop: 15, fontWeight: 600, textAlign: 'center'}}>{status}</div>}
        </motion.div>

      </div>
    </div>
  );
}
