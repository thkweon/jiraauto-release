export type ClockWidgetPosition =
  | 'left-top'
  | 'left-middle'
  | 'left-bottom'
  | 'right-top'
  | 'right-middle'
  | 'right-bottom';
export type ClockDateDisplay = 'above' | 'below' | 'hidden';
export type ClockTimeFormat = '24' | '12';

export const CLOCK_WORLD_TIME_ZONES = [
  { value: 'Etc/GMT+12', label: '베이커섬', longitude: -176.48, latitude: 0.19 },
  { value: 'Pacific/Pago_Pago', label: '파고파고', longitude: -170.70, latitude: -14.28 },
  { value: 'Pacific/Honolulu', label: '호놀룰루', longitude: -157.86, latitude: 21.31 },
  { value: 'America/Anchorage', label: '앵커리지', longitude: -149.90, latitude: 61.22 },
  { value: 'Pacific/Marquesas', label: '타이오하에', longitude: -140.10, latitude: -8.91 },
  { value: 'America/Los_Angeles', label: '로스앤젤레스', longitude: -118.24, latitude: 34.05 },
  { value: 'America/Vancouver', label: '밴쿠버', longitude: -123.12, latitude: 49.28 },
  { value: 'America/Denver', label: '덴버', longitude: -104.99, latitude: 39.74 },
  { value: 'America/Phoenix', label: '피닉스', longitude: -112.07, latitude: 33.45 },
  { value: 'America/Chicago', label: '시카고', longitude: -87.63, latitude: 41.88 },
  { value: 'America/Mexico_City', label: '멕시코시티', longitude: -99.13, latitude: 19.43 },
  { value: 'America/New_York', label: '뉴욕', longitude: -74.01, latitude: 40.71 },
  { value: 'America/Toronto', label: '토론토', longitude: -79.38, latitude: 43.65 },
  { value: 'America/Halifax', label: '핼리팩스', longitude: -63.58, latitude: 44.65 },
  { value: 'America/Caracas', label: '카라카스', longitude: -66.90, latitude: 10.48 },
  { value: 'America/St_Johns', label: '세인트존스', longitude: -52.71, latitude: 47.56 },
  { value: 'America/Sao_Paulo', label: '상파울루', longitude: -46.63, latitude: -23.55 },
  { value: 'America/Argentina/Buenos_Aires', label: '부에노스아이레스', longitude: -58.38, latitude: -34.60 },
  { value: 'America/Noronha', label: '페르난두지노로냐', longitude: -32.43, latitude: -3.85 },
  { value: 'Atlantic/South_Georgia', label: '킹에드워드포인트', longitude: -36.50, latitude: -54.28 },
  { value: 'Atlantic/Azores', label: '폰타델가다', longitude: -25.68, latitude: 37.74 },
  { value: 'Atlantic/Cape_Verde', label: '프라이아', longitude: -23.51, latitude: 14.93 },
  { value: 'UTC', label: 'UTC', longitude: 0, latitude: 0 },
  { value: 'Atlantic/Reykjavik', label: '레이캬비크', longitude: -21.94, latitude: 64.15 },
  { value: 'Europe/London', label: '런던', longitude: -0.13, latitude: 51.51 },
  { value: 'Africa/Casablanca', label: '카사블랑카', longitude: -7.59, latitude: 33.57 },
  { value: 'Europe/Paris', label: '파리', longitude: 2.35, latitude: 48.86 },
  { value: 'Europe/Berlin', label: '베를린', longitude: 13.41, latitude: 52.52 },
  { value: 'Europe/Madrid', label: '마드리드', longitude: -3.70, latitude: 40.42 },
  { value: 'Africa/Lagos', label: '라고스', longitude: 3.38, latitude: 6.52 },
  { value: 'Europe/Athens', label: '아테네', longitude: 23.73, latitude: 37.98 },
  { value: 'Africa/Cairo', label: '카이로', longitude: 31.24, latitude: 30.04 },
  { value: 'Africa/Johannesburg', label: '요하네스버그', longitude: 28.05, latitude: -26.20 },
  { value: 'Europe/Helsinki', label: '헬싱키', longitude: 24.94, latitude: 60.17 },
  { value: 'Europe/Moscow', label: '모스크바', longitude: 37.62, latitude: 55.76 },
  { value: 'Africa/Nairobi', label: '나이로비', longitude: 36.82, latitude: -1.29 },
  { value: 'Asia/Riyadh', label: '리야드', longitude: 46.68, latitude: 24.71 },
  { value: 'Asia/Tehran', label: '테헤란', longitude: 51.39, latitude: 35.69 },
  { value: 'Asia/Dubai', label: '두바이', longitude: 55.27, latitude: 25.20 },
  { value: 'Asia/Baku', label: '바쿠', longitude: 49.87, latitude: 40.41 },
  { value: 'Asia/Kabul', label: '카불', longitude: 69.21, latitude: 34.56 },
  { value: 'Asia/Karachi', label: '카라치', longitude: 67.00, latitude: 24.86 },
  { value: 'Asia/Tashkent', label: '타슈켄트', longitude: 69.24, latitude: 41.30 },
  { value: 'Asia/Kolkata', label: '콜카타', longitude: 88.36, latitude: 22.57 },
  { value: 'Asia/Kathmandu', label: '카트만두', longitude: 85.32, latitude: 27.72 },
  { value: 'Asia/Dhaka', label: '다카', longitude: 90.41, latitude: 23.81 },
  { value: 'Asia/Yangon', label: '양곤', longitude: 96.17, latitude: 16.84 },
  { value: 'Asia/Bangkok', label: '방콕', longitude: 100.50, latitude: 13.76 },
  { value: 'Asia/Jakarta', label: '자카르타', longitude: 106.85, latitude: -6.21 },
  { value: 'Asia/Ho_Chi_Minh', label: '호찌민', longitude: 106.63, latitude: 10.82 },
  { value: 'Asia/Shanghai', label: '상하이', longitude: 121.47, latitude: 31.23 },
  { value: 'Asia/Hong_Kong', label: '홍콩', longitude: 114.17, latitude: 22.32 },
  { value: 'Asia/Singapore', label: '싱가포르', longitude: 103.82, latitude: 1.35 },
  { value: 'Asia/Taipei', label: '타이베이', longitude: 121.57, latitude: 25.03 },
  { value: 'Australia/Perth', label: '퍼스', longitude: 115.86, latitude: -31.95 },
  { value: 'Australia/Eucla', label: '유클라', longitude: 128.88, latitude: -31.68 },
  { value: 'Asia/Seoul', label: '서울', longitude: 126.98, latitude: 37.57 },
  { value: 'Asia/Tokyo', label: '도쿄', longitude: 139.65, latitude: 35.68 },
  { value: 'Australia/Darwin', label: '다윈', longitude: 130.85, latitude: -12.46 },
  { value: 'Australia/Adelaide', label: '애들레이드', longitude: 138.60, latitude: -34.93 },
  { value: 'Australia/Brisbane', label: '브리즈번', longitude: 153.03, latitude: -27.47 },
  { value: 'Australia/Sydney', label: '시드니', longitude: 151.21, latitude: -33.87 },
  { value: 'Pacific/Port_Moresby', label: '포트모르즈비', longitude: 147.18, latitude: -9.44 },
  { value: 'Australia/Lord_Howe', label: '로드하우섬', longitude: 159.08, latitude: -31.54 },
  { value: 'Pacific/Noumea', label: '누메아', longitude: 166.45, latitude: -22.27 },
  { value: 'Pacific/Guadalcanal', label: '호니아라', longitude: 159.97, latitude: -9.45 },
  { value: 'Pacific/Norfolk', label: '킹스턴', longitude: 167.96, latitude: -29.06 },
  { value: 'Pacific/Auckland', label: '오클랜드', longitude: 174.76, latitude: -36.85 },
  { value: 'Pacific/Fiji', label: '수바', longitude: 178.45, latitude: -18.12 },
  { value: 'Pacific/Chatham', label: '채텀섬', longitude: -176.56, latitude: -43.95 },
  { value: 'Pacific/Tongatapu', label: '누쿠알로파', longitude: -175.20, latitude: -21.14 },
  { value: 'Pacific/Apia', label: '아피아', longitude: -171.75, latitude: -13.85 },
  { value: 'Pacific/Kiritimati', label: '키리티마티', longitude: -157.43, latitude: 1.87 },
] as const;

export type ClockWorldTimeZone = typeof CLOCK_WORLD_TIME_ZONES[number]['value'];

export interface ClockWidgetSettings {
  enabled: boolean;
  position: ClockWidgetPosition;
  dateDisplay: ClockDateDisplay;
  timeFormat: ClockTimeFormat;
  worldClockEnabled: boolean;
  worldTimeZones: ClockWorldTimeZone[];
}

export const CLOCK_WIDGET_SETTINGS_STORAGE_KEY = 'jiraautoClockWidgetSettings';
export const CLOCK_WIDGET_SETTINGS_CHANGED_EVENT = 'clockWidgetSettingsChanged';

const CLOCK_WIDGET_POSITIONS: ClockWidgetPosition[] = [
  'left-top',
  'left-middle',
  'left-bottom',
  'right-top',
  'right-middle',
  'right-bottom',
];

const DEFAULT_CLOCK_WIDGET_SETTINGS: ClockWidgetSettings = {
  enabled: false,
  position: 'left-middle',
  dateDisplay: 'below',
  timeFormat: '24',
  worldClockEnabled: false,
  worldTimeZones: ['UTC'],
};

const isClockWorldTimeZone = (value: unknown): value is ClockWorldTimeZone => (
  typeof value === 'string' && CLOCK_WORLD_TIME_ZONES.some(option => option.value === value)
);

export const loadClockWidgetSettings = (): ClockWidgetSettings => {
  try {
    const raw = localStorage.getItem(CLOCK_WIDGET_SETTINGS_STORAGE_KEY);
    if (!raw) return DEFAULT_CLOCK_WIDGET_SETTINGS;
    const value = JSON.parse(raw) as Partial<ClockWidgetSettings> & { worldTimeZone?: unknown };
    const rawSavedWorldTimeZones = value.worldTimeZones;
    const savedWorldTimeZones = Array.isArray(rawSavedWorldTimeZones)
      ? [...new Set(rawSavedWorldTimeZones.filter(isClockWorldTimeZone))].slice(0, 5)
      : [];
    const worldTimeZones = Array.isArray(rawSavedWorldTimeZones)
      ? savedWorldTimeZones
      : isClockWorldTimeZone(value.worldTimeZone)
        ? [value.worldTimeZone]
        : DEFAULT_CLOCK_WIDGET_SETTINGS.worldTimeZones;
    return {
      enabled: typeof value.enabled === 'boolean' ? value.enabled : DEFAULT_CLOCK_WIDGET_SETTINGS.enabled,
      position: CLOCK_WIDGET_POSITIONS.includes(value.position as ClockWidgetPosition)
        ? value.position as ClockWidgetPosition
        : DEFAULT_CLOCK_WIDGET_SETTINGS.position,
      dateDisplay: value.dateDisplay === 'above' || value.dateDisplay === 'hidden'
        ? value.dateDisplay
        : DEFAULT_CLOCK_WIDGET_SETTINGS.dateDisplay,
      timeFormat: value.timeFormat === '12' ? '12' : DEFAULT_CLOCK_WIDGET_SETTINGS.timeFormat,
      worldClockEnabled: typeof value.worldClockEnabled === 'boolean'
        ? value.worldClockEnabled
        : DEFAULT_CLOCK_WIDGET_SETTINGS.worldClockEnabled,
      worldTimeZones,
    };
  } catch {
    return DEFAULT_CLOCK_WIDGET_SETTINGS;
  }
};

export const saveClockWidgetSettings = (settings: ClockWidgetSettings) => {
  localStorage.setItem(CLOCK_WIDGET_SETTINGS_STORAGE_KEY, JSON.stringify(settings));
  window.dispatchEvent(new CustomEvent<ClockWidgetSettings>(
    CLOCK_WIDGET_SETTINGS_CHANGED_EVENT,
    { detail: settings },
  ));
};
