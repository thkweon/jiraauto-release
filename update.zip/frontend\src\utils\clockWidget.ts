export type ClockWidgetPosition =
  | 'left-top'
  | 'left-middle'
  | 'left-bottom'
  | 'right-top'
  | 'right-middle'
  | 'right-bottom';
export type ClockDateDisplay = 'above' | 'below' | 'hidden';

export interface ClockWidgetSettings {
  enabled: boolean;
  position: ClockWidgetPosition;
  dateDisplay: ClockDateDisplay;
}

export const CLOCK_WIDGET_SETTINGS_STORAGE_KEY = 'jiraautoClockWidgetSettings';
export const CLOCK_WIDGET_SETTINGS_CHANGED_EVENT = 'clockWidgetSettingsChanged';

const CLOCK_WIDGET_POSITIONS: ClockWidgetPosition[] = [
  'left-top',
  'left-middle',
  'left-bottom',
  'right-top',
  'right-middle',
  'right-bottom',
];

const DEFAULT_CLOCK_WIDGET_SETTINGS: ClockWidgetSettings = {
  enabled: false,
  position: 'left-middle',
  dateDisplay: 'below',
};

export const loadClockWidgetSettings = (): ClockWidgetSettings => {
  try {
    const raw = localStorage.getItem(CLOCK_WIDGET_SETTINGS_STORAGE_KEY);
    if (!raw) return DEFAULT_CLOCK_WIDGET_SETTINGS;
    const value = JSON.parse(raw) as Partial<ClockWidgetSettings>;
    return {
      enabled: typeof value.enabled === 'boolean' ? value.enabled : DEFAULT_CLOCK_WIDGET_SETTINGS.enabled,
      position: CLOCK_WIDGET_POSITIONS.includes(value.position as ClockWidgetPosition)
        ? value.position as ClockWidgetPosition
        : DEFAULT_CLOCK_WIDGET_SETTINGS.position,
      dateDisplay: value.dateDisplay === 'above' || value.dateDisplay === 'hidden'
        ? value.dateDisplay
        : DEFAULT_CLOCK_WIDGET_SETTINGS.dateDisplay,
    };
  } catch {
    return DEFAULT_CLOCK_WIDGET_SETTINGS;
  }
};

export const saveClockWidgetSettings = (settings: ClockWidgetSettings) => {
  localStorage.setItem(CLOCK_WIDGET_SETTINGS_STORAGE_KEY, JSON.stringify(settings));
  window.dispatchEvent(new CustomEvent<ClockWidgetSettings>(
    CLOCK_WIDGET_SETTINGS_CHANGED_EVENT,
    { detail: settings },
  ));
};
