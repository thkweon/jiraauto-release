import json
import unittest

import httpx

import main


class JiraSearchAdapterTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.clients = []

    async def asyncTearDown(self):
        for client in self.clients:
            await client.aclose()

    def instance(self, deployment_type, handler):
        inst = main.JiraInstance(
            1,
            "https://example.atlassian.net" if deployment_type == "cloud" else "https://jira.example.com",
            "token",
            deployment_type=deployment_type,
        )
        client = httpx.AsyncClient(transport=httpx.MockTransport(handler))
        self.clients.append(client)
        inst.http = client
        return inst

    async def test_cloud_search_uses_v3_post_and_next_page_token(self):
        requests = []

        def handler(request):
            requests.append(request)
            return httpx.Response(200, json={"issues": [{"key": "ABC-1"}], "nextPageToken": "page-2", "isLast": False})

        response, page = await main.jira_search_page(
            self.instance("cloud", handler),
            "project = ABC",
            "summary,status",
            cursor="page-1",
        )

        self.assertEqual(200, response.status_code)
        self.assertEqual("page-2", page["next_cursor"])
        self.assertIsNone(page["total"])
        self.assertEqual("POST", requests[0].method)
        self.assertEqual("/rest/api/3/search/jql", requests[0].url.path)
        self.assertEqual(
            {"jql": "project = ABC", "fields": ["summary", "status"], "maxResults": 100, "nextPageToken": "page-1"},
            json.loads(requests[0].content),
        )

    async def test_server_search_keeps_v2_start_at_pagination(self):
        requests = []

        def handler(request):
            requests.append(request)
            return httpx.Response(200, json={"issues": [{"key": "ABC-3"}], "total": 4})

        _, page = await main.jira_search_page(
            self.instance("server", handler),
            "project = ABC",
            ["key"],
            max_results=1,
            cursor=2,
        )

        self.assertEqual(3, page["next_cursor"])
        self.assertEqual(4, page["total"])
        self.assertEqual("GET", requests[0].method)
        self.assertEqual("/rest/api/2/search", requests[0].url.path)
        self.assertEqual("2", requests[0].url.params["startAt"])

    async def test_cloud_count_uses_approximate_count(self):
        requests = []

        def handler(request):
            requests.append(request)
            return httpx.Response(200, json={"count": 37})

        count = await main.jira_issue_count(self.instance("cloud", handler), "project = ABC")

        self.assertEqual(37, count)
        self.assertEqual("/rest/api/3/search/approximate-count", requests[0].url.path)

    async def test_rate_limit_is_retried(self):
        attempts = 0

        def handler(request):
            nonlocal attempts
            attempts += 1
            if attempts == 1:
                return httpx.Response(429, headers={"Retry-After": "0"})
            return httpx.Response(200, json={"issues": [], "total": 0})

        response, _ = await main.jira_search_page(self.instance("server", handler), "project = ABC", ["key"])

        self.assertEqual(200, response.status_code)
        self.assertEqual(2, attempts)

    def test_cloud_comment_uses_adf_mention_with_account_id(self):
        inst = main.JiraInstance(1, "https://example.atlassian.net", "token", deployment_type="cloud")

        payload = main.jira_comment_payload(inst, "확인 부탁드립니다 @[홍길동](abc-123) 감사합니다.")

        nodes = payload["body"]["content"][0]["content"]
        self.assertEqual({"type": "mention", "attrs": {"id": "abc-123", "text": "@홍길동"}}, nodes[1])

    def test_server_comment_keeps_wiki_mention(self):
        inst = main.JiraInstance(1, "https://jira.example.com", "token", deployment_type="server")

        payload = main.jira_comment_payload(inst, "확인 @[홍길동](hong) 부탁드립니다")

        self.assertEqual({"body": "확인 [~hong] 부탁드립니다"}, payload)


if __name__ == "__main__":
    unittest.main()
