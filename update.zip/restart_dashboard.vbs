Option Explicit

Dim WshShell, fso, scriptPath, stopScript, startScript, exitCode
Set WshShell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")

scriptPath = fso.GetParentFolderName(WScript.ScriptFullName)
stopScript = scriptPath & "\stop_dashboard.vbs"
startScript = scriptPath & "\start_dashboard.vbs"

If Not fso.FileExists(stopScript) Then
    MsgBox "Could not find stop_dashboard.vbs.", 16, "Jira Dashboard Restart Failed"
    WScript.Quit 1
End If

If Not fso.FileExists(startScript) Then
    MsgBox "Could not find start_dashboard.vbs.", 16, "Jira Dashboard Restart Failed"
    WScript.Quit 1
End If

' Wait until both dashboard processes have been stopped, then start them again.
exitCode = WshShell.Run("wscript.exe """ & stopScript & """ /silent", 0, True)
If exitCode <> 0 Then
    MsgBox "The dashboard could not be stopped.", 16, "Jira Dashboard Restart Failed"
    WScript.Quit exitCode
End If

WScript.Sleep 1000
WshShell.Run "wscript.exe """ & startScript & """", 0, False
