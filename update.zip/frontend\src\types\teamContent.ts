export interface CommentCountSource {
  comment_count?: number;
  commentCount?: number;
  comments_count?: number;
  commentsCount?: number;
  repliesCount?: number;
  replyCount?: number;
}

export interface TeamContent extends CommentCountSource {
  id: string;
  author: string;
  content: string;
  created_at: string;
  edit_count: number;
}

export interface TeamComment {
  id: string;
  author: string;
  content: string;
  created_at: string;
  edit_count: number;
}

export interface TeamUserIdentity {
  name?: string;
  displayName?: string;
}

export interface TeamContentItemProps {
  role: string | null;
  memberId: string | null;
  leaderUrl: string | null;
  onRefresh: () => void | Promise<void>;
}
