export type CalendarWidgetPosition =
  | 'left-top'
  | 'left-middle'
  | 'left-bottom'
  | 'right-top'
  | 'right-middle'
  | 'right-bottom';

export interface CalendarWidgetSettings {
  enabled: boolean;
  position: CalendarWidgetPosition;
  enabledEventSources: string[];
  eventSourceColors: Record<string, string>;
  eventSourceLineColors: Record<string, string>;
  outlookCalendarFolder: {
    entryId: string;
    storeId: string;
    label: string;
  } | null;
}

export const CALENDAR_WIDGET_SETTINGS_STORAGE_KEY = 'jiraautoCalendarWidgetSettings';
export const CALENDAR_WIDGET_SETTINGS_CHANGED_EVENT = 'calendarWidgetSettingsChanged';

const CALENDAR_WIDGET_POSITIONS: CalendarWidgetPosition[] = [
  'left-top',
  'left-middle',
  'left-bottom',
  'right-top',
  'right-middle',
  'right-bottom',
];

const CALENDAR_EVENT_SOURCE_IDS = ['d-day', 'outlook'];

const DEFAULT_CALENDAR_WIDGET_SETTINGS: CalendarWidgetSettings = {
  enabled: false,
  position: 'left-top',
  enabledEventSources: [],
  eventSourceColors: {
    'd-day': '#dc2626',
    outlook: '#2563eb',
  },
  eventSourceLineColors: {
    outlook: '#2563eb',
  },
  outlookCalendarFolder: null,
};

const isHexColor = (value: unknown): value is string => (
  typeof value === 'string' && /^#[0-9a-f]{6}$/i.test(value)
);

export const loadCalendarWidgetSettings = (): CalendarWidgetSettings => {
  try {
    const raw = localStorage.getItem(CALENDAR_WIDGET_SETTINGS_STORAGE_KEY);
    if (!raw) return DEFAULT_CALENDAR_WIDGET_SETTINGS;
    const value = JSON.parse(raw) as Partial<CalendarWidgetSettings>;
    return {
      enabled: typeof value.enabled === 'boolean' ? value.enabled : DEFAULT_CALENDAR_WIDGET_SETTINGS.enabled,
      position: CALENDAR_WIDGET_POSITIONS.includes(value.position as CalendarWidgetPosition)
        ? value.position as CalendarWidgetPosition
        : DEFAULT_CALENDAR_WIDGET_SETTINGS.position,
      enabledEventSources: Array.isArray(value.enabledEventSources)
        ? value.enabledEventSources.filter(source => CALENDAR_EVENT_SOURCE_IDS.includes(source))
        : DEFAULT_CALENDAR_WIDGET_SETTINGS.enabledEventSources,
      eventSourceColors: {
        'd-day': isHexColor(value.eventSourceColors?.['d-day'])
          ? value.eventSourceColors['d-day']
          : DEFAULT_CALENDAR_WIDGET_SETTINGS.eventSourceColors['d-day'],
        outlook: isHexColor(value.eventSourceColors?.outlook)
          ? value.eventSourceColors.outlook
          : DEFAULT_CALENDAR_WIDGET_SETTINGS.eventSourceColors.outlook,
      },
      eventSourceLineColors: {
        outlook: isHexColor(value.eventSourceLineColors?.outlook)
          ? value.eventSourceLineColors.outlook
          : DEFAULT_CALENDAR_WIDGET_SETTINGS.eventSourceLineColors.outlook,
      },
      outlookCalendarFolder: (
        value.outlookCalendarFolder
        && typeof value.outlookCalendarFolder.entryId === 'string'
        && typeof value.outlookCalendarFolder.storeId === 'string'
        && typeof value.outlookCalendarFolder.label === 'string'
      ) ? value.outlookCalendarFolder : null,
    };
  } catch {
    return DEFAULT_CALENDAR_WIDGET_SETTINGS;
  }
};

export const saveCalendarWidgetSettings = (settings: CalendarWidgetSettings) => {
  localStorage.setItem(CALENDAR_WIDGET_SETTINGS_STORAGE_KEY, JSON.stringify(settings));
  window.dispatchEvent(new CustomEvent<CalendarWidgetSettings>(
    CALENDAR_WIDGET_SETTINGS_CHANGED_EVENT,
    { detail: settings },
  ));
};
