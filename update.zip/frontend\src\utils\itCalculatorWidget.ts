export type ITCalculatorPlacement =
  | 'left-top-middle'
  | 'left-middle-bottom'
  | 'right-top-middle'
  | 'right-middle-bottom';

export type ITCalculatorTool =
  | 'cidr'
  | 'radix'
  | 'data-size'
  | 'unix-timestamp'
  | 'transfer-time';
export type ITCalculatorOccupiedPosition =
  | 'left-top'
  | 'left-middle'
  | 'left-bottom'
  | 'right-top'
  | 'right-middle'
  | 'right-bottom';

export interface ITCalculatorWidgetSettings {
  enabled: boolean;
  placement: ITCalculatorPlacement;
  enabledTools: ITCalculatorTool[];
}

export const IT_CALCULATOR_WIDGET_SETTINGS_STORAGE_KEY = 'jiraautoITCalculatorWidgetSettings';
export const IT_CALCULATOR_WIDGET_SETTINGS_CHANGED_EVENT = 'itCalculatorWidgetSettingsChanged';

export const IT_CALCULATOR_PLACEMENTS: ITCalculatorPlacement[] = [
  'left-top-middle',
  'left-middle-bottom',
  'right-top-middle',
  'right-middle-bottom',
];

export const IT_CALCULATOR_TOOLS: ITCalculatorTool[] = [
  'cidr',
  'radix',
  'data-size',
  'unix-timestamp',
  'transfer-time',
];

const DEFAULT_SETTINGS: ITCalculatorWidgetSettings = {
  enabled: false,
  placement: 'left-top-middle',
  enabledTools: ['cidr'],
};

export const getITCalculatorOccupiedPositions = (
  placement: ITCalculatorPlacement,
): ITCalculatorOccupiedPosition[] => {
  const [side, first, second] = placement.split('-');
  return [
    `${side}-${first}` as ITCalculatorOccupiedPosition,
    `${side}-${second}` as ITCalculatorOccupiedPosition,
  ];
};

export const loadITCalculatorWidgetSettings = (): ITCalculatorWidgetSettings => {
  try {
    const raw = localStorage.getItem(IT_CALCULATOR_WIDGET_SETTINGS_STORAGE_KEY);
    if (!raw) return DEFAULT_SETTINGS;
    const value = JSON.parse(raw) as Partial<ITCalculatorWidgetSettings>;
    return {
      enabled: typeof value.enabled === 'boolean' ? value.enabled : DEFAULT_SETTINGS.enabled,
      placement: IT_CALCULATOR_PLACEMENTS.includes(value.placement as ITCalculatorPlacement)
        ? value.placement as ITCalculatorPlacement
        : DEFAULT_SETTINGS.placement,
      enabledTools: Array.isArray(value.enabledTools)
        ? value.enabledTools.filter(
          (tool): tool is ITCalculatorTool => IT_CALCULATOR_TOOLS.includes(tool as ITCalculatorTool),
        ).slice(0, 1)
        : [],
    };
  } catch {
    return DEFAULT_SETTINGS;
  }
};

export const saveITCalculatorWidgetSettings = (settings: ITCalculatorWidgetSettings) => {
  localStorage.setItem(IT_CALCULATOR_WIDGET_SETTINGS_STORAGE_KEY, JSON.stringify(settings));
  window.dispatchEvent(new CustomEvent<ITCalculatorWidgetSettings>(
    IT_CALCULATOR_WIDGET_SETTINGS_CHANGED_EVENT,
    { detail: settings },
  ));
};
