from __future__ import annotations

from datetime import datetime, timezone
from typing import Any
from urllib.parse import urlparse, urlunparse

import httpx
from prometheus_client.parser import text_string_to_metric_families


STATUS_NAMES = {0: "down", 1: "up", 2: "pending", 3: "maintenance"}


class UptimeKumaError(Exception):
    def __init__(self, code: str, message: str, status_code: int = 502):
        super().__init__(message)
        self.code = code
        self.message = message
        self.status_code = status_code


def normalize_uptime_kuma_url(value: str) -> str:
    candidate = value.strip().rstrip("/")
    if not candidate:
        raise UptimeKumaError("invalid_url", "Uptime Kuma 주소를 입력해 주세요.", 400)
    if not candidate.lower().startswith(("http://", "https://")):
        candidate = f"http://{candidate}"
    parsed = urlparse(candidate)
    if parsed.scheme not in {"http", "https"} or not parsed.hostname:
        raise UptimeKumaError("invalid_url", "HTTP 또는 HTTPS Uptime Kuma 주소만 사용할 수 있습니다.", 400)
    if parsed.username or parsed.password or parsed.query or parsed.fragment:
        raise UptimeKumaError("invalid_url", "주소에는 사용자 정보, 쿼리 또는 프래그먼트를 포함할 수 없습니다.", 400)
    if parsed.path not in {"", "/"}:
        raise UptimeKumaError("invalid_url", "Uptime Kuma 기본 주소만 입력해 주세요.", 400)
    return urlunparse((parsed.scheme, parsed.netloc, "", "", "", ""))


def parse_uptime_kuma_metrics(content: str, base_url: str) -> dict[str, Any]:
    monitors: dict[tuple[str, str], dict[str, Any]] = {}
    supported = {
        "monitor_status",
        "monitor_response_time",
        "monitor_uptime_ratio",
        "monitor_cert_days_remaining",
        "monitor_cert_is_valid",
    }
    try:
        families = list(text_string_to_metric_families(content))
    except Exception as exc:
        raise UptimeKumaError("invalid_metrics", "응답이 Uptime Kuma metrics 형식이 아닙니다.") from exc

    for family in families:
        for sample in family.samples:
            if sample.name not in supported:
                continue
            labels = sample.labels
            monitor_id = labels.get("monitor_id")
            monitor_name = labels.get("monitor_name")
            if not monitor_id or not monitor_name:
                continue
            vault = labels.get("vault", "")
            key = (vault, monitor_id)
            monitor = monitors.setdefault(key, {
                "id": monitor_id,
                "name": monitor_name,
                "vault": vault,
                "type": labels.get("monitor_type", ""),
                "status": "pending",
                "response_time_ms": None,
                "uptime_24h": None,
                "certificate_valid": None,
                "certificate_days_remaining": None,
                "dashboard_url": f"{base_url}/dashboard/{monitor_id}",
            })
            value = float(sample.value)
            if sample.name == "monitor_status":
                monitor["status"] = STATUS_NAMES.get(int(value), "pending")
            elif sample.name == "monitor_response_time":
                monitor["response_time_ms"] = round(value, 1)
            elif sample.name == "monitor_uptime_ratio" and labels.get("window") == "1d":
                monitor["uptime_24h"] = round(value, 6)
            elif sample.name == "monitor_cert_is_valid":
                monitor["certificate_valid"] = value == 1
            elif sample.name == "monitor_cert_days_remaining":
                monitor["certificate_days_remaining"] = int(value)

    if not monitors:
        raise UptimeKumaError("no_monitors", "metrics 응답에서 Uptime Kuma 모니터를 찾지 못했습니다.")

    priority = {"down": 0, "pending": 1, "maintenance": 2, "up": 3}
    monitor_list = sorted(monitors.values(), key=lambda item: (priority[item["status"]], item["name"].lower()))
    summary = {"total": len(monitor_list), "up": 0, "down": 0, "pending": 0, "maintenance": 0}
    for monitor in monitor_list:
        summary[monitor["status"]] += 1
    return {
        "connected": True,
        "base_url": base_url,
        "updated_at": datetime.now(timezone.utc).isoformat(),
        "summary": summary,
        "monitors": monitor_list,
    }


async def fetch_uptime_kuma_summary(base_url: str, verify_ssl: bool = True) -> dict[str, Any]:
    normalized = normalize_uptime_kuma_url(base_url)
    timeout = httpx.Timeout(8.0, connect=4.0)
    try:
        async with httpx.AsyncClient(timeout=timeout, verify=verify_ssl, follow_redirects=False) as client:
            response = await client.get(f"{normalized}/metrics", headers={"Accept": "text/plain"})
    except httpx.TimeoutException as exc:
        raise UptimeKumaError("timeout", "Uptime Kuma 연결 시간이 초과되었습니다.") from exc
    except httpx.RequestError as exc:
        raise UptimeKumaError("connection_failed", "Uptime Kuma 서버에 연결할 수 없습니다.") from exc
    if response.is_redirect:
        raise UptimeKumaError("authentication_required", "인증 화면으로 이동되어 metrics를 읽을 수 없습니다.", 401)
    if response.status_code in {401, 403}:
        raise UptimeKumaError("authentication_required", "Uptime Kuma metrics 인증이 필요합니다.", 401)
    if response.status_code != 200:
        raise UptimeKumaError("unexpected_status", f"Uptime Kuma가 HTTP {response.status_code}을 반환했습니다.")
    if "text/plain" not in response.headers.get("content-type", "").lower():
        raise UptimeKumaError("invalid_metrics", "Uptime Kuma metrics 대신 다른 형식의 응답을 받았습니다.")
    return parse_uptime_kuma_metrics(response.text, normalized)
