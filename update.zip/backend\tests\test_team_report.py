import unittest

import main


class TeamReportWorklogTests(unittest.TestCase):
    def test_component_names_support_empty_and_multiple_values(self):
        self.assertEqual([], main._team_report_component_names({}))
        self.assertEqual(
            ["Checkout", "Payments"],
            main._team_report_component_names({
                "components": [
                    {"id": "1", "name": "Checkout"},
                    {"id": "2", "name": "Payments"},
                    {"id": "3"},
                    None,
                ],
            }),
        )

    def test_delegated_merge_preserves_instance_and_components(self):
        worklog = {
            "worklogId": "100",
            "accountId": "member-1",
            "authorAccountId": "member-1",
            "issueKey": "PAY-1",
            "issueComponents": ["Checkout", "Payments"],
            "instance_name": "gmarket",
            "issueUrl": "https://jira.example.com/browse/PAY-1",
            "started": "2026-08-13T09:00:00+0900",
            "timeSpentSeconds": 3600,
        }
        merged = main._merge_team_report_results(
            [{
                "result": {
                    "members": [{
                        "accountId": "member-1",
                        "totalSeconds": 3600,
                        "issueCount": 1,
                        "worklogCount": 1,
                    }],
                    "worklogs": [worklog],
                },
                "reportMembers": [{
                    "accountId": "member-1",
                    "displayName": "Member One",
                }],
                "sourceMemberId": "member-1",
            }],
            [],
        )

        self.assertEqual("gmarket", merged["worklogs"][0]["instance_name"])
        self.assertEqual(["Checkout", "Payments"], merged["worklogs"][0]["issueComponents"])


if __name__ == "__main__":
    unittest.main()
