import unittest

from settings_service import derive_jira_account_name


class JiraAccountNameTests(unittest.TestCase):
    def test_server_domain_uses_company_label(self):
        self.assertEqual(derive_jira_account_name("https://jira.gmarket.com"), "gmarket")

    def test_multi_part_country_suffix_is_removed(self):
        self.assertEqual(derive_jira_account_name("https://jira.mysmilepay.co.kr"), "mysmilepay")

    def test_atlassian_cloud_uses_tenant_label(self):
        self.assertEqual(
            derive_jira_account_name("https://smilepayments.atlassian.net"),
            "smilepayments",
        )

    def test_port_path_and_trailing_slash_do_not_affect_name(self):
        self.assertEqual(
            derive_jira_account_name("https://jira.gmarket.com:8443/jira/"),
            "gmarket",
        )

    def test_domain_like_company_label_is_not_removed(self):
        self.assertEqual(derive_jira_account_name("https://jira.app.com"), "app")

    def test_uppercase_scheme_is_accepted(self):
        self.assertEqual(derive_jira_account_name("HTTPS://smilepayments.atlassian.net"), "smilepayments")

    def test_unknown_labels_are_preserved_as_fallback_identity(self):
        self.assertEqual(
            derive_jira_account_name("https://jira.internal.example.xyz"),
            "internal.example.xyz",
        )


if __name__ == "__main__":
    unittest.main()
