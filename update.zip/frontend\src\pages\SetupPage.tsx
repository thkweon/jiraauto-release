import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { CheckCircle, Eye, EyeOff, Loader2 } from 'lucide-react';
import '../App.css';

const API_BASE = 'http://localhost:8000/api';
type DeploymentType = 'cloud' | 'server' | 'unknown';

interface TestResult {
  ok: boolean;
  display_name?: string;
  username?: string;
  message?: string;
  certificate_error?: boolean;
}

const defaultExpiration = () => {
  const value = new Date();
  value.setDate(value.getDate() + 365);
  return value.toISOString().slice(0, 10);
};

export default function SetupPage() {
  const navigate = useNavigate();
  const [baseUrl, setBaseUrl] = useState('');
  const [deploymentType, setDeploymentType] = useState<DeploymentType>('unknown');
  const [email, setEmail] = useState('');
  const [token, setToken] = useState('');
  const [tokenExpiresAt, setTokenExpiresAt] = useState(defaultExpiration);
  const [verifySsl, setVerifySsl] = useState(true);
  const [showToken, setShowToken] = useState(false);
  const [detecting, setDetecting] = useState(false);
  const [testing, setTesting] = useState(false);
  const [saving, setSaving] = useState(false);
  const [testResult, setTestResult] = useState<TestResult | null>(null);
  const [autoTracking, setAutoTracking] = useState(false);
  const [trackingProjects, setTrackingProjects] = useState('');
  const [error, setError] = useState('');

  const invalidateTest = () => setTestResult(null);

  const detectType = async () => {
    if (!baseUrl.trim()) return;
    setDetecting(true);
    setError('');
    invalidateTest();
    try {
      const res = await fetch(`${API_BASE}/settings/jira/accounts/detect`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ base_url: baseUrl }),
      });
      const data = await res.json();
      if (data.ok) {
        setDeploymentType(data.deployment_type);
        if (data.base_url) setBaseUrl(data.base_url);
      }
      else setError('Jira 유형을 자동으로 확인하지 못했습니다. 유형을 직접 선택해 주세요.');
    } catch {
      setError('Jira 유형을 자동으로 확인하지 못했습니다. 유형을 직접 선택해 주세요.');
    } finally {
      setDetecting(false);
    }
  };

  const requestTest = async (ssl: boolean): Promise<TestResult> => {
    const res = await fetch(`${API_BASE}/settings/jira/accounts/test`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ base_url: baseUrl, token, deployment_type: deploymentType, email, verify_ssl: ssl }),
    });
    return res.json();
  };

  const testConnection = async () => {
    setTesting(true); setError(''); invalidateTest();
    try {
      let ssl = true;
      let data = await requestTest(true);
      if (!data.ok && data.certificate_error) {
        const approved = window.confirm(
          'Jira 서버의 SSL 인증서를 확인할 수 없습니다.\n\n사내 SWG 또는 SSL 검사 프록시 환경에서도 이 오류가 발생할 수 있습니다. 조직에서 승인한 SWG인지 확인한 후 진행하세요. 승인되지 않은 네트워크에서는 계정 정보가 노출될 수 있습니다.\n\n인증서 검증 없이 다시 시도할까요?',
        );
        if (approved) { ssl = false; data = await requestTest(false); }
      }
      setVerifySsl(ssl);
      setTestResult(data);
      if (!data.ok) setError(data.message || 'Jira 연결 테스트에 실패했습니다.');
    } catch { setError('Jira 연결을 확인하지 못했습니다.'); }
    finally { setTesting(false); }
  };

  const save = async () => {
    if (!testResult?.ok) return;
    setSaving(true); setError('');
    try {
      const accountRes = await fetch(`${API_BASE}/settings/jira/accounts/1`, {
        method: 'PUT', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          base_url: baseUrl, token, scope: 'user', deployment_type: deploymentType,
          auth_type: deploymentType === 'cloud' ? 'basic_api_token' : 'bearer_pat',
          email: deploymentType === 'cloud' ? email : null,
          token_expires_at: deploymentType === 'cloud' ? tokenExpiresAt : null,
          verify_ssl: verifySsl,
        }),
      });
      if (!accountRes.ok) { const data = await accountRes.json(); setError(data.detail || 'Jira 계정 저장에 실패했습니다.'); return; }
      await fetch(`${API_BASE}/settings/time-tracking`, {
        method: 'PUT', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ enabled: autoTracking, tracking_projects: trackingProjects.split(',').map(p => p.trim()).filter(Boolean), scope: 'user' }),
      });
      window.dispatchEvent(new Event('jiraAccountsChanged'));
      navigate('/');
    } catch { setError('초기 설정 저장에 실패했습니다.'); }
    finally { setSaving(false); }
  };

  const canTest = Boolean(baseUrl && token && deploymentType !== 'unknown' && (deploymentType !== 'cloud' || (email && tokenExpiresAt)));

  return (
    <div style={{ maxWidth: 760, margin: '0 auto', padding: '32px 20px' }}>
      <div className="glass-panel" style={{ padding: 28 }}>
        <h1 style={{ margin: 0, fontSize: 22 }}>JiraAuto 초기 설정</h1>
        <p style={{ color: 'var(--text-secondary)', lineHeight: 1.6, fontSize: 14 }}>연결할 Jira 계정을 등록하세요. 인증 정보는 Windows 사용자 환경에만 저장됩니다.</p>

        <div className="form-group"><label>Jira 주소</label><div style={{ display: 'flex', gap: 8 }}>
          <input className="glass-input" value={baseUrl} onChange={e => { setBaseUrl(e.target.value); setDeploymentType('unknown'); invalidateTest(); }} onBlur={() => void detectType()} placeholder="https://jira.company.com" />
          <button className="btn-secondary" type="button" onClick={() => void detectType()} disabled={!baseUrl || detecting}>{detecting ? '확인 중...' : '유형 확인'}</button>
        </div></div>

        <div className="form-group"><label>Jira 유형</label><select className="glass-input" value={deploymentType} onChange={e => { setDeploymentType(e.target.value as DeploymentType); setToken(''); setEmail(''); setVerifySsl(true); invalidateTest(); }}>
          <option value="unknown">선택해 주세요</option><option value="server">Jira Server / Data Center</option><option value="cloud">Jira Cloud</option>
        </select></div>

        {deploymentType === 'cloud' && <>
          <div className="form-group"><label>Atlassian 계정 이메일</label><input className="glass-input" type="email" value={email} onChange={e => { setEmail(e.target.value); invalidateTest(); }} /></div>
        </>}

        {deploymentType !== 'unknown' && <div style={{ display: 'grid', gridTemplateColumns: deploymentType === 'cloud' ? 'minmax(0, 1fr) 190px' : '1fr', gap: 12, alignItems: 'end' }}>
          <div className="form-group"><label>{deploymentType === 'cloud' ? 'Jira Cloud API 토큰' : 'Bearer PAT'}</label><div style={{ display: 'flex', gap: 8 }}>
            <input className="glass-input" type={showToken ? 'text' : 'password'} value={token} onChange={e => { setToken(e.target.value); setVerifySsl(true); invalidateTest(); }} style={{ flex: 1 }} />
            <button className="btn-secondary" onClick={() => setShowToken(v => !v)} type="button">{showToken ? <EyeOff size={16} /> : <Eye size={16} />}</button>
          </div></div>
          {deploymentType === 'cloud' && <div className="form-group"><label>API 토큰 만료일</label><input className="glass-input" type="date" value={tokenExpiresAt} min={new Date().toISOString().slice(0, 10)} onChange={e => { setTokenExpiresAt(e.target.value); invalidateTest(); }} /></div>}
        </div>}

        <div style={{ display: 'flex', justifyContent: 'space-between', gap: 12, alignItems: 'center' }}>
          <button className="btn-secondary" onClick={() => void testConnection()} disabled={!canTest || testing}>{testing ? '확인 중...' : '연결 테스트'}</button>
          {testResult?.ok && <div style={{ color: '#078f55', display: 'flex', gap: 8, fontSize: 13 }}><CheckCircle size={16} />{testResult.display_name || testResult.username} 계정으로 연결되었습니다.</div>}
        </div>

        <div style={{ marginTop: 26, paddingTop: 22, borderTop: '1px solid rgba(0,0,0,0.08)' }}>
          <label style={{ display: 'flex', gap: 8, fontWeight: 700 }}><input type="checkbox" checked={autoTracking} onChange={e => setAutoTracking(e.target.checked)} />시간 추적 자동화 사용</label>
          <input className="glass-input" value={trackingProjects} onChange={e => setTrackingProjects(e.target.value)} placeholder="프로젝트 키: SSO,JIRA,DEV" disabled={!autoTracking} />
        </div>
        {error && <div style={{ marginTop: 18, color: '#b00020', background: '#ffe8e8', padding: 12, borderRadius: 8 }}>{error}</div>}
        <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 24 }}><button className="btn-premium" onClick={() => void save()} disabled={!testResult?.ok || saving}>{saving ? <Loader2 size={16} /> : '설정 완료'}</button></div>
      </div>
    </div>
  );
}
