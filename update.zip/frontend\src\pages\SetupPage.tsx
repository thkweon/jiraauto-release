import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { CheckCircle, Eye, EyeOff, Loader2 } from 'lucide-react';
import '../App.css';

const API_BASE = 'http://localhost:8000/api';

interface TestResult {
  ok: boolean;
  display_name?: string;
  username?: string;
  message?: string;
  status_code?: number;
}

export default function SetupPage() {
  const navigate = useNavigate();
  const [baseUrl, setBaseUrl] = useState('');
  const [token, setToken] = useState('');
  const [showToken, setShowToken] = useState(false);
  const [testing, setTesting] = useState(false);
  const [saving, setSaving] = useState(false);
  const [testResult, setTestResult] = useState<TestResult | null>(null);
  const [autoTracking, setAutoTracking] = useState(false);
  const [trackingProjects, setTrackingProjects] = useState('');
  const [error, setError] = useState('');

  const testConnection = async () => {
    setTesting(true);
    setError('');
    setTestResult(null);
    try {
      const res = await fetch(`${API_BASE}/settings/jira/accounts/test`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ base_url: baseUrl, token }),
      });
      const data = await res.json();
      setTestResult(data);
      if (!data.ok) setError(data.message || 'Connection test failed.');
    } catch {
      setError('Failed to test Jira connection.');
    } finally {
      setTesting(false);
    }
  };

  const save = async () => {
    setSaving(true);
    setError('');
    try {
      const accountRes = await fetch(`${API_BASE}/settings/jira/accounts/1`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ base_url: baseUrl, token, scope: 'user' }),
      });
      if (!accountRes.ok) {
        const data = await accountRes.json();
        setError(data.detail || 'Failed to save Jira account.');
        return;
      }
      await fetch(`${API_BASE}/settings/time-tracking`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          enabled: autoTracking,
          tracking_projects: trackingProjects.split(',').map(p => p.trim()).filter(Boolean),
          scope: 'user',
        }),
      });
      navigate('/');
    } catch {
      setError('Failed to save setup.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div style={{ maxWidth: 760, margin: '0 auto', padding: '32px 20px' }}>
      <div className="glass-panel" style={{ padding: 28 }}>
        <h1 style={{ marginTop: 0 }}>JiraAuto Setup</h1>
        <p style={{ color: 'var(--text-secondary)', lineHeight: 1.6 }}>
          Connect at least one Jira account. Your Jira token is stored in this Windows user environment only and is not sent to the license server.
        </p>

        <div className="form-group">
          <label>Jira URL</label>
          <input className="glass-input" value={baseUrl} onChange={e => setBaseUrl(e.target.value)} placeholder="https://jira.company.com" />
        </div>

        <div className="form-group">
          <label>Bearer Token</label>
          <div style={{ display: 'flex', gap: 8 }}>
            <input
              className="glass-input"
              type={showToken ? 'text' : 'password'}
              value={token}
              onChange={e => setToken(e.target.value)}
              placeholder="Paste Jira bearer token"
              style={{ flex: 1 }}
            />
            <button className="btn-secondary" onClick={() => setShowToken(v => !v)} type="button">
              {showToken ? <EyeOff size={16} /> : <Eye size={16} />}
            </button>
          </div>
        </div>

        <div style={{ display: 'flex', justifyContent: 'space-between', gap: 12, alignItems: 'center' }}>
          <button className="btn-secondary" onClick={testConnection} disabled={!baseUrl || !token || testing}>
            {testing ? 'Testing...' : 'Test connection'}
          </button>
          {testResult?.ok && (
            <div style={{ color: '#078f55', display: 'flex', alignItems: 'center', gap: 8, fontSize: 13 }}>
              <CheckCircle size={16} />
              Connected as {testResult.display_name || testResult.username}
            </div>
          )}
        </div>

        <div style={{ marginTop: 26, paddingTop: 22, borderTop: '1px solid rgba(0,0,0,0.08)' }}>
          <label style={{ display: 'flex', gap: 8, alignItems: 'center', fontWeight: 700 }}>
            <input type="checkbox" checked={autoTracking} onChange={e => setAutoTracking(e.target.checked)} />
            Enable automatic time tracking
          </label>
          <p style={{ color: 'var(--text-secondary)', fontSize: 13 }}>
            This can update Jira worklogs when issues are completed. Keep it disabled unless you need it.
          </p>
          <input
            className="glass-input"
            value={trackingProjects}
            onChange={e => setTrackingProjects(e.target.value)}
            placeholder="Project keys, e.g. SSO,JIRA,DEV"
            disabled={!autoTracking}
          />
        </div>

        {error && <div style={{ marginTop: 18, color: '#b00020', background: '#ffe8e8', padding: 12, borderRadius: 8 }}>{error}</div>}

        <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 24 }}>
          <button className="btn-premium" onClick={save} disabled={!testResult?.ok || saving}>
            {saving ? <Loader2 size={16} /> : 'Finish setup'}
          </button>
        </div>
      </div>
    </div>
  );
}
