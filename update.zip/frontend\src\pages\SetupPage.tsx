import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { CheckCircle, Eye, EyeOff, Loader2 } from 'lucide-react';
import '../App.css';

const API_BASE = 'http://localhost:8000/api';

interface TestResult {
  ok: boolean;
  display_name?: string;
  username?: string;
  message?: string;
  status_code?: number;
}

export default function SetupPage() {
  const navigate = useNavigate();
  const [baseUrl, setBaseUrl] = useState('');
  const [token, setToken] = useState('');
  const [showToken, setShowToken] = useState(false);
  const [testing, setTesting] = useState(false);
  const [saving, setSaving] = useState(false);
  const [testResult, setTestResult] = useState<TestResult | null>(null);
  const [autoTracking, setAutoTracking] = useState(false);
  const [trackingProjects, setTrackingProjects] = useState('');
  const [error, setError] = useState('');

  const testConnection = async () => {
    setTesting(true);
    setError('');
    setTestResult(null);
    try {
      const res = await fetch(`${API_BASE}/settings/jira/accounts/test`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ base_url: baseUrl, token }),
      });
      const data = await res.json();
      setTestResult(data);
      if (!data.ok) setError(data.message || 'Jira 연결 테스트에 실패했습니다.');
    } catch {
      setError('Jira 연결을 확인하지 못했습니다.');
    } finally {
      setTesting(false);
    }
  };

  const save = async () => {
    setSaving(true);
    setError('');
    try {
      const accountRes = await fetch(`${API_BASE}/settings/jira/accounts/1`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ base_url: baseUrl, token, scope: 'user' }),
      });
      if (!accountRes.ok) {
        const data = await accountRes.json();
        setError(data.detail || 'Jira 계정 저장에 실패했습니다.');
        return;
      }
      await fetch(`${API_BASE}/settings/time-tracking`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          enabled: autoTracking,
          tracking_projects: trackingProjects.split(',').map(p => p.trim()).filter(Boolean),
          scope: 'user',
        }),
      });
      window.dispatchEvent(new Event('jiraAccountsChanged'));
      navigate('/');
    } catch {
      setError('초기 설정 저장에 실패했습니다.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div style={{ maxWidth: 760, margin: '0 auto', padding: '32px 20px' }}>
      <div className="glass-panel" style={{ padding: 28 }}>
        <h1 style={{ margin: 0, fontSize: 22, fontWeight: 700, color: 'var(--text-primary)', letterSpacing: 0 }}>
          JiraAuto 초기 설정
        </h1>
        <p style={{ color: 'var(--text-secondary)', lineHeight: 1.6, fontSize: 14, margin: '10px 0 24px' }}>
          JiraAuto를 사용하려면 먼저 Jira 계정 하나를 연결해야 합니다. 입력한 Jira 토큰은 이 Windows 사용자 환경에만 저장되며, 정품 인증 서버로 전송되지 않습니다.
        </p>

        <div className="form-group">
          <label>Jira 주소</label>
          <input className="glass-input" value={baseUrl} onChange={e => setBaseUrl(e.target.value)} placeholder="https://jira.company.com" />
        </div>

        <div className="form-group">
          <label>Bearer 토큰</label>
          <div style={{ display: 'flex', gap: 8 }}>
            <input
              className="glass-input"
              type={showToken ? 'text' : 'password'}
              value={token}
              onChange={e => setToken(e.target.value)}
              placeholder="Jira Bearer 토큰을 붙여넣으세요"
              style={{ flex: 1 }}
            />
            <button className="btn-secondary" onClick={() => setShowToken(v => !v)} type="button">
              {showToken ? <EyeOff size={16} /> : <Eye size={16} />}
            </button>
          </div>
        </div>

        <div style={{ display: 'flex', justifyContent: 'space-between', gap: 12, alignItems: 'center' }}>
          <button className="btn-secondary" onClick={testConnection} disabled={!baseUrl || !token || testing}>
            {testing ? '확인 중...' : '연결 테스트'}
          </button>
          {testResult?.ok && (
            <div style={{ color: '#078f55', display: 'flex', alignItems: 'center', gap: 8, fontSize: 13 }}>
              <CheckCircle size={16} />
              {testResult.display_name || testResult.username} 계정으로 연결되었습니다
            </div>
          )}
        </div>

        <div style={{ marginTop: 26, paddingTop: 22, borderTop: '1px solid rgba(0,0,0,0.08)' }}>
          <label style={{ display: 'flex', gap: 8, alignItems: 'center', fontWeight: 700 }}>
            <input type="checkbox" checked={autoTracking} onChange={e => setAutoTracking(e.target.checked)} />
            시간 추적 자동화 사용
          </label>
          <p style={{ color: 'var(--text-secondary)', fontSize: 13 }}>
            이 기능은 이슈가 완료될 때 Jira 작업 로그와 시간 추적 값을 자동으로 수정할 수 있습니다. 필요한 경우에만 켜세요.
          </p>
          <input
            className="glass-input"
            value={trackingProjects}
            onChange={e => setTrackingProjects(e.target.value)}
            placeholder="프로젝트 키 예: SSO,JIRA,DEV"
            disabled={!autoTracking}
          />
        </div>

        {error && <div style={{ marginTop: 18, color: '#b00020', background: '#ffe8e8', padding: 12, borderRadius: 8 }}>{error}</div>}

        <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 24 }}>
          <button className="btn-premium" onClick={save} disabled={!testResult?.ok || saving}>
            {saving ? <Loader2 size={16} /> : '설정 완료'}
          </button>
        </div>
      </div>
    </div>
  );
}
