@echo off
setlocal

echo Stopping Jira Dashboard processes...
echo.

call :KillPortProcess 8000 python Backend
call :KillPortProcess 5173 node Frontend

echo.
echo Stop command completed.
pause
exit /b 0

:KillPortProcess
set "PORT=%~1"
set "EXPECTED_PROCESS=%~2"
set "LABEL=%~3"

echo [%LABEL%] Checking port %PORT%...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ErrorActionPreference = 'SilentlyContinue';" ^
  "$connections = Get-NetTCPConnection -LocalPort %PORT% -State Listen;" ^
  "$processIds = @($connections | Select-Object -ExpandProperty OwningProcess -Unique);" ^
  "if ($processIds.Count -eq 0) { Write-Host '[%LABEL%] No listening process found on port %PORT%.'; exit 0 }" ^
  "foreach ($processId in $processIds) {" ^
  "  $process = Get-Process -Id $processId;" ^
  "  if ($null -eq $process) { continue }" ^
  "  if ($process.ProcessName -notlike '%EXPECTED_PROCESS%*') {" ^
  "    Write-Host ('[%LABEL%] Skipped PID ' + $processId + ' (' + $process.ProcessName + ') because it is not %EXPECTED_PROCESS%.');" ^
  "    continue" ^
  "  }" ^
  "  Write-Host ('[%LABEL%] Stopping PID ' + $processId + ' (' + $process.ProcessName + ') on port %PORT%...');" ^
  "  Stop-Process -Id $processId -Force" ^
  "}"

exit /b 0
