@echo off
echo Stopping Jira Dashboard processes...

:: Python (Backend) 프로세스 종료
taskkill /F /IM python.exe /T 2>nul

:: Node/Vite (Frontend) 프로세스 종료
taskkill /F /IM node.exe /T 2>nul

echo.
echo All processes stopped successfully.
pause
