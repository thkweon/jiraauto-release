export type JiraDeploymentType = 'cloud' | 'server';

export const formatJiraInstanceName = (name: string, deploymentType?: string) =>
  deploymentType === 'cloud' ? `${name} ☁️` : name;
