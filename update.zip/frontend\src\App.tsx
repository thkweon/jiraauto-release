import { BrowserRouter, Routes, Route, NavLink, Navigate, useLocation } from 'react-router-dom';
import { ThemeProvider, useTheme } from './context/ThemeContext';
import { useState, useEffect } from 'react';
import type { ReactNode } from 'react';
import DashboardPage from './pages/DashboardPage';
import BulkTransitionPage from './pages/BulkTransitionPage';
import ActivationPage from './pages/ActivationPage';
import TeamDashboardPage from './pages/TeamDashboardPage';
import TeamNoticesPage from './pages/TeamNoticesPage';
import TeamBoardPage from './pages/TeamBoardPage';
import TeamAnalyticsPage from './pages/TeamAnalyticsPage';
import TeamStartPage from './pages/TeamStartPage';
import TeamManagePage from './pages/TeamManagePage';
import TeamInfoPage from './pages/TeamInfoPage';
import { useTeamNotifications } from './hooks/useTeamNotifications';
import { Moon, Sun } from 'lucide-react';
import './App.css';

const API_BASE = 'http://localhost:8000/api';

const ProtectedRoute = ({ children }: { children: ReactNode }) => {
  const location = useLocation();
  const [licensed, setLicensed] = useState<boolean | null>(null);

  useEffect(() => {
    let cancelled = false;
    const checkLicense = async () => {
      try {
        const res = await fetch(`${API_BASE}/license/status`);
        const data = await res.json();
        if (!cancelled) setLicensed(Boolean(data.licensed));
      } catch {
        if (!cancelled) setLicensed(false);
      }
    };
    checkLicense();
    return () => {
      cancelled = true;
    };
  }, []);

  if (licensed === null) {
    return <div style={{ padding: 40, textAlign: 'center', color: 'var(--text-secondary)' }}>Checking license...</div>;
  }

  if (!licensed) {
    return <Navigate to="/activation" replace state={{ from: location }} />;
  }

  return children;
};

const Navigation = () => {
  const { theme, toggleTheme } = useTheme();
  const [teamRole, setTeamRole] = useState(() => localStorage.getItem('teamRole'));
  const [instanceCount, setInstanceCount] = useState<number | null>(null);

  // Start background notifications
  useTeamNotifications();

  useEffect(() => {
    const handleStorageChange = () => setTeamRole(localStorage.getItem('teamRole'));
    window.addEventListener('storage', handleStorageChange);
    // Custom event for internal route changes
    window.addEventListener('teamRoleChanged', handleStorageChange);
    return () => {
      window.removeEventListener('storage', handleStorageChange);
      window.removeEventListener('teamRoleChanged', handleStorageChange);
    };
  }, []);

  useEffect(() => {
    let cancelled = false;
    const fetchConfig = async () => {
      try {
        const res = await fetch(`${API_BASE}/config`);
        const data = await res.json();
        if (!cancelled) setInstanceCount((data.instances || []).length);
      } catch {
        if (!cancelled) setInstanceCount(null);
      }
    };
    fetchConfig();
    return () => {
      cancelled = true;
    };
  }, []);

  return (
    <div style={{ padding: '15px 20px', display: 'flex', justifyContent: 'center', background: 'transparent' }}>
      <nav className="nav-container glass-panel">
        <NavLink to="/" className={({isActive}) => isActive ? "nav-link active" : "nav-link"}>개인 현황판</NavLink>
        <NavLink to="/bulk" className={({isActive}) => isActive ? "nav-link active" : "nav-link"}>일괄 변경</NavLink>
        
        {teamRole ? (
          <>
            <div className="nav-divider" />
            <NavLink to="/team" end className={({isActive}) => isActive ? "nav-link active" : "nav-link"}>팀 현황판</NavLink>
            <NavLink to="/team/notices" className={({isActive}) => isActive ? "nav-link active" : "nav-link"}>팀 공지사항</NavLink>
            <NavLink to="/team/board" className={({isActive}) => isActive ? "nav-link active" : "nav-link"}>팀 게시판</NavLink>
            <NavLink to="/team/analytics" className={({isActive}) => isActive ? "nav-link active" : "nav-link"}>팀 통계</NavLink>
            {teamRole === 'leader' ? (
              <NavLink to="/team-manage" className={({isActive}) => isActive ? "nav-link active" : "nav-link"}>팀 관리(팀장)</NavLink>
            ) : (
              <NavLink to="/team-info" className={({isActive}) => isActive ? "nav-link active" : "nav-link"}>팀 정보</NavLink>
            )}
          </>
        ) : (
          <>
            <div className="nav-divider" />
            <NavLink to="/join" className={({isActive}) => isActive ? "nav-link active" : "nav-link"}>팀 참여하기</NavLink>
          </>
        )}
        
        <div className="nav-spacer" />
        {instanceCount !== null && (
          <span style={{fontSize: 12, fontWeight: 700, color: 'var(--text-secondary)', whiteSpace: 'nowrap', marginRight: 8}}>
            연결된 계정 {instanceCount}개
          </span>
        )}
        <button className="theme-toggle-btn hoverable" onClick={toggleTheme}>
          {theme === 'light' ? <Moon size={18} /> : <Sun size={18} />}
        </button>
      </nav>
    </div>
  );
};

export default function App() {
  return (
    <ThemeProvider>
      <BrowserRouter>
        <Navigation />
        <Routes>
          <Route path="/activation" element={<ActivationPage />} />
          <Route path="/" element={<ProtectedRoute><DashboardPage /></ProtectedRoute>} />
          <Route path="/bulk" element={<ProtectedRoute><BulkTransitionPage /></ProtectedRoute>} />
          <Route path="/team" element={<ProtectedRoute><TeamDashboardPage /></ProtectedRoute>} />
          <Route path="/team/notices" element={<ProtectedRoute><TeamNoticesPage /></ProtectedRoute>} />
          <Route path="/team/board" element={<ProtectedRoute><TeamBoardPage /></ProtectedRoute>} />
          <Route path="/team/analytics" element={<ProtectedRoute><TeamAnalyticsPage /></ProtectedRoute>} />
          <Route path="/join" element={<ProtectedRoute><TeamStartPage /></ProtectedRoute>} />
          <Route path="/team-manage" element={<ProtectedRoute><TeamManagePage /></ProtectedRoute>} />
          <Route path="/team-info" element={<ProtectedRoute><TeamInfoPage /></ProtectedRoute>} />
        </Routes>
      </BrowserRouter>
    </ThemeProvider>
  );
}
