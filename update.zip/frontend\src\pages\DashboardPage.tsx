import { useState, useEffect, useCallback, useRef } from 'react';
import { RefreshCcw, Search, Star } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { MentionsInput, Mention } from 'react-mentions';
import '../App.css';

// ---------------------------------------------------------
// 1. 타입 정의
// ---------------------------------------------------------
interface JiraIssue {
  key: string;
  instance_id: number;
  fields: {
    summary: string;
    status: { name: string };
    project: { key: string };
    issuetype: { name: string };
    priority?: { name?: string; iconUrl?: string };
    assignee: { name: string; displayName: string } | null;
    reporter: { name: string; displayName: string } | null;
    updated: string;
    created: string;
  };
}

interface JiraComment {
  id: string;
  author: { name: string; displayName: string; };
  body: string;
  renderedBody?: string;
  created: string;
}

interface JiraHistoryItem {
  id: string;
  author: { displayName: string };
  created: string;
  items: { field: string; fromString: string; toString: string; }[];
}

interface JiraIssueDetail extends JiraIssue {
  fields: JiraIssue['fields'] & {
    description: string;
    comment: { comments: JiraComment[] };
    priority: { name: string };
    components: { name: string }[];
    labels: string[];
    watchers: string[];
    created: string;
    updated: string;
  };
  changelog?: { histories: JiraHistoryItem[]; };
}

interface JiraTransition { id: string; name: string; to: { name: string }; }
interface JiraUser { name: string; accountId: string; }
interface JiraInstanceInfo { id: number; base_url: string; name: string; }

const mentionsStyle = {
  control: { backgroundColor: '#fff', fontSize: 14, lineHeight: 1.5, fontFamily: 'inherit' },
  '&multiLine': {
    control: { minHeight: 150, fontFamily: 'inherit' },
    highlighter: { padding: 12, border: '1px solid transparent', boxSizing: 'border-box' as const },
    input: { padding: 12, border: '1px solid #ddd', borderRadius: 8, outline: 'none', boxSizing: 'border-box' as const, minHeight: 150 },
  },
  suggestions: {
    list: { backgroundColor: 'white', border: '1px solid #ddd', borderRadius: 8, boxShadow: '0 4px 15px rgba(0,0,0,0.15)', fontSize: 13, zIndex: 10000 },
    item: { padding: '8px 12px', borderBottom: '1px solid #f0f0f0', '&focused': { backgroundColor: '#f0f7ff', color: '#0984e3' } },
  },
};

const API_BASE = 'http://localhost:8000/api';
const FAVORITES_STORAGE_KEY = 'jiraDashboardFavoriteIssueMap';
const UNREAD_UPDATES_STORAGE_KEY = 'jiraDashboardUnreadUpdatedIssueMap';

const issueStorageKey = (issue: { key: string; instance_id: number }) => `${issue.instance_id}:${issue.key}`;

const loadFavoriteIssueMap = <T,>(storageKey: string): Record<string, T> => {
  try {
    const raw = localStorage.getItem(storageKey);
    if (!raw) return {};
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : {};
  } catch {
    localStorage.removeItem(storageKey);
    return {};
  }
};

const loadJsonObject = <T,>(storageKey: string): Record<string, T> => {
  try {
    const raw = localStorage.getItem(storageKey);
    if (!raw) return {};
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : {};
  } catch {
    localStorage.removeItem(storageKey);
    return {};
  }
};

export default function DashboardPage() {
  const [issues, setIssues] = useState<JiraIssue[]>([]);
  const [userMap, setUserMap] = useState<Record<string, JiraUser>>({});
  const [loading, setLoading] = useState(true);
  const [lastUpdated, setLastUpdated] = useState<Date>(new Date());
  const [jiraUrl, setJiraUrl] = useState<string>('');
  const [instanceList, setInstanceList] = useState<JiraInstanceInfo[]>([]);
  
  const prevIssuesRef = useRef<Record<string, string>>({});
  const isFirstLoadRef = useRef(true);
  const fetchIssuesAbortRef = useRef<AbortController | null>(null);

  const [datePreset, setDatePreset] = useState<string>(() => localStorage.getItem('datePreset') || '30');
  const [startDate, setStartDate] = useState<string>(() => localStorage.getItem('startDate') || '');
  const [endDate, setEndDate] = useState<string>(() => localStorage.getItem('endDate') || '');
  const [projectFilter, setProjectFilter] = useState<string>(() => localStorage.getItem('projectFilter') || 'all');
  const [instanceFilter, setInstanceFilter] = useState<string>(() => localStorage.getItem('instanceFilter') || 'all');
  const [searchQuery, setSearchQuery] = useState<string>(() => localStorage.getItem('dashboardSearchQuery') || '');
  const [refreshInterval, setRefreshInterval] = useState<number>(() => parseInt(localStorage.getItem('refreshInterval') || '15'));
  const [cacheMinutes, setCacheMinutes] = useState<number>(() => parseInt(localStorage.getItem('cacheMinutes') || '5'));
  const [includeClosed, setIncludeClosed] = useState<boolean>(() =>
    localStorage.getItem('dashboardIncludeClosedIssues') === 'true' ||
    localStorage.getItem('includeClosedIssues') === 'true'
  );
  const [readIssues, setReadIssues] = useState<Record<string, string>>(() => loadJsonObject<string>('readIssues'));

  const [activeModal, setActiveModal] = useState<'comment' | 'subtask' | 'linked' | 'detail' | null>(null);
  const [selectedIssue, setSelectedIssue] = useState<JiraIssue | null>(null);
  const [issueDetail, setIssueDetail] = useState<JiraIssueDetail | null>(null);
  const [transitions, setTransitions] = useState<JiraTransition[]>([]);
  const [detailLoading, setDetailLoading] = useState(false);
  const [isSubmittingComment, setIsSubmittingComment] = useState(false);
  const [commentText, setCommentText] = useState('');
  const [editingCommentId, setEditingCommentId] = useState<string | null>(null);
  const [editingCommentText, setEditingCommentText] = useState('');
  const [favoriteIssues, setFavoriteIssues] = useState<Record<string, JiraIssue>>(() => loadFavoriteIssueMap<JiraIssue>(FAVORITES_STORAGE_KEY));
  const [unreadUpdatedIssues, setUnreadUpdatedIssues] = useState<Record<string, string>>(() => loadJsonObject<string>(UNREAD_UPDATES_STORAGE_KEY));

  const favoriteKey = issueStorageKey;
  const isFavoriteIssue = (issue: { key: string; instance_id: number }) => Boolean(favoriteIssues[favoriteKey(issue)]);
  const getReadIssueUpdated = (issue: { key: string; instance_id: number }) =>
    readIssues[issueStorageKey(issue)] || readIssues[issue.key];
  const persistUnreadUpdates = (next: Record<string, string>) => {
    setUnreadUpdatedIssues(next);
    localStorage.setItem(UNREAD_UPDATES_STORAGE_KEY, JSON.stringify(next));
  };
  const persistFavorites = (next: Record<string, JiraIssue>) => {
    setFavoriteIssues(next);
    localStorage.setItem(FAVORITES_STORAGE_KEY, JSON.stringify(next));
    window.dispatchEvent(new Event('jiraFavoritesChanged'));
  };
  const toggleFavoriteIssue = (issue: JiraIssue) => {
    const key = favoriteKey(issue);
    const next = { ...favoriteIssues };
    if (next[key]) {
      delete next[key];
    } else {
      next[key] = issue;
    }
    persistFavorites(next);
  };
  const refreshFavoriteSnapshots = (latestIssues: JiraIssue[]) => {
    const current = loadFavoriteIssueMap<JiraIssue>(FAVORITES_STORAGE_KEY);
    let changed = false;
    const next = { ...current };
    latestIssues.forEach(issue => {
      const key = favoriteKey(issue);
      if (next[key]) {
        next[key] = issue;
        changed = true;
      }
    });
    if (changed) persistFavorites(next);
  };
  const fetchFavoriteIssueUpdates = async (baseIssues: JiraIssue[], signal: AbortSignal): Promise<JiraIssue[]> => {
    const baseKeys = new Set(baseIssues.map(issueStorageKey));
    const favoriteTargets = Object.values(loadFavoriteIssueMap<JiraIssue>(FAVORITES_STORAGE_KEY))
      .filter(issue => !baseKeys.has(issueStorageKey(issue)));

    if (favoriteTargets.length === 0) return [];

    const refreshed = await Promise.all(
      favoriteTargets.map(async issue => {
        try {
          const res = await fetch(`${API_BASE}/issues/${issue.key}?instance_id=${issue.instance_id}&refresh=true`, { signal });
          if (!res.ok) return null;
          const data = await res.json();
          if (!data || data === false || !data.fields) return null;
          return data as JiraIssue;
        } catch (e: any) {
          if (e?.name !== 'AbortError') console.error(e);
          return null;
        }
      })
    );

    return refreshed.filter((issue): issue is JiraIssue => Boolean(issue?.key && issue?.instance_id && issue?.fields?.updated));
  };

  useEffect(() => {
    const syncFavorites = () => setFavoriteIssues(loadFavoriteIssueMap<JiraIssue>(FAVORITES_STORAGE_KEY));
    window.addEventListener('storage', syncFavorites);
    window.addEventListener('jiraFavoritesChanged', syncFavorites);
    return () => {
      window.removeEventListener('storage', syncFavorites);
      window.removeEventListener('jiraFavoritesChanged', syncFavorites);
    };
  }, []);

  const fetchIssues = useCallback(async () => {
    fetchIssuesAbortRef.current?.abort();
    const controller = new AbortController();
    fetchIssuesAbortRef.current = controller;
    try {
      let url = `${API_BASE}/issues?cache_minutes=${cacheMinutes}`;
      if (datePreset === 'custom') { 
        if (startDate) url += `&start_date=${startDate}`; 
        if (endDate) url += `&end_date=${endDate}`; 
      } else if (datePreset !== 'all') { 
        const start = new Date(); start.setDate(start.getDate() - parseInt(datePreset)); 
        url += `&start_date=${start.toISOString().split('T')[0]}`; 
      }
      if (includeClosed) url += '&include_closed=true';
      const res = await fetch(url, { signal: controller.signal });
      const data = await res.json();
      if (controller.signal.aborted) return;
      const newIssues: JiraIssue[] = data.issues || [];
      const refreshedFavoriteIssues = await fetchFavoriteIssueUpdates(newIssues, controller.signal);
      if (controller.signal.aborted) return;
      const latestIssuesForDetection = [
        ...newIssues,
        ...refreshedFavoriteIssues.filter(fav => !newIssues.some(issue => issueStorageKey(issue) === issueStorageKey(fav)))
      ];
      refreshFavoriteSnapshots(latestIssuesForDetection);

      const changedIssues: JiraIssue[] = [];
      const currentUnread = loadJsonObject<string>(UNREAD_UPDATES_STORAGE_KEY);
      const nextUnread = { ...currentUnread };
      let unreadChanged = false;

      if (!isFirstLoadRef.current) {
        latestIssuesForDetection.forEach(issue => {
          const key = issueStorageKey(issue);
          const prevUpdate = prevIssuesRef.current[key];
          const currentUpdate = issue.fields?.updated;
          if (!currentUpdate) return;

          const isNewIssue = !prevUpdate;
          const isUpdatedIssue = Boolean(prevUpdate && prevUpdate !== currentUpdate);
          const wasRead = getReadIssueUpdated(issue) === currentUpdate;
          const alreadyUnread = nextUnread[key] === currentUpdate;

          if ((isNewIssue || isUpdatedIssue) && !wasRead && !alreadyUnread) {
            nextUnread[key] = currentUpdate;
            unreadChanged = true;
            changedIssues.push(issue);
          }
        });
      }

      if (unreadChanged) persistUnreadUpdates(nextUnread);

      if (changedIssues.length > 0 && 'Notification' in window && Notification.permission === 'granted') {
        changedIssues.forEach(issue => {
          const currentUser = userMap[issue.instance_id.toString()];
          const isAssigned = currentUser && issue.fields.assignee?.name === currentUser.name;
          const isMentioned = currentUser && issue.fields.assignee?.name !== currentUser.name && issue.fields.reporter?.name !== currentUser.name;
          if (isAssigned || isMentioned) {
            const inst = instanceList.find(ins => ins.id === issue.instance_id);
            const instName = inst?.name || 'Jira';
            const n = new Notification(`[${instName}] ${isAssigned ? '내 업무 업데이트' : '멘션 알림'}`, { body: `${issue.key}: ${issue.fields.summary}`, icon: '/favicon.svg' });
            n.onclick = () => { window.open(`${inst?.base_url || jiraUrl}/browse/${issue.key}`, '_blank'); window.focus(); };
          }
        });
      }

      const issueStates: Record<string, string> = {};
      latestIssuesForDetection.forEach(i => { issueStates[issueStorageKey(i)] = i.fields.updated; });
      prevIssuesRef.current = issueStates; isFirstLoadRef.current = false;
      setIssues(newIssues); setLastUpdated(new Date());
    } catch (e: any) {
      if (e?.name !== 'AbortError') console.error(e);
    } finally {
      if (fetchIssuesAbortRef.current === controller) {
        fetchIssuesAbortRef.current = null;
        setLoading(false);
      }
    }
  }, [datePreset, startDate, endDate, cacheMinutes, includeClosed, userMap, jiraUrl, readIssues, instanceList]);

  const fetchIssueDetail = async (key: string, iid: number) => {
    setDetailLoading(true);
    try {
      const [d, t] = await Promise.all([fetch(`${API_BASE}/issues/${key}?instance_id=${iid}`), fetch(`${API_BASE}/issues/${key}/transitions?instance_id=${iid}`)]);
      setIssueDetail(await d.json()); setTransitions((await t.json()).transitions || []);
    } catch (e) {} finally { setDetailLoading(false); }
  };

  const convertMentionsToJiraFormat = (text: string) => text.replace(/@\[([^\]]+)\]\(([^)]+)\)/g, '[~$2]');

  const renderJiraWikiToHtml = (text: string): string => {
    const lines = text.split('\n');
    const result: string[] = [];
    let inTable = false;

    for (const line of lines) {
      const trimmed = line.trim();
      const isHeaderRow = /^\|\|/.test(trimmed);
      const isDataRow = !isHeaderRow && /^\|/.test(trimmed) && /\|$/.test(trimmed);

      if (isHeaderRow || isDataRow) {
        if (!inTable) { result.push('<table class="jira-wiki-table"><tbody>'); inTable = true; }
        if (isHeaderRow) {
          const cells = trimmed.replace(/^\|\|/, '').replace(/\|\|$/, '').split('||');
          result.push('<tr>' + cells.map(c => `<th>${renderJiraInline(c.trim())}</th>`).join('') + '</tr>');
        } else {
          const cells = trimmed.replace(/^\|/, '').replace(/\|$/, '').split('|');
          result.push('<tr>' + cells.map(c => `<td>${renderJiraInline(c.trim())}</td>`).join('') + '</tr>');
        }
      } else {
        if (inTable) { result.push('</tbody></table>'); inTable = false; }
        result.push(trimmed === '' ? '<br/>' : `<p>${renderJiraInline(line)}</p>`);
      }
    }
    if (inTable) result.push('</tbody></table>');
    return result.join('');
  };

  const renderJiraInline = (text: string): string => {
    return text
      .replace(/\[([^\]|]+)\|([^\]]+)\]/g, '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>')
      .replace(/\[~([^\]]+)\]/g, '<span class="jira-mention">@$1</span>')
      .replace(/\*([^*]+)\*/g, '<strong>$1</strong>')
      .replace(/_([^_]+)_/g, '<em>$1</em>')
      .replace(/\{\{([^}]+)\}\}/g, '<code>$1</code>');
  };

  const renderJiraCommentHtml = (comment: JiraComment): string => {
    if (comment.renderedBody) return comment.renderedBody;
    return renderJiraWikiToHtml(comment.body || '');
  };

  const searchUsers = async (query: string, callback: (users: any[]) => void) => {
    if (!query || !selectedIssue) return;
    try {
      const res = await fetch(`${API_BASE}/users/search?issue_key=${selectedIssue.key}&query=${encodeURIComponent(query)}`);
      const data = await res.json();
      const users = Array.isArray(data) ? data : (data.users || []);
      callback(users.map((u: any) => ({ id: u.name || u.key, display: u.displayName })));
    } catch (e) { callback([]); }
  };

  useEffect(() => { 
    const fetchConfig = async () => { try { const res = await fetch(`${API_BASE}/config`); const data = await res.json(); setJiraUrl(data.jira_base_url); setInstanceList(data.instances || []); } catch (e) {} };
    const fetchMe = async () => { try { const res = await fetch(`${API_BASE}/me`); const data = await res.json(); setUserMap(data); } catch (e) {} };
    fetchMe(); fetchConfig(); 
    if ('Notification' in window && Notification.permission !== 'granted' && Notification.permission !== 'denied') Notification.requestPermission(); 
  }, []);

  useEffect(() => {
    fetchIssues();
    const interval = setInterval(fetchIssues, refreshInterval * 1000);
    return () => clearInterval(interval);
  }, [datePreset, startDate, endDate, refreshInterval, fetchIssues]);

  const handlePasteImage = async (e: React.ClipboardEvent, setter: React.Dispatch<React.SetStateAction<string>>) => {
    if (!selectedIssue) return;
    const items = e.clipboardData?.items;
    if (!items) return;
    for (const item of items) {
        if (item.type.indexOf('image') !== -1) {
            e.preventDefault();
            const file = item.getAsFile();
            if (!file) continue;
            const formData = new FormData();
            formData.append('file', file);
            try {
                const res = await fetch(`${API_BASE}/issues/${selectedIssue.key}/attachments?instance_id=${selectedIssue.instance_id}`, { method: 'POST', body: formData });
                if (res.ok) {
                    const data = await res.json();
                    const filename = data.data?.[0]?.filename || file.name;
                    setter(prev => prev + `\n!${filename}!\n`);
                } else {
                    alert('이미지 업로드 실패');
                }
            } catch(e) { console.error(e); }
        }
    }
  };


  const formatDateTime = (s: string | undefined) => {
    if (!s) return '-'; const d = new Date(s); const now = new Date(); const diff = now.getTime() - d.getTime();
    if (diff > 0 && diff < 7200000) {
      const min = Math.floor(diff/60000);
      return `${min < 1 ? '방금 전' : (min < 60 ? min+'분 전' : '1시간 전')} (${d.toLocaleString()})`;
    }
    return d.toLocaleString();
  };

  const handleOpenDetailModal = (i: JiraIssue) => {
    setSelectedIssue(i); setActiveModal('detail'); fetchIssueDetail(i.key, i.instance_id);
    const key = issueStorageKey(i);
    const nr = { ...readIssues, [key]: i.fields.updated, [i.key]: i.fields.updated };
    setReadIssues(nr);
    localStorage.setItem('readIssues', JSON.stringify(nr));
    if (unreadUpdatedIssues[key]) {
      const nextUnread = { ...unreadUpdatedIssues };
      delete nextUnread[key];
      persistUnreadUpdates(nextUnread);
    }
  };

  const displaySourceIssues = [
    ...Object.values(favoriteIssues),
    ...issues.filter(issue => !favoriteIssues[favoriteKey(issue)])
  ];
  const visibleIssuesForFilter = instanceFilter === 'all' ? issues : issues.filter(i => i.instance_id.toString() === instanceFilter);
  const projectList = Array.from(new Set(visibleIssuesForFilter.map(i => i.fields.project.key))).sort();
  const matchesIssueSearch = (issue: JiraIssue) => {
    const query = searchQuery.trim().toLowerCase();
    if (!query) return true;
    const haystack = `${issue.key || ''} ${issue.fields?.summary || ''}`.toLowerCase();
    return haystack.includes(query);
  };
  const filteredIssues = displaySourceIssues.filter(i => {
    if (isFavoriteIssue(i)) return true;
    const pMatch = projectFilter === 'all' || i.fields.project.key === projectFilter;
    const iMatch = instanceFilter === 'all' || i.instance_id.toString() === instanceFilter;
    const sMatch = matchesIssueSearch(i);
    return pMatch && iMatch && sMatch;
  });

  const sortIssues = (a: any, b: any) => {
    const favoriteDiff = Number(isFavoriteIssue(b)) - Number(isFavoriteIssue(a));
    if (favoriteDiff !== 0) return favoriteDiff;
    const aUpdated = Boolean(unreadUpdatedIssues[issueStorageKey(a)]);
    const bUpdated = Boolean(unreadUpdatedIssues[issueStorageKey(b)]);
    if (aUpdated && !bUpdated) return -1;
    if (!aUpdated && bUpdated) return 1;
    const dateA = new Date(a.fields?.updated || a.fields?.created || 0).getTime();
    const dateB = new Date(b.fields?.updated || b.fields?.created || 0).getTime();
    return dateB - dateA;
  };

  const renderIssueCard = (issue: JiraIssue, type: 'assigned' | 'mentioned' | 'reported') => {
    const isUpdated = Boolean(unreadUpdatedIssues[issueStorageKey(issue)]);
    const instName = instanceList.find(ins => ins.id === issue.instance_id)?.name;
    const isFavorite = isFavoriteIssue(issue);
    return (
      <motion.div key={issue.key + '_' + issue.instance_id} layout initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, scale: 0.9 }}>
        <div className={`issue-card ${type === 'mentioned' ? 'mentioned' : ''} ${type === 'reported' ? 'reported' : ''} ${isUpdated ? 'has-update' : ''}`} onClick={() => handleOpenDetailModal(issue)}>
          <button
            className={`favorite-star-button ${isFavorite ? 'active' : ''}`}
            title={isFavorite ? '즐겨찾기 해제' : '즐겨찾기'}
            onClick={(e) => {
              e.stopPropagation();
              toggleFavoriteIssue(issue);
            }}
          >
            <Star size={17} fill={isFavorite ? '#f1c40f' : 'none'} />
          </button>
          <div className="issue-header" style={{alignItems: 'center', justifyContent: 'space-between', display: 'flex'}}>
            <span className="issue-key">
              {instanceList.length > 1 && instName && <span className="instance-badge">{instName}</span>}
              {type === 'mentioned' && '📢 '}{type === 'reported' && '👀 '}{type === 'assigned' && '📅 '}{issue.key}
            </span>
            <span className="status-badge" style={{marginTop: 0}}>{issue.fields?.status?.name}</span>
          </div>
          <div className="issue-summary">{issue.fields?.summary}</div>
          <div className="issue-footer" style={{marginTop: 'auto'}}>
            <div className="issue-assignee" style={{fontSize: '12px', fontWeight: 600, color: 'var(--text-secondary)'}}>
              <span>{issue.fields?.assignee?.displayName || issue.fields?.assignee?.name || '할당 안됨'}</span>
            </div>
            <div style={{display: 'flex', alignItems: 'center', gap: '8px'}}>
              {issue.fields?.priority?.iconUrl && <img src={issue.fields.priority.iconUrl} alt="priority" style={{width: 16, height: 16}} />}
              <span className="issue-date" style={{fontSize: '12px', color: 'var(--text-secondary)'}}>{new Date(issue.fields?.updated || issue.fields?.created || 0).toLocaleDateString()}</span>
            </div>
          </div>
        </div>
      </motion.div>
    );
  };

  return (
    <div className="dashboard-glass-container">
      <div style={{ display: 'flex', flexDirection: 'column', gap: 20, marginBottom: 30 }}>
        <div style={{display:'flex', gap:'12px', alignItems:'center', flexWrap: 'nowrap', width: '100%', boxSizing: 'border-box', background: 'var(--card-bg)', padding: '12px 16px', borderRadius: '12px', boxShadow: '0 4px 15px rgba(0,0,0,0.05)', overflowX: 'auto', overflowY: 'hidden'}}>
          <div style={{display: 'flex', alignItems: 'center', gap: 5, flexShrink: 0}}>
            <span style={{fontSize: 13, fontWeight: 700, color: 'var(--text-secondary)'}}>계정</span>
            <select className="glass-input" style={{width: 'auto', padding: '6px 12px'}} value={instanceFilter} onChange={e => {setInstanceFilter(e.target.value); localStorage.setItem('instanceFilter', e.target.value); setProjectFilter('all');}}>
              <option value="all">모든 계정</option>
              {instanceList.map(inst => <option key={inst.id} value={inst.id}>{inst.name}</option>)}
            </select>
          </div>

          <div style={{display: 'flex', alignItems: 'center', gap: 5, flexShrink: 0}}>
            <span style={{fontSize: 13, fontWeight: 700, color: 'var(--text-secondary)'}}>기간</span>
            <select className="glass-input" style={{width: 'auto', padding: '6px 12px'}} value={datePreset} onChange={(e) => {setDatePreset(e.target.value); localStorage.setItem('datePreset', e.target.value)}}>
              <option value="1">1일</option><option value="7">7일</option><option value="14">14일</option><option value="30">30일</option><option value="90">90일</option><option value="all">전체</option><option value="custom">직접입력</option>
            </select>
            {datePreset === 'custom' && (
              <div style={{display: 'flex', alignItems: 'center', gap: 5, marginLeft: 5, flexShrink: 0}}>
                <input type="date" className="glass-input" style={{padding: '6px', fontSize: 12}} value={startDate} onChange={e => {setStartDate(e.target.value); localStorage.setItem('startDate', e.target.value)}} />
                <span style={{color: '#ccc'}}>~</span>
                <input type="date" className="glass-input" style={{padding: '6px', fontSize: 12}} value={endDate} onChange={e => {setEndDate(e.target.value); localStorage.setItem('endDate', e.target.value)}} />
              </div>
            )}
          </div>

          <div style={{display: 'flex', alignItems: 'center', gap: 5, flexShrink: 0}}>
            <span style={{fontSize: 13, fontWeight: 700, color: 'var(--text-secondary)'}}>프로젝트</span>
            <select className="glass-input" style={{width: 'auto', padding: '6px 12px'}} value={projectFilter} onChange={e => {setProjectFilter(e.target.value); localStorage.setItem('projectFilter', e.target.value)}}>
              <option value="all">모든 프로젝트</option>
              {projectList.map(p => <option key={p} value={p}>{p}</option>)}
            </select>
          </div>

          <label
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: 6,
              fontSize: 13,
              fontWeight: 700,
              color: 'var(--text-secondary)',
              cursor: 'pointer',
              whiteSpace: 'nowrap',
              flexShrink: 0
            }}
          >
            <input
              type="checkbox"
              checked={includeClosed}
              onChange={e => {
                setIncludeClosed(e.target.checked);
                localStorage.setItem('dashboardIncludeClosedIssues', e.target.checked ? 'true' : 'false');
                localStorage.setItem('includeClosedIssues', e.target.checked ? 'true' : 'false');
              }}
              style={{cursor: 'pointer'}}
            />
            완료/닫힘 포함
          </label>
          
          <div style={{display: 'flex', alignItems: 'center', gap: 10, marginLeft: 'auto', flexWrap: 'nowrap', flexShrink: 0}}>
            <div style={{display: 'flex', alignItems: 'center', gap: 5, whiteSpace: 'nowrap', flexShrink: 0}}>
              <span style={{fontSize: 13, fontWeight: 700, color: 'var(--text-secondary)'}}>설정</span>
              <div style={{display:'flex', alignItems:'center', background: 'rgba(0,0,0,0.03)', padding: '4px 8px', borderRadius: '8px', gap: '5px'}}>
                 <span style={{fontSize: 11, color: 'var(--text-secondary)'}}>갱신(초)</span>
                 <input type="number" min="15" className="glass-input" style={{ width: '50px', padding: '4px', fontSize: 12 }} value={refreshInterval} onChange={e => {
                   const n=parseInt(e.target.value); 
                   setRefreshInterval(n); 
                   localStorage.setItem('refreshInterval', n.toString());
                   window.dispatchEvent(new Event('refreshIntervalChanged'));
                 }} />
                 <span style={{fontSize: 11, color: 'var(--text-secondary)', marginLeft: '5px'}}>캐시(분)</span>
                 <input type="number" min="1" className="glass-input" style={{ width: '50px', padding: '4px', fontSize: 12 }} value={cacheMinutes} onChange={e => {const n=parseInt(e.target.value); setCacheMinutes(n); localStorage.setItem('cacheMinutes', n.toString())}} />
              </div>
            </div>

            <div style={{display: 'flex', alignItems: 'center', gap: 8, whiteSpace: 'nowrap', flexShrink: 0}}>
               <span style={{ fontSize: '11px', color: 'var(--text-secondary)' }}>최종 갱신: {lastUpdated.toLocaleTimeString()}</span>
               <button className="btn-premium" style={{padding: '6px 12px'}} onClick={fetchIssues}><RefreshCcw size={14} /></button>
            </div>
          </div>
        </div>
        <div style={{position: 'relative', width: '100%'}}>
          <Search size={16} style={{position: 'absolute', left: 14, top: '50%', transform: 'translateY(-50%)', color: 'var(--text-secondary)', pointerEvents: 'none'}} />
          <input
            className="glass-input"
            type="search"
            value={searchQuery}
            onChange={e => {
              setSearchQuery(e.target.value);
              localStorage.setItem('dashboardSearchQuery', e.target.value);
            }}
            placeholder="티켓 번호 또는 제목 검색"
            style={{width: '100%', padding: '10px 14px 10px 40px', boxSizing: 'border-box'}}
          />
        </div>
      </div>

      {loading ? (<div style={{ textAlign: 'center', marginTop: '100px', color: 'var(--text-secondary)' }}><div style={{margin: '0 auto 15px auto', width: 30, height: 30, border: '3px solid rgba(0,0,0,0.1)', borderTopColor: 'var(--accent-color)', borderRadius: '50%', animation: 'spin 1s linear infinite'}} />데이터 수집 중...</div>) : (
        <div className="dashboard-board">
          {/* Assigned Column */}
          <div className="dashboard-column">
            <div className="dashboard-column-header">
              <h2>내 업무 <span style={{fontWeight: 400, opacity: 0.6, fontSize: 13}}>(Assigned)</span></h2>
              <span className="dashboard-count-badge">{filteredIssues.filter(i => {const u = userMap[i.instance_id.toString()]; return u && i.fields.assignee?.name === u.name}).length}</span>
            </div>
            <motion.div layout className="issue-grid" style={{display: 'flex', flexDirection: 'column', gap: 15}}>
              <AnimatePresence>
                {filteredIssues.filter(i => {const u = userMap[i.instance_id.toString()]; return u && i.fields.assignee?.name === u.name}).sort(sortIssues).map(issue => renderIssueCard(issue, 'assigned'))}
              </AnimatePresence>
            </motion.div>
          </div>
          
          {/* Mentioned Column */}
          <div className="dashboard-column">
            <div className="dashboard-column-header">
              <h2>멘션된 업무 <span style={{fontWeight: 400, opacity: 0.6, fontSize: 13}}>(Mentioned)</span></h2>
              <span className="dashboard-count-badge">{filteredIssues.filter(i => {const u = userMap[i.instance_id.toString()]; return u && i.fields.assignee?.name !== u.name && i.fields.reporter?.name !== u.name}).length}</span>
            </div>
            <motion.div layout className="issue-grid" style={{display: 'flex', flexDirection: 'column', gap: 15}}>
              <AnimatePresence>
                {filteredIssues.filter(i => {const u = userMap[i.instance_id.toString()]; return u && i.fields.assignee?.name !== u.name && i.fields.reporter?.name !== u.name}).sort(sortIssues).map(issue => renderIssueCard(issue, 'mentioned'))}
              </AnimatePresence>
            </motion.div>
          </div>
          
          {/* Reported Column */}
          <div className="dashboard-column">
            <div className="dashboard-column-header">
              <h2>보고한 업무 <span style={{fontWeight: 400, opacity: 0.6, fontSize: 13}}>(Reported)</span></h2>
              <span className="dashboard-count-badge">{filteredIssues.filter(i => {const u = userMap[i.instance_id.toString()]; return u && i.fields.reporter?.name === u.name && i.fields.assignee?.name !== u.name}).length}</span>
            </div>
            <motion.div layout className="issue-grid" style={{display: 'flex', flexDirection: 'column', gap: 15}}>
              <AnimatePresence>
                {filteredIssues.filter(i => {const u = userMap[i.instance_id.toString()]; return u && i.fields.reporter?.name === u.name && i.fields.assignee?.name !== u.name}).sort(sortIssues).map(issue => renderIssueCard(issue, 'reported'))}
              </AnimatePresence>
            </motion.div>
          </div>
        </div>
      )}

      {/* Detail Modal */}
      <AnimatePresence>
        {activeModal && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="glass-modal-overlay" onClick={() => setActiveModal(null)}>
            <motion.div initial={{ scale: 0.9, y: 20 }} animate={{ scale: 1, y: 0 }} exit={{ scale: 0.9, y: 20 }} className="glass-modal-content" onClick={e => e.stopPropagation()} style={{textAlign: 'left'}}>
              
              <div style={{display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:'20px'}}>
                <h2 style={{margin: 0, fontSize: 22, fontWeight: 700}}>
                  {activeModal === 'comment' && '코멘트 작성'}
                  {activeModal === 'subtask' && '하위 작업 생성'}
                  {activeModal === 'linked' && '연관 이슈 생성'}
                  {activeModal === 'detail' && '이슈 상세 정보'}
                </h2>
                {issueDetail && (
                  <div style={{display: 'flex', alignItems: 'center', gap: 8}}>
                    <button
                      className={`favorite-star-button modal-star ${isFavoriteIssue(issueDetail) ? 'active' : ''}`}
                      title={isFavoriteIssue(issueDetail) ? '즐겨찾기 해제' : '즐겨찾기'}
                      onClick={() => toggleFavoriteIssue(issueDetail)}
                    >
                      <Star size={18} fill={isFavoriteIssue(issueDetail) ? '#f1c40f' : 'none'} />
                    </button>
                    <span className="premium-badge" style={{position: 'relative', top: 0, right: 0}}>{instanceList.find(ins=>ins.id===issueDetail.instance_id)?.name || 'Jira'}</span>
                  </div>
                )}
              </div>
              
              <p style={{ fontSize: '15px', color: 'var(--text-secondary)', marginBottom: 25 }}>
                <a href={`${instanceList.find(ins=>ins.id===selectedIssue?.instance_id)?.base_url}/browse/${selectedIssue?.key}`} target="_blank" rel="noreferrer" style={{textDecoration: 'none', color: '#0984e3', fontWeight: 600}}>
                  {selectedIssue?.key}
                </a>
                <span style={{margin: '0 8px'}}>-</span>
                <span style={{color: 'var(--text-primary)'}}>{selectedIssue?.fields.summary}</span>
              </p>

              {(activeModal === 'comment' || activeModal === 'detail') && (
                <div>
                  {detailLoading ? (<div style={{padding: 40, textAlign: 'center', color: 'var(--text-secondary)'}}><div style={{margin: '0 auto 15px auto', width: 30, height: 30, border: '3px solid rgba(0,0,0,0.1)', borderTopColor: 'var(--accent-color)', borderRadius: '50%', animation: 'spin 1s linear infinite'}} />데이터 불러오는 중...</div>) : (
                    <>
                      <div style={{display: 'flex', alignItems: 'center', gap: 15, marginBottom: 20}}>
                         <span className="apple-meta-label" style={{whiteSpace: 'nowrap', flexShrink: 0}}>상태 변경</span>
                         <select className="glass-input" value="" style={{flex: 1}} onChange={async e => {
                           await fetch(`${API_BASE}/issues/${selectedIssue?.key}/transitions?instance_id=${selectedIssue?.instance_id}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ transition_id: e.target.value }) });
                           fetchIssues(); fetchIssueDetail(selectedIssue!.key, selectedIssue!.instance_id);
                         }}>
                           <option value="" disabled>새로운 상태 선택...</option>
                           {transitions.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
                         </select>
                      </div>

                      <div className="apple-meta-grid">
                        <div className="apple-meta-item"><span className="apple-meta-label">유형</span><span className="apple-meta-value">{issueDetail?.fields.issuetype.name}</span></div>
                        <div className="apple-meta-item"><span className="apple-meta-label">우선순위</span><span className="apple-meta-value">{issueDetail?.fields.priority?.name || '없음'}</span></div>
                        <div className="apple-meta-item"><span className="apple-meta-label">담당자</span><span className="apple-meta-value">{issueDetail?.fields.assignee?.displayName || '미지정'}</span></div>
                        <div className="apple-meta-item"><span className="apple-meta-label">보고자</span><span className="apple-meta-value">{issueDetail?.fields.reporter?.displayName}</span></div>
                        <div className="apple-meta-item" style={{ gridColumn: 'span 2' }}><span className="apple-meta-label">지켜보는 사람</span><span className="apple-meta-value">{issueDetail?.fields.watchers?.join(', ') || '없음'}</span></div>
                        <div className="apple-meta-item"><span className="apple-meta-label">생성 날짜</span><span className="apple-meta-value">{formatDateTime(issueDetail?.fields.created)}</span></div>
                        <div className="apple-meta-item"><span className="apple-meta-label">최종 변경</span><span className="apple-meta-value">{formatDateTime(issueDetail?.fields.updated)}</span></div>
                      </div>

                      <span className="apple-meta-label" style={{display: 'block', marginBottom: 8}}>설명</span>
                      <div className="apple-description-box" dangerouslySetInnerHTML={{__html: issueDetail?.fields.description ? renderJiraWikiToHtml(issueDetail.fields.description) : '설명이 없습니다.'}}></div>

                      <span className="apple-meta-label" style={{display: 'block', marginBottom: 8}}>코멘트</span>
                      <div className="glass-panel" style={{padding: '20px', marginBottom: '20px'}}>
                        <div onPaste={(e) => handlePasteImage(e, setCommentText)}>
                          <MentionsInput value={commentText} onChange={(_, newValue) => setCommentText(newValue)} onKeyDown={async (e) => { if (e.altKey && e.key === 'Enter') {
                              e.preventDefault();
                              if (!commentText.trim() || isSubmittingComment) return;
                              setIsSubmittingComment(true);
                              try {
                                await fetch(`${API_BASE}/issues/${selectedIssue?.key}/comments?instance_id=${selectedIssue?.instance_id}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ body: convertMentionsToJiraFormat(commentText) }) });
                                setCommentText(''); fetchIssueDetail(selectedIssue!.key, selectedIssue!.instance_id);
                              } finally {
                                setIsSubmittingComment(false);
                              }
                            }}} style={{...mentionsStyle, control: { ...mentionsStyle.control, backgroundColor: 'transparent' }, '&multiLine': { ...mentionsStyle['&multiLine'], input: { ...mentionsStyle['&multiLine'].input, backgroundColor: 'var(--card-bg)', border: '1px solid rgba(0,0,0,0.1)' } }}} placeholder="@를 입력하여 팀원 멘션... (Alt+Enter로 즉시 작성)">
                            <Mention trigger="@" data={searchUsers} markup="@[__display__](__id__)" displayTransform={(_id, display) => display} className="mention-badge" appendSpaceOnAdd />
                          </MentionsInput>
                        </div>
                        <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: '12px' }}>
                          <button className="btn-premium" style={{whiteSpace: 'nowrap', opacity: isSubmittingComment ? 0.6 : 1}} disabled={isSubmittingComment} onClick={async () => {
                            if (!commentText.trim() || isSubmittingComment) return;
                            setIsSubmittingComment(true);
                            try {
                              await fetch(`${API_BASE}/issues/${selectedIssue?.key}/comments?instance_id=${selectedIssue?.instance_id}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ body: convertMentionsToJiraFormat(commentText) }) });
                              setCommentText(''); 
                              await fetchIssueDetail(selectedIssue!.key, selectedIssue!.instance_id);
                            } finally {
                              setIsSubmittingComment(false);
                            }
                          }}>{isSubmittingComment ? '처리 중...' : '코멘트 추가'}</button>
                        </div>
                      </div>

                      <div className="imessage-container">
                        {!issueDetail?.fields.comment.comments?.length ? <p style={{fontSize:'13px', color:'var(--text-secondary)', textAlign: 'center'}}>작성된 코멘트가 없습니다.</p> :
                          [...issueDetail.fields.comment.comments].sort((a,b)=>new Date(b.created).getTime()-new Date(a.created).getTime()).map(c => {
                            const isMine = selectedIssue && userMap[selectedIssue.instance_id.toString()] && c.author.name === userMap[selectedIssue.instance_id.toString()].name;
                            return (
                              <div key={c.id} className={`imessage-bubble-wrapper ${isMine ? 'mine' : 'others'}`}>
                                {!isMine && <div className="imessage-author">{c.author.displayName}</div>}
                                
                                {editingCommentId === c.id ? (
                                  <div className="glass-panel" style={{padding: 15, width: '100%', minWidth: 300}}>
                                    <MentionsInput value={editingCommentText} onChange={(_, newValue) => setEditingCommentText(newValue)} onKeyDown={async (e) => { if (e.altKey && e.key === 'Enter') {
                                          e.preventDefault();
                                          await fetch(`${API_BASE}/issues/${selectedIssue?.key}/comments/${c.id}?instance_id=${selectedIssue?.instance_id}`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ body: convertMentionsToJiraFormat(editingCommentText) }) });
                                          setEditingCommentId(null); fetchIssueDetail(selectedIssue!.key, selectedIssue!.instance_id);
                                        }}} style={mentionsStyle} placeholder="코멘트 수정...">
                                      <Mention trigger="@" data={searchUsers} markup="@[__display__](__id__)" displayTransform={(_id, display) => display} className="mention-badge" appendSpaceOnAdd />
                                    </MentionsInput>
                                    <div style={{display:'flex',justifyContent:'flex-end',gap:'8px', marginTop:'10px'}}>
                                      <button className="btn-secondary" onClick={()=>setEditingCommentId(null)}>취소</button>
                                      <button className="btn-premium" onClick={async ()=>{
                                        await fetch(`${API_BASE}/issues/${selectedIssue?.key}/comments/${c.id}?instance_id=${selectedIssue?.instance_id}`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ body: convertMentionsToJiraFormat(editingCommentText) }) });
                                        setEditingCommentId(null); fetchIssueDetail(selectedIssue!.key, selectedIssue!.instance_id);
                                      }}>저장</button>
                                    </div>
                                  </div>
                                ) : (
                                  <>
                                    <div className="imessage-bubble" dangerouslySetInnerHTML={{__html: renderJiraCommentHtml(c)}} />
                                    <div className="imessage-date">{formatDateTime(c.created)}</div>
                                    {isMine && (
                                      <div className="imessage-actions">
                                        <button onClick={()=>{setEditingCommentId(c.id); setEditingCommentText(c.body);}}>수정</button>
                                        <button className="danger" onClick={async ()=>{
                                          if(!confirm('삭제하시겠습니까?')) return;
                                          await fetch(`${API_BASE}/issues/${selectedIssue?.key}/comments/${c.id}?instance_id=${selectedIssue?.instance_id}`, { method: 'DELETE' });
                                          fetchIssueDetail(selectedIssue!.key, selectedIssue!.instance_id);
                                        }}>삭제</button>
                                      </div>
                                    )}
                                  </>
                                )}
                              </div>
                            );
                          })
                        }
                      </div>
                      
                      <div style={{marginTop: 40}}>
                        <span className="apple-meta-label" style={{display: 'block', marginBottom: 8}}>활동 이력</span>
                        <div className="glass-panel" style={{padding: 20}}>
                          {!issueDetail?.changelog?.histories?.length ? <p style={{fontSize:'13px',color:'var(--text-secondary)'}}>기록이 없습니다.</p> : 
                            issueDetail.changelog.histories.slice(0,5).map(h=>(
                              <div key={h.id} style={{marginBottom: 15, paddingBottom: 15, borderBottom: '1px solid rgba(0,0,0,0.05)'}}>
                                <div style={{display: 'flex', justifyContent: 'space-between', marginBottom: 8}}>
                                  <span style={{fontWeight: 700, fontSize: 13, color: 'var(--text-primary)'}}>{h.author.displayName}</span>
                                  <span style={{fontSize: 12, color: 'var(--text-secondary)'}}>{formatDateTime(h.created)}</span>
                                </div>
                                <div style={{fontSize: 13, color: 'var(--text-secondary)', lineHeight: 1.5}}>
                                  {h.items.map((it,idx)=>(<div key={idx}>• <b>{it.field}</b>: {it.fromString||'없음'} → <b>{it.toString}</b></div>))}
                                </div>
                              </div>
                            ))
                          }
                        </div>
                      </div>
                    </>
                  )}
                </div>
              )}
              
              <div style={{display:'flex',justifyContent:'flex-end',gap:'10px',marginTop:'30px', paddingTop: '20px', borderTop: '1px solid rgba(0,0,0,0.05)'}}>
                <button className="btn-secondary" onClick={()=>setActiveModal(null)}>닫기</button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
