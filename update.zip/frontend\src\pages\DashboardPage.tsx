import { useState, useEffect, useCallback, useRef } from 'react';
import { CheckCheck, Flag, Plus, RefreshCcw, Search, Star } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { MentionsInput, Mention } from 'react-mentions';
import '../App.css';
import { updateEndDateWithinRange, updateStartDateWithinRange } from '../utils/dateRange';

// ---------------------------------------------------------
// 1. 타입 정의
// ---------------------------------------------------------
interface JiraPerson {
  name?: string;
  key?: string;
  accountId?: string;
  displayName?: string;
}

interface JiraIssue {
  key: string;
  instance_id: number;
  errorMessages?: string[];
  favorite_unavailable?: boolean;
  favorite_unavailable_reason?: string;
  fields: {
    summary: string;
    status: { name: string };
    project: { key: string };
    issuetype: { name: string };
    priority?: { name?: string; iconUrl?: string };
    assignee: JiraPerson | null;
    reporter: JiraPerson | null;
    creator?: JiraPerson | null;
    updated: string;
    created: string;
    timetracking?: {
      originalEstimate?: string;
      remainingEstimate?: string;
      timeSpent?: string;
    };
  };
}

interface JiraComment {
  id: string;
  author: JiraPerson;
  updateAuthor?: JiraPerson;
  body: string;
  renderedBody?: string;
  created: string;
  updated?: string;
}

interface JiraHistoryItem {
  id: string;
  author: JiraPerson;
  created: string;
  items: { field: string; fromString: string; toString: string; }[];
}

interface JiraIssueDetail extends JiraIssue {
  fields: JiraIssue['fields'] & {
    description: string;
    comment: { comments: JiraComment[] };
    priority: { name: string };
    components: { name: string }[];
    labels: string[];
    watchers: string[];
    created: string;
    updated: string;
  };
  changelog?: { histories: JiraHistoryItem[]; };
}

interface JiraTransition { id: string; name: string; to: { name: string }; }
type JiraUser = JiraPerson;
interface JiraUserSuggestion { id: string; display: string; name?: string; key?: string; accountId?: string; }
interface JiraInstanceInfo { id: number; base_url: string; name: string; }
interface TimeTrackingSnapshot {
  timetracking: {
    originalEstimate?: string;
    remainingEstimate?: string;
    timeSpent?: string;
  };
  worklog?: { total?: number };
}

const priorityColor = (name?: string) => {
  const normalized = (name || '').trim().toLowerCase();
  if (['highest', 'blocker', 'critical', '긴급', '매우 높음'].some(value => normalized.includes(value))) return '#d32f2f';
  if (['high', 'major', '높음'].some(value => normalized.includes(value))) return '#f57c00';
  if (['medium', 'normal', '중간', '보통'].some(value => normalized.includes(value))) return '#f9a825';
  if (['lowest', 'trivial', '매우 낮음'].some(value => normalized.includes(value))) return '#78909c';
  if (['low', 'minor', '낮음'].some(value => normalized.includes(value))) return '#1976d2';
  return '#78909c';
};

const sameStringRecord = (left: Record<string, string>, right: Record<string, string>) => {
  const leftKeys = Object.keys(left);
  const rightKeys = Object.keys(right);
  return leftKeys.length === rightKeys.length && leftKeys.every(key => left[key] === right[key]);
};

const issueSnapshotSignature = (issues: JiraIssue[]) => issues
  .map(issue => [
    issue.instance_id,
    issue.key,
    issue.fields?.updated || '',
    issue.fields?.status?.name || '',
    issue.fields?.assignee?.accountId || issue.fields?.assignee?.key || issue.fields?.assignee?.name || '',
    issue.favorite_unavailable ? '1' : '0',
  ].join(':'))
  .sort()
  .join('|');
interface IssueCreateOption { id?: string; name: string; }
interface IssueCreateProjectMeta {
  instance_id: number;
  instance_name: string;
  base_url: string;
  project_key: string;
  issue_types: IssueCreateOption[];
  components: IssueCreateOption[];
  error?: string;
}

interface WorklogPayload {
  timeSpent: string;
  comment: string;
  started: string;
  adjustEstimate: 'auto' | 'new' | 'leave';
  newEstimate?: string;
}

interface DashboardIssueState {
  observed_updated_at: string;
  unread_updated_at?: string | null;
  read_updated_at?: string | null;
}

interface DashboardIssueStatePayload {
  states: Record<string, DashboardIssueState>;
  initialized_instance_ids: number[];
  migration_pending_instance_ids: number[];
  last_sync_at_by_instance: Record<string, string>;
}

type UnknownRecord = Record<string, unknown>;

const asRecord = (value: unknown): UnknownRecord | null =>
  typeof value === 'object' && value !== null ? value as UnknownRecord : null;

const errorMessage = (error: unknown, fallback: string) =>
  error instanceof Error && error.message ? error.message : fallback;

const isAbortError = (error: unknown) =>
  error instanceof DOMException
    ? error.name === 'AbortError'
    : asRecord(error)?.name === 'AbortError';

const mentionsStyle = {
  control: { backgroundColor: 'var(--card-bg)', color: 'var(--text-primary)', fontSize: 14, lineHeight: 1.5, fontFamily: 'inherit' },
  '&multiLine': {
    control: { minHeight: 150, fontFamily: 'inherit' },
    highlighter: { padding: 12, border: '1px solid transparent', boxSizing: 'border-box' as const, color: 'var(--text-primary)' },
    input: { padding: 12, border: '1px solid rgba(127, 140, 141, 0.32)', borderRadius: 8, outline: 'none', boxSizing: 'border-box' as const, minHeight: 150, color: 'var(--text-primary)', caretColor: 'var(--text-primary)' },
  },
  suggestions: {
    list: { backgroundColor: 'var(--card-bg)', color: 'var(--text-primary)', border: '1px solid rgba(127, 140, 141, 0.32)', borderRadius: 8, boxShadow: '0 4px 15px rgba(0,0,0,0.15)', fontSize: 13, zIndex: 10000 },
    item: { padding: '8px 12px', borderBottom: '1px solid rgba(127, 140, 141, 0.18)', '&focused': { backgroundColor: 'rgba(9, 132, 227, 0.12)', color: 'var(--accent-color)' } },
  },
};

const API_BASE = 'http://localhost:8000/api';
const FAVORITES_STORAGE_KEY = 'jiraDashboardFavoriteIssueMap';
const UNREAD_UPDATES_STORAGE_KEY = 'jiraDashboardUnreadUpdatedIssueMap';
const TRACK_OWN_ACTIVITY_STORAGE_KEY = 'jiraDashboardTrackOwnActivity';

const issueStorageKey = (issue: { key: string; instance_id: number }) => `${issue.instance_id}:${issue.key}`;

const isUnavailableIssue = (issue: Partial<JiraIssue> | null | undefined) =>
  Boolean(
    issue?.favorite_unavailable ||
    (Array.isArray(issue?.errorMessages) && issue.errorMessages.length > 0) ||
    !issue?.fields
  );

const getUnavailableReason = (data: unknown, fallback = 'Jira 이슈를 찾을 수 없습니다.') => {
  const record = asRecord(data);
  if (Array.isArray(record?.errorMessages) && record.errorMessages.length > 0) return record.errorMessages.join(', ');
  if (typeof record?.message === 'string' && record.message.trim()) return record.message;
  if (typeof record?.detail === 'string' && record.detail.trim()) return record.detail;
  return fallback;
};

const getUpdatedTime = (value: string | undefined) => {
  if (!value) return 0;
  const time = new Date(value).getTime();
  return Number.isFinite(time) ? time : 0;
};

const isReadUpdate = (readValue: string | undefined, updateValue: string | undefined) =>
  Boolean(readValue && updateValue && getUpdatedTime(readValue) >= getUpdatedTime(updateValue));

const isSameJiraUser = (left?: JiraPerson | null, right?: JiraPerson | null) => {
  if (!left || !right) return false;
  const pairs: Array<[string | undefined, string | undefined]> = [
    [left.accountId, right.accountId],
    [left.name, right.name],
    [left.key, right.key],
    [left.displayName, right.displayName],
  ];
  return pairs.some(([a, b]) => Boolean(a && b && a === b));
};

const getLatestIssueActor = (detail: JiraIssueDetail | null | undefined): JiraPerson | null => {
  if (!detail) return null;
  const candidates: Array<{ at: number; actor?: JiraPerson | null }> = [];

  detail.changelog?.histories?.forEach(history => {
    candidates.push({ at: getUpdatedTime(history.created), actor: history.author });
  });
  detail.fields.comment?.comments?.forEach(comment => {
    candidates.push({
      at: getUpdatedTime(comment.updated || comment.created),
      actor: comment.updateAuthor || comment.author,
    });
  });

  candidates.sort((left, right) => right.at - left.at);
  return candidates.find(candidate => candidate.at > 0 && candidate.actor)?.actor || null;
};

const normalizeJiraUserSuggestion = (value: unknown): JiraUserSuggestion | null => {
  const user = asRecord(value);
  if (!user) return null;
  const id = [user.accountId, user.name, user.key].find(item => typeof item === 'string' && item.trim()) as string | undefined;
  const display = [user.displayName, user.name, user.key, user.accountId].find(item => typeof item === 'string' && item.trim()) as string | undefined;
  if (!id || !display) return null;
  return {
    id,
    display,
    name: typeof user.name === 'string' ? user.name : undefined,
    key: typeof user.key === 'string' ? user.key : undefined,
    accountId: typeof user.accountId === 'string' ? user.accountId : undefined,
  };
};

const parseWorklogTime = (input: string, allowZero = false): { ok: boolean; normalized?: string; minutes?: number; error?: string } => {
  const value = input.trim().toLowerCase();
  if (!value) return { ok: false, error: '작업한 시간을 입력하세요.' };
  const source = /^\d+$/.test(value) ? `${value}m` : value.replace(/\s+/g, '');
  const matches = Array.from(source.matchAll(/(\d+)([wdhm])/g));
  if (!matches.length || matches.map(m => m[0]).join('') !== source) {
    return { ok: false, error: '시간 형식이 올바르지 않습니다. 예: 70, 1h 10m, 1w3h' };
  }
  const unitMinutes: Record<string, number> = { w: 5 * 8 * 60, d: 8 * 60, h: 60, m: 1 };
  const totalMinutes = matches.reduce((sum, match) => sum + Number(match[1]) * unitMinutes[match[2]], 0);
  if (totalMinutes <= 0 && !allowZero) return { ok: false, error: '작업한 시간은 0보다 커야 합니다.' };

  let rest = totalMinutes;
  const weeks = Math.floor(rest / unitMinutes.w); rest %= unitMinutes.w;
  const days = Math.floor(rest / unitMinutes.d); rest %= unitMinutes.d;
  const hours = Math.floor(rest / unitMinutes.h); rest %= unitMinutes.h;
  const parts = [
    weeks ? `${weeks}w` : '',
    days ? `${days}d` : '',
    hours ? `${hours}h` : '',
    rest ? `${rest}m` : '',
  ].filter(Boolean);
  return { ok: true, minutes: totalMinutes, normalized: parts.join(' ') || '0m' };
};

const toLocalDateTimeInputValue = (date = new Date()) => {
  const offset = date.getTimezoneOffset();
  const local = new Date(date.getTime() - offset * 60000);
  return local.toISOString().slice(0, 16);
};

const getAutoStartedValue = (minutes?: number) => {
  if (!minutes || minutes <= 0) return toLocalDateTimeInputValue();
  return toLocalDateTimeInputValue(new Date(Date.now() - minutes * 60000));
};

const toJiraStartedValue = (localDateTime: string) => {
  const date = localDateTime ? new Date(localDateTime) : new Date();
  const pad = (n: number) => String(Math.abs(Math.trunc(n))).padStart(2, '0');
  const offsetMinutes = -date.getTimezoneOffset();
  const sign = offsetMinutes >= 0 ? '+' : '-';
  const hours = Math.floor(Math.abs(offsetMinutes) / 60);
  const minutes = Math.abs(offsetMinutes) % 60;
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}:00.000${sign}${pad(hours)}${pad(minutes)}`;
};

const loadFavoriteIssueMap = <T,>(storageKey: string): Record<string, T> => {
  try {
    const raw = localStorage.getItem(storageKey);
    if (!raw) return {};
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : {};
  } catch {
    localStorage.removeItem(storageKey);
    return {};
  }
};

const loadJsonObject = <T,>(storageKey: string): Record<string, T> => {
  try {
    const raw = localStorage.getItem(storageKey);
    if (!raw) return {};
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : {};
  } catch {
    localStorage.removeItem(storageKey);
    return {};
  }
};

const dashboardStateMaps = (states: Record<string, DashboardIssueState>) => {
  const read: Record<string, string> = {};
  const unread: Record<string, string> = {};
  const observed: Record<string, string> = {};
  Object.entries(states).forEach(([key, state]) => {
    if (state.read_updated_at) read[key] = state.read_updated_at;
    if (state.unread_updated_at) unread[key] = state.unread_updated_at;
    if (state.observed_updated_at) observed[key] = state.observed_updated_at;
  });
  return { read, unread, observed };
};

export default function DashboardPage() {
  const [issues, setIssues] = useState<JiraIssue[]>([]);
  const [userMap, setUserMap] = useState<Record<string, JiraUser>>({});
  const [userMapLoaded, setUserMapLoaded] = useState(false);
  const [loading, setLoading] = useState(true);
  const [lastUpdated, setLastUpdated] = useState<Date>(new Date());
  const [jiraUrl, setJiraUrl] = useState<string>('');
  const [instanceList, setInstanceList] = useState<JiraInstanceInfo[]>([]);
  const [trackingProjects, setTrackingProjects] = useState<string[]>([]);
  const [allowUnassignedProcessing, setAllowUnassignedProcessing] = useState(false);
  const [allowAllProjectWorklog, setAllowAllProjectWorklog] = useState(false);
  const [originalEstimateEnabled, setOriginalEstimateEnabled] = useState(false);
  const [originalEstimateAuto, setOriginalEstimateAuto] = useState(false);
  const [originalEstimateValue, setOriginalEstimateValue] = useState('');
  
  const fetchIssuesAbortRef = useRef<AbortController | null>(null);
  const modalPointerStartedOnOverlayRef = useRef(false);

  const [datePreset, setDatePreset] = useState<string>(() => localStorage.getItem('datePreset') || '30');
  const [startDate, setStartDate] = useState<string>(() => localStorage.getItem('startDate') || '');
  const [endDate, setEndDate] = useState<string>(() => localStorage.getItem('endDate') || '');
  const [projectFilter, setProjectFilter] = useState<string>(() => localStorage.getItem('projectFilter') || 'all');
  const [instanceFilter, setInstanceFilter] = useState<string>(() =>
    localStorage.getItem('dashboardInstanceFilter') ||
    localStorage.getItem('instanceFilter') ||
    'all'
  );
  const [searchQuery, setSearchQuery] = useState<string>(() => localStorage.getItem('dashboardSearchQuery') || '');
  const [refreshInterval, setRefreshInterval] = useState<number>(() => parseInt(localStorage.getItem('refreshInterval') || '15'));
  const [cacheMinutes, setCacheMinutes] = useState<number>(() => parseInt(localStorage.getItem('cacheMinutes') || '5'));
  const [trackOwnActivity, setTrackOwnActivity] = useState<boolean>(() => localStorage.getItem(TRACK_OWN_ACTIVITY_STORAGE_KEY) !== 'false');
  const [includeClosed, setIncludeClosed] = useState<boolean>(() =>
    localStorage.getItem('dashboardIncludeClosedIssues') === 'true' ||
    localStorage.getItem('includeClosedIssues') === 'true'
  );
  const [readIssues, setReadIssues] = useState<Record<string, string>>(() => loadJsonObject<string>('readIssues'));

  const handleStartDateChange = (value: string) => {
    const next = updateStartDateWithinRange(value, endDate);
    setStartDate(next.startDate);
    setEndDate(next.endDate);
    localStorage.setItem('startDate', next.startDate);
    localStorage.setItem('endDate', next.endDate);
  };

  const handleEndDateChange = (value: string) => {
    const next = updateEndDateWithinRange(startDate, value);
    setStartDate(next.startDate);
    setEndDate(next.endDate);
    localStorage.setItem('startDate', next.startDate);
    localStorage.setItem('endDate', next.endDate);
  };

  const [activeModal, setActiveModal] = useState<'comment' | 'subtask' | 'linked' | 'detail' | null>(null);
  const [selectedIssue, setSelectedIssue] = useState<JiraIssue | null>(null);
  const [issueDetail, setIssueDetail] = useState<JiraIssueDetail | null>(null);
  const [transitions, setTransitions] = useState<JiraTransition[]>([]);
  const [detailLoading, setDetailLoading] = useState(false);
  const [isSubmittingComment, setIsSubmittingComment] = useState(false);
  const [commentText, setCommentText] = useState('');
  const [editingCommentId, setEditingCommentId] = useState<string | null>(null);
  const [editingCommentText, setEditingCommentText] = useState('');
  const [worklogOpen, setWorklogOpen] = useState(false);
  const [timetrackingLoading, setTimetrackingLoading] = useState(false);
  const [timetracking, setTimetracking] = useState<TimeTrackingSnapshot | null>(null);
  const [worklogTime, setWorklogTime] = useState('');
  const [worklogComment, setWorklogComment] = useState('');
  const [worklogStarted, setWorklogStarted] = useState(() => toLocalDateTimeInputValue());
  const [worklogStartedTouched, setWorklogStartedTouched] = useState(false);
  const [adjustEstimate, setAdjustEstimate] = useState<'auto' | 'new' | 'leave'>('auto');
  const [newEstimate, setNewEstimate] = useState('');
  const [worklogSubmitting, setWorklogSubmitting] = useState(false);
  const [worklogMessage, setWorklogMessage] = useState('');
  const [worklogError, setWorklogError] = useState('');
  const [originalEstimateSubmitting, setOriginalEstimateSubmitting] = useState(false);
  const [originalEstimateMessage, setOriginalEstimateMessage] = useState('');
  const [originalEstimateError, setOriginalEstimateError] = useState('');
  const [favoriteIssues, setFavoriteIssues] = useState<Record<string, JiraIssue>>(() => loadFavoriteIssueMap<JiraIssue>(FAVORITES_STORAGE_KEY));
  const [unreadUpdatedIssues, setUnreadUpdatedIssues] = useState<Record<string, string>>(() => loadJsonObject<string>(UNREAD_UPDATES_STORAGE_KEY));
  const [createModalOpen, setCreateModalOpen] = useState(false);
  const [createMetadata, setCreateMetadata] = useState<IssueCreateProjectMeta[]>([]);
  const [createMetadataLoading, setCreateMetadataLoading] = useState(false);
  const [createSelectedProject, setCreateSelectedProject] = useState('');
  const [createIssueType, setCreateIssueType] = useState('');
  const [createSummary, setCreateSummary] = useState('');
  const [createDescription, setCreateDescription] = useState('');
  const [createComponent, setCreateComponent] = useState('');
  const [createAssigneeMode, setCreateAssigneeMode] = useState<'default' | 'me' | 'manual'>('default');
  const [createAssigneeQuery, setCreateAssigneeQuery] = useState('');
  const [createAssigneeSelected, setCreateAssigneeSelected] = useState<JiraUserSuggestion | null>(null);
  const [createAssigneeSuggestions, setCreateAssigneeSuggestions] = useState<JiraUserSuggestion[]>([]);
  const [createAssigneeLoading, setCreateAssigneeLoading] = useState(false);
  const [createSubmitting, setCreateSubmitting] = useState(false);
  const [createError, setCreateError] = useState('');

  const currentSelectedUser = selectedIssue ? userMap[selectedIssue.instance_id.toString()] : null;
  const isIssueChangeByCurrentUser = useCallback(async (issue: JiraIssue, signal: AbortSignal, isNewIssue: boolean) => {
    const currentUser = userMap[issue.instance_id.toString()];
    if (!currentUser) return false;
    try {
      const res = await fetch(`${API_BASE}/issues/${issue.key}?instance_id=${issue.instance_id}&refresh=true`, { signal });
      const detail = await res.json().catch(() => null);
      if (!res.ok || !detail || isUnavailableIssue(detail)) return false;
      const issueDetail = detail as JiraIssueDetail;
      const actor = isNewIssue
        ? issueDetail.fields?.creator || issue.fields?.creator || getLatestIssueActor(issueDetail)
        : getLatestIssueActor(issueDetail);
      return isSameJiraUser(actor, currentUser);
    } catch (error) {
      if (!(error instanceof DOMException && error.name === 'AbortError')) console.error(error);
      return false;
    }
  }, [userMap]);
  const selectedAssignee = issueDetail?.fields?.assignee || selectedIssue?.fields?.assignee || null;
  const isSelectedIssueAssignedToMe = Boolean(
    selectedIssue &&
    currentSelectedUser &&
    isSameJiraUser(selectedAssignee, currentSelectedUser)
  );
  const selectedIssueProjectKey = (issueDetail?.fields?.project?.key || selectedIssue?.fields?.project?.key || '').toUpperCase();
  const isSelectedIssueTrackedProject = Boolean(
    selectedIssueProjectKey &&
    trackingProjects.map(project => project.toUpperCase()).includes(selectedIssueProjectKey)
  );
  const canUseWorklogPanel = Boolean(
    selectedIssue &&
    (
      allowAllProjectWorklog ||
      (isSelectedIssueTrackedProject && (isSelectedIssueAssignedToMe || allowUnassignedProcessing))
    )
  );
  const normalizedTrackingProjects = trackingProjects.map(project => project.toUpperCase());
  const parsedOriginalEstimate = originalEstimateValue.trim() ? parseWorklogTime(originalEstimateValue) : null;
  const canUseOriginalEstimateValue = Boolean(parsedOriginalEstimate?.ok && parsedOriginalEstimate.normalized);
  const isIssueAssignedToMe = (issue: JiraIssue) => {
    const currentUser = userMap[issue.instance_id.toString()];
    return Boolean(currentUser && isSameJiraUser(issue.fields?.assignee, currentUser));
  };
  const isIssueMentionedForMe = (issue: JiraIssue) => {
    const currentUser = userMap[issue.instance_id.toString()];
    if (!currentUser) return false;
    return !isSameJiraUser(issue.fields?.assignee, currentUser) && !isSameJiraUser(issue.fields?.reporter, currentUser);
  };
  const isIssueReportedByMe = (issue: JiraIssue) => {
    const currentUser = userMap[issue.instance_id.toString()];
    return Boolean(
      currentUser &&
      isSameJiraUser(issue.fields?.reporter, currentUser) &&
      !isSameJiraUser(issue.fields?.assignee, currentUser)
    );
  };
  const isOriginalEstimateTarget = (issue: JiraIssue) => {
    const projectKey = issue.fields?.project?.key?.toUpperCase();
    if (!originalEstimateEnabled || !projectKey || !normalizedTrackingProjects.includes(projectKey)) return false;
    if (isIssueAssignedToMe(issue)) return true;
    return allowUnassignedProcessing && isIssueMentionedForMe(issue);
  };
  const selectedHasOriginalEstimate = Boolean(timetracking?.timetracking?.originalEstimate || selectedIssue?.fields?.timetracking?.originalEstimate);
  const canUseManualOriginalEstimate = Boolean(
    selectedIssue &&
    isOriginalEstimateTarget(selectedIssue) &&
    !originalEstimateAuto &&
    canUseOriginalEstimateValue
  );
  const isFavoriteIssue = (issue: { key: string; instance_id: number }) => Boolean(favoriteIssues[issueStorageKey(issue)]);
  const removeFavoriteIssue = (issue: { key: string; instance_id: number }) => {
    const key = issueStorageKey(issue);
    if (!favoriteIssues[key]) return;
    const next = { ...favoriteIssues };
    delete next[key];
    persistFavorites(next);
  };
  const persistFavorites = useCallback((next: Record<string, JiraIssue>) => {
    setFavoriteIssues(next);
    localStorage.setItem(FAVORITES_STORAGE_KEY, JSON.stringify(next));
    window.dispatchEvent(new Event('jiraFavoritesChanged'));
  }, []);
  const toggleFavoriteIssue = (issue: JiraIssue) => {
    const key = issueStorageKey(issue);
    const next = { ...favoriteIssues };
    if (next[key]) {
      delete next[key];
    } else {
      next[key] = issue;
    }
    persistFavorites(next);
  };
  const fetchFavoriteIssueUpdates = async (baseIssues: JiraIssue[], signal: AbortSignal): Promise<JiraIssue[]> => {
    const baseKeys = new Set(baseIssues.map(issueStorageKey));
    const activeInstanceIds = new Set(instanceList.map(instance => instance.id));
    const favoriteTargets = Object.values(loadFavoriteIssueMap<JiraIssue>(FAVORITES_STORAGE_KEY))
      .filter(issue => activeInstanceIds.has(issue.instance_id) && !baseKeys.has(issueStorageKey(issue)));

    if (favoriteTargets.length === 0) return [];

    const refreshed = await Promise.all(
      favoriteTargets.map(async issue => {
        try {
          const res = await fetch(`${API_BASE}/issues/${issue.key}?instance_id=${issue.instance_id}&refresh=true`, { signal });
          const data = await res.json().catch(() => null);
          if (!res.ok || !data || data === false || isUnavailableIssue(data)) {
            return {
              ...issue,
              favorite_unavailable: true,
              favorite_unavailable_reason: getUnavailableReason(data, !res.ok ? `HTTP ${res.status}` : undefined),
            };
          }
          return { ...data, favorite_unavailable: false, favorite_unavailable_reason: undefined } as JiraIssue;
        } catch (error: unknown) {
          if (!isAbortError(error)) console.error(error);
          return null;
        }
      })
    );

    return refreshed.filter((issue): issue is JiraIssue => Boolean(issue?.key && issue?.instance_id));
  };

  useEffect(() => {
    const syncFavorites = () => setFavoriteIssues(loadFavoriteIssueMap<JiraIssue>(FAVORITES_STORAGE_KEY));
    window.addEventListener('storage', syncFavorites);
    window.addEventListener('jiraFavoritesChanged', syncFavorites);
    return () => {
      window.removeEventListener('storage', syncFavorites);
      window.removeEventListener('jiraFavoritesChanged', syncFavorites);
    };
  }, []);

  const fetchIssues = useCallback(async () => {
    fetchIssuesAbortRef.current?.abort();
    const controller = new AbortController();
    fetchIssuesAbortRef.current = controller;
    try {
      let url = `${API_BASE}/issues?cache_minutes=${cacheMinutes}`;
      if (datePreset === 'custom') { 
        if (startDate) url += `&start_date=${startDate}`; 
        if (endDate) url += `&end_date=${endDate}`; 
      } else if (datePreset !== 'all') { 
        const start = new Date(); start.setDate(start.getDate() - parseInt(datePreset)); 
        url += `&start_date=${start.toISOString().split('T')[0]}`; 
      }
      if (includeClosed) url += '&include_closed=true';
      const res = await fetch(url, { signal: controller.signal });
      const data = await res.json();
      if (controller.signal.aborted) return;
      const newIssues: JiraIssue[] = data.issues || [];
      const refreshedFavoriteIssues = await fetchFavoriteIssueUpdates(newIssues, controller.signal);
      if (controller.signal.aborted) return;
      const latestIssuesForDetection = [
        ...newIssues,
        ...refreshedFavoriteIssues.filter(fav => !newIssues.some(issue => issueStorageKey(issue) === issueStorageKey(fav)))
      ];
      const currentFavorites = loadFavoriteIssueMap<JiraIssue>(FAVORITES_STORAGE_KEY);
      let favoritesChanged = false;
      const nextFavorites = { ...currentFavorites };
      latestIssuesForDetection.forEach(issue => {
        const key = issueStorageKey(issue);
        if (nextFavorites[key]) {
          nextFavorites[key] = issue;
          favoritesChanged = true;
        }
      });
      if (favoritesChanged) persistFavorites(nextFavorites);

      const successfulInstanceIds: number[] = Array.isArray(data.successful_instance_ids)
        ? data.successful_instance_ids
        : Array.from(new Set(newIssues.map(issue => issue.instance_id)));
      const stateRes = await fetch(`${API_BASE}/dashboard/issue-states`, { signal: controller.signal });
      let dashboardState = await stateRes.json().catch(() => null) as DashboardIssueStatePayload | null;
      if (!stateRes.ok || !dashboardState) throw new Error('대시보드 알림 상태를 불러오지 못했습니다.');

      const pendingMigrationIds = dashboardState.migration_pending_instance_ids
        .filter(iid => successfulInstanceIds.includes(iid));
      if (pendingMigrationIds.length > 0) {
        const legacyRead = loadJsonObject<string>('readIssues');
        const legacyUnread = loadJsonObject<string>(UNREAD_UPDATES_STORAGE_KEY);
        const hasLegacyReadHistory = Object.keys(legacyRead).length > 0;
        const issueKeyCounts = latestIssuesForDetection.reduce<Record<string, number>>((counts, issue) => {
          counts[issue.key] = (counts[issue.key] || 0) + 1;
          return counts;
        }, {});
        const migrationIssues = latestIssuesForDetection
          .filter(issue => pendingMigrationIds.includes(issue.instance_id) && issue.fields?.updated)
          .map(issue => {
            const key = issueStorageKey(issue);
            const legacyReadValue = issueKeyCounts[issue.key] === 1 ? legacyRead[issue.key] : undefined;
            const readUpdatedAt = legacyRead[key] || legacyReadValue || null;
            const currentUser = userMap[issue.instance_id.toString()];
            const isOwnCreation = Boolean(currentUser && isSameJiraUser(issue.fields?.creator, currentUser));
            const inferredUnread = hasLegacyReadHistory && !readUpdatedAt && (trackOwnActivity || !isOwnCreation)
              ? issue.fields.updated
              : null;
            return {
              instance_id: issue.instance_id,
              issue_key: issue.key,
              observed_updated_at: issue.fields.updated,
              unread_updated_at: legacyUnread[key] || inferredUnread,
              read_updated_at: readUpdatedAt,
            };
          });
        const migrationRes = await fetch(`${API_BASE}/dashboard/issue-states/migrate`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ issues: migrationIssues, instance_ids: pendingMigrationIds }),
          signal: controller.signal,
        });
        const migratedState = await migrationRes.json().catch(() => null) as DashboardIssueStatePayload | null;
        if (!migrationRes.ok || !migratedState) throw new Error('기존 대시보드 알림 상태를 DB로 이관하지 못했습니다.');
        dashboardState = migratedState;
        if (dashboardState.migration_pending_instance_ids.length === 0) {
          localStorage.removeItem('readIssues');
          localStorage.removeItem(UNREAD_UPDATES_STORAGE_KEY);
        }
      }

      const changedIssues: JiraIssue[] = [];
      const observations: Array<{
        instance_id: number;
        issue_key: string;
        observed_updated_at: string;
        mark_unread: boolean;
      }> = [];
      const initializedInstances = new Set(dashboardState.initialized_instance_ids);

      for (const issue of latestIssuesForDetection) {
        const key = issueStorageKey(issue);
        const state = dashboardState.states[key];
        const currentUpdate = issue.fields?.updated;
        if (!currentUpdate || !successfulInstanceIds.includes(issue.instance_id)) continue;

        const previousUpdate = state?.observed_updated_at;
        const lastSyncAt = dashboardState.last_sync_at_by_instance[issue.instance_id.toString()];
        const isNewIssue = Boolean(
          initializedInstances.has(issue.instance_id) &&
          !previousUpdate &&
          lastSyncAt &&
          getUpdatedTime(currentUpdate) > getUpdatedTime(lastSyncAt)
        );
        const isUpdatedIssue = Boolean(
          previousUpdate && getUpdatedTime(currentUpdate) > getUpdatedTime(previousUpdate)
        );
        const wasRead = isReadUpdate(state?.read_updated_at || undefined, currentUpdate);
        const alreadyUnread = state?.unread_updated_at === currentUpdate;
        let markUnread = false;

        if ((isNewIssue || isUpdatedIssue) && !wasRead && !alreadyUnread) {
          const isOwnChange = !trackOwnActivity && await isIssueChangeByCurrentUser(
            issue,
            controller.signal,
            isNewIssue,
          );
          if (!isOwnChange) {
            markUnread = true;
            changedIssues.push(issue);
          }
        }

        observations.push({
          instance_id: issue.instance_id,
          issue_key: issue.key,
          observed_updated_at: currentUpdate,
          mark_unread: markUnread,
        });
      }

      let finalDashboardState = dashboardState;
      const observeRes = await fetch(`${API_BASE}/dashboard/issue-states/observe`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ issues: observations, successful_instance_ids: successfulInstanceIds }),
        signal: controller.signal,
      });
      const observedState = await observeRes.json().catch(() => null) as DashboardIssueStatePayload | null;
      if (observeRes.ok && observedState) {
        finalDashboardState = observedState;
      } else {
        console.error('대시보드 알림 상태를 DB에 저장하지 못했습니다.');
      }
      const finalMaps = dashboardStateMaps(finalDashboardState.states);
      changedIssues.forEach(issue => {
        const key = issueStorageKey(issue);
        if (issue.fields?.updated) finalMaps.unread[key] = issue.fields.updated;
      });
      setReadIssues(current => sameStringRecord(current, finalMaps.read) ? current : finalMaps.read);
      setUnreadUpdatedIssues(current => sameStringRecord(current, finalMaps.unread) ? current : finalMaps.unread);

      if (changedIssues.length > 0 && 'Notification' in window && Notification.permission === 'granted') {
        changedIssues.forEach(issue => {
          const currentUser = userMap[issue.instance_id.toString()];
          const isAssigned = currentUser && issue.fields?.assignee?.name === currentUser.name;
          const isMentioned = currentUser && issue.fields?.assignee?.name !== currentUser.name && issue.fields?.reporter?.name !== currentUser.name;
          if (isAssigned || isMentioned) {
            const inst = instanceList.find(ins => ins.id === issue.instance_id);
            const instName = inst?.name || 'Jira';
            const n = new Notification(`[${instName}] ${isAssigned ? '내 업무 업데이트' : '멘션 알림'}`, { body: `${issue.key}: ${issue.fields?.summary || ''}`, icon: '/favicon.svg' });
            n.onclick = () => { window.open(`${inst?.base_url || jiraUrl}/browse/${issue.key}`, '_blank'); window.focus(); };
          }
        });
      }

      setIssues(current => issueSnapshotSignature(current) === issueSnapshotSignature(newIssues) ? current : newIssues);
      setLastUpdated(new Date());
    } catch (error: unknown) {
      if (!isAbortError(error)) console.error(error);
    } finally {
      if (fetchIssuesAbortRef.current === controller) {
        fetchIssuesAbortRef.current = null;
        setLoading(false);
      }
    }
  }, [datePreset, startDate, endDate, cacheMinutes, includeClosed, trackOwnActivity, userMap, jiraUrl, instanceList, isIssueChangeByCurrentUser, persistFavorites]);

  const fetchIssueDetail = async (key: string, iid: number) => {
    setDetailLoading(true);
    try {
      const [d, t] = await Promise.all([fetch(`${API_BASE}/issues/${key}?instance_id=${iid}`), fetch(`${API_BASE}/issues/${key}/transitions?instance_id=${iid}`)]);
      const detailData = await d.json().catch(() => null);
      const transitionData = await t.json().catch(() => ({}));
      setTransitions(transitionData.transitions || []);
      if (!d.ok || !detailData || isUnavailableIssue(detailData)) {
        setIssueDetail(null);
        return;
      }
      setIssueDetail(detailData);
    } catch {
      setIssueDetail(null);
    } finally { setDetailLoading(false); }
  };

  const fetchTimeTracking = async (issue = selectedIssue) => {
    if (!issue) return;
    setTimetrackingLoading(true);
    try {
      const res = await fetch(`${API_BASE}/issues/${issue.key}/timetracking?instance_id=${issue.instance_id}`);
      if (!res.ok) throw new Error('시간 추적 정보를 불러오지 못했습니다.');
      setTimetracking(await res.json());
    } catch (error: unknown) {
      setWorklogError(errorMessage(error, '시간 추적 정보를 불러오지 못했습니다.'));
    } finally {
      setTimetrackingLoading(false);
    }
  };

  const submitWorklog = async () => {
    if (!selectedIssue || worklogSubmitting) return;
    setWorklogError('');
    setWorklogMessage('');
    const parsedTime = parseWorklogTime(worklogTime);
    if (!parsedTime.ok || !parsedTime.normalized) {
      setWorklogError(parsedTime.error || '작업한 시간을 확인하세요.');
      return;
    }
    const payload: WorklogPayload = {
      timeSpent: parsedTime.normalized,
      comment: worklogComment.trim(),
      started: toJiraStartedValue(worklogStarted),
      adjustEstimate,
    };
    if (adjustEstimate === 'new') {
      const parsedEstimate = parseWorklogTime(newEstimate, true);
      if (!parsedEstimate.ok || !parsedEstimate.normalized) {
        setWorklogError(parsedEstimate.error || '새 남은 시간을 확인하세요.');
        return;
      }
      payload.newEstimate = parsedEstimate.normalized;
      setNewEstimate(parsedEstimate.normalized);
    }
    setWorklogSubmitting(true);
    try {
      const res = await fetch(`${API_BASE}/issues/${selectedIssue.key}/worklog?instance_id=${selectedIssue.instance_id}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(typeof data.detail === 'string' ? data.detail : '작업로그 등록에 실패했습니다.');
      setWorklogTime(parsedTime.normalized);
      setWorklogComment('');
      setWorklogMessage('작업로그가 추가되었습니다.');
      await fetchTimeTracking(selectedIssue);
      await fetchIssueDetail(selectedIssue.key, selectedIssue.instance_id);
    } catch (error: unknown) {
      setWorklogError(errorMessage(error, '작업로그 등록에 실패했습니다.'));
    } finally {
      setWorklogSubmitting(false);
    }
  };

  const submitOriginalEstimate = async () => {
    if (!selectedIssue || originalEstimateSubmitting) return;
    setOriginalEstimateError('');
    setOriginalEstimateMessage('');
    const parsed = parseWorklogTime(originalEstimateValue);
    if (!parsed.ok || !parsed.normalized) {
      setOriginalEstimateError(parsed.error || '최초 추정 시간을 확인하세요.');
      return;
    }
    setOriginalEstimateSubmitting(true);
    try {
      const res = await fetch(`${API_BASE}/issues/${selectedIssue.key}/original-estimate?instance_id=${selectedIssue.instance_id}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ originalEstimate: parsed.normalized }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(typeof data.detail === 'string' ? data.detail : '최초 추정 입력에 실패했습니다.');
      setOriginalEstimateValue(parsed.normalized);
      setOriginalEstimateMessage(data.status === 'updated' ? '최초 추정을 입력했습니다.' : '이미 최초 추정이 입력되어 있습니다.');
      await fetchTimeTracking(selectedIssue);
      await fetchIssueDetail(selectedIssue.key, selectedIssue.instance_id);
    } catch (error: unknown) {
      setOriginalEstimateError(errorMessage(error, '최초 추정 입력에 실패했습니다.'));
    } finally {
      setOriginalEstimateSubmitting(false);
    }
  };

  const autoSubmitOriginalEstimateForIssue = async (issue: JiraIssue) => {
    if (!originalEstimateEnabled || !originalEstimateAuto) return;
    if (!isOriginalEstimateTarget(issue) || issue.fields?.timetracking?.originalEstimate) return;
    const parsed = parseWorklogTime(originalEstimateValue);
    if (!parsed.ok || !parsed.normalized) return;

    setOriginalEstimateError('');
    setOriginalEstimateMessage('');
    setOriginalEstimateSubmitting(true);
    try {
      const res = await fetch(`${API_BASE}/issues/${issue.key}/original-estimate?instance_id=${issue.instance_id}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ originalEstimate: parsed.normalized }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(typeof data.detail === 'string' ? data.detail : '최초 추정 자동 입력에 실패했습니다.');
      if (data.status === 'updated') {
        setOriginalEstimateMessage('최초 추정을 자동 입력했습니다.');
      }
      await fetchTimeTracking(issue);
    } catch (error: unknown) {
      setOriginalEstimateError(errorMessage(error, '최초 추정 자동 입력에 실패했습니다.'));
    } finally {
      setOriginalEstimateSubmitting(false);
    }
  };

  const metaKey = (meta: IssueCreateProjectMeta) => `${meta.instance_id}:${meta.project_key}`;
  const selectedCreateMeta = createMetadata.find(meta => metaKey(meta) === createSelectedProject);
  const currentCreateUser = selectedCreateMeta ? userMap[selectedCreateMeta.instance_id.toString()] : null;
  const createAssigneeValue =
    createAssigneeMode === 'me'
      ? (currentCreateUser?.name || currentCreateUser?.key || currentCreateUser?.accountId || '')
      : createAssigneeMode === 'manual'
        ? (createAssigneeSelected?.name || createAssigneeSelected?.key || createAssigneeSelected?.id || '')
        : '';

  const searchUsersForContext = useCallback(async (
    query: string,
    options: { issueKey?: string; instanceId?: number; projectKey?: string; assignable?: boolean }
  ): Promise<JiraUserSuggestion[]> => {
    if (!query.trim()) return [];
    const params = new URLSearchParams({ query: query.trim() });
    if (options.issueKey) params.set('issue_key', options.issueKey);
    if (options.instanceId !== undefined) params.set('instance_id', String(options.instanceId));
    if (options.projectKey) params.set('project_key', options.projectKey);
    if (options.assignable) params.set('assignable', 'true');
    try {
      const res = await fetch(`${API_BASE}/users/search?${params.toString()}`);
      const data = await res.json();
      const users = Array.isArray(data) ? data : (data.users || []);
      return users.map(normalizeJiraUserSuggestion).filter(Boolean) as JiraUserSuggestion[];
    } catch {
      return [];
    }
  }, []);

  const applyCreateDefaults = (meta?: IssueCreateProjectMeta) => {
    setCreateIssueType(meta?.issue_types[0]?.name || '');
    setCreateComponent('');
    setCreateAssigneeMode('default');
    setCreateAssigneeQuery('');
    setCreateAssigneeSelected(null);
    setCreateAssigneeSuggestions([]);
  };

  const loadCreateMetadata = async () => {
    setCreateMetadataLoading(true);
    setCreateError('');
    try {
      const res = await fetch(`${API_BASE}/issues/create-metadata`);
      const data = await res.json();
      const availableProjects: IssueCreateProjectMeta[] = (data.projects || []).filter((meta: IssueCreateProjectMeta) => meta.issue_types?.length || meta.components?.length);
      setCreateMetadata(availableProjects);
      const current = availableProjects.find(meta => metaKey(meta) === createSelectedProject);
      const next = current || availableProjects[0];
      setCreateSelectedProject(next ? metaKey(next) : '');
      applyCreateDefaults(next);
    } catch (error: unknown) {
      setCreateError(errorMessage(error, '생성 정보를 불러오지 못했습니다.'));
    } finally {
      setCreateMetadataLoading(false);
    }
  };

  const openCreateIssueModal = () => {
    setCreateModalOpen(true);
    setCreateError('');
    if (createMetadata.length === 0) loadCreateMetadata();
  };

  const resetCreateIssueForm = () => {
    setCreateSummary('');
    setCreateDescription('');
    setCreateComponent('');
    setCreateAssigneeMode('default');
    setCreateAssigneeQuery('');
    setCreateAssigneeSelected(null);
    setCreateAssigneeSuggestions([]);
    setCreateError('');
  };

  const extractJiraErrorMessage = (payload: unknown, fallback: string) => {
    const collect = (value: unknown): string[] => {
      if (!value) return [];
      if (typeof value === 'string') {
        const trimmed = value.trim();
        if (!trimmed) return [];
        if (trimmed.startsWith('{') || trimmed.startsWith('[')) {
          try {
            return collect(JSON.parse(trimmed));
          } catch {
            return [trimmed];
          }
        }
        return [trimmed];
      }
      if (Array.isArray(value)) return value.flatMap(collect);
      if (typeof value === 'object') {
        const record = value as UnknownRecord;
        const messages: string[] = [];
        if (record.detail) messages.push(...collect(record.detail));
        if (record.message) messages.push(...collect(record.message));
        if (record.errorMessages) messages.push(...collect(record.errorMessages));
        if (record.errors && typeof record.errors === 'object') {
          messages.push(...Object.values(record.errors).flatMap(collect));
        }
        return messages;
      }
      return [];
    };

    const messages = Array.from(new Set(collect(payload)));
    return messages.length ? messages.join('\n') : fallback;
  };

  const submitCreateIssue = async () => {
    if (!selectedCreateMeta || !createIssueType || !createSummary.trim() || createSubmitting) return;
    if (createAssigneeMode === 'me' && !createAssigneeValue) {
      setCreateError('현재 Jira 계정 정보를 찾을 수 없습니다.');
      return;
    }
    if (createAssigneeMode === 'manual' && !createAssigneeValue) {
      setCreateError('담당자를 선택해 주세요.');
      return;
    }
    setCreateSubmitting(true);
    setCreateError('');
    try {
      const res = await fetch(`${API_BASE}/issues`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          instance_id: selectedCreateMeta.instance_id,
          project_key: selectedCreateMeta.project_key,
          issuetype_name: createIssueType,
          summary: createSummary.trim(),
          description: convertMentionsToJiraFormat(createDescription),
          component_name: createComponent || null,
          assignee_name: createAssigneeValue || null,
        }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(extractJiraErrorMessage(data, 'Jira 이슈 생성에 실패했습니다.'));
      resetCreateIssueForm();
      setCreateModalOpen(false);
      await fetchIssues();
      if (data?.key) {
        const createdIssue: JiraIssue = {
          key: data.key,
          instance_id: selectedCreateMeta.instance_id,
          fields: {
            summary: createSummary.trim(),
            status: { name: 'Created' },
            project: { key: selectedCreateMeta.project_key },
            issuetype: { name: createIssueType },
            assignee: createAssigneeValue ? { name: createAssigneeValue, displayName: createAssigneeMode === 'manual' ? (createAssigneeSelected?.display || createAssigneeValue) : (currentCreateUser?.displayName || createAssigneeValue) } : null,
            reporter: null,
            updated: new Date().toISOString(),
            created: new Date().toISOString(),
          },
        };
        handleOpenDetailModal(createdIssue);
      }
    } catch (error: unknown) {
      setCreateError(errorMessage(error, 'Jira 이슈 생성에 실패했습니다.'));
    } finally {
      setCreateSubmitting(false);
    }
  };

  // Preserve both the display name and Jira user id. The backend converts this
  // to an ADF mention for Cloud or [~username] for Server/Data Center.
  const convertMentionsToJiraFormat = (text: string) => text;

  const escapeHtml = (value: string) => value
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');

  const stripEmptyJiraMarkers = (value: string): string => value
    .replace(/\{\s*(?:<!--[\s\S]*?-->\s*)*(?:<\/?[^>]+>\s*)*\}/g, '')
    .replace(/&#0*123;\s*(?:<!--[\s\S]*?-->\s*)*(?:<\/?[^>]+>\s*)*&#0*125;/gi, '')
    .replace(/&#x0*7b;\s*(?:<!--[\s\S]*?-->\s*)*(?:<\/?[^>]+>\s*)*&#x0*7d;/gi, '')
    .replace(/&lbrace;\s*(?:<!--[\s\S]*?-->\s*)*(?:<\/?[^>]+>\s*)*&rbrace;/gi, '');

  const normalizeJiraWikiMarkers = (value: string): string => value
    .replace(/\{\*\}/g, '*')
    .replace(/\{_\}/g, '_')
    .replace(/\{\+\}/g, '+')
    .replace(/\{-\}/g, '-');

  const renderJiraWikiToHtml = (text: string): string => {
    const trimJiraTableRow = (row: string, delimiter: '|' | '||'): string => {
      let value = row;
      if (value.startsWith(delimiter)) value = value.slice(delimiter.length);
      if (value.endsWith(delimiter)) value = value.slice(0, -delimiter.length);
      return value;
    };

    const splitJiraTableCells = (row: string, delimiter: '|' | '||'): string[] => {
      const cells: string[] = [];
      let current = '';
      let bracketDepth = 0;

      for (let index = 0; index < row.length; index += 1) {
        const char = row[index];

        if (char === '[') {
          bracketDepth += 1;
          current += char;
          continue;
        }

        if (char === ']' && bracketDepth > 0) {
          bracketDepth -= 1;
          current += char;
          continue;
        }

        if (bracketDepth === 0 && row.startsWith(delimiter, index)) {
          cells.push(current);
          current = '';
          index += delimiter.length - 1;
          continue;
        }

        current += char;
      }

      cells.push(current);
      return cells;
    };

    const mergeMultilineTableRows = (rawLines: string[]) => {
      const merged: string[] = [];
      let pending: string | null = null;

      rawLines.forEach(line => {
        const trimmed = line.trim();
        if (pending !== null) {
          pending += trimmed ? `\n${line}` : '\n';
          if (trimmed.endsWith('|')) {
            merged.push(pending);
            pending = null;
          }
          return;
        }

        if (/^\|/.test(trimmed) && !trimmed.endsWith('|')) {
          pending = line;
          return;
        }

        merged.push(line);
      });

      if (pending !== null) merged.push(pending);
      return merged;
    };

    const lines = mergeMultilineTableRows(stripEmptyJiraMarkers(text).split('\n'));
    const result: string[] = [];
    let inTable = false;

    for (const line of lines) {
      const trimmed = line.trim();
      const isHeaderRow = /^\|\|/.test(trimmed);
      const isDataRow = !isHeaderRow && /^\|/.test(trimmed) && /\|$/.test(trimmed);

      if (isHeaderRow || isDataRow) {
        if (!inTable) { result.push('<table class="jira-wiki-table"><tbody>'); inTable = true; }
        if (isHeaderRow) {
          const cells = splitJiraTableCells(trimJiraTableRow(trimmed, '||'), '||');
          result.push('<tr>' + cells.map(c => `<th>${renderJiraTableCell(c.trim())}</th>`).join('') + '</tr>');
        } else {
          const cells = splitJiraTableCells(trimJiraTableRow(trimmed, '|'), '|');
          result.push('<tr>' + cells.map(c => `<td>${renderJiraTableCell(c.trim())}</td>`).join('') + '</tr>');
        }
      } else {
        if (inTable) { result.push('</tbody></table>'); inTable = false; }
        result.push(trimmed === '' ? '<br/>' : `<p>${renderJiraInline(line)}</p>`);
      }
    }
    if (inTable) result.push('</tbody></table>');
    return result.join('');
  };

  const renderJiraTableCell = (text: string): string =>
    renderJiraInline(normalizeJiraWikiMarkers(text)).replace(/\r?\n/g, '<br/>');

  const replaceBoundedJiraStyle = (
    value: string,
    marker: '*' | '_' | '+' | '-',
    render: (content: string) => string
  ): string => {
    const escapedMarker = marker.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const contentPattern = marker === '-'
      ? `(?!&gt;)([^${escapedMarker}\\n]+?)`
      : `([^${escapedMarker}\\n]+?)`;
    const pattern = new RegExp(
      `(^|[^\\p{L}\\p{N}_-])${escapedMarker}${contentPattern}${escapedMarker}(?=$|[^\\p{L}\\p{N}_-])`,
      'gu'
    );

    return value.replace(pattern, (_match, prefix, content) => `${prefix}${render(content)}`);
  };

  const renderJiraInline = (text: string): string => {
    const safeColor = (color: string) => {
      const trimmed = color.trim();
      if (/^#[0-9a-fA-F]{3}([0-9a-fA-F]{3})?$/.test(trimmed)) return trimmed;
      if (/^rgba?\(\s*\d{1,3}\s*,\s*\d{1,3}\s*,\s*\d{1,3}(?:\s*,\s*(?:0|1|0?\.\d+))?\s*\)$/.test(trimmed)) return trimmed;
      return '';
    };

    const protectedTokens: string[] = [];
    const protectToken = (html: string) => {
      const token = `@@JIRA_INLINE_${protectedTokens.length}@@`;
      protectedTokens.push(html);
      return token;
    };
    const protectExplicitStyle = (
      value: string,
      marker: '*' | '_' | '+' | '-',
      render: (content: string) => string
    ) => {
      const escapedMarker = marker.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      return value.replace(
        new RegExp(`\\{${escapedMarker}\\}([\\s\\S]+?)\\{${escapedMarker}\\}`, 'g'),
        (_match, content) => protectToken(render(content))
      );
    };

    let html = escapeHtml(stripEmptyJiraMarkers(text));
    html = protectExplicitStyle(html, '*', (content) => `<strong>${content}</strong>`);
    html = protectExplicitStyle(html, '_', (content) => `<em>${content}</em>`);
    html = protectExplicitStyle(html, '+', (content) => `<span class="jira-underline">${content}</span>`);
    html = protectExplicitStyle(html, '-', (content) => `<span class="jira-strike">${content}</span>`);
    html = normalizeJiraWikiMarkers(html)
      .replace(/\{color:([^}]+)\}([\s\S]*?)\{color\}/g, (_match, color, content) => {
        const colorValue = safeColor(color);
        return colorValue ? `<span style="color:${colorValue}">${content}</span>` : content;
      })
      .replace(/\{\}/g, '')
      .replace(/\{\{([^}]+)\}\}/g, (_match, content) => protectToken(`<code>${content}</code>`))
      .replace(/\?\?([^?\n]+)\?\?/g, (_match, content) => protectToken(`<cite>${content}</cite>`));

    html = replaceBoundedJiraStyle(html, '*', (content) => `<strong>${content}</strong>`);
    html = replaceBoundedJiraStyle(html, '_', (content) => `<em>${content}</em>`);
    html = replaceBoundedJiraStyle(html, '+', (content) => `<span class="jira-underline">${content}</span>`);
    html = replaceBoundedJiraStyle(html, '-', (content) => `<span class="jira-strike">${content}</span>`);

    return html
      .replace(/\[([^\]|]+)\|([^\]]+)\]/g, (_match, label, url) => {
        const href = url.trim();
        if (!/^https?:\/\//i.test(href)) return label;
        return `<a href="${href}" target="_blank" rel="noopener noreferrer">${label}</a>`;
      })
      .replace(/\[~([^\]]+)\]/g, '<span class="jira-mention">@$1</span>')
      .replace(/@@JIRA_INLINE_(\d+)@@/g, (_match, index) => protectedTokens[Number(index)] || '');
  };

  const renderJiraCommentHtml = (comment: JiraComment): string => {
    return renderJiraWikiToHtml(comment.body || '');
  };

  const searchUsers = async (query: string, callback: (users: JiraUserSuggestion[]) => void) => {
    if (!query || !selectedIssue) return;
    const users = await searchUsersForContext(query, { issueKey: selectedIssue.key });
    callback(users);
  };

  const searchCreateMentionUsers = async (query: string, callback: (users: JiraUserSuggestion[]) => void) => {
    if (!selectedCreateMeta) {
      callback([]);
      return;
    }
    const users = await searchUsersForContext(query, {
      instanceId: selectedCreateMeta.instance_id,
      projectKey: selectedCreateMeta.project_key,
    });
    callback(users);
  };

  useEffect(() => {
    let cancelled = false;
    const timer = window.setTimeout(async () => {
      if (createAssigneeMode !== 'manual' || !selectedCreateMeta || createAssigneeSelected || createAssigneeQuery.trim().length < 1) {
        setCreateAssigneeSuggestions([]);
        setCreateAssigneeLoading(false);
        return;
      }
      setCreateAssigneeLoading(true);
      const users = await searchUsersForContext(createAssigneeQuery, {
        instanceId: selectedCreateMeta.instance_id,
        projectKey: selectedCreateMeta.project_key,
        assignable: true,
      });
      if (!cancelled) {
        setCreateAssigneeSuggestions(users);
        setCreateAssigneeLoading(false);
      }
    }, 180);
    return () => {
      cancelled = true;
      window.clearTimeout(timer);
    };
  }, [createAssigneeMode, createAssigneeQuery, createAssigneeSelected, searchUsersForContext, selectedCreateMeta]);

  useEffect(() => { 
    const fetchConfig = async () => {
      try {
        const res = await fetch(`${API_BASE}/config`);
        const data = await res.json();
        setJiraUrl(data.jira_base_url);
        setInstanceList(data.instances || []);
        setTrackingProjects(data.tracking_projects || []);
        setAllowUnassignedProcessing(Boolean(data.allow_unassigned_processing));
        setAllowAllProjectWorklog(Boolean(data.allow_all_project_worklog));
        setOriginalEstimateEnabled(Boolean(data.original_estimate_enabled));
        setOriginalEstimateAuto(Boolean(data.original_estimate_auto));
        setOriginalEstimateValue(data.original_estimate_value || '');
      } catch {
        // Dashboard settings are optional; retain the current defaults.
      }
    };
    const fetchMe = async () => {
      try {
        const res = await fetch(`${API_BASE}/me`);
        const data = await res.json();
        setUserMap(data);
      } catch {
        // User metadata is optional for rendering the dashboard.
      } finally {
        setUserMapLoaded(true);
      }
    };
    fetchMe(); fetchConfig(); 
    if ('Notification' in window && Notification.permission !== 'granted' && Notification.permission !== 'denied') Notification.requestPermission(); 
  }, []);

  useEffect(() => {
    if (instanceList.length === 0 || instanceFilter === 'all') return;
    const selectedInstanceStillExists = instanceList.some(instance => String(instance.id) === instanceFilter);
    if (selectedInstanceStillExists) return;

    setInstanceFilter('all');
    localStorage.setItem('dashboardInstanceFilter', 'all');
    localStorage.removeItem('instanceFilter');
    setProjectFilter('all');
    localStorage.setItem('projectFilter', 'all');
  }, [instanceFilter, instanceList]);

  useEffect(() => {
    if (loading || projectFilter === 'all') return;
    const availableProjects = new Set(
      issues
        .filter(issue => instanceFilter === 'all' || String(issue.instance_id) === instanceFilter)
        .map(issue => issue.fields?.project?.key)
        .filter((key): key is string => Boolean(key)),
    );
    if (availableProjects.has(projectFilter)) return;

    setProjectFilter('all');
    localStorage.setItem('projectFilter', 'all');
  }, [instanceFilter, issues, loading, projectFilter]);

  useEffect(() => {
    const syncDashboardSettings = () => {
      setRefreshInterval(parseInt(localStorage.getItem('refreshInterval') || '15'));
      setCacheMinutes(parseInt(localStorage.getItem('cacheMinutes') || '5'));
      setTrackOwnActivity(localStorage.getItem(TRACK_OWN_ACTIVITY_STORAGE_KEY) !== 'false');
      fetch(`${API_BASE}/config`)
        .then(res => res.json())
        .then(data => {
          setTrackingProjects(data.tracking_projects || []);
          setAllowUnassignedProcessing(Boolean(data.allow_unassigned_processing));
          setAllowAllProjectWorklog(Boolean(data.allow_all_project_worklog));
          setOriginalEstimateEnabled(Boolean(data.original_estimate_enabled));
          setOriginalEstimateAuto(Boolean(data.original_estimate_auto));
          setOriginalEstimateValue(data.original_estimate_value || '');
        })
        .catch(() => {});
    };
    window.addEventListener('storage', syncDashboardSettings);
    window.addEventListener('refreshIntervalChanged', syncDashboardSettings);
    window.addEventListener('dashboardSettingsChanged', syncDashboardSettings);
    return () => {
      window.removeEventListener('storage', syncDashboardSettings);
      window.removeEventListener('refreshIntervalChanged', syncDashboardSettings);
      window.removeEventListener('dashboardSettingsChanged', syncDashboardSettings);
    };
  }, []);

  useEffect(() => {
    if (!userMapLoaded) return;
    const initialTimer = window.setTimeout(() => {
      void fetchIssues();
    }, 0);
    const interval = window.setInterval(fetchIssues, refreshInterval * 1000);
    return () => {
      window.clearTimeout(initialTimer);
      window.clearInterval(interval);
    };
  }, [datePreset, startDate, endDate, refreshInterval, userMapLoaded, fetchIssues]);

  const toggleWorklogPanel = () => {
    const nextOpen = !worklogOpen;
    setWorklogOpen(nextOpen);
    if (nextOpen && selectedIssue && canUseWorklogPanel) {
      setWorklogStarted(toLocalDateTimeInputValue());
      setWorklogStartedTouched(false);
      void fetchTimeTracking(selectedIssue);
    }
  };

  const handleWorklogTimeChange = (value: string) => {
    setWorklogTime(value);
    if (worklogOpen && !worklogStartedTouched) {
      const parsed = parseWorklogTime(value);
      if (parsed.ok) setWorklogStarted(getAutoStartedValue(parsed.minutes));
    }
  };

  const handlePasteImage = async (e: React.ClipboardEvent, setter: React.Dispatch<React.SetStateAction<string>>) => {
    if (!selectedIssue) return;
    const items = e.clipboardData?.items;
    if (!items) return;
    for (const item of items) {
        if (item.type.indexOf('image') !== -1) {
            e.preventDefault();
            const file = item.getAsFile();
            if (!file) continue;
            const formData = new FormData();
            formData.append('file', file);
            try {
                const res = await fetch(`${API_BASE}/issues/${selectedIssue.key}/attachments?instance_id=${selectedIssue.instance_id}`, { method: 'POST', body: formData });
                if (res.ok) {
                    const data = await res.json();
                    const filename = data.data?.[0]?.filename || file.name;
                    setter(prev => prev + `\n!${filename}!\n`);
                } else {
                    alert('이미지 업로드 실패');
                }
            } catch(e) { console.error(e); }
        }
    }
  };


  const formatDateTime = (s: string | undefined) => {
    if (!s) return '-'; const d = new Date(s); const now = new Date(); const diff = now.getTime() - d.getTime();
    if (diff > 0 && diff < 7200000) {
      const min = Math.floor(diff/60000);
      return `${min < 1 ? '방금 전' : (min < 60 ? min+'분 전' : '1시간 전')} (${d.toLocaleString()})`;
    }
    return d.toLocaleString();
  };

  const persistReadState = async (readTargets: JiraIssue[]) => {
    if (readTargets.length === 0) return;
    try {
      const res = await fetch(`${API_BASE}/dashboard/issue-states/read`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          issues: readTargets
            .filter(issue => Boolean(issue.fields?.updated))
            .map(issue => ({
              instance_id: issue.instance_id,
              issue_key: issue.key,
              observed_updated_at: issue.fields.updated,
              read_updated_at: issue.fields.updated,
            })),
        }),
      });
      const payload = await res.json().catch(() => null) as DashboardIssueStatePayload | null;
      if (!res.ok || !payload) throw new Error('읽음 상태 저장에 실패했습니다.');
      const maps = dashboardStateMaps(payload.states);
      setReadIssues(maps.read);
      setUnreadUpdatedIssues(maps.unread);
    } catch (error) {
      console.error(error);
    }
  };

  const handleOpenDetailModal = (i: JiraIssue) => {
    if (isUnavailableIssue(i)) {
      removeFavoriteIssue(i);
      return;
    }
    setSelectedIssue(i); setActiveModal('detail'); fetchIssueDetail(i.key, i.instance_id);
    setCommentText('');
    setEditingCommentId(null);
    setEditingCommentText('');
    setWorklogOpen(false);
    setTimetracking(null);
    setWorklogTime('');
    setWorklogComment('');
    setWorklogStarted(toLocalDateTimeInputValue());
    setWorklogStartedTouched(false);
    setAdjustEstimate('auto');
    setNewEstimate('');
    setWorklogMessage('');
    setWorklogError('');
    setOriginalEstimateMessage('');
    setOriginalEstimateError('');
    autoSubmitOriginalEstimateForIssue(i);
    const key = issueStorageKey(i);
    const readUpdated = i.fields?.updated;
    const nr = readUpdated ? { ...readIssues, [key]: readUpdated } : readIssues;
    setReadIssues(nr);
    if (unreadUpdatedIssues[key]) {
      const nextUnread = { ...unreadUpdatedIssues };
      delete nextUnread[key];
      setUnreadUpdatedIssues(nextUnread);
    }
    void persistReadState([i]);
  };

  const issuesByKey = new Map(issues.map(issue => [issueStorageKey(issue), issue]));
  const displaySourceIssues = [
    ...Object.values(favoriteIssues).map(issue => issuesByKey.get(issueStorageKey(issue)) || issue),
    ...issues.filter(issue => !favoriteIssues[issueStorageKey(issue)])
  ];
  const visibleIssuesForFilter = instanceFilter === 'all' ? issues : issues.filter(i => i.instance_id.toString() === instanceFilter);
  const projectList = Array.from(new Set(visibleIssuesForFilter.map(i => i.fields?.project?.key).filter(Boolean))).sort();
  const matchesIssueSearch = (issue: JiraIssue) => {
    const query = searchQuery.trim().toLowerCase();
    if (!query) return true;
    const haystack = `${issue.key || ''} ${issue.fields?.summary || ''}`.toLowerCase();
    return haystack.includes(query);
  };
  const filteredIssues = displaySourceIssues.filter(i => {
    if (isFavoriteIssue(i)) return true;
    const pMatch = projectFilter === 'all' || i.fields?.project?.key === projectFilter;
    const iMatch = instanceFilter === 'all' || i.instance_id.toString() === instanceFilter;
    const sMatch = matchesIssueSearch(i);
    return pMatch && iMatch && sMatch;
  });

  const hasUnreadVisibleIssue = filteredIssues.some(issue => {
    const key = issueStorageKey(issue);
    return Boolean(unreadUpdatedIssues[key] && !isReadUpdate(readIssues[key], unreadUpdatedIssues[key]));
  });
  const worklogTimePreview = worklogTime.trim() ? parseWorklogTime(worklogTime) : null;
  const newEstimatePreview = newEstimate.trim() ? parseWorklogTime(newEstimate, true) : null;
  const tracked = timetracking?.timetracking || {};
  const displayTracking = {
    originalEstimate: tracked.originalEstimate || '없음',
    remainingEstimate: tracked.remainingEstimate || '없음',
    timeSpent: tracked.timeSpent || '없음',
  };

  const markVisibleIssuesAsRead = () => {
    const nextRead = { ...readIssues };
    const nextUnread = { ...unreadUpdatedIssues };
    const readTargets: JiraIssue[] = [];
    let changed = false;

    filteredIssues.forEach(issue => {
      const key = issueStorageKey(issue);
      const unreadUpdated = unreadUpdatedIssues[key];
      if (!unreadUpdated) return;

      const readUpdated = issue.fields?.updated || unreadUpdated;
      nextRead[key] = readUpdated;
      delete nextUnread[key];
      readTargets.push(issue);
      changed = true;
    });

    if (!changed) return;
    setReadIssues(nextRead);
    setUnreadUpdatedIssues(nextUnread);
    void persistReadState(readTargets);
  };

  const sortIssues = (a: JiraIssue, b: JiraIssue) => {
    const favoriteDiff = Number(isFavoriteIssue(b)) - Number(isFavoriteIssue(a));
    if (favoriteDiff !== 0) return favoriteDiff;
    const aUpdated = Boolean(unreadUpdatedIssues[issueStorageKey(a)] && !isReadUpdate(readIssues[issueStorageKey(a)], unreadUpdatedIssues[issueStorageKey(a)]));
    const bUpdated = Boolean(unreadUpdatedIssues[issueStorageKey(b)] && !isReadUpdate(readIssues[issueStorageKey(b)], unreadUpdatedIssues[issueStorageKey(b)]));
    if (aUpdated && !bUpdated) return -1;
    if (!aUpdated && bUpdated) return 1;
    const dateA = new Date(a.fields?.updated || a.fields?.created || 0).getTime();
    const dateB = new Date(b.fields?.updated || b.fields?.created || 0).getTime();
    return dateB - dateA;
  };

  const renderIssueCard = (issue: JiraIssue, type: 'assigned' | 'mentioned' | 'reported') => {
    const key = issueStorageKey(issue);
    const isUpdated = Boolean(unreadUpdatedIssues[key] && !isReadUpdate(readIssues[key], unreadUpdatedIssues[key]));
    const instName = instanceList.find(ins => ins.id === issue.instance_id)?.name;
    const isFavorite = isFavoriteIssue(issue);
    const isUnavailable = isUnavailableIssue(issue);
    const issuePriority = issue.fields?.priority?.name;
    return (
      <motion.div key={issue.key + '_' + issue.instance_id} layout initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, scale: 0.9 }}>
        <div className={`issue-card ${type === 'mentioned' ? 'mentioned' : ''} ${type === 'reported' ? 'reported' : ''} ${isUpdated ? 'has-update' : ''}`} onClick={() => handleOpenDetailModal(issue)}>
          <button
            className={`favorite-star-button ${isFavorite ? 'active' : ''}`}
            title={isFavorite ? '즐겨찾기 해제' : '즐겨찾기'}
            onClick={(e) => {
              e.stopPropagation();
              toggleFavoriteIssue(issue);
            }}
          >
            <Star size={17} fill={isFavorite ? '#f1c40f' : 'none'} />
          </button>
          <div className="issue-header" style={{alignItems: 'center', justifyContent: 'space-between', display: 'flex'}}>
            <span className="issue-key">
              {instanceList.length > 1 && instName && <span className="instance-badge">{instName}</span>}
              {type === 'mentioned' && '📢 '}{type === 'reported' && '👀 '}{type === 'assigned' && '📅 '}{issue.key}
            </span>
            <span className="status-badge" style={{marginTop: 0}}>{isUnavailable ? '삭제 됨' : issue.fields?.status?.name}</span>
          </div>
          <div className="issue-summary">{issue.fields?.summary}</div>
          <div className="issue-footer" style={{marginTop: 'auto'}}>
            <div className="issue-assignee" style={{fontSize: '12px', fontWeight: 600, color: 'var(--text-secondary)'}}>
              <span>{issue.fields?.assignee?.displayName || issue.fields?.assignee?.name || '할당 안됨'}</span>
            </div>
            <div style={{display: 'flex', alignItems: 'center', gap: '8px'}}>
              {issuePriority && (
                <Flag
                  size={16}
                  color={priorityColor(issuePriority)}
                  fill={priorityColor(issuePriority)}
                  aria-label={`우선순위: ${issuePriority}`}
                >
                  <title>{`우선순위: ${issuePriority}`}</title>
                </Flag>
              )}
              <span className="issue-date" style={{fontSize: '12px', color: 'var(--text-secondary)'}}>{new Date(issue.fields?.updated || issue.fields?.created || 0).toLocaleDateString()}</span>
            </div>
          </div>
        </div>
      </motion.div>
    );
  };

  return (
    <div className="dashboard-glass-container">
      <div style={{ display: 'flex', flexDirection: 'column', gap: 20, marginBottom: 30 }}>
        <div style={{display:'flex', gap:'12px', alignItems:'center', flexWrap: 'nowrap', width: '100%', boxSizing: 'border-box', background: 'var(--card-bg)', padding: '12px 16px', borderRadius: '12px', boxShadow: '0 4px 15px rgba(0,0,0,0.05)', overflowX: 'auto', overflowY: 'hidden'}}>
          <div style={{display: 'flex', alignItems: 'center', gap: 5, flexShrink: 0}}>
            <span style={{fontSize: 13, fontWeight: 700, color: 'var(--text-secondary)'}}>계정</span>
            <select className="glass-input" style={{width: 'auto', padding: '6px 12px'}} value={instanceFilter} onChange={e => {setInstanceFilter(e.target.value); localStorage.setItem('dashboardInstanceFilter', e.target.value); setProjectFilter('all');}}>
              <option value="all">모든 계정</option>
              {instanceList.map(inst => <option key={inst.id} value={inst.id}>{inst.name}</option>)}
            </select>
          </div>

          <div style={{display: 'flex', alignItems: 'center', gap: 5, flexShrink: 0}}>
            <span style={{fontSize: 13, fontWeight: 700, color: 'var(--text-secondary)'}}>기간</span>
            <select className="glass-input" style={{width: 'auto', padding: '6px 12px'}} value={datePreset} onChange={(e) => {setDatePreset(e.target.value); localStorage.setItem('datePreset', e.target.value)}}>
              <option value="1">1일</option><option value="7">7일</option><option value="14">14일</option><option value="30">30일</option><option value="90">90일</option><option value="all">전체</option><option value="custom">직접입력</option>
            </select>
            {datePreset === 'custom' && (
              <div style={{display: 'flex', alignItems: 'center', gap: 5, marginLeft: 5, flexShrink: 0}}>
                <input type="date" className="glass-input" style={{padding: '6px', fontSize: 12}} value={startDate} onChange={e => handleStartDateChange(e.target.value)} />
                <span style={{color: '#ccc'}}>~</span>
                <input type="date" className="glass-input" style={{padding: '6px', fontSize: 12}} value={endDate} onChange={e => handleEndDateChange(e.target.value)} />
              </div>
            )}
          </div>

          <div style={{display: 'flex', alignItems: 'center', gap: 5, flexShrink: 0}}>
            <span style={{fontSize: 13, fontWeight: 700, color: 'var(--text-secondary)'}}>프로젝트</span>
            <select className="glass-input" style={{width: 'auto', padding: '6px 12px'}} value={projectFilter} onChange={e => {setProjectFilter(e.target.value); localStorage.setItem('projectFilter', e.target.value)}}>
              <option value="all">모든 프로젝트</option>
              {projectList.map(p => <option key={p} value={p}>{p}</option>)}
            </select>
          </div>

          <label
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: 6,
              fontSize: 13,
              fontWeight: 700,
              color: 'var(--text-secondary)',
              cursor: 'pointer',
              whiteSpace: 'nowrap',
              flexShrink: 0
            }}
          >
            <input
              type="checkbox"
              checked={includeClosed}
              onChange={e => {
                setIncludeClosed(e.target.checked);
                localStorage.setItem('dashboardIncludeClosedIssues', e.target.checked ? 'true' : 'false');
                localStorage.setItem('includeClosedIssues', e.target.checked ? 'true' : 'false');
              }}
              style={{cursor: 'pointer'}}
            />
            완료/닫힘 포함
          </label>
          
          <div style={{display: 'flex', alignItems: 'center', gap: 10, marginLeft: 'auto', flexWrap: 'nowrap', flexShrink: 0}}>
            <div style={{display: 'flex', alignItems: 'center', gap: 8, whiteSpace: 'nowrap', flexShrink: 0}}>
               <span style={{ fontSize: '11px', color: 'var(--text-secondary)' }}>최종 갱신: {lastUpdated.toLocaleTimeString()}</span>
               <button className="btn-premium" style={{padding: '6px 12px'}} onClick={markVisibleIssuesAsRead} disabled={!hasUnreadVisibleIssue} title="현재 표시된 티켓 모두 읽음"><CheckCheck size={14} /></button>
               <button className="btn-premium" style={{padding: '6px 12px'}} onClick={fetchIssues}><RefreshCcw size={14} /></button>
            </div>
          </div>
        </div>
        <div style={{position: 'relative', width: '100%'}}>
          <Search size={16} style={{position: 'absolute', left: 14, top: '50%', transform: 'translateY(-50%)', color: 'var(--text-secondary)', pointerEvents: 'none'}} />
          <input
            className="glass-input"
            type="search"
            value={searchQuery}
            onChange={e => {
              setSearchQuery(e.target.value);
              localStorage.setItem('dashboardSearchQuery', e.target.value);
            }}
            placeholder="티켓 번호 또는 제목 검색"
            style={{width: '100%', padding: '10px 14px 10px 40px', boxSizing: 'border-box'}}
          />
        </div>
      </div>

      {loading ? (<div style={{ textAlign: 'center', marginTop: '100px', color: 'var(--text-secondary)' }}><div style={{margin: '0 auto 15px auto', width: 30, height: 30, border: '3px solid rgba(0,0,0,0.1)', borderTopColor: 'var(--accent-color)', borderRadius: '50%', animation: 'spin 1s linear infinite'}} />데이터 수집 중...</div>) : (
        <div className="dashboard-board">
          {/* Assigned Column */}
          <div className="dashboard-column">
            <div className="dashboard-column-header">
              <h2>내 업무 <span style={{fontWeight: 400, opacity: 0.6, fontSize: 13}}>(Assigned)</span></h2>
              <div className="dashboard-header-actions">
                <button className="dashboard-create-issue-button" onClick={openCreateIssueModal} title="내 업무 Jira 기록">
                  <Plus size={14} />
                  <span>기록</span>
                </button>
                <span className="dashboard-count-badge">{filteredIssues.filter(isIssueAssignedToMe).length}</span>
              </div>
            </div>
            <motion.div layout className="issue-grid" style={{display: 'flex', flexDirection: 'column', gap: 15}}>
              <AnimatePresence>
                {filteredIssues.filter(isIssueAssignedToMe).sort(sortIssues).map(issue => renderIssueCard(issue, 'assigned'))}
              </AnimatePresence>
            </motion.div>
          </div>
          
          {/* Mentioned Column */}
          <div className="dashboard-column">
            <div className="dashboard-column-header">
              <h2>멘션된 업무 <span style={{fontWeight: 400, opacity: 0.6, fontSize: 13}}>(Mentioned)</span></h2>
              <span className="dashboard-count-badge">{filteredIssues.filter(isIssueMentionedForMe).length}</span>
            </div>
            <motion.div layout className="issue-grid" style={{display: 'flex', flexDirection: 'column', gap: 15}}>
              <AnimatePresence>
                {filteredIssues.filter(isIssueMentionedForMe).sort(sortIssues).map(issue => renderIssueCard(issue, 'mentioned'))}
              </AnimatePresence>
            </motion.div>
          </div>
          
          {/* Reported Column */}
          <div className="dashboard-column">
            <div className="dashboard-column-header">
              <h2>보고한 업무 <span style={{fontWeight: 400, opacity: 0.6, fontSize: 13}}>(Reported)</span></h2>
              <span className="dashboard-count-badge">{filteredIssues.filter(isIssueReportedByMe).length}</span>
            </div>
            <motion.div layout className="issue-grid" style={{display: 'flex', flexDirection: 'column', gap: 15}}>
              <AnimatePresence>
                {filteredIssues.filter(isIssueReportedByMe).sort(sortIssues).map(issue => renderIssueCard(issue, 'reported'))}
              </AnimatePresence>
            </motion.div>
          </div>
        </div>
      )}

      <AnimatePresence>
        {createModalOpen && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="glass-modal-overlay" onClick={() => setCreateModalOpen(false)}>
            <motion.div initial={{ scale: 0.94, y: 18 }} animate={{ scale: 1, y: 0 }} exit={{ scale: 0.94, y: 18 }} className="glass-modal-content create-issue-modal" onClick={e => e.stopPropagation()} style={{textAlign: 'left'}}>
              <div className="create-issue-modal-header">
                <div>
                  <div className="apple-meta-label">Jira issue</div>
                  <h2>내 업무 기록</h2>
                </div>
                <button className="btn-secondary" onClick={() => setCreateModalOpen(false)}>닫기</button>
              </div>

              {createMetadataLoading ? (
                <div className="create-issue-loading">
                  <div style={{margin: '0 auto 15px auto', width: 30, height: 30, border: '3px solid rgba(0,0,0,0.1)', borderTopColor: 'var(--accent-color)', borderRadius: '50%', animation: 'spin 1s linear infinite'}} />
                  생성 정보를 불러오는 중...
                </div>
              ) : (
                <div className="create-issue-form">
                  {createMetadata.length === 0 ? (
                    <div className="create-issue-empty">
                      JIRA_TRACKING_PROJECTS에 설정된 프로젝트에서 생성 가능한 정보를 찾지 못했습니다.
                    </div>
                  ) : (
                    <>
                      <div className="create-issue-grid">
                        <label>
                          <span className="apple-meta-label">프로젝트</span>
                          <select
                            className="glass-input"
                            value={createSelectedProject}
                            onChange={e => {
                              const nextKey = e.target.value;
                              const nextMeta = createMetadata.find(meta => metaKey(meta) === nextKey);
                              setCreateSelectedProject(nextKey);
                              applyCreateDefaults(nextMeta);
                            }}
                          >
                            {createMetadata.map(meta => (
                              <option key={metaKey(meta)} value={metaKey(meta)}>
                                {instanceList.length > 1 ? `[${meta.instance_name}] ` : ''}{meta.project_key}
                              </option>
                            ))}
                          </select>
                        </label>

                        <label>
                          <span className="apple-meta-label">이슈 유형</span>
                          <select
                            className="glass-input"
                            value={createIssueType}
                            disabled={!selectedCreateMeta || selectedCreateMeta.issue_types.length <= 1}
                            onChange={e => setCreateIssueType(e.target.value)}
                          >
                            {(selectedCreateMeta?.issue_types || []).map(type => (
                              <option key={type.id || type.name} value={type.name}>{type.name}</option>
                            ))}
                          </select>
                        </label>
                      </div>

                      <label>
                        <span className="apple-meta-label">요약</span>
                        <input
                          className="glass-input"
                          value={createSummary}
                          onChange={e => setCreateSummary(e.target.value)}
                          placeholder="Jira에 기록할 업무 요약"
                        />
                      </label>

                      <label>
                        <span className="apple-meta-label">설명</span>
                        <MentionsInput
                          value={createDescription}
                          onChange={(_, newValue) => setCreateDescription(newValue)}
                          style={{
                            ...mentionsStyle,
                            '&multiLine': {
                              ...mentionsStyle['&multiLine'],
                              control: { ...mentionsStyle['&multiLine'].control, minHeight: 120 },
                              input: { ...mentionsStyle['&multiLine'].input, minHeight: 120, backgroundColor: 'var(--card-bg)' },
                            },
                          }}
                          placeholder="@를 입력하여 팀원을 멘션할 수 있습니다."
                        >
                          <Mention trigger="@" data={searchCreateMentionUsers} markup="@[__display__](__id__)" displayTransform={(_id, display) => display} className="mention-badge" appendSpaceOnAdd />
                        </MentionsInput>
                      </label>

                      <label>
                        <span className="apple-meta-label">구성요소</span>
                        <select className="glass-input" value={createComponent} onChange={e => setCreateComponent(e.target.value)} disabled={!selectedCreateMeta?.components.length}>
                          <option value="">선택 안 함</option>
                          {(selectedCreateMeta?.components || []).map(component => (
                            <option key={component.id || component.name} value={component.name}>{component.name}</option>
                          ))}
                        </select>
                      </label>

                      <div className="create-assignee-section">
                        <span className="apple-meta-label">담당자</span>
                        <div className="create-assignee-options">
                          <label>
                            <input
                              type="radio"
                              checked={createAssigneeMode === 'default'}
                              onChange={() => {
                                setCreateAssigneeMode('default');
                                setCreateAssigneeQuery('');
                                setCreateAssigneeSelected(null);
                              }}
                            />
                            구성 요소 기본값
                          </label>
                          <label>
                            <input
                              type="radio"
                              checked={createAssigneeMode === 'me'}
                              onChange={() => {
                                setCreateAssigneeMode('me');
                                setCreateAssigneeQuery('');
                                setCreateAssigneeSelected(null);
                              }}
                            />
                            나{currentCreateUser?.displayName ? ` (${currentCreateUser.displayName})` : ''}
                          </label>
                          <label>
                            <input
                              type="radio"
                              checked={createAssigneeMode === 'manual'}
                              onChange={() => {
                                setCreateAssigneeMode('manual');
                                setCreateAssigneeQuery('');
                                setCreateAssigneeSelected(null);
                              }}
                            />
                            직접 지정
                          </label>
                        </div>

                        {createAssigneeMode === 'manual' && (
                          <div className="create-assignee-search">
                            <input
                              className="glass-input"
                              value={createAssigneeQuery}
                              onChange={e => {
                                setCreateAssigneeQuery(e.target.value);
                                setCreateAssigneeSelected(null);
                              }}
                              placeholder="이름으로 검색"
                            />
                            {createAssigneeSelected && <span className="create-assignee-selected">선택됨: {createAssigneeSelected.display}</span>}
                            {!createAssigneeSelected && createAssigneeQuery.trim() && (
                              <div className="create-assignee-suggestions">
                                {createAssigneeLoading ? (
                                  <div className="create-assignee-suggestion muted">검색 중...</div>
                                ) : createAssigneeSuggestions.length ? (
                                  createAssigneeSuggestions.map(user => (
                                    <button
                                      type="button"
                                      key={user.id}
                                      className="create-assignee-suggestion"
                                      onClick={() => {
                                        setCreateAssigneeSelected(user);
                                        setCreateAssigneeQuery(user.display);
                                        setCreateAssigneeSuggestions([]);
                                      }}
                                    >
                                      {user.display}
                                    </button>
                                  ))
                                ) : (
                                  <div className="create-assignee-suggestion muted">검색 결과가 없습니다.</div>
                                )}
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    </>
                  )}

                  {createError && <div className="create-issue-error">{createError}</div>}

                  <div className="create-issue-actions">
                    <button className="btn-secondary" onClick={() => setCreateModalOpen(false)} disabled={createSubmitting}>취소</button>
                    <button
                      className="btn-premium"
                      onClick={submitCreateIssue}
                      disabled={createSubmitting || createMetadata.length === 0 || !createIssueType || !createSummary.trim() || (createAssigneeMode === 'manual' && !createAssigneeValue)}
                    >
                      {createSubmitting ? '기록 중...' : 'Jira에 기록'}
                    </button>
                  </div>
                </div>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Detail Modal */}
      <AnimatePresence>
        {activeModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="glass-modal-overlay"
            onPointerDown={e => {
              modalPointerStartedOnOverlayRef.current = e.target === e.currentTarget;
            }}
            onPointerUp={e => {
              const shouldClose = modalPointerStartedOnOverlayRef.current && e.target === e.currentTarget;
              modalPointerStartedOnOverlayRef.current = false;
              if (shouldClose) setActiveModal(null);
            }}
            onPointerCancel={() => {
              modalPointerStartedOnOverlayRef.current = false;
            }}
          >
            <motion.div initial={{ scale: 0.9, y: 20 }} animate={{ scale: 1, y: 0 }} exit={{ scale: 0.9, y: 20 }} className="glass-modal-content" onClick={e => e.stopPropagation()} style={{textAlign: 'left'}}>
              
              <div style={{display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:'20px'}}>
                <h2 style={{margin: 0, fontSize: 22, fontWeight: 700}}>
                  {activeModal === 'comment' && '코멘트 작성'}
                  {activeModal === 'subtask' && '하위 작업 생성'}
                  {activeModal === 'linked' && '연관 이슈 생성'}
                  {activeModal === 'detail' && '이슈 상세 정보'}
                </h2>
                {issueDetail && (
                  <div style={{display: 'flex', alignItems: 'center', gap: 8}}>
                    <button
                      className={`favorite-star-button modal-star ${isFavoriteIssue(issueDetail) ? 'active' : ''}`}
                      title={isFavoriteIssue(issueDetail) ? '즐겨찾기 해제' : '즐겨찾기'}
                      onClick={() => toggleFavoriteIssue(issueDetail)}
                    >
                      <Star size={18} fill={isFavoriteIssue(issueDetail) ? '#f1c40f' : 'none'} />
                    </button>
                    <span className="premium-badge" style={{position: 'relative', top: 0, right: 0}}>{instanceList.find(ins=>ins.id===issueDetail.instance_id)?.name || 'Jira'}</span>
                  </div>
                )}
              </div>
              
              <p style={{ fontSize: '15px', color: 'var(--text-secondary)', marginBottom: 25 }}>
                <a href={`${instanceList.find(ins=>ins.id===selectedIssue?.instance_id)?.base_url}/browse/${selectedIssue?.key}`} target="_blank" rel="noreferrer" style={{textDecoration: 'none', color: '#0984e3', fontWeight: 600}}>
                  {selectedIssue?.key}
                </a>
                <span style={{margin: '0 8px'}}>-</span>
                <span style={{color: 'var(--text-primary)'}}>{selectedIssue?.fields?.summary}</span>
              </p>

              {(activeModal === 'comment' || activeModal === 'detail') && (
                <div>
                  {detailLoading ? (<div style={{padding: 40, textAlign: 'center', color: 'var(--text-secondary)'}}><div style={{margin: '0 auto 15px auto', width: 30, height: 30, border: '3px solid rgba(0,0,0,0.1)', borderTopColor: 'var(--accent-color)', borderRadius: '50%', animation: 'spin 1s linear infinite'}} />데이터 불러오는 중...</div>) : (
                    <>
                      <div style={{display: 'flex', alignItems: 'center', gap: 12, marginBottom: 20, flexWrap: 'wrap'}}>
                         {selectedIssue && isOriginalEstimateTarget(selectedIssue) && !originalEstimateAuto && (
                           <button
                             className="btn-secondary"
                             onClick={submitOriginalEstimate}
                             disabled={originalEstimateSubmitting || selectedHasOriginalEstimate || !canUseManualOriginalEstimate}
                             title={selectedHasOriginalEstimate ? '이미 최초 추정이 입력되어 있습니다.' : ''}
                             style={{ whiteSpace: 'nowrap', opacity: (originalEstimateSubmitting || selectedHasOriginalEstimate || !canUseManualOriginalEstimate) ? 0.65 : 1 }}
                           >
                             {originalEstimateSubmitting ? '입력 중...' : selectedHasOriginalEstimate ? '최초 추정 입력됨' : '최초 추정 입력'}
                           </button>
                         )}
                         <span className="apple-meta-label" style={{whiteSpace: 'nowrap', flexShrink: 0}}>상태 변경</span>
                         <select className="glass-input" value="" style={{flex: '1 1 260px', minWidth: 220}} onChange={async e => {
                           await fetch(`${API_BASE}/issues/${selectedIssue?.key}/transitions?instance_id=${selectedIssue?.instance_id}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ transition_id: e.target.value }) });
                           fetchIssues(); fetchIssueDetail(selectedIssue!.key, selectedIssue!.instance_id);
                         }}>
                           <option value="" disabled>새로운 상태 선택...</option>
                           {transitions.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
                         </select>
                      </div>
                      {originalEstimateError && <div style={{ marginTop: -10, marginBottom: 16, color: '#d63031', fontSize: 13, fontWeight: 700 }}>{originalEstimateError}</div>}
                      {originalEstimateMessage && <div style={{ marginTop: -10, marginBottom: 16, color: '#078f55', fontSize: 13, fontWeight: 700 }}>{originalEstimateMessage}</div>}

                      {canUseWorklogPanel && (
                        <div className="glass-panel" style={{ padding: 18, marginBottom: 20 }}>
                          <button
                            className="btn-secondary"
                            onClick={toggleWorklogPanel}
                            style={{ width: '100%', display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 12px' }}
                          >
                            <span>시간 추적 / 작업로그</span>
                            <span>{worklogOpen ? '접기' : '펼치기'}</span>
                          </button>

                          {worklogOpen && (
                            <div style={{ marginTop: 16 }}>
                              <div className="apple-meta-grid" style={{ marginBottom: 16 }}>
                                <div className="apple-meta-item"><span className="apple-meta-label">원래 추정</span><span className="apple-meta-value">{timetrackingLoading ? '불러오는 중...' : displayTracking.originalEstimate}</span></div>
                                <div className="apple-meta-item"><span className="apple-meta-label">남은 시간</span><span className="apple-meta-value">{timetrackingLoading ? '불러오는 중...' : displayTracking.remainingEstimate}</span></div>
                                <div className="apple-meta-item"><span className="apple-meta-label">기록된 시간</span><span className="apple-meta-value">{timetrackingLoading ? '불러오는 중...' : displayTracking.timeSpent}</span></div>
                                <div className="apple-meta-item"><span className="apple-meta-label">작업로그 수</span><span className="apple-meta-value">{timetrackingLoading ? '불러오는 중...' : `${timetracking?.worklog?.total ?? 0}개`}</span></div>
                              </div>

                              <div className="create-issue-grid">
                                <label>
                                  <span className="apple-meta-label">작업한 시간 *</span>
                                  <input className="glass-input" value={worklogTime} onChange={e => handleWorklogTimeChange(e.target.value)} onBlur={() => { const parsed = parseWorklogTime(worklogTime); if (parsed.ok && parsed.normalized) setWorklogTime(parsed.normalized); }} placeholder="예: 70, 1h 10m, 1w3h" />
                                  {worklogTimePreview && <span style={{ marginTop: 6, fontSize: 12, color: worklogTimePreview.ok ? 'var(--text-secondary)' : '#d63031' }}>{worklogTimePreview.ok ? `변환: ${worklogTimePreview.normalized}` : worklogTimePreview.error}</span>}
                                </label>

                                <label>
                                  <span className="apple-meta-label">작업 시작 시각</span>
                                  <input className="glass-input" type="datetime-local" value={worklogStarted} onChange={e => { setWorklogStartedTouched(true); setWorklogStarted(e.target.value); }} />
                                  <span style={{ marginTop: 6, fontSize: 12, color: 'var(--text-secondary)' }}>
                                    {worklogStartedTouched ? '직접 수정됨: 작업한 시간을 바꿔도 시작 시각은 유지됩니다.' : '자동 계산됨: 현재 시각에서 작업한 시간을 뺀 값입니다.'}
                                  </span>
                                  {worklogStartedTouched && (
                                    <button
                                      type="button"
                                      className="btn-secondary"
                                      style={{ marginTop: 8, alignSelf: 'flex-start', padding: '5px 10px' }}
                                      onClick={() => {
                                        const parsed = parseWorklogTime(worklogTime);
                                        setWorklogStarted(getAutoStartedValue(parsed.ok ? parsed.minutes : undefined));
                                        setWorklogStartedTouched(false);
                                      }}
                                    >
                                      자동 계산 다시 적용
                                    </button>
                                  )}
                                </label>
                              </div>

                              <label style={{ display: 'flex', flexDirection: 'column', gap: 8, marginTop: 14 }}>
                                <span className="apple-meta-label">작업 설명</span>
                                <textarea className="glass-input" value={worklogComment} onChange={e => setWorklogComment(e.target.value)} placeholder="선택 입력" style={{ minHeight: 80, resize: 'vertical' }} />
                              </label>

                              <div style={{ marginTop: 16 }}>
                                <span className="apple-meta-label" style={{ display: 'block', marginBottom: 8 }}>남은 시간 처리</span>
                                <div style={{ display: 'flex', flexWrap: 'wrap', gap: 12, color: 'var(--text-primary)', fontSize: 13 }}>
                                  <label style={{ display: 'flex', alignItems: 'center', gap: 6 }}><input type="radio" checked={adjustEstimate === 'auto'} onChange={() => setAdjustEstimate('auto')} /> 자동 감소</label>
                                  <label style={{ display: 'flex', alignItems: 'center', gap: 6 }}><input type="radio" checked={adjustEstimate === 'new'} onChange={() => setAdjustEstimate('new')} /> 남은 시간 직접 설정</label>
                                  <label style={{ display: 'flex', alignItems: 'center', gap: 6 }}><input type="radio" checked={adjustEstimate === 'leave'} onChange={() => setAdjustEstimate('leave')} /> 변경 안 함</label>
                                </div>
                                {adjustEstimate === 'new' && (
                                  <label style={{ display: 'flex', flexDirection: 'column', gap: 8, marginTop: 12 }}>
                                    <span className="apple-meta-label">새 남은 시간</span>
                                    <input className="glass-input" value={newEstimate} onChange={e => setNewEstimate(e.target.value)} onBlur={() => { const parsed = parseWorklogTime(newEstimate, true); if (parsed.ok && parsed.normalized) setNewEstimate(parsed.normalized); }} placeholder="예: 0, 30m, 2h" />
                                    {newEstimatePreview && <span style={{ fontSize: 12, color: newEstimatePreview.ok ? 'var(--text-secondary)' : '#d63031' }}>{newEstimatePreview.ok ? `변환: ${newEstimatePreview.normalized}` : newEstimatePreview.error}</span>}
                                  </label>
                                )}
                              </div>

                              {worklogError && <div style={{ marginTop: 12, color: '#d63031', fontSize: 13, fontWeight: 700 }}>{worklogError}</div>}
                              {worklogMessage && <div style={{ marginTop: 12, color: '#078f55', fontSize: 13, fontWeight: 700 }}>{worklogMessage}</div>}

                              <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 10, marginTop: 16 }}>
                                <button className="btn-secondary" onClick={() => fetchTimeTracking(selectedIssue || undefined)} disabled={timetrackingLoading}>새로고침</button>
                                <button className="btn-premium" onClick={submitWorklog} disabled={worklogSubmitting} style={{ opacity: worklogSubmitting ? 0.65 : 1 }}>{worklogSubmitting ? '등록 중...' : '작업로그 추가'}</button>
                              </div>
                            </div>
                          )}
                        </div>
                      )}

                      <div className="apple-meta-grid">
                        <div className="apple-meta-item"><span className="apple-meta-label">유형</span><span className="apple-meta-value">{issueDetail?.fields?.issuetype?.name}</span></div>
                        <div className="apple-meta-item"><span className="apple-meta-label">우선순위</span><span className="apple-meta-value">{issueDetail?.fields?.priority?.name || '없음'}</span></div>
                        <div className="apple-meta-item"><span className="apple-meta-label">담당자</span><span className="apple-meta-value">{issueDetail?.fields?.assignee?.displayName || '미지정'}</span></div>
                        <div className="apple-meta-item"><span className="apple-meta-label">보고자</span><span className="apple-meta-value">{issueDetail?.fields?.reporter?.displayName}</span></div>
                        <div className="apple-meta-item" style={{ gridColumn: 'span 2' }}><span className="apple-meta-label">지켜보는 사람</span><span className="apple-meta-value">{issueDetail?.fields?.watchers?.join(', ') || '없음'}</span></div>
                        <div className="apple-meta-item"><span className="apple-meta-label">생성 날짜</span><span className="apple-meta-value">{formatDateTime(issueDetail?.fields?.created)}</span></div>
                        <div className="apple-meta-item"><span className="apple-meta-label">최종 변경</span><span className="apple-meta-value">{formatDateTime(issueDetail?.fields?.updated)}</span></div>
                      </div>

                      <span className="apple-meta-label" style={{display: 'block', marginBottom: 8}}>설명</span>
                      <div className="apple-description-box" dangerouslySetInnerHTML={{__html: issueDetail?.fields?.description ? renderJiraWikiToHtml(issueDetail.fields.description) : '설명이 없습니다.'}}></div>

                      <span className="apple-meta-label" style={{display: 'block', marginBottom: 8}}>코멘트</span>
                      <div className="glass-panel" style={{padding: '20px', marginBottom: '20px'}}>
                        <div onPaste={(e) => handlePasteImage(e, setCommentText)}>
                          <MentionsInput value={commentText} onChange={(_, newValue) => setCommentText(newValue)} onKeyDown={async (e) => { if (e.altKey && e.key === 'Enter') {
                              e.preventDefault();
                              if (!commentText.trim() || isSubmittingComment) return;
                              setIsSubmittingComment(true);
                              try {
                                await fetch(`${API_BASE}/issues/${selectedIssue?.key}/comments?instance_id=${selectedIssue?.instance_id}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ body: convertMentionsToJiraFormat(commentText) }) });
                                setCommentText(''); fetchIssueDetail(selectedIssue!.key, selectedIssue!.instance_id);
                              } finally {
                                setIsSubmittingComment(false);
                              }
                            }}} style={{...mentionsStyle, control: { ...mentionsStyle.control, backgroundColor: 'transparent' }, '&multiLine': { ...mentionsStyle['&multiLine'], input: { ...mentionsStyle['&multiLine'].input, backgroundColor: 'var(--card-bg)', border: '1px solid rgba(0,0,0,0.1)' } }}} placeholder="@를 입력하여 팀원 멘션... (Alt+Enter로 즉시 작성)">
                            <Mention trigger="@" data={searchUsers} markup="@[__display__](__id__)" displayTransform={(_id, display) => display} className="mention-badge" appendSpaceOnAdd />
                          </MentionsInput>
                        </div>
                        <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: '12px' }}>
                          <button className="btn-premium" style={{whiteSpace: 'nowrap', opacity: isSubmittingComment ? 0.6 : 1}} disabled={isSubmittingComment} onClick={async () => {
                            if (!commentText.trim() || isSubmittingComment) return;
                            setIsSubmittingComment(true);
                            try {
                              await fetch(`${API_BASE}/issues/${selectedIssue?.key}/comments?instance_id=${selectedIssue?.instance_id}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ body: convertMentionsToJiraFormat(commentText) }) });
                              setCommentText(''); 
                              await fetchIssueDetail(selectedIssue!.key, selectedIssue!.instance_id);
                            } finally {
                              setIsSubmittingComment(false);
                            }
                          }}>{isSubmittingComment ? '처리 중...' : '코멘트 추가'}</button>
                        </div>
                      </div>

                      <div className="imessage-container">
                        {!issueDetail?.fields?.comment?.comments?.length ? <p style={{fontSize:'13px', color:'var(--text-secondary)', textAlign: 'center'}}>작성된 코멘트가 없습니다.</p> :
                          [...issueDetail.fields.comment.comments].sort((a,b)=>new Date(b.created).getTime()-new Date(a.created).getTime()).map(c => {
                            const isMine = selectedIssue && userMap[selectedIssue.instance_id.toString()] && c.author.name === userMap[selectedIssue.instance_id.toString()].name;
                            return (
                              <div key={c.id} className={`imessage-bubble-wrapper ${isMine ? 'mine' : 'others'}`}>
                                {!isMine && <div className="imessage-author">{c.author.displayName}</div>}
                                
                                {editingCommentId === c.id ? (
                                  <div className="glass-panel" style={{padding: 15, width: '100%', minWidth: 300}}>
                                    <MentionsInput value={editingCommentText} onChange={(_, newValue) => setEditingCommentText(newValue)} onKeyDown={async (e) => { if (e.altKey && e.key === 'Enter') {
                                          e.preventDefault();
                                          await fetch(`${API_BASE}/issues/${selectedIssue?.key}/comments/${c.id}?instance_id=${selectedIssue?.instance_id}`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ body: convertMentionsToJiraFormat(editingCommentText) }) });
                                          setEditingCommentId(null); fetchIssueDetail(selectedIssue!.key, selectedIssue!.instance_id);
                                        }}} style={mentionsStyle} placeholder="코멘트 수정...">
                                      <Mention trigger="@" data={searchUsers} markup="@[__display__](__id__)" displayTransform={(_id, display) => display} className="mention-badge" appendSpaceOnAdd />
                                    </MentionsInput>
                                    <div style={{display:'flex',justifyContent:'flex-end',gap:'8px', marginTop:'10px'}}>
                                      <button className="btn-secondary" onClick={()=>setEditingCommentId(null)}>취소</button>
                                      <button className="btn-premium" onClick={async ()=>{
                                        await fetch(`${API_BASE}/issues/${selectedIssue?.key}/comments/${c.id}?instance_id=${selectedIssue?.instance_id}`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ body: convertMentionsToJiraFormat(editingCommentText) }) });
                                        setEditingCommentId(null); fetchIssueDetail(selectedIssue!.key, selectedIssue!.instance_id);
                                      }}>저장</button>
                                    </div>
                                  </div>
                                ) : (
                                  <>
                                    <div className="imessage-bubble" dangerouslySetInnerHTML={{__html: renderJiraCommentHtml(c)}} />
                                    <div className="imessage-date">{formatDateTime(c.created)}</div>
                                    {isMine && (
                                      <div className="imessage-actions">
                                        <button onClick={()=>{setEditingCommentId(c.id); setEditingCommentText(c.body);}}>수정</button>
                                        <button className="danger" onClick={async ()=>{
                                          if(!confirm('삭제하시겠습니까?')) return;
                                          await fetch(`${API_BASE}/issues/${selectedIssue?.key}/comments/${c.id}?instance_id=${selectedIssue?.instance_id}`, { method: 'DELETE' });
                                          fetchIssueDetail(selectedIssue!.key, selectedIssue!.instance_id);
                                        }}>삭제</button>
                                      </div>
                                    )}
                                  </>
                                )}
                              </div>
                            );
                          })
                        }
                      </div>
                      
                      <div style={{marginTop: 40}}>
                        <span className="apple-meta-label" style={{display: 'block', marginBottom: 8}}>활동 이력</span>
                        <div className="glass-panel" style={{padding: 20}}>
                          {!issueDetail?.changelog?.histories?.length ? <p style={{fontSize:'13px',color:'var(--text-secondary)'}}>기록이 없습니다.</p> : 
                            issueDetail.changelog.histories.slice(0,5).map(h=>(
                              <div key={h.id} style={{marginBottom: 15, paddingBottom: 15, borderBottom: '1px solid rgba(0,0,0,0.05)'}}>
                                <div style={{display: 'flex', justifyContent: 'space-between', marginBottom: 8}}>
                                  <span style={{fontWeight: 700, fontSize: 13, color: 'var(--text-primary)'}}>{h.author.displayName}</span>
                                  <span style={{fontSize: 12, color: 'var(--text-secondary)'}}>{formatDateTime(h.created)}</span>
                                </div>
                                <div style={{fontSize: 13, color: 'var(--text-secondary)', lineHeight: 1.5}}>
                                  {h.items.map((it,idx)=>(<div key={idx}>• <b>{it.field}</b>: {it.fromString||'없음'} → <b>{it.toString}</b></div>))}
                                </div>
                              </div>
                            ))
                          }
                        </div>
                      </div>
                    </>
                  )}
                </div>
              )}
              
              <div style={{display:'flex',justifyContent:'flex-end',gap:'10px',marginTop:'30px', paddingTop: '20px', borderTop: '1px solid rgba(0,0,0,0.05)'}}>
                <button className="btn-secondary" onClick={()=>setActiveModal(null)}>닫기</button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
