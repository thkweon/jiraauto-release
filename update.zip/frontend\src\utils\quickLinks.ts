export interface QuickLinkItem {
  id: string;
  title: string;
  url: string;
  imageUrl?: string;
}

export const QUICK_LINKS_STORAGE_KEY = 'jiraautoQuickLinks';
export const QUICK_LINKS_CHANGED_EVENT = 'quickLinksChanged';

const isQuickLinkItem = (value: unknown): value is QuickLinkItem => {
  if (!value || typeof value !== 'object') return false;
  const item = value as Partial<QuickLinkItem>;
  return typeof item.id === 'string' && typeof item.title === 'string' && typeof item.url === 'string';
};

export const loadQuickLinks = (): QuickLinkItem[] => {
  try {
    const raw = localStorage.getItem(QUICK_LINKS_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed.filter(isQuickLinkItem);
  } catch {
    localStorage.removeItem(QUICK_LINKS_STORAGE_KEY);
    return [];
  }
};

export const saveQuickLinks = (links: QuickLinkItem[]) => {
  localStorage.setItem(QUICK_LINKS_STORAGE_KEY, JSON.stringify(links));
  window.dispatchEvent(new CustomEvent<QuickLinkItem[]>(QUICK_LINKS_CHANGED_EVENT, { detail: links }));
};

export const createQuickLinkId = () => {
  if (typeof crypto !== 'undefined' && 'randomUUID' in crypto) {
    return crypto.randomUUID();
  }
  return `quick-link-${Date.now()}-${Math.random().toString(36).slice(2)}`;
};
