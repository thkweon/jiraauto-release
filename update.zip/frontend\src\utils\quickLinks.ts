export interface QuickLinkLinkItem {
  id: string;
  title: string;
  type: 'link';
  url: string;
  imageUrl?: string;
}

export interface QuickLinkFolderItem {
  id: string;
  title: string;
  type: 'folder';
  imageUrl?: string;
  children: QuickLinkLinkItem[];
}

export type QuickLinkItem = QuickLinkLinkItem | QuickLinkFolderItem;

export const QUICK_LINKS_STORAGE_KEY = 'jiraautoQuickLinks';
export const QUICK_LINKS_CHANGED_EVENT = 'quickLinksChanged';

const isQuickLinkLinkItem = (value: unknown): value is QuickLinkLinkItem => {
  if (!value || typeof value !== 'object') return false;
  const item = value as Partial<QuickLinkLinkItem>;
  return typeof item.id === 'string' && typeof item.title === 'string' && typeof item.url === 'string';
};

const migrateLinkItem = (value: unknown): QuickLinkLinkItem | null => {
  if (!isQuickLinkLinkItem(value)) return null;
  return {
    id: value.id,
    title: value.title,
    type: 'link',
    url: value.url,
    imageUrl: typeof value.imageUrl === 'string' ? value.imageUrl : undefined,
  };
};

const isMigratedQuickLink = (value: QuickLinkItem | null): value is QuickLinkItem => Boolean(value);
const isMigratedQuickLinkLink = (value: QuickLinkLinkItem | null): value is QuickLinkLinkItem => Boolean(value);

const migrateQuickLinkItem = (value: unknown): QuickLinkItem | null => {
  if (!value || typeof value !== 'object') return null;
  const item = value as Partial<QuickLinkItem> & { type?: unknown; children?: unknown };

  if (item.type === 'folder') {
    if (typeof item.id !== 'string' || typeof item.title !== 'string') return null;
    return {
      id: item.id,
      title: item.title,
      type: 'folder',
      imageUrl: typeof item.imageUrl === 'string' ? item.imageUrl : undefined,
      children: Array.isArray(item.children) ? item.children.map(migrateLinkItem).filter(isMigratedQuickLinkLink) : [],
    };
  }

  return migrateLinkItem(value);
};

const normalizeQuickLinks = (links: QuickLinkItem[]) => {
  return links.map(migrateQuickLinkItem).filter(isMigratedQuickLink);
};

export const loadQuickLinks = (): QuickLinkItem[] => {
  try {
    const raw = localStorage.getItem(QUICK_LINKS_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return normalizeQuickLinks(parsed);
  } catch {
    localStorage.removeItem(QUICK_LINKS_STORAGE_KEY);
    return [];
  }
};

export const saveQuickLinks = (links: QuickLinkItem[]) => {
  const normalizedLinks = normalizeQuickLinks(links);
  localStorage.setItem(QUICK_LINKS_STORAGE_KEY, JSON.stringify(normalizedLinks));
  window.dispatchEvent(new CustomEvent<QuickLinkItem[]>(QUICK_LINKS_CHANGED_EVENT, { detail: normalizedLinks }));
  return normalizedLinks;
};

export const createQuickLinkId = () => {
  if (typeof crypto !== 'undefined' && 'randomUUID' in crypto) {
    return crypto.randomUUID();
  }
  return `quick-link-${Date.now()}-${Math.random().toString(36).slice(2)}`;
};
