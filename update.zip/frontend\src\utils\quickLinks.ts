export interface QuickLinkLinkItem {
  id: string;
  title: string;
  type: 'link';
  url: string;
  imageUrl?: string;
}

export interface QuickLinkFolderItem {
  id: string;
  title: string;
  type: 'folder';
  imageUrl?: string;
  children: QuickLinkLinkItem[];
}

export type QuickLinkItem = QuickLinkLinkItem | QuickLinkFolderItem;
export type QuickLinkPosition = 'left-top' | 'left-middle' | 'left-bottom' | 'right-top' | 'right-middle' | 'right-bottom';

export const QUICK_LINKS_STORAGE_KEY = 'jiraautoQuickLinks';
export const QUICK_LINKS_CHANGED_EVENT = 'quickLinksChanged';
export const QUICK_LINK_POSITION_STORAGE_KEY = 'jiraautoQuickLinkPosition';
export const QUICK_LINK_POSITION_CHANGED_EVENT = 'quickLinkPositionChanged';
export const QUICK_LINK_ENABLED_STORAGE_KEY = 'jiraautoQuickLinkEnabled';
export const QUICK_LINK_ENABLED_CHANGED_EVENT = 'quickLinkEnabledChanged';
export const QUICK_LINK_IMAGE_REF_PREFIX = 'indexeddb:quick-link-image:';
const QUICK_LINK_IMAGE_DB_NAME = 'jiraautoQuickLinkImages';
const QUICK_LINK_IMAGE_STORE_NAME = 'images';

const QUICK_LINK_POSITIONS: QuickLinkPosition[] = [
  'left-top',
  'left-middle',
  'left-bottom',
  'right-top',
  'right-middle',
  'right-bottom',
];

export const loadQuickLinkPosition = (): QuickLinkPosition => {
  const value = localStorage.getItem(QUICK_LINK_POSITION_STORAGE_KEY);
  const position = QUICK_LINK_POSITIONS.includes(value as QuickLinkPosition)
    ? value as QuickLinkPosition
    : 'right-middle';
  const side = position.startsWith('left-') ? 'left' : 'right';
  return `${side}-middle` as QuickLinkPosition;
};

export const saveQuickLinkPosition = (position: QuickLinkPosition) => {
  const side = position.startsWith('left-') ? 'left' : 'right';
  const normalizedPosition = `${side}-middle` as QuickLinkPosition;
  localStorage.setItem(QUICK_LINK_POSITION_STORAGE_KEY, normalizedPosition);
  window.dispatchEvent(new CustomEvent<QuickLinkPosition>(
    QUICK_LINK_POSITION_CHANGED_EVENT,
    { detail: normalizedPosition },
  ));
};

export const loadQuickLinkEnabled = () => localStorage.getItem(QUICK_LINK_ENABLED_STORAGE_KEY) === 'true';

export const saveQuickLinkEnabled = (enabled: boolean) => {
  localStorage.setItem(QUICK_LINK_ENABLED_STORAGE_KEY, String(enabled));
  window.dispatchEvent(new CustomEvent<boolean>(QUICK_LINK_ENABLED_CHANGED_EVENT, { detail: enabled }));
};

export class QuickLinkStorageQuotaError extends Error {
  constructor() {
    super('Quick link storage quota exceeded');
    this.name = 'QuickLinkStorageQuotaError';
  }
}

const isQuickLinkLinkItem = (value: unknown): value is QuickLinkLinkItem => {
  if (!value || typeof value !== 'object') return false;
  const item = value as Partial<QuickLinkLinkItem>;
  return typeof item.id === 'string' && typeof item.title === 'string' && typeof item.url === 'string';
};

const migrateLinkItem = (value: unknown): QuickLinkLinkItem | null => {
  if (!isQuickLinkLinkItem(value)) return null;
  return {
    id: value.id,
    title: value.title,
    type: 'link',
    url: value.url,
    imageUrl: typeof value.imageUrl === 'string' ? value.imageUrl : undefined,
  };
};

const isMigratedQuickLink = (value: QuickLinkItem | null): value is QuickLinkItem => Boolean(value);
const isMigratedQuickLinkLink = (value: QuickLinkLinkItem | null): value is QuickLinkLinkItem => Boolean(value);

const migrateQuickLinkItem = (value: unknown): QuickLinkItem | null => {
  if (!value || typeof value !== 'object') return null;
  const item = value as Partial<QuickLinkItem> & { type?: unknown; children?: unknown };

  if (item.type === 'folder') {
    if (typeof item.id !== 'string' || typeof item.title !== 'string') return null;
    return {
      id: item.id,
      title: item.title,
      type: 'folder',
      imageUrl: typeof item.imageUrl === 'string' ? item.imageUrl : undefined,
      children: Array.isArray(item.children) ? item.children.map(migrateLinkItem).filter(isMigratedQuickLinkLink) : [],
    };
  }

  return migrateLinkItem(value);
};

const normalizeQuickLinks = (links: QuickLinkItem[]) => {
  return links.map(migrateQuickLinkItem).filter(isMigratedQuickLink);
};

export const loadQuickLinks = (): QuickLinkItem[] => {
  try {
    const raw = localStorage.getItem(QUICK_LINKS_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return normalizeQuickLinks(parsed);
  } catch {
    localStorage.removeItem(QUICK_LINKS_STORAGE_KEY);
    return [];
  }
};

export const saveQuickLinks = (links: QuickLinkItem[]) => {
  const normalizedLinks = normalizeQuickLinks(links);
  try {
    localStorage.setItem(QUICK_LINKS_STORAGE_KEY, JSON.stringify(normalizedLinks));
  } catch (error) {
    if (
      error instanceof DOMException
      && (error.name === 'QuotaExceededError' || error.name === 'NS_ERROR_DOM_QUOTA_REACHED')
    ) {
      throw new QuickLinkStorageQuotaError();
    }
    throw error;
  }
  window.dispatchEvent(new CustomEvent<QuickLinkItem[]>(QUICK_LINKS_CHANGED_EVENT, { detail: normalizedLinks }));
  return normalizedLinks;
};

export const createQuickLinkId = () => {
  if (typeof crypto !== 'undefined' && 'randomUUID' in crypto) {
    return crypto.randomUUID();
  }
  return `quick-link-${Date.now()}-${Math.random().toString(36).slice(2)}`;
};

export const isQuickLinkImageRef = (value?: string) => {
  return Boolean(value?.startsWith(QUICK_LINK_IMAGE_REF_PREFIX));
};

const openQuickLinkImageDb = () => {
  return new Promise<IDBDatabase>((resolve, reject) => {
    const request = indexedDB.open(QUICK_LINK_IMAGE_DB_NAME, 1);
    request.onerror = () => reject(request.error);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(QUICK_LINK_IMAGE_STORE_NAME)) {
        db.createObjectStore(QUICK_LINK_IMAGE_STORE_NAME);
      }
    };
    request.onsuccess = () => resolve(request.result);
  });
};

export const saveQuickLinkImage = async (dataUrl: string) => {
  const id = createQuickLinkId();
  const db = await openQuickLinkImageDb();
  await new Promise<void>((resolve, reject) => {
    const transaction = db.transaction(QUICK_LINK_IMAGE_STORE_NAME, 'readwrite');
    transaction.onerror = () => reject(transaction.error);
    transaction.oncomplete = () => resolve();
    transaction.objectStore(QUICK_LINK_IMAGE_STORE_NAME).put(dataUrl, id);
  });
  db.close();
  return `${QUICK_LINK_IMAGE_REF_PREFIX}${id}`;
};

export const loadQuickLinkImage = async (imageUrl?: string) => {
  if (!imageUrl) return '';
  if (!isQuickLinkImageRef(imageUrl)) return imageUrl;

  const id = imageUrl.slice(QUICK_LINK_IMAGE_REF_PREFIX.length);
  const db = await openQuickLinkImageDb();
  const result = await new Promise<string>((resolve, reject) => {
    const transaction = db.transaction(QUICK_LINK_IMAGE_STORE_NAME, 'readonly');
    transaction.onerror = () => reject(transaction.error);
    const request = transaction.objectStore(QUICK_LINK_IMAGE_STORE_NAME).get(id);
    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve(typeof request.result === 'string' ? request.result : '');
  });
  db.close();
  return result;
};
