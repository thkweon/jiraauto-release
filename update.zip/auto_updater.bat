@echo off
setlocal
chcp 65001 > nul
echo =========================================
echo Jira Dashboard Auto-Updater
echo =========================================

echo [1/5] Waiting for backend to gracefully exit...
timeout /t 3 /nobreak > nul

echo [2/5] Ensuring all dashboard processes are stopped...
taskkill /F /IM python.exe /T 2>nul
taskkill /F /IM node.exe /T 2>nul

echo [3/5] Downloading latest release from GitHub...
if exist "version_remote.json" del "version_remote.json"
curl -sL "https://raw.githubusercontent.com/thkweon/jiraauto-release/main/version.json" -o "version_remote.json"

for /f "delims=" %%A in ('powershell -NoProfile -Command "if (Test-Path version_remote.json) { (Get-Content version_remote.json -Raw | ConvertFrom-Json).download_url }"') do set "DOWNLOAD_URL=%%A"
for /f "delims=" %%B in ('powershell -NoProfile -Command "if (Test-Path version_remote.json) { (Get-Content version_remote.json -Raw | ConvertFrom-Json).sha256 }"') do set "EXPECTED_HASH=%%B"

if "%DOWNLOAD_URL%"=="" (
    echo [ERROR] Failed to parse download_url.
    timeout /t 10
    exit
)

if exist "update_temp.zip" del "update_temp.zip"
curl -sL "%DOWNLOAD_URL%" -o "update_temp.zip"

echo [4/5] Verifying integrity (SHA256)...
for /f "delims=" %%H in ('powershell -NoProfile -Command "(Get-FileHash '.\update_temp.zip' -Algorithm SHA256).Hash"') do set "ACTUAL_HASH=%%H"

if /I not "%EXPECTED_HASH%"=="%ACTUAL_HASH%" (
    echo [ERROR] Integrity check failed!
    echo Expected: %EXPECTED_HASH%
    echo Actual  : %ACTUAL_HASH%
    del "update_temp.zip"
    timeout /t 10
    exit
)

echo [5/5] Extracting and applying update...
powershell -NoProfile -Command "Expand-Archive -Path '.\update_temp.zip' -DestinationPath '.\' -Force"
del "update_temp.zip"

:: Update local version.json record
move /Y version_remote.json version.json > nul

echo Update applied successfully! Restarting dashboard...
start "" "start_dashboard.vbs"
exit
