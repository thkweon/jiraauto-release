@echo off
setlocal
chcp 65001 > nul
echo =========================================
echo Jira Dashboard Auto-Updater
echo =========================================

echo [1/5] Waiting for backend to gracefully exit...
timeout /t 3 /nobreak > nul

echo [2/5] Ensuring all dashboard processes are stopped...
taskkill /F /IM python.exe /T 2>nul
taskkill /F /IM node.exe /T 2>nul

echo [3/5] Initializing Python Downloader (Bypassing Firewall/Proxy restrictions)...
if exist "downloader.py" del "downloader.py"
(
echo import urllib.request, sys, ssl
echo ctx = ssl.create_default_context^(^)
echo ctx.check_hostname = False
echo ctx.verify_mode = ssl.CERT_NONE
echo proxy = urllib.request.ProxyHandler^(^)
echo opener = urllib.request.build_opener^(proxy, urllib.request.HTTPSHandler^(context=ctx^)^)
echo urllib.request.install_opener^(opener^)
echo try:
echo     urllib.request.urlretrieve^(sys.argv[1], sys.argv[2]^)
echo except Exception as e:
echo     print^("Download Error:", e^)
echo     sys.exit^(1^)
) > downloader.py

echo [4/5] Downloading latest release from GitHub...
if exist "version_remote.json" del "version_remote.json"
backend\venv\Scripts\python.exe downloader.py "https://raw.githubusercontent.com/thkweon/jiraauto-release/main/version.json" "version_remote.json"

if not exist "version_remote.json" (
    echo [ERROR] Failed to download version_remote.json.
    echo Please check if github is blocked by the corporate firewall.
    timeout /t 15
    exit
)

for /f "delims=" %%A in ('powershell -NoProfile -Command "if (Test-Path version_remote.json) { (Get-Content version_remote.json -Raw | ConvertFrom-Json).download_url }"') do set "DOWNLOAD_URL=%%A"
for /f "delims=" %%B in ('powershell -NoProfile -Command "if (Test-Path version_remote.json) { (Get-Content version_remote.json -Raw | ConvertFrom-Json).sha256 }"') do set "EXPECTED_HASH=%%B"

if "%DOWNLOAD_URL%"=="" (
    echo [ERROR] Failed to parse download_url.
    timeout /t 10
    exit
)

if exist "update_temp.zip" del "update_temp.zip"
backend\venv\Scripts\python.exe downloader.py "%DOWNLOAD_URL%" "update_temp.zip"

if not exist "update_temp.zip" (
    echo [ERROR] Failed to download update_temp.zip.
    timeout /t 15
    exit
)

echo [5/5] Verifying integrity (SHA256)...
for /f "delims=" %%H in ('powershell -NoProfile -Command "(Get-FileHash '.\update_temp.zip' -Algorithm SHA256).Hash"') do set "ACTUAL_HASH=%%H"

if /I not "%EXPECTED_HASH%"=="%ACTUAL_HASH%" (
    echo [ERROR] Integrity check failed!
    echo Expected: %EXPECTED_HASH%
    echo Actual  : %ACTUAL_HASH%
    del "update_temp.zip"
    timeout /t 10
    exit
)

echo [6/6] Extracting and applying update...
powershell -NoProfile -Command "Expand-Archive -Path '.\update_temp.zip' -DestinationPath '.\' -Force"
del "update_temp.zip"
if exist "downloader.py" del "downloader.py"

:: Update local version.json record
move /Y version_remote.json version.json > nul

echo Update applied successfully! Restarting dashboard...
start "" "start_dashboard.vbs"
exit
