from __future__ import annotations

from datetime import date, datetime, time, timedelta
from typing import Any


OUTLOOK_CALENDAR_FOLDER = 9
MAX_OUTLOOK_RANGE_DAYS = 62
MAX_OUTLOOK_EVENTS = 1000


class OutlookCalendarError(RuntimeError):
    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code


def _as_datetime(value: Any) -> datetime:
    if isinstance(value, datetime):
        return value
    return datetime.fromisoformat(str(value))


def _outlook_filter_datetime(value: datetime) -> str:
    return value.strftime("%m/%d/%Y %I:%M %p")


def _load_outlook_modules():
    try:
        import pythoncom
        import win32com.client
    except ImportError as exc:
        raise OutlookCalendarError(
            "integration_unavailable",
            "Classic Outlook integration component is not installed",
        ) from exc
    return pythoncom, win32com.client


def _get_outlook_namespace(win32_client):
    try:
        outlook = win32_client.Dispatch("Outlook.Application")
        return outlook.GetNamespace("MAPI")
    except Exception as exc:
        raise OutlookCalendarError(
            "classic_outlook_unavailable",
            "Classic Outlook is not installed or its default profile is unavailable",
        ) from exc


def list_outlook_calendar_folders() -> list[dict[str, Any]]:
    pythoncom, win32_client = _load_outlook_modules()
    pythoncom.CoInitialize()
    try:
        namespace = _get_outlook_namespace(win32_client)
        default_calendar = namespace.GetDefaultFolder(OUTLOOK_CALENDAR_FOLDER)
        default_key = (
            str(default_calendar.EntryID),
            str(default_calendar.Store.StoreID),
        )
        folders: list[dict[str, Any]] = []
        seen: set[tuple[str, str]] = set()

        def visit(folder, depth: int = 0):
            try:
                if str(getattr(folder, "DefaultMessageClass", "")) == "IPM.Appointment":
                    entry_id = str(folder.EntryID)
                    store_id = str(folder.Store.StoreID)
                    key = (entry_id, store_id)
                    if key not in seen:
                        seen.add(key)
                        store_name = str(folder.Store.DisplayName)
                        folders.append({
                            "entry_id": entry_id,
                            "store_id": store_id,
                            "name": str(folder.Name),
                            "path": str(folder.FolderPath),
                            "store_name": store_name,
                            "item_count": int(folder.Items.Count),
                            "is_default": key == default_key,
                            "recommended": depth == 1 and "@" in store_name,
                        })
            except Exception:
                pass
            try:
                children = folder.Folders
                for index in range(1, children.Count + 1):
                    visit(children.Item(index), depth + 1)
            except Exception:
                pass

        roots = namespace.Folders
        for index in range(1, roots.Count + 1):
            visit(roots.Item(index))
        folders.sort(key=lambda folder: (
            not folder["recommended"],
            not folder["is_default"],
            folder["store_name"].lower(),
            folder["path"].lower(),
        ))
        return folders
    finally:
        pythoncom.CoUninitialize()


def list_outlook_calendar_events(
    start_date: date,
    end_date: date,
    folder_entry_id: str | None = None,
    store_id: str | None = None,
) -> list[dict[str, Any]]:
    if end_date <= start_date:
        raise ValueError("end must be later than start")
    if (end_date - start_date).days > MAX_OUTLOOK_RANGE_DAYS:
        raise ValueError(f"Outlook calendar range cannot exceed {MAX_OUTLOOK_RANGE_DAYS} days")
    if bool(folder_entry_id) != bool(store_id):
        raise ValueError("folder_id and store_id must be provided together")

    pythoncom, win32_client = _load_outlook_modules()
    range_start = datetime.combine(start_date, time.min)
    range_end = datetime.combine(end_date, time.min)
    pythoncom.CoInitialize()
    try:
        namespace = _get_outlook_namespace(win32_client)
        try:
            calendar = (
                namespace.GetFolderFromID(folder_entry_id, store_id)
                if folder_entry_id and store_id
                else namespace.GetDefaultFolder(OUTLOOK_CALENDAR_FOLDER)
            )
            items = calendar.Items
            items.Sort("[Start]")
            items.IncludeRecurrences = True
            restriction = (
                f"[Start] < '{_outlook_filter_datetime(range_end)}' "
                f"AND [End] >= '{_outlook_filter_datetime(range_start)}'"
            )
            appointments = items.Restrict(restriction)
        except Exception as exc:
            raise OutlookCalendarError(
                "outlook_folder_unavailable",
                "The selected Classic Outlook calendar folder is unavailable",
            ) from exc

        events: list[dict[str, Any]] = []
        try:
            appointment = appointments.GetFirst()
            while appointment is not None and len(events) < MAX_OUTLOOK_EVENTS:
                start_at = _as_datetime(appointment.Start)
                end_at = _as_datetime(appointment.End)
                display_end_at = end_at
                if end_at > start_at and end_at.time() == time.min:
                    display_end_at = end_at - timedelta(microseconds=1)
                entry_id = str(getattr(appointment, "EntryID", ""))
                subject = str(getattr(appointment, "Subject", "") or "제목 없는 일정")
                events.append({
                    "id": f"{entry_id}:{start_at.isoformat()}",
                    "date": start_at.date().isoformat(),
                    "end_date": display_end_at.date().isoformat(),
                    "title": subject,
                    "start_at": start_at.isoformat(),
                    "end_at": end_at.isoformat(),
                    "all_day": bool(getattr(appointment, "AllDayEvent", False)),
                    "location": str(getattr(appointment, "Location", "") or ""),
                })
                appointment = appointments.GetNext()
        except Exception as exc:
            raise OutlookCalendarError(
                "outlook_read_failed",
                "Classic Outlook calendar could not be read",
            ) from exc
        return events
    finally:
        pythoncom.CoUninitialize()
