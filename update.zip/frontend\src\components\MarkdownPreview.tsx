import { Fragment } from 'react';
import type { ReactNode } from 'react';

const INLINE_PATTERN = /(`[^`]+`|\*\*[^*]+\*\*|__[^_]+__|\*[^*]+\*|_[^_]+_|\[[^\]]+\]\([^)]+\))/g;

const renderInline = (text: string): ReactNode[] => text.split(INLINE_PATTERN).map((part, index) => {
  if (part.startsWith('`') && part.endsWith('`')) {
    return <code key={index}>{part.slice(1, -1)}</code>;
  }
  if ((part.startsWith('**') && part.endsWith('**')) || (part.startsWith('__') && part.endsWith('__'))) {
    return <strong key={index}>{part.slice(2, -2)}</strong>;
  }
  if ((part.startsWith('*') && part.endsWith('*')) || (part.startsWith('_') && part.endsWith('_'))) {
    return <em key={index}>{part.slice(1, -1)}</em>;
  }
  const linkMatch = part.match(/^\[([^\]]+)\]\(([^)]+)\)$/);
  if (linkMatch) {
    const [, label, href] = linkMatch;
    const safeHref = /^(https?:|mailto:)/i.test(href) ? href : undefined;
    return safeHref
      ? <a key={index} href={safeHref} target="_blank" rel="noreferrer">{label}</a>
      : <Fragment key={index}>{label}</Fragment>;
  }
  return <Fragment key={index}>{part}</Fragment>;
});

const isBlockStart = (line: string) => (
  /^#{1,6}\s/.test(line)
  || /^```/.test(line)
  || /^>\s?/.test(line)
  || /^[-*+]\s/.test(line)
  || /^\d+\.\s/.test(line)
  || /^\s*(---+|___+|\*\*\*+)\s*$/.test(line)
);

interface MarkdownPreviewProps {
  content: string;
}

export default function MarkdownPreview({ content }: MarkdownPreviewProps) {
  if (!content.trim()) {
    return <div className="notepad-markdown-preview empty">Markdown 내용을 입력해 주세요.</div>;
  }

  const lines = content.replace(/\r\n/g, '\n').split('\n');
  const blocks: ReactNode[] = [];
  let index = 0;

  while (index < lines.length) {
    const line = lines[index];
    if (!line.trim()) {
      index += 1;
      continue;
    }

    const fenceMatch = line.match(/^```\s*([^\s]*)/);
    if (fenceMatch) {
      const code: string[] = [];
      index += 1;
      while (index < lines.length && !/^```/.test(lines[index])) {
        code.push(lines[index]);
        index += 1;
      }
      if (index < lines.length) index += 1;
      blocks.push(
        <pre key={`code-${index}`} data-language={fenceMatch[1] || undefined}>
          <code>{code.join('\n')}</code>
        </pre>,
      );
      continue;
    }

    const headingMatch = line.match(/^(#{1,6})\s+(.+)$/);
    if (headingMatch) {
      const level = headingMatch[1].length;
      const Heading = `h${level}` as keyof React.JSX.IntrinsicElements;
      blocks.push(<Heading key={`heading-${index}`}>{renderInline(headingMatch[2])}</Heading>);
      index += 1;
      continue;
    }

    if (/^\s*(---+|___+|\*\*\*+)\s*$/.test(line)) {
      blocks.push(<hr key={`hr-${index}`} />);
      index += 1;
      continue;
    }

    if (/^>\s?/.test(line)) {
      const quote: string[] = [];
      while (index < lines.length && /^>\s?/.test(lines[index])) {
        quote.push(lines[index].replace(/^>\s?/, ''));
        index += 1;
      }
      blocks.push(<blockquote key={`quote-${index}`}>{renderInline(quote.join(' '))}</blockquote>);
      continue;
    }

    if (/^[-*+]\s/.test(line)) {
      const items: ReactNode[] = [];
      while (index < lines.length && /^[-*+]\s/.test(lines[index])) {
        const item = lines[index].replace(/^[-*+]\s/, '');
        const taskMatch = item.match(/^\[([ xX])\]\s*(.*)$/);
        items.push(
          <li key={index} className={taskMatch ? 'task' : undefined}>
            {taskMatch && <input type="checkbox" checked={taskMatch[1].toLowerCase() === 'x'} readOnly />}
            {renderInline(taskMatch ? taskMatch[2] : item)}
          </li>,
        );
        index += 1;
      }
      blocks.push(<ul key={`ul-${index}`}>{items}</ul>);
      continue;
    }

    if (/^\d+\.\s/.test(line)) {
      const items: ReactNode[] = [];
      while (index < lines.length && /^\d+\.\s/.test(lines[index])) {
        items.push(<li key={index}>{renderInline(lines[index].replace(/^\d+\.\s/, ''))}</li>);
        index += 1;
      }
      blocks.push(<ol key={`ol-${index}`}>{items}</ol>);
      continue;
    }

    const paragraph: string[] = [line];
    index += 1;
    while (index < lines.length && lines[index].trim() && !isBlockStart(lines[index])) {
      paragraph.push(lines[index]);
      index += 1;
    }
    blocks.push(
      <p key={`paragraph-${index}`}>
        {paragraph.map((paragraphLine, lineIndex) => (
          <Fragment key={lineIndex}>
            {lineIndex > 0 && <br />}
            {renderInline(paragraphLine)}
          </Fragment>
        ))}
      </p>,
    );
  }

  return <div className="notepad-markdown-preview">{blocks}</div>;
}
