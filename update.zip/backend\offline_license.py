import base64
import json
import os
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any, Dict

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

from license_plans import apply_plan_defaults, normalize_plan
from license_service import isoformat, machine_id_hash, utc_now


PUBLIC_KEY_PATH = Path(__file__).with_name("offline_license_public_key.pem")


def canonical_json(data: Dict[str, Any]) -> bytes:
    return json.dumps(data, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


def b64url_decode(value: str) -> bytes:
    padding = "=" * (-len(value) % 4)
    return base64.urlsafe_b64decode((value + padding).encode("ascii"))


def load_public_key() -> Ed25519PublicKey:
    configured = os.getenv("OFFLINE_LICENSE_PUBLIC_KEY_PATH", "").strip()
    path = Path(configured) if configured else PUBLIC_KEY_PATH
    if not path.exists():
        raise FileNotFoundError(f"Offline license public key not found: {path}")
    key = serialization.load_pem_public_key(path.read_bytes())
    if not isinstance(key, Ed25519PublicKey):
        raise ValueError("Offline license public key must be Ed25519.")
    return key


def validate_license_document(document: Dict[str, Any]) -> Dict[str, Any]:
    payload = document.get("payload")
    signature = document.get("signature")
    if not isinstance(payload, dict) or not isinstance(signature, str):
        raise ValueError("Offline license file must contain payload and signature.")

    public_key = load_public_key()
    try:
        public_key.verify(b64url_decode(signature), canonical_json(payload))
    except InvalidSignature:
        raise ValueError("Offline license signature is invalid.")

    expected_machine = payload.get("machine_id_hash")
    current_machine = machine_id_hash()
    if expected_machine and expected_machine != current_machine:
        raise ValueError("Offline license is not issued for this device.")

    plan = normalize_plan(payload.get("plan"))
    if plan not in {"enterprise", "developer"}:
        raise ValueError("Offline license is available only for enterprise or developer plans.")

    expires_at = payload.get("expires_at")
    if not expires_at:
        raise ValueError("Offline license must include expires_at.")
    expiry = datetime.fromisoformat(str(expires_at).replace("Z", "+00:00"))
    now = datetime.now(expiry.tzinfo) if expiry.tzinfo else utc_now()
    if now > expiry:
        raise ValueError("Offline license has expired.")

    data = {
        **payload,
        "licensed": True,
        "status": "active",
        "provider": "offline",
        "activation_id": payload.get("activation_id") or f"offact_{uuid.uuid4().hex[:16]}",
        "activated_at": isoformat(utc_now()),
        "last_checked_at": isoformat(utc_now()),
        "message": "Offline license activated.",
    }
    return apply_plan_defaults(data)
