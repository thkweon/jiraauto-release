import { useState, useEffect, useCallback } from 'react';
import { RefreshCcw, ExternalLink, Search, Star } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import '../App.css';
import '../TeamStyles.css';

const API_BASE = 'http://localhost:8000/api';
const FAVORITES_STORAGE_KEY = 'jiraTeamFavoriteIssueMap';

const loadFavoriteIssueMap = <T,>(storageKey: string): Record<string, T> => {
  try {
    const raw = localStorage.getItem(storageKey);
    if (!raw) return {};
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : {};
  } catch {
    localStorage.removeItem(storageKey);
    return {};
  }
};

const groupTeamIssues = (issues: any[]) => {
  const groupedIssuesMap = new Map<string, any>();
  issues.forEach(issue => {
    const uniqueId = `${issue.instance_id}_${issue.key}`;
    if (!groupedIssuesMap.has(uniqueId)) {
      groupedIssuesMap.set(uniqueId, { ...issue, shared_members: [issue.team_member_id || 'Unknown'] });
    } else {
      const existing = groupedIssuesMap.get(uniqueId);
      if (!existing.shared_members.includes(issue.team_member_id)) {
        existing.shared_members.push(issue.team_member_id || 'Unknown');
      }
    }
  });
  return Array.from(groupedIssuesMap.values());
};


const getInstanceColor = (name: string) => {
  let hash = 0;
  for (let i = 0; i < name.length; i++) {
    hash = name.charCodeAt(i) + ((hash << 5) - hash);
  }
  const colors = [
    { bg: 'linear-gradient(135deg, #00b894 0%, #00cec9 100%)', shadow: 'rgba(0, 184, 148, 0.3)' }, // Green
    { bg: 'linear-gradient(135deg, #6c5ce7 0%, #a29bfe 100%)', shadow: 'rgba(108, 92, 231, 0.3)' }, // Purple
    { bg: 'linear-gradient(135deg, #fdcb6e 0%, #ffeaa7 100%)', shadow: 'rgba(253, 203, 110, 0.3)' }, // Yellow
    { bg: 'linear-gradient(135deg, #0984e3 0%, #74b9ff 100%)', shadow: 'rgba(9, 132, 227, 0.3)' },   // Blue
    { bg: 'linear-gradient(135deg, #e84393 0%, #fd79a8 100%)', shadow: 'rgba(232, 67, 147, 0.3)' }    // Pink
  ];
  return colors[Math.abs(hash) % colors.length];
};

const getMemberColor = (name: string) => {
  let hash = 0;
  for (let i = 0; i < name.length; i++) {
    hash = name.charCodeAt(i) + ((hash << 5) - hash);
  }
  const colors = [
    { bg: 'linear-gradient(135deg, #ff9f43 0%, #ffc048 100%)', shadow: 'rgba(255, 159, 67, 0.3)' }, // Orange
    { bg: 'linear-gradient(135deg, #222f3e 0%, #576574 100%)', shadow: 'rgba(34, 47, 62, 0.3)' },   // Dark Navy
    { bg: 'linear-gradient(135deg, #5f27cd 0%, #341f97 100%)', shadow: 'rgba(95, 39, 205, 0.3)' },  // Deep Purple
    { bg: 'linear-gradient(135deg, #3c40c6 0%, #575fcf 100%)', shadow: 'rgba(60, 64, 198, 0.3)' },   // Indigo
    { bg: 'linear-gradient(135deg, #485460 0%, #808e9b 100%)', shadow: 'rgba(72, 84, 96, 0.3)' },    // Slate Blue
    { bg: 'linear-gradient(135deg, #f39c12 0%, #f1c40f 100%)', shadow: 'rgba(243, 156, 18, 0.3)' },  // Golden Yellow
    { bg: 'linear-gradient(135deg, #273c75 0%, #192a56 100%)', shadow: 'rgba(39, 60, 117, 0.3)' },   // Royal Blue
    { bg: 'linear-gradient(135deg, #d35400 0%, #e67e22 100%)', shadow: 'rgba(211, 84, 0, 0.3)' },    // Brown Orange
    { bg: 'linear-gradient(135deg, #5c2a1d 0%, #8b4513 100%)', shadow: 'rgba(92, 42, 29, 0.3)' },    // Dark Brown
    { bg: 'linear-gradient(135deg, #2c3e50 0%, #34495e 100%)', shadow: 'rgba(44, 62, 80, 0.3)' },    // Midnight Blue
    { bg: 'linear-gradient(135deg, #8c7ae6 0%, #9c88ff 100%)', shadow: 'rgba(140, 122, 230, 0.3)' }, // Purple Illusion
    { bg: 'linear-gradient(135deg, #718093 0%, #7f8fa6 100%)', shadow: 'rgba(113, 128, 147, 0.3)' }, // Blue Grey
    { bg: 'linear-gradient(135deg, #e58e26 0%, #fa983a 100%)', shadow: 'rgba(229, 142, 38, 0.3)' },  // Amber
    { bg: 'linear-gradient(135deg, #4a69bd 0%, #6a89cc 100%)', shadow: 'rgba(74, 105, 189, 0.3)' },  // Steel Blue
    { bg: 'linear-gradient(135deg, #0652DD 0%, #12CBC4 100%)', shadow: 'rgba(6, 82, 221, 0.3)' },    // Vivid Blue
    { bg: 'linear-gradient(135deg, #574b90 0%, #786fa6 100%)', shadow: 'rgba(87, 75, 144, 0.3)' },   // Violet
    { bg: 'linear-gradient(135deg, #A3CB38 0%, #C4E538 100%)', shadow: 'rgba(163, 203, 56, 0.3)' },  // Olive Green
    { bg: 'linear-gradient(135deg, #cd6133 0%, #cc8e35 100%)', shadow: 'rgba(205, 97, 51, 0.3)' },   // Cocoa Brown
    { bg: 'linear-gradient(135deg, #1e272e 0%, #485460 100%)', shadow: 'rgba(30, 39, 46, 0.3)' },    // Charcoal
    { bg: 'linear-gradient(135deg, #b8e994 0%, #78e08f 100%)', shadow: 'rgba(120, 224, 143, 0.3)' }  // Light Green
  ];
  return colors[Math.abs(hash) % colors.length];
};

export default function TeamDashboardPage() {

  const [issues, setIssues] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  
  const [memberFilter, setMemberFilter] = useState('all');
  const [accountFilter, setAccountFilter] = useState('all');
  const [projectFilter, setProjectFilter] = useState('all');
  const [datePreset, setDatePreset] = useState('30');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [searchQuery, setSearchQuery] = useState(() => localStorage.getItem('teamDashboardSearchQuery') || '');
  const [includeClosed, setIncludeClosed] = useState(() => localStorage.getItem('teamIncludeClosedIssues') === 'true');
  const [favoriteIssues, setFavoriteIssues] = useState<Record<string, any>>(() => loadFavoriteIssueMap<any>(FAVORITES_STORAGE_KEY));
  const [teamRole, setTeamRole] = useState(() => localStorage.getItem('teamRole'));
  const [teamLeaderUrl, setTeamLeaderUrl] = useState(() => localStorage.getItem('teamLeaderUrl'));

  const favoriteKey = (issue: any) => `${issue.instance_id}:${issue.key}`;
  const isFavoriteIssue = (issue: any) => Boolean(favoriteIssues[favoriteKey(issue)]);
  const normalizeTeamFavoriteIssue = (issue: any) => ({
    ...issue,
    shared_members: Array.isArray(issue.shared_members)
      ? issue.shared_members
      : [issue.team_member_id || 'Unknown'],
  });
  const persistFavorites = (next: Record<string, any>) => {
    setFavoriteIssues(next);
    localStorage.setItem(FAVORITES_STORAGE_KEY, JSON.stringify(next));
    window.dispatchEvent(new Event('jiraFavoritesChanged'));
  };
  const toggleFavoriteIssue = (issue: any) => {
    const key = favoriteKey(issue);
    const next = { ...favoriteIssues };
    if (next[key]) {
      delete next[key];
    } else {
      next[key] = normalizeTeamFavoriteIssue(issue);
    }
    persistFavorites(next);
  };
  const refreshFavoriteSnapshots = (latestGroupedIssues: any[]) => {
    const current = loadFavoriteIssueMap<any>(FAVORITES_STORAGE_KEY);
    let changed = false;
    const next = { ...current };
    latestGroupedIssues.forEach(issue => {
      const key = favoriteKey(issue);
      if (next[key]) {
        next[key] = normalizeTeamFavoriteIssue(issue);
        changed = true;
      }
    });
    if (changed) persistFavorites(next);
  };

  useEffect(() => {
    const syncFavorites = () => setFavoriteIssues(loadFavoriteIssueMap<any>(FAVORITES_STORAGE_KEY));
    window.addEventListener('storage', syncFavorites);
    window.addEventListener('jiraFavoritesChanged', syncFavorites);
    return () => {
      window.removeEventListener('storage', syncFavorites);
      window.removeEventListener('jiraFavoritesChanged', syncFavorites);
    };
  }, []);

  useEffect(() => {
    const syncTeamContext = () => {
      setTeamRole(localStorage.getItem('teamRole'));
      setTeamLeaderUrl(localStorage.getItem('teamLeaderUrl'));
    };
    window.addEventListener('storage', syncTeamContext);
    window.addEventListener('teamRoleChanged', syncTeamContext);
    return () => {
      window.removeEventListener('storage', syncTeamContext);
      window.removeEventListener('teamRoleChanged', syncTeamContext);
    };
  }, []);

  const fetchTeamData = useCallback(async () => {
    try {
      if (teamRole !== 'leader' && !teamLeaderUrl) {
        setIssues([]);
        setLoading(false);
        return;
      }
      const baseUrl = teamRole === 'leader' ? API_BASE : `${teamLeaderUrl}/api`;
      const resIss = await fetch(`${baseUrl}/team/issues?include_closed=${includeClosed ? 'true' : 'false'}`);
      const dataIss = await resIss.json();
      
      const sortedIssues = (dataIss.issues || []).sort((a: any, b: any) => {
        const d1 = new Date(a.fields?.created || 0).getTime();
        const d2 = new Date(b.fields?.created || 0).getTime();
        return d2 - d1;
      });
      setIssues(sortedIssues);
    } catch(e) { console.error(e); }
    setLoading(false);
  }, [includeClosed, teamRole, teamLeaderUrl]);

  useEffect(() => {
    fetchTeamData();
    const interval = setInterval(fetchTeamData, 15000);
    return () => clearInterval(interval);
  }, [fetchTeamData]);

  const isWithinDate = (dateStr: string) => {
    if (!dateStr) return true;
    const issueDate = new Date(dateStr).getTime();
    
    if (datePreset === 'custom') {
      if (startDate && issueDate < new Date(startDate).getTime()) return false;
      if (endDate && issueDate > new Date(endDate).getTime() + 86400000) return false;
      return true;
    }
    
    if (datePreset === 'all') return true;
    
    const days = parseInt(datePreset);
    const start = new Date();
    start.setDate(start.getDate() - days);
    return issueDate >= start.getTime();
  };

  const doneStatusNames = ['Done', 'Closed', 'Resolved', '완료', '닫힘', '해결됨'];
  const isDoneIssue = (issue: any) => {
    const categoryKey = issue.fields?.status?.statusCategory?.key;
    const statusName = issue.fields?.status?.name;
    return categoryKey === 'done' || doneStatusNames.includes(statusName);
  };

  const matchesIssueSearch = (issue: any) => {
    const query = searchQuery.trim().toLowerCase();
    if (!query) return true;
    const key = issue.key || '';
    const summary = issue.fields?.summary || issue.summary || '';
    return `${key} ${summary}`.toLowerCase().includes(query);
  };

  // 1단계: 조건에 맞는 이슈 필터링
  const displaySourceIssues = [
    ...Object.values(favoriteIssues),
    ...issues.filter(issue => !favoriteIssues[favoriteKey(issue)])
  ];
  const filteredIssues = displaySourceIssues.filter(i => {
    if (isFavoriteIssue(i)) return true;
    const pMatch = projectFilter === 'all' || i.fields?.project?.key === projectFilter;
    const mMatch = memberFilter === 'all' || i.team_member_id === memberFilter;
    const acMatch = accountFilter === 'all' || (i.team_instance_name || '미분류') === accountFilter;
    const dMatch = isWithinDate(i.fields?.created);
    const activeMatch = includeClosed || i.sync_active !== false;
    const doneMatch = includeClosed || !isDoneIssue(i);
    const sMatch = matchesIssueSearch(i);
    return pMatch && mMatch && acMatch && dMatch && activeMatch && doneMatch && sMatch;
  });

  // 2단계: 동일한 이슈(Jira 티켓) 병합 처리 (연동 멤버 취합)
  const groupedIssues = groupTeamIssues(filteredIssues);
  const searchRank = (issue: any) => {
    const query = searchQuery.trim().toLowerCase();
    if (!query) return 0;
    const key = String(issue.key || '').toLowerCase();
    const summary = String(issue.fields?.summary || issue.summary || '').toLowerCase();
    const combined = `${key} ${summary}`;
    if (key === query) return 0;
    if (key.startsWith(query)) return 1;
    if (key.includes(query)) return 2;
    if (summary.startsWith(query)) return 3;
    if (summary.includes(query)) return 4;
    if (combined.includes(query)) return 5;
    return 9;
  };
  const issueTime = (issue: any) => new Date(issue.fields?.updated || issue.fields?.created || 0).getTime();
  const finalDisplayIssues = groupedIssues.sort((a, b) => {
    const favoriteDiff = Number(isFavoriteIssue(b)) - Number(isFavoriteIssue(a));
    if (favoriteDiff !== 0) return favoriteDiff;
    const rankDiff = searchRank(a) - searchRank(b);
    if (rankDiff !== 0) return rankDiff;
    return issueTime(b) - issueTime(a);
  });

  useEffect(() => {
    refreshFavoriteSnapshots(groupTeamIssues(issues));
  }, [issues]);

  const members = Array.from(new Set(issues.map(i => i.team_member_id).filter(Boolean))).sort();
  const accounts = Array.from(new Set(issues.map(i => i.team_instance_name || '미분류'))).sort();
  const projects = Array.from(new Set(issues.map(i => i.fields?.project?.key).filter(Boolean))).sort();

  return (
    <div className="glass-container" style={{maxWidth: '1800px'}}>
      <div style={{ display: 'flex', alignItems: 'center', marginBottom: 30, width: '100%' }}>
        <div style={{display:'flex', gap:'12px', alignItems:'center', flexWrap: 'nowrap', width: '100%', boxSizing: 'border-box', background: 'var(--card-bg)', padding: '12px 16px', borderRadius: '12px', boxShadow: '0 4px 15px rgba(0,0,0,0.05)', overflowX: 'auto'}}>
          <div style={{display: 'flex', alignItems: 'center', gap: 5}}>
            <span style={{fontSize: 13, fontWeight: 700, color: 'var(--text-secondary)'}}>연동 멤버</span>
            <select className="glass-input" style={{width: 'auto', padding: '6px 12px'}} value={memberFilter} onChange={e => setMemberFilter(e.target.value)}>
              <option value="all">전체</option>
              {members.map(m => <option key={m as string} value={m as string}>{m as string}</option>)}
            </select>
          </div>

          <div style={{display: 'flex', alignItems: 'center', gap: 5}}>
            <span style={{fontSize: 13, fontWeight: 700, color: 'var(--text-secondary)'}}>계정</span>
            <select className="glass-input" style={{width: 'auto', padding: '6px 12px'}} value={accountFilter} onChange={e => setAccountFilter(e.target.value)}>
              <option value="all">전체 계정</option>
              {accounts.map(a => <option key={a as string} value={a as string}>{a as string}</option>)}
            </select>
          </div>

          <div style={{display: 'flex', alignItems: 'center', gap: 5}}>
            <span style={{fontSize: 13, fontWeight: 700, color: 'var(--text-secondary)'}}>기간</span>
            <select className="glass-input" style={{width: 'auto', padding: '6px 12px'}} value={datePreset} onChange={e => setDatePreset(e.target.value)}>
              <option value="1">1일</option>
              <option value="7">7일</option>
              <option value="14">14일</option>
              <option value="30">30일</option>
              <option value="90">90일</option>
              <option value="all">전체</option>
              <option value="custom">직접입력</option>
            </select>
            {datePreset === 'custom' && (
              <div style={{display: 'flex', alignItems: 'center', gap: 5, marginLeft: 5}}>
                <input type="date" className="glass-input" style={{padding: '6px', fontSize: 12}} value={startDate} onChange={e => setStartDate(e.target.value)} />
                <span style={{color: '#ccc'}}>~</span>
                <input type="date" className="glass-input" style={{padding: '6px', fontSize: 12}} value={endDate} onChange={e => setEndDate(e.target.value)} />
              </div>
            )}
          </div>

          <div style={{display: 'flex', alignItems: 'center', gap: 5}}>
            <span style={{fontSize: 13, fontWeight: 700, color: 'var(--text-secondary)'}}>프로젝트</span>
            <select className="glass-input" style={{width: 'auto', padding: '6px 12px'}} value={projectFilter} onChange={e => setProjectFilter(e.target.value)}>
              <option value="all">모든 프로젝트</option>
              {projects.map(p => <option key={p as string} value={p as string}>{p as string}</option>)}
            </select>
          </div>

          <label style={{display: 'flex', alignItems: 'center', gap: 6, fontSize: 13, fontWeight: 700, color: 'var(--text-secondary)', cursor: 'pointer', whiteSpace: 'nowrap', flexShrink: 0}}>
            <input
              type="checkbox"
              checked={includeClosed}
              onChange={e => {
                setIncludeClosed(e.target.checked);
                localStorage.setItem('teamIncludeClosedIssues', e.target.checked ? 'true' : 'false');
              }}
              style={{cursor: 'pointer'}}
            />
            완료/닫힘 포함
          </label>

          <button className="btn-premium" style={{padding: '6px 12px', marginLeft: 'auto', flexShrink: 0}} onClick={fetchTeamData}><RefreshCcw size={14}/></button>
        </div>
      </div>

      <div style={{position: 'relative', width: '100%', marginBottom: 30}}>
        <Search size={16} style={{position: 'absolute', left: 14, top: '50%', transform: 'translateY(-50%)', color: 'var(--text-secondary)', pointerEvents: 'none'}} />
        <input
          className="glass-input"
          type="search"
          value={searchQuery}
          onChange={e => {
            setSearchQuery(e.target.value);
            localStorage.setItem('teamDashboardSearchQuery', e.target.value);
          }}
          placeholder="티켓 번호 또는 제목 검색"
          style={{width: '100%', padding: '10px 14px 10px 40px', boxSizing: 'border-box'}}
        />
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, minmax(300px, 1fr))', gap: '20px', alignContent: 'start' }}>
        <AnimatePresence>
          {finalDisplayIssues.map(issue => {
            const issueLink = issue.team_instance_url ? `${issue.team_instance_url}/browse/${issue.key}` : '#';

            return (
              <motion.a 
                href={issueLink}
                target="_blank"
                rel="noreferrer"
                initial={{opacity:0, scale:0.95}} 
                animate={{opacity:1, scale:1}} 
                exit={{opacity:0, scale:0.9}} 
                key={`${issue.instance_id}-${issue.key}`} 
                className="issue-card hoverable" 
                style={{position: 'relative', border: '1px solid rgba(0,0,0,0.05)', background: 'var(--card-bg)', textDecoration: 'none', color: 'inherit', display: 'flex', flexDirection: 'column', height: '100%', boxSizing: 'border-box'}}
              >
                <button
                  className={`favorite-star-button team-star ${isFavoriteIssue(issue) ? 'active' : ''}`}
                  title={isFavoriteIssue(issue) ? '즐겨찾기 해제' : '즐겨찾기'}
                  onClick={(e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    toggleFavoriteIssue(issue);
                  }}
                >
                  <Star size={17} fill={isFavoriteIssue(issue) ? '#f1c40f' : 'none'} />
                </button>
                <div style={{ position: 'absolute', top: -12, right: -12, display: 'flex', gap: 6, zIndex: 10 }}>
                  {(() => {
                    const instName = issue.team_instance_name || '미분류';
                    const c = getInstanceColor(instName);
                    return (
                      <div className="premium-badge" style={{ position: 'relative', top: 'auto', right: 'auto', background: c.bg, boxShadow: `0 4px 10px ${c.shadow}` }}>
                        {instName}
                      </div>
                    );
                  })()}
                  {(() => {
                    const memName = issue.shared_members.join(', ');
                    const mc = getMemberColor(memName);
                    return (
                      <div className="premium-badge" style={{ position: 'relative', top: 'auto', right: 'auto', background: mc.bg, boxShadow: `0 4px 10px ${mc.shadow}` }}>
                        {memName}
                      </div>
                    );
                  })()}
                </div>
                
                <div className="issue-header" style={{marginTop: 10, display: 'flex', alignItems: 'center', justifyContent: 'space-between'}}>
                  <span className="issue-key" style={{fontWeight: 700}}>{issue.key} <ExternalLink size={12} style={{marginLeft: 4, verticalAlign: 'middle', opacity: 0.6}}/></span>
                  <span className="status-badge" style={{background: 'rgba(9, 132, 227, 0.1)', color: '#0984e3', marginTop: 0}}>{issue.fields?.status?.name}</span>
                </div>
                
                <div className="issue-summary" style={{fontSize: 15, lineHeight: 1.5, marginTop: 10, marginBottom: 15, color: 'var(--text-primary)'}}>{issue.fields?.summary}</div>
                
                <div style={{borderTop: '1px solid rgba(0,0,0,0.05)', paddingTop: 12, marginTop: 'auto'}}>
                  <div style={{display: 'flex', justifyContent: 'space-between', fontSize: 12, color: 'var(--text-secondary)'}}>
                    <span style={{fontWeight: 600}}>{issue.fields?.assignee?.displayName || issue.fields?.assignee?.name || '미할당'}</span>
                    <span>{new Date(issue.fields?.created).toLocaleDateString()}</span>
                  </div>
                </div>
              </motion.a>
            )
          })}
        </AnimatePresence>
      </div>
      {finalDisplayIssues.length === 0 && !loading && (
        <div style={{padding: 40, textAlign: 'center', color: 'var(--text-secondary)'}}>
          조건에 맞는 이슈가 없습니다.
        </div>
      )}
    </div>
  );
}
