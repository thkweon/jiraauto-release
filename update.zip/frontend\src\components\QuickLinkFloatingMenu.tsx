import { useEffect, useState } from 'react';
import type { CSSProperties } from 'react';
import { Folder } from 'lucide-react';
import { QUICK_LINKS_CHANGED_EVENT, loadQuickLinks } from '../utils/quickLinks';
import type { QuickLinkItem } from '../utils/quickLinks';

const API_BASE = 'http://localhost:8000/api';
const MAX_FOLLOW_OFFSET = 42;
const SCROLL_DAMPING = 0.34;
const SETTLE_DAMPING = 0.16;
const SCROLL_IDLE_MS = 90;

const getFallbackText = (title: string) => {
  const compact = title.trim().replace(/\s+/g, '');
  return Array.from(compact || '?').slice(0, 2).join('');
};

function QuickLinkFloatingIcon({ link }: { link: QuickLinkItem }) {
  if (link.type === 'folder') {
    return link.imageUrl ? (
      <img src={link.imageUrl} alt="" className="quick-link-floating-image" />
    ) : (
      <Folder size={22} aria-hidden="true" />
    );
  }

  return link.imageUrl ? (
    <img src={link.imageUrl} alt="" className="quick-link-floating-image" />
  ) : (
    <span className="quick-link-floating-fallback">{getFallbackText(link.title)}</span>
  );
}

export default function QuickLinkFloatingMenu() {
  const [links, setLinks] = useState<QuickLinkItem[]>(() => loadQuickLinks());
  const [followOffset, setFollowOffset] = useState(0);
  const [licensed, setLicensed] = useState<boolean | null>(null);

  useEffect(() => {
    let cancelled = false;

    const checkLicense = async () => {
      try {
        const res = await fetch(`${API_BASE}/license/status`);
        const data = await res.json();
        if (!cancelled) setLicensed(Boolean(data.licensed));
      } catch {
        if (!cancelled) setLicensed(false);
      }
    };

    checkLicense();
    window.addEventListener('licenseChanged', checkLicense);
    return () => {
      cancelled = true;
      window.removeEventListener('licenseChanged', checkLicense);
    };
  }, []);

  useEffect(() => {
    const syncLinks = (event?: Event) => {
      if (event instanceof CustomEvent && Array.isArray(event.detail)) {
        setLinks(event.detail);
        return;
      }
      setLinks(loadQuickLinks());
    };

    window.addEventListener(QUICK_LINKS_CHANGED_EVENT, syncLinks);
    window.addEventListener('storage', syncLinks);
    return () => {
      window.removeEventListener(QUICK_LINKS_CHANGED_EVENT, syncLinks);
      window.removeEventListener('storage', syncLinks);
    };
  }, []);

  useEffect(() => {
    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (reduceMotion) return;

    let animationId = 0;
    let idleTimer = 0;
    let lastScrollY = window.scrollY;
    let currentOffset = 0;
    let targetOffset = 0;

    const animate = () => {
      const damping = targetOffset === 0 ? SETTLE_DAMPING : SCROLL_DAMPING;
      currentOffset += (targetOffset - currentOffset) * damping;
      if (Math.abs(currentOffset) < 0.15 && targetOffset === 0) {
        currentOffset = 0;
      }
      setFollowOffset(currentOffset);
      if (currentOffset === 0 && targetOffset === 0) {
        animationId = 0;
        return;
      }
      animationId = window.requestAnimationFrame(animate);
    };

    const handleScroll = () => {
      const nextScrollY = window.scrollY;
      const delta = nextScrollY - lastScrollY;
      lastScrollY = nextScrollY;

      targetOffset = Math.max(
        -MAX_FOLLOW_OFFSET,
        Math.min(MAX_FOLLOW_OFFSET, -delta * 1.25),
      );

      if (idleTimer) window.clearTimeout(idleTimer);
      idleTimer = window.setTimeout(() => {
        targetOffset = 0;
        if (!animationId) {
          animationId = window.requestAnimationFrame(animate);
        }
      }, SCROLL_IDLE_MS);

      if (!animationId) {
        animationId = window.requestAnimationFrame(animate);
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });

    return () => {
      window.cancelAnimationFrame(animationId);
      if (idleTimer) window.clearTimeout(idleTimer);
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  if (licensed !== true || links.length === 0) return null;

  return (
    <nav
      className="quick-link-floating-menu"
      aria-label="Quick links"
      style={{ '--quick-link-follow-offset': `${followOffset}px` } as CSSProperties}
    >
      {links.map(link => (
        link.type === 'folder' ? (
          <div key={link.id} className="quick-link-floating-folder">
            <button
              type="button"
              className="quick-link-floating-item quick-link-floating-folder-trigger"
              title={link.title}
              aria-label={`${link.title} 폴더`}
              onClick={event => event.preventDefault()}
            >
              <QuickLinkFloatingIcon link={link} />
            </button>
            {link.children.length > 0 && (
              <div className="quick-link-floating-flyout" role="menu" aria-label={`${link.title} 폴더 링크`}>
                {link.children.map(child => (
                  <button
                    key={child.id}
                    type="button"
                    className="quick-link-floating-item"
                    title={child.title}
                    aria-label={child.title}
                    role="menuitem"
                    onClick={() => {
                      window.open(child.url, '_blank', 'noopener,noreferrer');
                    }}
                  >
                    <QuickLinkFloatingIcon link={child} />
                  </button>
                ))}
              </div>
            )}
          </div>
        ) : (
          <button
            key={link.id}
            type="button"
            className="quick-link-floating-item"
            title={link.title}
            aria-label={link.title}
            onClick={() => {
              window.open(link.url, '_blank', 'noopener,noreferrer');
            }}
          >
            <QuickLinkFloatingIcon link={link} />
          </button>
        )
      ))}
    </nav>
  );
}
