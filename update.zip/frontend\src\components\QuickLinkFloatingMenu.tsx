import { useEffect, useState } from 'react';
import { QUICK_LINKS_CHANGED_EVENT, loadQuickLinks } from '../utils/quickLinks';
import type { QuickLinkItem } from '../utils/quickLinks';

const getFallbackText = (title: string) => {
  const compact = title.trim().replace(/\s+/g, '');
  return Array.from(compact || '?').slice(0, 2).join('');
};

export default function QuickLinkFloatingMenu() {
  const [links, setLinks] = useState<QuickLinkItem[]>(() => loadQuickLinks());

  useEffect(() => {
    const syncLinks = (event?: Event) => {
      if (event instanceof CustomEvent && Array.isArray(event.detail)) {
        setLinks(event.detail);
        return;
      }
      setLinks(loadQuickLinks());
    };

    window.addEventListener(QUICK_LINKS_CHANGED_EVENT, syncLinks);
    window.addEventListener('storage', syncLinks);
    return () => {
      window.removeEventListener(QUICK_LINKS_CHANGED_EVENT, syncLinks);
      window.removeEventListener('storage', syncLinks);
    };
  }, []);

  if (links.length === 0) return null;

  return (
    <nav className="quick-link-floating-menu" aria-label="Quick links">
      {links.map(link => (
        <button
          key={link.id}
          type="button"
          className="quick-link-floating-item"
          title={link.title}
          aria-label={link.title}
          onClick={() => {
            window.open(link.url, '_blank', 'noopener,noreferrer');
          }}
        >
          {link.imageUrl ? (
            <img src={link.imageUrl} alt="" className="quick-link-floating-image" />
          ) : (
            <span className="quick-link-floating-fallback">{getFallbackText(link.title)}</span>
          )}
        </button>
      ))}
    </nav>
  );
}
