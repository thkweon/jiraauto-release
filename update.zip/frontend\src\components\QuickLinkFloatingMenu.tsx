import { useEffect, useLayoutEffect, useRef, useState } from 'react';
import { Folder } from 'lucide-react';
import {
  QUICK_LINK_ENABLED_CHANGED_EVENT,
  QUICK_LINK_POSITION_CHANGED_EVENT,
  QUICK_LINKS_CHANGED_EVENT,
  loadQuickLinkImage,
  loadQuickLinkEnabled,
  loadQuickLinkPosition,
  loadQuickLinks,
} from '../utils/quickLinks';
import type { QuickLinkItem, QuickLinkPosition } from '../utils/quickLinks';
import { useFloatingWidgetLayout } from '../hooks/useFloatingWidgetLayout';

const API_BASE = 'http://localhost:8000/api';

const getFallbackText = (title: string) => {
  const compact = title.trim().replace(/\s+/g, '');
  return Array.from(compact || '?').slice(0, 2).join('');
};

function QuickLinkFloatingIcon({ link }: { link: QuickLinkItem }) {
  const [resolvedImageUrl, setResolvedImageUrl] = useState('');

  useEffect(() => {
    let cancelled = false;
    loadQuickLinkImage(link.imageUrl).then(value => {
      if (!cancelled) setResolvedImageUrl(value);
    });
    return () => {
      cancelled = true;
    };
  }, [link.imageUrl]);

  if (link.type === 'folder') {
    return resolvedImageUrl ? (
      <img src={resolvedImageUrl} alt="" className="quick-link-floating-image" />
    ) : (
      <Folder size={22} aria-hidden="true" />
    );
  }

  return resolvedImageUrl ? (
    <img src={resolvedImageUrl} alt="" className="quick-link-floating-image" />
  ) : (
    <span className="quick-link-floating-fallback">{getFallbackText(link.title)}</span>
  );
}

type QuickLinkFolder = Extract<QuickLinkItem, { type: 'folder' }>;

function QuickLinkFloatingFolder({
  link,
  position,
}: {
  link: QuickLinkFolder;
  position: QuickLinkPosition;
}) {
  const triggerRef = useRef<HTMLButtonElement>(null);
  const [vertical, setVertical] = useState(false);

  useLayoutEffect(() => {
    const trigger = triggerRef.current;
    if (!trigger || link.children.length < 2) {
      setVertical(false);
      return;
    }

    let animationFrame = 0;
    const updateOrientation = () => {
      window.cancelAnimationFrame(animationFrame);
      animationFrame = window.requestAnimationFrame(() => {
        const rect = trigger.getBoundingClientRect();
        if (rect.width <= 0) return;

        const scale = rect.width / 44;
        const flyoutGap = 8 * scale;
        const viewportMargin = 16;
        const itemGap = 8 * scale;
        const horizontalPadding = 16 * scale;
        const borderWidth = 2;
        const requiredWidth = link.children.length * rect.width
          + (link.children.length - 1) * itemGap
          + horizontalPadding
          + borderWidth;
        const availableWidth = position.startsWith('left-')
          ? rect.left - flyoutGap - viewportMargin
          : window.innerWidth - rect.right - flyoutGap - viewportMargin;

        setVertical(requiredWidth > availableWidth);
      });
    };

    updateOrientation();
    const resizeObserver = new ResizeObserver(updateOrientation);
    resizeObserver.observe(trigger);
    window.addEventListener('resize', updateOrientation);
    window.visualViewport?.addEventListener('resize', updateOrientation);
    return () => {
      window.cancelAnimationFrame(animationFrame);
      resizeObserver.disconnect();
      window.removeEventListener('resize', updateOrientation);
      window.visualViewport?.removeEventListener('resize', updateOrientation);
    };
  }, [link.children.length, position]);

  return (
    <div className="quick-link-floating-folder">
      <button
        ref={triggerRef}
        type="button"
        className="quick-link-floating-item quick-link-floating-folder-trigger"
        title={link.title}
        aria-label={`${link.title} 폴더`}
        onClick={event => event.preventDefault()}
      >
        <QuickLinkFloatingIcon link={link} />
      </button>
      {link.children.length > 0 && (
        <div
          className={`quick-link-floating-flyout${vertical ? ' quick-link-floating-flyout-vertical' : ''}`}
          data-flyout-orientation={vertical ? 'vertical' : 'horizontal'}
          role="menu"
          aria-label={`${link.title} 폴더 링크`}
        >
          {link.children.map(child => (
            <button
              key={child.id}
              type="button"
              className="quick-link-floating-item"
              title={child.title}
              aria-label={child.title}
              role="menuitem"
              onClick={event => {
                event.currentTarget.blur();
                window.open(child.url, '_blank', 'noopener,noreferrer');
              }}
            >
              <QuickLinkFloatingIcon link={child} />
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

export default function QuickLinkFloatingMenu() {
  const [links, setLinks] = useState<QuickLinkItem[]>(() => loadQuickLinks());
  const [enabled, setEnabled] = useState(loadQuickLinkEnabled);
  const [position, setPosition] = useState<QuickLinkPosition>(loadQuickLinkPosition);
  const [licensed, setLicensed] = useState<boolean | null>(null);
  const layout = useFloatingWidgetLayout(
    'quick-link',
    position,
    enabled && licensed === true && links.length > 0,
  );

  useEffect(() => {
    let cancelled = false;

    const checkLicense = async () => {
      try {
        const res = await fetch(`${API_BASE}/license/status`);
        const data = await res.json();
        if (!cancelled) setLicensed(Boolean(data.licensed));
      } catch {
        if (!cancelled) setLicensed(false);
      }
    };

    checkLicense();
    window.addEventListener('licenseChanged', checkLicense);
    return () => {
      cancelled = true;
      window.removeEventListener('licenseChanged', checkLicense);
    };
  }, []);

  useEffect(() => {
    const syncEnabled = () => setEnabled(loadQuickLinkEnabled());
    window.addEventListener(QUICK_LINK_ENABLED_CHANGED_EVENT, syncEnabled);
    window.addEventListener('storage', syncEnabled);
    return () => {
      window.removeEventListener(QUICK_LINK_ENABLED_CHANGED_EVENT, syncEnabled);
      window.removeEventListener('storage', syncEnabled);
    };
  }, []);

  useEffect(() => {
    const syncPosition = () => setPosition(loadQuickLinkPosition());
    window.addEventListener(QUICK_LINK_POSITION_CHANGED_EVENT, syncPosition);
    window.addEventListener('storage', syncPosition);
    return () => {
      window.removeEventListener(QUICK_LINK_POSITION_CHANGED_EVENT, syncPosition);
      window.removeEventListener('storage', syncPosition);
    };
  }, []);

  useEffect(() => {
    const syncLinks = (event?: Event) => {
      if (event instanceof CustomEvent && Array.isArray(event.detail)) {
        setLinks(event.detail);
        return;
      }
      setLinks(loadQuickLinks());
    };

    window.addEventListener(QUICK_LINKS_CHANGED_EVENT, syncLinks);
    window.addEventListener('storage', syncLinks);
    return () => {
      window.removeEventListener(QUICK_LINKS_CHANGED_EVENT, syncLinks);
      window.removeEventListener('storage', syncLinks);
    };
  }, []);

  if (!enabled || licensed !== true || links.length === 0) return null;

  return (
    <nav
      className={`quick-link-floating-menu floating-widget-responsive quick-link-position-${position}`}
      data-floating-side={layout.side}
      data-floating-block={layout.block}
      hidden={layout.hidden}
      aria-hidden={layout.hidden || undefined}
      aria-label="퀵 링크"
      style={layout.style}
    >
      {links.map(link => (
        link.type === 'folder' ? (
          <QuickLinkFloatingFolder key={link.id} link={link} position={position} />
        ) : (
          <button
            key={link.id}
            type="button"
            className="quick-link-floating-item"
            title={link.title}
            aria-label={link.title}
            onClick={event => {
              event.currentTarget.blur();
              window.open(link.url, '_blank', 'noopener,noreferrer');
            }}
          >
            <QuickLinkFloatingIcon link={link} />
          </button>
        )
      ))}
    </nav>
  );
}
