import { useState } from 'react';
import { Copy, CheckCircle } from 'lucide-react';
import '../App.css';

const API_BASE = 'http://localhost:8000/api';

export default function TeamJoinPage() {
  const [mode, setMode] = useState<'join' | 'create'>('join');
  const [inviteCode, setInviteCode] = useState('');
  const [memberId, setMemberId] = useState(() => localStorage.getItem('teamMemberId') || '');
  const [status, setStatus] = useState('');
  const [generatedCode, setGeneratedCode] = useState('');
  const [copied, setCopied] = useState(false);

  const handleJoin = () => {
    if (!inviteCode.trim() || !memberId.trim()) {
      setStatus('초대 코드와 식별자를 모두 입력해주세요.');
      return;
    }
    try {
      const decoded = atob(inviteCode.trim());
      const data = JSON.parse(decoded);
      if (data.url) {
        localStorage.setItem('teamLeaderUrl', data.url);
        localStorage.setItem('teamMemberId', memberId);
        setStatus(`성공적으로 연결되었습니다! (팀장 서버: ${data.url}) 메인 화면에서 동기화가 시작됩니다.`);
      } else {
        setStatus('유효하지 않은 초대 코드입니다.');
      }
    } catch(e) {
      setStatus('초대 코드 형식이 올바르지 않습니다.');
    }
  };

  const handleCreateTeam = async () => {
    try {
      const res = await fetch(`${API_BASE}/team/invite`);
      const data = await res.json();
      setGeneratedCode(data.invite_code);
    } catch(e) {
      setStatus('초대 코드 생성 실패. 서버를 확인해주세요.');
    }
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(generatedCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div style={{ padding: '40px', maxWidth: '600px', margin: '0 auto' }}>
      <div style={{ display: 'flex', gap: '10px', marginBottom: '20px' }}>
        <button 
          className={mode === 'join' ? 'btn-primary' : 'btn-secondary'} 
          style={{flex: 1, padding: '15px'}} 
          onClick={() => setMode('join')}
        >
          팀원 (팀 가입하기)
        </button>
        <button 
          className={mode === 'create' ? 'btn-primary' : 'btn-secondary'} 
          style={{flex: 1, padding: '15px'}} 
          onClick={() => { setMode('create'); handleCreateTeam(); }}
        >
          팀장 (팀 생성하기)
        </button>
      </div>

      <div style={{ background: 'var(--card-bg)', padding: '30px', borderRadius: '8px', border: '1px solid var(--border-color)' }}>
        {mode === 'join' ? (
          <>
            <h2 style={{marginTop:0}}>팀 가입 및 연동 설정</h2>
            <p style={{fontSize: 14, color: '#666', marginBottom: '20px'}}>
              팀장에게 받은 '초대 코드'를 입력하면 IP 주소나 포트 등 복잡한 설정 없이 한 번에 연동됩니다.
            </p>
            
            <div className="form-group">
              <label className="detail-label">초대 코드 붙여넣기</label>
              <textarea 
                className="edit-input" 
                rows={3}
                value={inviteCode} 
                onChange={e => setInviteCode(e.target.value)} 
                placeholder="eyA... 로 시작하는 코드를 입력하세요" 
                style={{resize: 'vertical'}}
              />
            </div>

            <div className="form-group" style={{marginTop: '15px'}}>
              <label className="detail-label">내 식별자 (이름)</label>
              <input 
                type="text" 
                className="edit-input" 
                value={memberId} 
                onChange={e => setMemberId(e.target.value)} 
                placeholder="예: 홍길동" 
              />
            </div>

            <button className="btn-primary" style={{marginTop: '20px', width: '100%', padding: '10px'}} onClick={handleJoin}>
              초대 코드로 팀 연동 활성화
            </button>
          </>
        ) : (
          <>
            <h2 style={{marginTop:0}}>팀 생성 및 초대</h2>
            <p style={{fontSize: 14, color: '#666', marginBottom: '20px'}}>
              아래의 초대 코드를 팀원들에게 공유하세요. 팀원들이 코드를 입력하면 내 PC의 데이터베이스로 데이터가 모입니다.
            </p>
            
            <div className="form-group">
              <label className="detail-label">생성된 초대 코드</label>
              <div style={{ display: 'flex', gap: '10px' }}>
                <textarea 
                  className="edit-input" 
                  rows={3}
                  value={generatedCode} 
                  readOnly 
                  style={{flex: 1, resize: 'none', background: 'var(--bg-color)'}}
                />
                <button className="btn-secondary" onClick={copyToClipboard} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minWidth: '80px' }}>
                  {copied ? <CheckCircle size={20} color="green" /> : <Copy size={20} />}
                  <span style={{fontSize: 12, marginTop: 5}}>{copied ? '복사됨' : '복사'}</span>
                </button>
              </div>
            </div>
            
            <p style={{fontSize: 13, color: '#999', marginTop: '15px'}}>
              * 팀장 PC는 고정 IP를 사용하거나, 팀원들과 같은 사내망(VPN 등)에 연결되어 있어야 정상적으로 통신이 가능합니다.
            </p>
          </>
        )}

        {status && <div style={{marginTop: '15px', padding: '10px', background: '#e3fcef', color: '#006644', borderRadius: '4px', fontSize: '14px', border: '1px solid #79f2c0'}}>{status}</div>}
      </div>
    </div>
  );
}
