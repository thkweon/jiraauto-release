import ctypes
import os
import platform
from datetime import date
from typing import Any, Dict, List, Optional
from urllib.parse import urlparse

try:
    import winreg
except ImportError:  # pragma: no cover - non-Windows fallback
    winreg = None


JIRA_SLOT_RANGE = range(1, 11)


def normalize_base_url(base_url: str) -> str:
    value = base_url.strip().rstrip("/")
    if not value:
        return ""
    if not value.startswith(("http://", "https://")):
        value = f"https://{value}"
    parsed = urlparse(value)
    host = (parsed.hostname or "").lower()
    if host.endswith(".atlassian.net") and parsed.path.rstrip("/").lower() == "/jira":
        value = f"{parsed.scheme}://{parsed.netloc}"
    return value


def normalize_token(token: Optional[str]) -> str:
    if token is None:
        return ""
    value = token.strip().strip('"').strip("'")
    if value.lower().startswith("bearer "):
        value = value[7:].strip()
    return value


def normalize_project_keys(value: str | List[str]) -> List[str]:
    if isinstance(value, str):
        parts = value.split(",")
    else:
        parts = value
    seen = set()
    result = []
    for part in parts:
        key = str(part).strip().upper()
        if key and key not in seen:
            seen.add(key)
            result.append(key)
    return result


def _registry_root(scope: str):
    if winreg is None:
        return None, None
    normalized = scope.lower()
    if normalized == "machine":
        return winreg.HKEY_LOCAL_MACHINE, r"SYSTEM\CurrentControlSet\Control\Session Manager\Environment"
    return winreg.HKEY_CURRENT_USER, "Environment"


def _set_persistent_env(name: str, value: Optional[str], scope: str = "user") -> None:
    os_name = platform.system().lower()
    if os_name != "windows" or winreg is None:
        if value is None:
            os.environ.pop(name, None)
        else:
            os.environ[name] = value
        return

    root, path = _registry_root(scope)
    access = winreg.KEY_SET_VALUE
    with winreg.OpenKey(root, path, 0, access) as key:
        if value is None:
            try:
                winreg.DeleteValue(key, name)
            except FileNotFoundError:
                pass
            os.environ.pop(name, None)
        else:
            winreg.SetValueEx(key, name, 0, winreg.REG_SZ, value)
            os.environ[name] = value

    try:
        HWND_BROADCAST = 0xFFFF
        WM_SETTINGCHANGE = 0x001A
        SMTO_ABORTIFHUNG = 0x0002
        ctypes.windll.user32.SendMessageTimeoutW(
            HWND_BROADCAST,
            WM_SETTINGCHANGE,
            0,
            "Environment",
            SMTO_ABORTIFHUNG,
            5000,
            None,
        )
    except Exception:
        pass


def _get_env(name: str) -> Optional[str]:
    value = os.environ.get(name)
    if value and value.strip():
        return value.strip()
    return None


def token_preview(token: Optional[str]) -> Optional[str]:
    if not token:
        return None
    suffix = token[-4:] if len(token) >= 4 else token
    return f"************{suffix}"


def normalize_deployment_type(value: Optional[str]) -> str:
    normalized = (value or "server").strip().lower()
    if normalized not in {"server", "cloud"}:
        raise ValueError("deployment_type must be server or cloud")
    return normalized


def normalize_auth_type(value: Optional[str], deployment_type: str) -> str:
    default = "basic_api_token" if deployment_type == "cloud" else "bearer_pat"
    normalized = (value or default).strip().lower()
    expected = "basic_api_token" if deployment_type == "cloud" else "bearer_pat"
    if normalized != expected:
        raise ValueError(f"{deployment_type} accounts require {expected} authentication")
    return normalized


def _bool_env(name: str, default: bool = True) -> bool:
    value = _get_env(name)
    if value is None:
        return default
    return value.upper() not in {"N", "NO", "FALSE", "0"}


def configured_slots(max_slot: Optional[int] = None) -> List[int]:
    slots = []
    slot_range = range(1, min(max_slot, 10) + 1) if max_slot is not None else JIRA_SLOT_RANGE
    for slot in slot_range:
        if _get_env(f"JIRA_BASE_URL_{slot}") and _get_env(f"JIRA_TOKEN_{slot}"):
            slots.append(slot)
    return slots


def legacy_found() -> bool:
    return bool(_get_env("JIRA_BASE_URL") and _get_env("JIRA_TOKEN"))


def setup_status(max_slot: Optional[int] = None) -> Dict[str, Any]:
    slots = configured_slots(max_slot)
    legacy = legacy_found()
    if slots:
        return {
            "setup_required": False,
            "reason": "jira_accounts_found",
            "accounts_found": len(slots),
            "legacy_found": legacy,
            "configured_slots": slots,
        }
    return {
        "setup_required": True,
        "reason": "legacy_account_found" if legacy else "no_jira_accounts",
        "accounts_found": 0,
        "legacy_found": legacy,
        "configured_slots": [],
    }


def account_info(slot: int) -> Dict[str, Any]:
    base_url = _get_env(f"JIRA_BASE_URL_{slot}")
    token = _get_env(f"JIRA_TOKEN_{slot}")
    deployment_type = normalize_deployment_type(_get_env(f"JIRA_DEPLOYMENT_TYPE_{slot}"))
    auth_type = normalize_auth_type(_get_env(f"JIRA_AUTH_TYPE_{slot}"), deployment_type)
    email = _get_env(f"JIRA_EMAIL_{slot}")
    return {
        "slot": slot,
        "base_url": base_url,
        "deployment_type": deployment_type,
        "auth_type": auth_type,
        "email": email,
        "token_expires_at": _get_env(f"JIRA_TOKEN_EXPIRES_AT_{slot}"),
        "verify_ssl": _bool_env(f"JIRA_VERIFY_SSL_{slot}"),
        "token_set": bool(token),
        "token_preview": token_preview(token),
        "configured": bool(base_url and token),
    }


def account_credentials(slot: int) -> Dict[str, Optional[str]]:
    if slot not in JIRA_SLOT_RANGE:
        raise ValueError("slot must be between 1 and 10")
    deployment_type = normalize_deployment_type(_get_env(f"JIRA_DEPLOYMENT_TYPE_{slot}"))
    return {
        "base_url": _get_env(f"JIRA_BASE_URL_{slot}"),
        "token": _get_env(f"JIRA_TOKEN_{slot}"),
        "deployment_type": deployment_type,
        "auth_type": normalize_auth_type(_get_env(f"JIRA_AUTH_TYPE_{slot}"), deployment_type),
        "email": _get_env(f"JIRA_EMAIL_{slot}"),
        "token_expires_at": _get_env(f"JIRA_TOKEN_EXPIRES_AT_{slot}"),
        "verify_ssl": _bool_env(f"JIRA_VERIFY_SSL_{slot}"),
    }


def list_accounts(max_slot: Optional[int] = None) -> Dict[str, Any]:
    slot_range = range(1, min(max_slot, 10) + 1) if max_slot is not None else JIRA_SLOT_RANGE
    return {"accounts": [account_info(slot) for slot in slot_range]}


def save_account(
    slot: int,
    base_url: str,
    token: Optional[str],
    scope: str = "user",
    deployment_type: Optional[str] = None,
    auth_type: Optional[str] = None,
    email: Optional[str] = None,
    token_expires_at: Optional[str] = None,
    verify_ssl: bool = True,
) -> Dict[str, Any]:
    if slot not in JIRA_SLOT_RANGE:
        raise ValueError("slot must be between 1 and 10")
    normalized_url = normalize_base_url(base_url)
    normalized_token = normalize_token(token) or _get_env(f"JIRA_TOKEN_{slot}") or ""
    normalized_deployment = normalize_deployment_type(deployment_type)
    normalized_auth = normalize_auth_type(auth_type, normalized_deployment)
    normalized_email = (email or _get_env(f"JIRA_EMAIL_{slot}") or "").strip()
    if not normalized_url or not normalized_token:
        raise ValueError("base_url and token are required")
    if normalized_deployment == "cloud" and not normalized_email:
        raise ValueError("email is required for Jira Cloud")
    if normalized_deployment == "cloud" and not token_expires_at:
        token_expires_at = _get_env(f"JIRA_TOKEN_EXPIRES_AT_{slot}")
    if normalized_deployment == "cloud" and not token_expires_at:
        raise ValueError("token_expires_at is required for Jira Cloud")
    if normalized_deployment == "cloud":
        try:
            expiration = date.fromisoformat(str(token_expires_at))
        except ValueError as exc:
            raise ValueError("token_expires_at must use YYYY-MM-DD format") from exc
        if expiration < date.today():
            raise ValueError("token_expires_at cannot be in the past")
    _set_persistent_env(f"JIRA_BASE_URL_{slot}", normalized_url, scope)
    _set_persistent_env(f"JIRA_TOKEN_{slot}", normalized_token, scope)
    _set_persistent_env(f"JIRA_DEPLOYMENT_TYPE_{slot}", normalized_deployment, scope)
    _set_persistent_env(f"JIRA_AUTH_TYPE_{slot}", normalized_auth, scope)
    _set_persistent_env(f"JIRA_EMAIL_{slot}", normalized_email if normalized_deployment == "cloud" else None, scope)
    _set_persistent_env(f"JIRA_TOKEN_EXPIRES_AT_{slot}", token_expires_at if normalized_deployment == "cloud" else None, scope)
    _set_persistent_env(f"JIRA_VERIFY_SSL_{slot}", "Y" if verify_ssl else "N", scope)
    return account_info(slot)


def delete_account(slot: int, scope: str = "user") -> Dict[str, Any]:
    if slot not in JIRA_SLOT_RANGE:
        raise ValueError("slot must be between 1 and 10")
    _set_persistent_env(f"JIRA_BASE_URL_{slot}", None, scope)
    _set_persistent_env(f"JIRA_TOKEN_{slot}", None, scope)
    for suffix in ("DEPLOYMENT_TYPE", "AUTH_TYPE", "EMAIL", "TOKEN_EXPIRES_AT", "VERIFY_SSL"):
        _set_persistent_env(f"JIRA_{suffix}_{slot}", None, scope)
    return account_info(slot)


def get_time_tracking() -> Dict[str, Any]:
    enabled = (_get_env("JIRA_AUTO_TIME_TRACKING") or "N").upper() == "Y"
    time_tracking_enabled = (_get_env("JIRA_AUTO_TIMETRACKING_ENABLED") or ("Y" if enabled else "N")).upper() == "Y"
    worklog_enabled = (_get_env("JIRA_AUTO_WORKLOG_ENABLED") or ("Y" if enabled else "N")).upper() == "Y"
    projects = normalize_project_keys(_get_env("JIRA_TRACKING_PROJECTS") or "")
    allow_unassigned_processing = (_get_env("JIRA_ALLOW_UNASSIGNED_PROCESSING") or "N").upper() == "Y"
    allow_all_project_worklog = (_get_env("JIRA_ALLOW_ALL_PROJECT_WORKLOG") or "N").upper() == "Y"
    original_estimate_enabled = (_get_env("JIRA_ORIGINAL_ESTIMATE_ENABLED") or "N").upper() == "Y"
    original_estimate_auto = (_get_env("JIRA_ORIGINAL_ESTIMATE_AUTO") or "N").upper() == "Y"
    original_estimate_value = _get_env("JIRA_ORIGINAL_ESTIMATE_VALUE") or ""
    worklog_comment = _get_env("JIRA_AUTO_WORKLOG_COMMENT") or "Automatically logged by Jira Manager"
    return {
        "enabled": time_tracking_enabled or worklog_enabled,
        "time_tracking_enabled": time_tracking_enabled,
        "worklog_enabled": worklog_enabled,
        "tracking_projects": projects,
        "allow_unassigned_processing": allow_unassigned_processing,
        "allow_all_project_worklog": allow_all_project_worklog,
        "original_estimate_enabled": original_estimate_enabled,
        "original_estimate_auto": original_estimate_auto,
        "original_estimate_value": original_estimate_value,
        "worklog_comment": worklog_comment,
    }


def save_time_tracking(
    enabled: bool,
    tracking_projects: List[str],
    allow_unassigned_processing: bool = False,
    allow_all_project_worklog: bool = False,
    scope: str = "user",
    original_estimate_enabled: bool = False,
    original_estimate_auto: bool = False,
    original_estimate_value: str = "",
    worklog_comment: str = "Automatically logged by Jira Manager",
    time_tracking_enabled: Optional[bool] = None,
    worklog_enabled: Optional[bool] = None,
) -> Dict[str, Any]:
    projects = normalize_project_keys(tracking_projects)
    normalized_worklog_comment = worklog_comment.strip() or "Automatically logged by Jira Manager"
    normalized_time_tracking_enabled = enabled if time_tracking_enabled is None else time_tracking_enabled
    normalized_worklog_enabled = enabled if worklog_enabled is None else worklog_enabled
    any_auto_enabled = normalized_time_tracking_enabled or normalized_worklog_enabled
    _set_persistent_env("JIRA_AUTO_TIME_TRACKING", "Y" if any_auto_enabled else "N", scope)
    _set_persistent_env("JIRA_AUTO_TIMETRACKING_ENABLED", "Y" if normalized_time_tracking_enabled else "N", scope)
    _set_persistent_env("JIRA_AUTO_WORKLOG_ENABLED", "Y" if normalized_worklog_enabled else "N", scope)
    _set_persistent_env("JIRA_TRACKING_PROJECTS", ",".join(projects), scope)
    _set_persistent_env("JIRA_ALLOW_UNASSIGNED_PROCESSING", "Y" if allow_unassigned_processing else "N", scope)
    _set_persistent_env("JIRA_ALLOW_ALL_PROJECT_WORKLOG", "Y" if allow_all_project_worklog else "N", scope)
    _set_persistent_env("JIRA_ORIGINAL_ESTIMATE_ENABLED", "Y" if original_estimate_enabled else "N", scope)
    _set_persistent_env("JIRA_ORIGINAL_ESTIMATE_AUTO", "Y" if original_estimate_auto else "N", scope)
    _set_persistent_env("JIRA_ORIGINAL_ESTIMATE_VALUE", original_estimate_value.strip(), scope)
    _set_persistent_env("JIRA_AUTO_WORKLOG_COMMENT", normalized_worklog_comment, scope)
    return get_time_tracking()


def migrate_legacy(scope: str = "user") -> Dict[str, Any]:
    legacy_url = _get_env("JIRA_BASE_URL")
    legacy_token = _get_env("JIRA_TOKEN")
    if not legacy_url or not legacy_token:
        return {"migrated": False, "reason": "legacy_not_found"}
    for slot in JIRA_SLOT_RANGE:
        if not _get_env(f"JIRA_BASE_URL_{slot}") and not _get_env(f"JIRA_TOKEN_{slot}"):
            save_account(slot, legacy_url, legacy_token, scope)
            _set_persistent_env("JIRA_BASE_URL", None, scope)
            _set_persistent_env("JIRA_TOKEN", None, scope)
            return {"migrated": True, "slot": slot}
    return {"migrated": False, "reason": "no_empty_slot"}
