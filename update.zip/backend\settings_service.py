import ctypes
import os
import platform
from typing import Any, Dict, List, Optional

try:
    import winreg
except ImportError:  # pragma: no cover - non-Windows fallback
    winreg = None


JIRA_SLOT_RANGE = range(1, 11)


def normalize_base_url(base_url: str) -> str:
    value = base_url.strip().rstrip("/")
    if not value.startswith(("http://", "https://")):
        value = f"https://{value}"
    return value


def normalize_token(token: str) -> str:
    value = token.strip().strip('"').strip("'")
    if value.lower().startswith("bearer "):
        value = value[7:].strip()
    return value


def normalize_project_keys(value: str | List[str]) -> List[str]:
    if isinstance(value, str):
        parts = value.split(",")
    else:
        parts = value
    seen = set()
    result = []
    for part in parts:
        key = str(part).strip().upper()
        if key and key not in seen:
            seen.add(key)
            result.append(key)
    return result


def _registry_root(scope: str):
    if winreg is None:
        return None, None
    normalized = scope.lower()
    if normalized == "machine":
        return winreg.HKEY_LOCAL_MACHINE, r"SYSTEM\CurrentControlSet\Control\Session Manager\Environment"
    return winreg.HKEY_CURRENT_USER, "Environment"


def _set_persistent_env(name: str, value: Optional[str], scope: str = "user") -> None:
    os_name = platform.system().lower()
    if os_name != "windows" or winreg is None:
        if value is None:
            os.environ.pop(name, None)
        else:
            os.environ[name] = value
        return

    root, path = _registry_root(scope)
    access = winreg.KEY_SET_VALUE
    with winreg.OpenKey(root, path, 0, access) as key:
        if value is None:
            try:
                winreg.DeleteValue(key, name)
            except FileNotFoundError:
                pass
            os.environ.pop(name, None)
        else:
            winreg.SetValueEx(key, name, 0, winreg.REG_SZ, value)
            os.environ[name] = value

    try:
        HWND_BROADCAST = 0xFFFF
        WM_SETTINGCHANGE = 0x001A
        SMTO_ABORTIFHUNG = 0x0002
        ctypes.windll.user32.SendMessageTimeoutW(
            HWND_BROADCAST,
            WM_SETTINGCHANGE,
            0,
            "Environment",
            SMTO_ABORTIFHUNG,
            5000,
            None,
        )
    except Exception:
        pass


def _get_env(name: str) -> Optional[str]:
    value = os.environ.get(name)
    if value and value.strip():
        return value.strip()
    return None


def token_preview(token: Optional[str]) -> Optional[str]:
    if not token:
        return None
    suffix = token[-4:] if len(token) >= 4 else token
    return f"************{suffix}"


def configured_slots(max_slot: Optional[int] = None) -> List[int]:
    slots = []
    slot_range = range(1, min(max_slot, 10) + 1) if max_slot is not None else JIRA_SLOT_RANGE
    for slot in slot_range:
        if _get_env(f"JIRA_BASE_URL_{slot}") and _get_env(f"JIRA_TOKEN_{slot}"):
            slots.append(slot)
    return slots


def legacy_found() -> bool:
    return bool(_get_env("JIRA_BASE_URL") and _get_env("JIRA_TOKEN"))


def setup_status(max_slot: Optional[int] = None) -> Dict[str, Any]:
    slots = configured_slots(max_slot)
    legacy = legacy_found()
    if slots:
        return {
            "setup_required": False,
            "reason": "jira_accounts_found",
            "accounts_found": len(slots),
            "legacy_found": legacy,
            "configured_slots": slots,
        }
    return {
        "setup_required": True,
        "reason": "legacy_account_found" if legacy else "no_jira_accounts",
        "accounts_found": 0,
        "legacy_found": legacy,
        "configured_slots": [],
    }


def account_info(slot: int) -> Dict[str, Any]:
    base_url = _get_env(f"JIRA_BASE_URL_{slot}")
    token = _get_env(f"JIRA_TOKEN_{slot}")
    return {
        "slot": slot,
        "base_url": base_url,
        "token": token,
        "token_set": bool(token),
        "token_preview": token_preview(token),
        "configured": bool(base_url and token),
    }


def list_accounts(max_slot: Optional[int] = None) -> Dict[str, Any]:
    slot_range = range(1, min(max_slot, 10) + 1) if max_slot is not None else JIRA_SLOT_RANGE
    return {"accounts": [account_info(slot) for slot in slot_range]}


def save_account(slot: int, base_url: str, token: str, scope: str = "user") -> Dict[str, Any]:
    if slot not in JIRA_SLOT_RANGE:
        raise ValueError("slot must be between 1 and 10")
    normalized_url = normalize_base_url(base_url)
    normalized_token = normalize_token(token)
    if not normalized_url or not normalized_token:
        raise ValueError("base_url and token are required")
    _set_persistent_env(f"JIRA_BASE_URL_{slot}", normalized_url, scope)
    _set_persistent_env(f"JIRA_TOKEN_{slot}", normalized_token, scope)
    return account_info(slot)


def delete_account(slot: int, scope: str = "user") -> Dict[str, Any]:
    if slot not in JIRA_SLOT_RANGE:
        raise ValueError("slot must be between 1 and 10")
    _set_persistent_env(f"JIRA_BASE_URL_{slot}", None, scope)
    _set_persistent_env(f"JIRA_TOKEN_{slot}", None, scope)
    return account_info(slot)


def get_time_tracking() -> Dict[str, Any]:
    enabled = (_get_env("JIRA_AUTO_TIME_TRACKING") or "N").upper() == "Y"
    time_tracking_enabled = (_get_env("JIRA_AUTO_TIMETRACKING_ENABLED") or ("Y" if enabled else "N")).upper() == "Y"
    worklog_enabled = (_get_env("JIRA_AUTO_WORKLOG_ENABLED") or ("Y" if enabled else "N")).upper() == "Y"
    projects = normalize_project_keys(_get_env("JIRA_TRACKING_PROJECTS") or "")
    allow_unassigned_processing = (_get_env("JIRA_ALLOW_UNASSIGNED_PROCESSING") or "N").upper() == "Y"
    original_estimate_enabled = (_get_env("JIRA_ORIGINAL_ESTIMATE_ENABLED") or "N").upper() == "Y"
    original_estimate_auto = (_get_env("JIRA_ORIGINAL_ESTIMATE_AUTO") or "N").upper() == "Y"
    original_estimate_value = _get_env("JIRA_ORIGINAL_ESTIMATE_VALUE") or ""
    worklog_comment = _get_env("JIRA_AUTO_WORKLOG_COMMENT") or "Automatically logged by Jira Manager"
    return {
        "enabled": time_tracking_enabled or worklog_enabled,
        "time_tracking_enabled": time_tracking_enabled,
        "worklog_enabled": worklog_enabled,
        "tracking_projects": projects,
        "allow_unassigned_processing": allow_unassigned_processing,
        "original_estimate_enabled": original_estimate_enabled,
        "original_estimate_auto": original_estimate_auto,
        "original_estimate_value": original_estimate_value,
        "worklog_comment": worklog_comment,
    }


def save_time_tracking(
    enabled: bool,
    tracking_projects: List[str],
    allow_unassigned_processing: bool = False,
    scope: str = "user",
    original_estimate_enabled: bool = False,
    original_estimate_auto: bool = False,
    original_estimate_value: str = "",
    worklog_comment: str = "Automatically logged by Jira Manager",
    time_tracking_enabled: Optional[bool] = None,
    worklog_enabled: Optional[bool] = None,
) -> Dict[str, Any]:
    projects = normalize_project_keys(tracking_projects)
    normalized_worklog_comment = worklog_comment.strip() or "Automatically logged by Jira Manager"
    normalized_time_tracking_enabled = enabled if time_tracking_enabled is None else time_tracking_enabled
    normalized_worklog_enabled = enabled if worklog_enabled is None else worklog_enabled
    any_auto_enabled = normalized_time_tracking_enabled or normalized_worklog_enabled
    _set_persistent_env("JIRA_AUTO_TIME_TRACKING", "Y" if any_auto_enabled else "N", scope)
    _set_persistent_env("JIRA_AUTO_TIMETRACKING_ENABLED", "Y" if normalized_time_tracking_enabled else "N", scope)
    _set_persistent_env("JIRA_AUTO_WORKLOG_ENABLED", "Y" if normalized_worklog_enabled else "N", scope)
    _set_persistent_env("JIRA_TRACKING_PROJECTS", ",".join(projects), scope)
    _set_persistent_env("JIRA_ALLOW_UNASSIGNED_PROCESSING", "Y" if allow_unassigned_processing else "N", scope)
    _set_persistent_env("JIRA_ORIGINAL_ESTIMATE_ENABLED", "Y" if original_estimate_enabled else "N", scope)
    _set_persistent_env("JIRA_ORIGINAL_ESTIMATE_AUTO", "Y" if original_estimate_auto else "N", scope)
    _set_persistent_env("JIRA_ORIGINAL_ESTIMATE_VALUE", original_estimate_value.strip(), scope)
    _set_persistent_env("JIRA_AUTO_WORKLOG_COMMENT", normalized_worklog_comment, scope)
    return get_time_tracking()


def migrate_legacy(scope: str = "user") -> Dict[str, Any]:
    legacy_url = _get_env("JIRA_BASE_URL")
    legacy_token = _get_env("JIRA_TOKEN")
    if not legacy_url or not legacy_token:
        return {"migrated": False, "reason": "legacy_not_found"}
    for slot in JIRA_SLOT_RANGE:
        if not _get_env(f"JIRA_BASE_URL_{slot}") and not _get_env(f"JIRA_TOKEN_{slot}"):
            save_account(slot, legacy_url, legacy_token, scope)
            _set_persistent_env("JIRA_BASE_URL", None, scope)
            _set_persistent_env("JIRA_TOKEN", None, scope)
            return {"migrated": True, "slot": slot}
    return {"migrated": False, "reason": "no_empty_slot"}
