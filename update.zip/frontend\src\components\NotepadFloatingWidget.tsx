import { useEffect, useState } from 'react';
import type { CSSProperties } from 'react';
import { Download, NotebookPen } from 'lucide-react';
import useFloatingFollowOffset from '../hooks/useFloatingFollowOffset';
import {
  isNotepadDoublePlacement,
  loadNotepadContent,
  loadNotepadWidgetSettings,
  NOTEPAD_WIDGET_SETTINGS_CHANGED_EVENT,
  saveNotepadContent,
} from '../utils/notepadWidget';
import type { NotepadWidgetSettings } from '../utils/notepadWidget';

export default function NotepadFloatingWidget() {
  const [settings, setSettings] = useState<NotepadWidgetSettings>(loadNotepadWidgetSettings);
  const [content, setContent] = useState(loadNotepadContent);
  const followOffset = useFloatingFollowOffset();

  useEffect(() => {
    const syncSettings = () => setSettings(loadNotepadWidgetSettings());
    window.addEventListener(NOTEPAD_WIDGET_SETTINGS_CHANGED_EVENT, syncSettings);
    window.addEventListener('storage', syncSettings);
    return () => {
      window.removeEventListener(NOTEPAD_WIDGET_SETTINGS_CHANGED_EVENT, syncSettings);
      window.removeEventListener('storage', syncSettings);
    };
  }, []);

  if (!settings.enabled) return null;

  const downloadText = () => {
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    const date = new Date().toISOString().slice(0, 10);
    anchor.href = url;
    anchor.download = `jiraauto-note-${date}.txt`;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    URL.revokeObjectURL(url);
  };

  return (
    <section
      className={`notepad-floating-widget notepad-placement-${settings.placement}${isNotepadDoublePlacement(settings.placement) ? ' double' : ' single'}`}
      aria-label="메모장"
      style={{ '--widget-follow-offset': `${followOffset}px` } as CSSProperties}
    >
      <header className="notepad-widget-header">
        <strong><NotebookPen size={17} /> 메모장</strong>
        <button type="button" onClick={downloadText} title="TXT로 다운로드" aria-label="메모를 TXT로 다운로드">
          <Download size={16} />
        </button>
      </header>
      <textarea
        value={content}
        onChange={event => {
          setContent(event.target.value);
          saveNotepadContent(event.target.value);
        }}
        placeholder="메모를 입력하세요. 내용은 이 브라우저에 자동 저장됩니다."
        aria-label="메모 내용"
      />
      <span className="notepad-widget-save-status">자동 저장 · {content.length.toLocaleString('ko-KR')}자</span>
    </section>
  );
}
