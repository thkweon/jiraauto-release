import { useEffect, useState } from 'react';
import type { CSSProperties } from 'react';
import { Braces, Check, Copy, Download, Eye, EyeOff, NotebookPen } from 'lucide-react';
import useFloatingFollowOffset from '../hooks/useFloatingFollowOffset';
import MarkdownPreview from './MarkdownPreview';
import {
  isNotepadDoublePlacement,
  loadNotepadContent,
  loadNotepadWidgetSettings,
  NOTEPAD_WIDGET_SETTINGS_CHANGED_EVENT,
  saveNotepadContent,
} from '../utils/notepadWidget';
import type { NotepadWidgetSettings } from '../utils/notepadWidget';

export default function NotepadFloatingWidget() {
  const [settings, setSettings] = useState<NotepadWidgetSettings>(loadNotepadWidgetSettings);
  const [content, setContent] = useState(loadNotepadContent);
  const [markdownPreviewEnabled, setMarkdownPreviewEnabled] = useState(false);
  const [statusMessage, setStatusMessage] = useState('');
  const followOffset = useFloatingFollowOffset();

  useEffect(() => {
    const syncSettings = () => setSettings(loadNotepadWidgetSettings());
    window.addEventListener(NOTEPAD_WIDGET_SETTINGS_CHANGED_EVENT, syncSettings);
    window.addEventListener('storage', syncSettings);
    return () => {
      window.removeEventListener(NOTEPAD_WIDGET_SETTINGS_CHANGED_EVENT, syncSettings);
      window.removeEventListener('storage', syncSettings);
    };
  }, []);

  useEffect(() => {
    if (!statusMessage) return;
    const timer = window.setTimeout(() => setStatusMessage(''), 2200);
    return () => window.clearTimeout(timer);
  }, [statusMessage]);

  if (!settings.enabled) return null;

  const downloadText = () => {
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    const date = new Date().toISOString().slice(0, 10);
    anchor.href = url;
    anchor.download = `jiraauto-note-${date}.txt`;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    URL.revokeObjectURL(url);
  };

  const copyContent = async () => {
    try {
      if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(content);
      } else {
        const copyTarget = document.createElement('textarea');
        copyTarget.value = content;
        copyTarget.style.position = 'fixed';
        copyTarget.style.opacity = '0';
        document.body.appendChild(copyTarget);
        copyTarget.select();
        let copied = false;
        try {
          copied = document.execCommand('copy');
        } finally {
          copyTarget.remove();
        }
        if (!copied) throw new Error('Clipboard copy failed');
      }
      setStatusMessage('클립보드에 복사했습니다.');
    } catch {
      setStatusMessage('클립보드에 복사하지 못했습니다.');
    }
  };

  const prettifyJson = () => {
    try {
      const prettyContent = JSON.stringify(JSON.parse(content), null, 2);
      setContent(prettyContent);
      saveNotepadContent(prettyContent);
      setStatusMessage('JSON을 정리했습니다.');
    } catch {
      setStatusMessage('올바른 JSON 형식인지 확인해 주세요.');
    }
  };

  return (
    <section
      className={`notepad-floating-widget notepad-placement-${settings.placement}${isNotepadDoublePlacement(settings.placement) ? ' double' : ' single'}`}
      aria-label="메모장"
      style={{ '--widget-follow-offset': `${followOffset}px` } as CSSProperties}
    >
      <header className="notepad-widget-header">
        <strong><NotebookPen size={17} /> 메모장</strong>
        <div className="notepad-widget-header-actions">
          <button type="button" onClick={prettifyJson} title="JSON Pretty" aria-label="JSON 들여쓰기 정리">
            <Braces size={16} />
          </button>
          <button
            type="button"
            className={markdownPreviewEnabled ? 'active' : undefined}
            onClick={() => setMarkdownPreviewEnabled(value => !value)}
            title={markdownPreviewEnabled ? 'Markdown 편집' : 'Markdown 미리보기'}
            aria-label={markdownPreviewEnabled ? 'Markdown 편집 화면으로 전환' : 'Markdown 미리보기로 전환'}
            aria-pressed={markdownPreviewEnabled}
          >
            {markdownPreviewEnabled ? <EyeOff size={16} /> : <Eye size={16} />}
          </button>
          <button type="button" onClick={() => void copyContent()} title="클립보드에 복사" aria-label="메모를 클립보드에 복사">
            {statusMessage === '클립보드에 복사했습니다.' ? <Check size={16} /> : <Copy size={16} />}
          </button>
          <button type="button" onClick={downloadText} title="TXT로 다운로드" aria-label="메모를 TXT로 다운로드">
            <Download size={16} />
          </button>
        </div>
      </header>
      {markdownPreviewEnabled ? (
        <MarkdownPreview content={content} />
      ) : (
        <textarea
          value={content}
          onChange={event => {
            setContent(event.target.value);
            saveNotepadContent(event.target.value);
          }}
          placeholder="메모를 입력하세요. 내용은 이 브라우저에 자동 저장됩니다."
          aria-label="메모 내용"
        />
      )}
      <span className={`notepad-widget-save-status${statusMessage ? ' has-message' : ''}`}>
        {statusMessage || `자동 저장 · ${content.length.toLocaleString('ko-KR')}자`}
      </span>
    </section>
  );
}
