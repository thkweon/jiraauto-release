import { useEffect, useState } from 'react';
import type { CSSProperties } from 'react';
import { Braces, Check, Copy, Download, Eye, EyeOff, NotebookPen, Trash2 } from 'lucide-react';
import useFloatingFollowOffset from '../hooks/useFloatingFollowOffset';
import MarkdownPreview from './MarkdownPreview';
import {
  createNotepadPage,
  isNotepadDoublePlacement,
  loadNotepadPagesState,
  loadNotepadWidgetSettings,
  NOTEPAD_PAGES_STORAGE_KEY,
  NOTEPAD_WIDGET_SETTINGS_CHANGED_EVENT,
  saveNotepadPagesState,
} from '../utils/notepadWidget';
import type { NotepadPagesState, NotepadWidgetSettings } from '../utils/notepadWidget';

export default function NotepadFloatingWidget() {
  const [settings, setSettings] = useState<NotepadWidgetSettings>(loadNotepadWidgetSettings);
  const [pagesState, setPagesState] = useState<NotepadPagesState>(loadNotepadPagesState);
  const [markdownPreviewEnabled, setMarkdownPreviewEnabled] = useState(false);
  const [statusMessage, setStatusMessage] = useState('');
  const followOffset = useFloatingFollowOffset();

  useEffect(() => {
    const syncSettings = () => setSettings(loadNotepadWidgetSettings());
    const syncStorage = (event: StorageEvent) => {
      syncSettings();
      if (event.key === NOTEPAD_PAGES_STORAGE_KEY) setPagesState(loadNotepadPagesState());
    };
    window.addEventListener(NOTEPAD_WIDGET_SETTINGS_CHANGED_EVENT, syncSettings);
    window.addEventListener('storage', syncStorage);
    return () => {
      window.removeEventListener(NOTEPAD_WIDGET_SETTINGS_CHANGED_EVENT, syncSettings);
      window.removeEventListener('storage', syncStorage);
    };
  }, []);

  useEffect(() => {
    if (!statusMessage) return;
    const timer = window.setTimeout(() => setStatusMessage(''), 2200);
    return () => window.clearTimeout(timer);
  }, [statusMessage]);

  if (!settings.enabled) return null;

  const activePageIndex = Math.max(
    0,
    pagesState.pages.findIndex(page => page.id === pagesState.activePageId),
  );
  const activePage = pagesState.pages[activePageIndex];
  const content = activePage?.content || '';
  const visiblePageStart = Math.max(
    0,
    Math.min(activePageIndex - 1, pagesState.pages.length - 3),
  );
  const visiblePages = pagesState.pages.slice(visiblePageStart, visiblePageStart + 3);

  const updatePagesState = (state: NotepadPagesState) => {
    setPagesState(state);
    saveNotepadPagesState(state);
  };

  const updateContent = (nextContent: string) => {
    const pages = pagesState.pages.map(page => (
      page.id === pagesState.activePageId ? { ...page, content: nextContent } : page
    ));
    updatePagesState({ ...pagesState, pages });
  };

  const selectPage = (index: number) => {
    const page = pagesState.pages[index];
    if (!page || page.id === pagesState.activePageId) return;
    updatePagesState({ ...pagesState, activePageId: page.id });
  };

  const addPageAfterCurrent = () => {
    const page = createNotepadPage();
    const pages = [...pagesState.pages];
    pages.splice(activePageIndex + 1, 0, page);
    updatePagesState({ pages, activePageId: page.id });
    setMarkdownPreviewEnabled(false);
    setStatusMessage(`${activePageIndex + 2}페이지를 추가했습니다.`);
  };

  const addPageAtEnd = () => {
    const page = createNotepadPage();
    updatePagesState({ pages: [...pagesState.pages, page], activePageId: page.id });
    setMarkdownPreviewEnabled(false);
    setStatusMessage(`${pagesState.pages.length + 1}페이지를 추가했습니다.`);
  };

  const deleteCurrentPage = () => {
    if (!confirm(`${activePageIndex + 1}페이지를 삭제할까요?`)) return;
    if (pagesState.pages.length === 1) {
      const page = createNotepadPage();
      updatePagesState({ pages: [page], activePageId: page.id });
      setMarkdownPreviewEnabled(false);
      setStatusMessage('빈 1페이지로 초기화했습니다.');
      return;
    }
    const pages = pagesState.pages.filter(page => page.id !== pagesState.activePageId);
    const nextPage = pages[Math.min(activePageIndex, pages.length - 1)];
    updatePagesState({ pages, activePageId: nextPage.id });
    setStatusMessage('현재 페이지를 삭제했습니다.');
  };

  const deleteAllPages = () => {
    if (!confirm(`메모장 ${pagesState.pages.length}페이지의 내용을 모두 삭제할까요?`)) return;
    const page = createNotepadPage();
    updatePagesState({ pages: [page], activePageId: page.id });
    setMarkdownPreviewEnabled(false);
    setStatusMessage('모든 페이지를 삭제하고 1페이지로 초기화했습니다.');
  };

  const downloadText = () => {
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    const date = new Date().toISOString().slice(0, 10);
    anchor.href = url;
    anchor.download = `jiraauto-note-${activePageIndex + 1}-${date}.txt`;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    URL.revokeObjectURL(url);
  };

  const copyContent = async () => {
    try {
      if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(content);
      } else {
        const copyTarget = document.createElement('textarea');
        copyTarget.value = content;
        copyTarget.style.position = 'fixed';
        copyTarget.style.opacity = '0';
        document.body.appendChild(copyTarget);
        copyTarget.select();
        let copied = false;
        try {
          copied = document.execCommand('copy');
        } finally {
          copyTarget.remove();
        }
        if (!copied) throw new Error('Clipboard copy failed');
      }
      setStatusMessage('클립보드에 복사했습니다.');
    } catch {
      setStatusMessage('클립보드에 복사하지 못했습니다.');
    }
  };

  const prettifyJson = () => {
    try {
      const prettyContent = JSON.stringify(JSON.parse(content), null, 2);
      updateContent(prettyContent);
      setStatusMessage('JSON을 정리했습니다.');
    } catch {
      setStatusMessage('올바른 JSON 형식인지 확인해 주세요.');
    }
  };

  return (
    <section
      className={`notepad-floating-widget notepad-placement-${settings.placement}${isNotepadDoublePlacement(settings.placement) ? ' double' : ' single'}`}
      aria-label="메모장"
      style={{ '--widget-follow-offset': `${followOffset}px` } as CSSProperties}
    >
      <header className="notepad-widget-header">
        <strong>
          <NotebookPen size={17} /> 메모장
          <small>{activePageIndex + 1}/{pagesState.pages.length}</small>
        </strong>
        <div className="notepad-widget-header-actions">
          <button type="button" onClick={prettifyJson} title="JSON Pretty" aria-label="JSON 들여쓰기 정리">
            <Braces size={16} />
          </button>
          <button type="button" onClick={deleteAllPages} title="모든 페이지 삭제" aria-label="메모장 모든 페이지 삭제">
            <Trash2 size={16} />
          </button>
          <button
            type="button"
            className={markdownPreviewEnabled ? 'active' : undefined}
            onClick={() => setMarkdownPreviewEnabled(value => !value)}
            title={markdownPreviewEnabled ? 'Markdown 편집' : 'Markdown 미리보기'}
            aria-label={markdownPreviewEnabled ? 'Markdown 편집 화면으로 전환' : 'Markdown 미리보기로 전환'}
            aria-pressed={markdownPreviewEnabled}
          >
            {markdownPreviewEnabled ? <EyeOff size={16} /> : <Eye size={16} />}
          </button>
          <button type="button" onClick={() => void copyContent()} title="클립보드에 복사" aria-label="메모를 클립보드에 복사">
            {statusMessage === '클립보드에 복사했습니다.' ? <Check size={16} /> : <Copy size={16} />}
          </button>
          <button type="button" onClick={downloadText} title="TXT로 다운로드" aria-label="메모를 TXT로 다운로드">
            <Download size={16} />
          </button>
        </div>
      </header>
      {markdownPreviewEnabled ? (
        <MarkdownPreview content={content} />
      ) : (
        <textarea
          value={content}
          onChange={event => {
            updateContent(event.target.value);
          }}
          placeholder="메모를 입력하세요. 내용은 이 브라우저에 자동 저장됩니다."
          aria-label="메모 내용"
        />
      )}
      <span className={`notepad-widget-save-status${statusMessage ? ' has-message' : ''}`}>
        {statusMessage || `자동 저장 · ${content.length.toLocaleString('ko-KR')}자`}
      </span>
      <nav className="notepad-page-navigation" aria-label="메모장 페이지 이동">
        <button type="button" onClick={deleteCurrentPage} title="현재 페이지 삭제" aria-label="현재 메모장 페이지 삭제">−</button>
        <button type="button" onClick={() => selectPage(0)} disabled={activePageIndex === 0}>처음</button>
        <button type="button" onClick={() => selectPage(activePageIndex - 1)} disabled={activePageIndex === 0}>이전</button>
        {visiblePages.map((page, visibleIndex) => {
          const pageIndex = visiblePageStart + visibleIndex;
          return (
            <button
              type="button"
              key={page.id}
              className={pageIndex === activePageIndex ? 'active' : undefined}
              onClick={() => selectPage(pageIndex)}
              aria-current={pageIndex === activePageIndex ? 'page' : undefined}
            >
              {pageIndex + 1}
            </button>
          );
        })}
        <button
          type="button"
          onClick={() => selectPage(activePageIndex + 1)}
          disabled={activePageIndex === pagesState.pages.length - 1}
        >
          다음
        </button>
        <button
          type="button"
          onClick={() => selectPage(pagesState.pages.length - 1)}
          disabled={activePageIndex === pagesState.pages.length - 1}
        >
          끝
        </button>
        <button type="button" onClick={addPageAfterCurrent} title="현재 페이지 바로 뒤에 추가">+</button>
        <button type="button" onClick={addPageAtEnd} title="맨 끝에 페이지 추가">*</button>
      </nav>
    </section>
  );
}
