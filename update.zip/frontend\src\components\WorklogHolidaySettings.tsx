import { CalendarPlus, Check, ChevronDown, ChevronRight, Pencil, Plus, Trash2, X } from 'lucide-react';
import { useCallback, useEffect, useState } from 'react';
import {
  WORKLOG_HOLIDAYS_CHANGED_EVENT,
  type WorklogHoliday,
} from '../utils/worklogSummaryWidget';

const API_BASE = 'http://localhost:8000/api';
const YEAR_OPTIONS = Array.from({ length: 201 }, (_, index) => 1900 + index);

interface Props {
  available: boolean;
  onMessage: (message: string) => void;
}

const errorMessage = async (response: Response, fallback: string) => {
  const data = await response.json().catch(() => ({}));
  return data.detail?.message || data.detail || fallback;
};

const notifyHolidayChange = () => window.dispatchEvent(new Event(WORKLOG_HOLIDAYS_CHANGED_EVENT));

export default function WorklogHolidaySettings({ available, onMessage }: Props) {
  const [collapsed, setCollapsed] = useState(false);
  const [year, setYear] = useState(new Date().getFullYear());
  const [holidays, setHolidays] = useState<WorklogHoliday[]>([]);
  const [loading, setLoading] = useState(false);
  const [busy, setBusy] = useState(false);
  const [holidayDate, setHolidayDate] = useState('');
  const [holidayName, setHolidayName] = useState('');
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editingDate, setEditingDate] = useState('');
  const [editingName, setEditingName] = useState('');

  const load = useCallback(async () => {
    if (!available) return;
    setLoading(true);
    try {
      const response = await fetch(`${API_BASE}/settings/worklog-holidays?year=${year}`);
      if (!response.ok) throw new Error(await errorMessage(response, '휴무일을 불러오지 못했습니다.'));
      const data = await response.json();
      setHolidays(Array.isArray(data.holidays) ? data.holidays : []);
    } catch (reason) {
      onMessage(reason instanceof Error ? reason.message : '휴무일을 불러오지 못했습니다.');
    } finally {
      setLoading(false);
    }
  }, [available, onMessage, year]);

  useEffect(() => {
    void load();
  }, [load]);

  const importKoreanHolidays = async () => {
    setBusy(true);
    try {
      const response = await fetch(`${API_BASE}/settings/worklog-holidays/korean/import`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ year }),
      });
      if (!response.ok) throw new Error(await errorMessage(response, '한국 공휴일을 추가하지 못했습니다.'));
      const data = await response.json();
      setHolidays(data.holidays || []);
      notifyHolidayChange();
      const changes = [
        `${data.imported}개 추가`,
        data.updated ? `${data.updated}개 갱신` : '',
        data.removed ? `${data.removed}개 정리` : '',
      ].filter(Boolean).join(', ');
      onMessage(`한국 공휴일을 동기화했습니다. (${changes})`);
    } catch (reason) {
      onMessage(reason instanceof Error ? reason.message : '한국 공휴일을 추가하지 못했습니다.');
    } finally {
      setBusy(false);
    }
  };

  const addCompanyHoliday = async () => {
    if (!holidayDate || !holidayName.trim()) {
      onMessage('회사 휴무일의 날짜와 명칭을 입력해 주세요.');
      return;
    }
    setBusy(true);
    try {
      const response = await fetch(`${API_BASE}/settings/worklog-holidays`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ holiday_date: holidayDate, name: holidayName.trim() }),
      });
      if (!response.ok) throw new Error(await errorMessage(response, '회사 휴무일을 추가하지 못했습니다.'));
      setHolidayDate('');
      setHolidayName('');
      if (Number(holidayDate.slice(0, 4)) !== year) setYear(Number(holidayDate.slice(0, 4)));
      else await load();
      notifyHolidayChange();
      onMessage('회사 휴무일을 추가했습니다.');
    } catch (reason) {
      onMessage(reason instanceof Error ? reason.message : '회사 휴무일을 추가하지 못했습니다.');
    } finally {
      setBusy(false);
    }
  };

  const beginEdit = (holiday: WorklogHoliday) => {
    setEditingId(holiday.id);
    setEditingDate(holiday.holiday_date);
    setEditingName(holiday.name);
  };

  const saveEdit = async () => {
    if (editingId === null || !editingDate || !editingName.trim()) {
      onMessage('휴무일의 날짜와 명칭을 입력해 주세요.');
      return;
    }
    setBusy(true);
    try {
      const response = await fetch(`${API_BASE}/settings/worklog-holidays/${editingId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ holiday_date: editingDate, name: editingName.trim() }),
      });
      if (!response.ok) throw new Error(await errorMessage(response, '휴무일을 수정하지 못했습니다.'));
      setEditingId(null);
      if (Number(editingDate.slice(0, 4)) !== year) setYear(Number(editingDate.slice(0, 4)));
      else await load();
      notifyHolidayChange();
      onMessage('휴무일을 수정했습니다.');
    } catch (reason) {
      onMessage(reason instanceof Error ? reason.message : '휴무일을 수정하지 못했습니다.');
    } finally {
      setBusy(false);
    }
  };

  const removeHoliday = async (holiday: WorklogHoliday) => {
    if (!window.confirm(`${holiday.holiday_date} ${holiday.name}을(를) 삭제할까요?`)) return;
    setBusy(true);
    try {
      const response = await fetch(`${API_BASE}/settings/worklog-holidays/${holiday.id}`, { method: 'DELETE' });
      if (!response.ok) throw new Error(await errorMessage(response, '휴무일을 삭제하지 못했습니다.'));
      setHolidays(current => current.filter(item => item.id !== holiday.id));
      if (editingId === holiday.id) setEditingId(null);
      notifyHolidayChange();
      onMessage('휴무일을 삭제했습니다.');
    } catch (reason) {
      onMessage(reason instanceof Error ? reason.message : '휴무일을 삭제하지 못했습니다.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <section className="worklog-holiday-settings">
      <header className="worklog-holiday-settings-header">
        <div>
          <strong>휴무일 관리</strong>
          <small>휴무일을 제외하여 목표 근무시간과 달성률을 계산합니다.</small>
        </div>
        <button
          className="btn-secondary widget-settings-collapse-button"
          type="button"
          onClick={() => setCollapsed(value => !value)}
          aria-expanded={!collapsed}
        >
          {collapsed ? <ChevronRight size={15} /> : <ChevronDown size={15} />}
          {collapsed ? '펼치기' : '접기'}
        </button>
      </header>

      {!collapsed && (
        <div className="worklog-holiday-settings-body">
          <div className="worklog-holiday-toolbar">
            <label>
              <span>조회 연도</span>
              <select
                className="glass-input"
                value={year}
                onChange={event => setYear(Number(event.target.value))}
              >
                {YEAR_OPTIONS.map(option => <option value={option} key={option}>{option}년</option>)}
              </select>
            </label>
            <button className="btn-secondary" type="button" disabled={!available || busy} onClick={() => void importKoreanHolidays()}>
              <CalendarPlus size={15} /> {year}년 한국 공휴일 추가
            </button>
          </div>
          <small className="worklog-holiday-help">향후 연도도 조회 연도를 변경한 뒤 버튼을 누르면 해당 연도의 공휴일이 일괄 등록됩니다.</small>

          <div className="worklog-holiday-add-form">
            <input
              className="glass-input"
              type="date"
              value={holidayDate}
              onChange={event => setHolidayDate(event.target.value)}
              aria-label="회사 휴무일 날짜"
            />
            <input
              className="glass-input"
              type="text"
              maxLength={100}
              placeholder="회사 휴무일 명칭"
              value={holidayName}
              onChange={event => setHolidayName(event.target.value)}
              onKeyDown={event => {
                if (event.key === 'Enter') void addCompanyHoliday();
              }}
            />
            <button className="btn-secondary" type="button" disabled={!available || busy} onClick={() => void addCompanyHoliday()}>
              <Plus size={15} /> 추가
            </button>
          </div>

          <div className="worklog-holiday-list" aria-busy={loading}>
            {loading && <div className="worklog-holiday-empty">휴무일을 불러오는 중입니다.</div>}
            {!loading && holidays.length === 0 && <div className="worklog-holiday-empty">{year}년에 등록된 휴무일이 없습니다.</div>}
            {!loading && holidays.map(holiday => (
              <div className="worklog-holiday-row" key={holiday.id}>
                {editingId === holiday.id ? (
                  <>
                    <input className="glass-input" type="date" value={editingDate} onChange={event => setEditingDate(event.target.value)} />
                    <input className="glass-input" type="text" maxLength={100} value={editingName} onChange={event => setEditingName(event.target.value)} />
                    <span className={`worklog-holiday-type ${holiday.holiday_type}`}>
                      {holiday.holiday_type === 'national' ? '한국 공휴일' : '회사 휴무일'}
                    </span>
                    <div className="worklog-holiday-actions">
                      <button type="button" title="저장" disabled={busy} onClick={() => void saveEdit()}><Check size={14} /></button>
                      <button type="button" title="취소" disabled={busy} onClick={() => setEditingId(null)}><X size={14} /></button>
                    </div>
                  </>
                ) : (
                  <>
                    <time>{holiday.holiday_date}</time>
                    <span className="worklog-holiday-name">{holiday.name}</span>
                    <span className={`worklog-holiday-type ${holiday.holiday_type}`}>
                      {holiday.holiday_type === 'national' ? '한국 공휴일' : '회사 휴무일'}
                    </span>
                    <div className="worklog-holiday-actions">
                      <button type="button" title="수정" disabled={busy} onClick={() => beginEdit(holiday)}><Pencil size={14} /></button>
                      <button type="button" title="삭제" disabled={busy} onClick={() => void removeHoliday(holiday)}><Trash2 size={14} /></button>
                    </div>
                  </>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </section>
  );
}
