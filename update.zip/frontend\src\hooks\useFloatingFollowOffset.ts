import { useEffect } from 'react';

const MAX_FOLLOW_OFFSET = 42;
const SCROLL_DAMPING = 0.34;
const SETTLE_DAMPING = 0.16;
const SCROLL_IDLE_MS = 90;

export default function useFloatingFollowOffset() {
  useEffect(() => {
    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (reduceMotion) return;

    let animationId = 0;
    let idleTimer = 0;
    let lastScrollY = window.scrollY;
    let currentOffset = 0;
    let targetOffset = 0;

    const animate = () => {
      const damping = targetOffset === 0 ? SETTLE_DAMPING : SCROLL_DAMPING;
      currentOffset += (targetOffset - currentOffset) * damping;
      if (Math.abs(currentOffset) < 0.15 && targetOffset === 0) currentOffset = 0;
      document.documentElement.style.setProperty('--widget-follow-offset', `${currentOffset}px`);
      document.documentElement.style.setProperty('--quick-link-follow-offset', `${currentOffset}px`);
      if (currentOffset === 0 && targetOffset === 0) {
        animationId = 0;
        return;
      }
      animationId = window.requestAnimationFrame(animate);
    };

    const handleScroll = () => {
      const nextScrollY = window.scrollY;
      const delta = nextScrollY - lastScrollY;
      lastScrollY = nextScrollY;
      targetOffset = Math.max(-MAX_FOLLOW_OFFSET, Math.min(MAX_FOLLOW_OFFSET, -delta * 1.25));

      if (idleTimer) window.clearTimeout(idleTimer);
      idleTimer = window.setTimeout(() => {
        targetOffset = 0;
        if (!animationId) animationId = window.requestAnimationFrame(animate);
      }, SCROLL_IDLE_MS);

      if (!animationId) animationId = window.requestAnimationFrame(animate);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => {
      window.cancelAnimationFrame(animationId);
      if (idleTimer) window.clearTimeout(idleTimer);
      window.removeEventListener('scroll', handleScroll);
      document.documentElement.style.removeProperty('--widget-follow-offset');
      document.documentElement.style.removeProperty('--quick-link-follow-offset');
    };
  }, []);
}
