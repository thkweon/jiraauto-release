import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { CheckCircle, KeyRound, Loader2, ShieldCheck } from 'lucide-react';
import '../App.css';

const API_BASE = 'http://localhost:8000/api';

interface LicenseStatus {
  licensed: boolean;
  status: string;
  plan?: string;
  expires_at?: string;
  device_name?: string;
  license_key_suffix?: string;
  message?: string;
}

export default function ActivationPage() {
  const navigate = useNavigate();
  const [licenseKey, setLicenseKey] = useState('');
  const [deviceName, setDeviceName] = useState(() => localStorage.getItem('licenseDeviceName') || '');
  const [status, setStatus] = useState<LicenseStatus | null>(null);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  const loadStatus = async () => {
    setLoading(true);
    try {
      const res = await fetch(`${API_BASE}/license/status`);
      const data = await res.json();
      setStatus(data);
      if (data.licensed) navigate('/');
    } catch {
      setError('License service is unavailable.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadStatus();
  }, []);

  const activate = async () => {
    if (!licenseKey.trim()) {
      setError('Enter a license key.');
      return;
    }

    setSubmitting(true);
    setError('');
    try {
      const res = await fetch(`${API_BASE}/license/activate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          license_key: licenseKey,
          device_name: deviceName || undefined,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data?.detail?.message || data?.message || 'Activation failed.');
        setStatus(data?.detail || null);
        return;
      }
      if (deviceName) localStorage.setItem('licenseDeviceName', deviceName);
      setStatus(data);
      navigate('/');
    } catch {
      setError('Activation server is unavailable.');
    } finally {
      setSubmitting(false);
    }
  };

  const deactivate = async () => {
    setSubmitting(true);
    setError('');
    try {
      const res = await fetch(`${API_BASE}/license/deactivate`, { method: 'POST' });
      setStatus(await res.json());
      setLicenseKey('');
    } catch {
      setError('Failed to deactivate license.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div style={{ minHeight: 'calc(100vh - 90px)', display: 'grid', placeItems: 'center', padding: 24 }}>
      <div className="glass-panel" style={{ width: '100%', maxWidth: 520, padding: 32 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 24 }}>
          <ShieldCheck size={30} color="var(--accent-color)" />
          <div>
            <h1 style={{ margin: 0, fontSize: 24 }}>JiraAuto Activation</h1>
            <p style={{ margin: '6px 0 0', color: 'var(--text-secondary)', fontSize: 14 }}>
              Activate this device before using JiraAuto.
            </p>
          </div>
        </div>

        {loading ? (
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, color: 'var(--text-secondary)' }}>
            <Loader2 size={18} className="spin-icon" />
            Checking license status...
          </div>
        ) : (
          <>
            {status?.licensed && (
              <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 18, color: '#078f55' }}>
                <CheckCircle size={18} />
                Active {status.plan ? `(${status.plan})` : ''}
              </div>
            )}

            <label className="detail-label">License key</label>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginTop: 8 }}>
              <KeyRound size={18} color="var(--text-secondary)" />
              <input
                className="glass-input"
                value={licenseKey}
                onChange={e => setLicenseKey(e.target.value)}
                placeholder="JIRAUTO-DEV-2026"
                style={{ flex: 1 }}
              />
            </div>

            <label className="detail-label" style={{ display: 'block', marginTop: 18 }}>Device name</label>
            <input
              className="glass-input"
              value={deviceName}
              onChange={e => setDeviceName(e.target.value)}
              placeholder="Office laptop"
              style={{ width: '100%', marginTop: 8 }}
            />

            {status && (
              <div style={{ marginTop: 18, padding: 12, borderRadius: 8, background: 'rgba(0,0,0,0.04)', fontSize: 13, color: 'var(--text-secondary)' }}>
                <div>Status: {status.status}</div>
                {status.expires_at && <div>Expires: {new Date(status.expires_at).toLocaleString()}</div>}
                {status.license_key_suffix && <div>Key suffix: {status.license_key_suffix}</div>}
              </div>
            )}

            {error && (
              <div style={{ marginTop: 18, padding: 12, borderRadius: 8, background: '#ffe8e8', color: '#b00020', fontSize: 13 }}>
                {error}
              </div>
            )}

            <div style={{ display: 'flex', justifyContent: 'space-between', gap: 10, marginTop: 24 }}>
              <button className="btn-secondary" onClick={deactivate} disabled={submitting}>
                Deactivate
              </button>
              <button className="btn-premium" onClick={activate} disabled={submitting}>
                {submitting ? 'Processing...' : 'Activate'}
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
