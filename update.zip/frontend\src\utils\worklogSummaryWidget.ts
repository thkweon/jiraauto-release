export type WorklogSummaryWidgetPosition =
  | 'left-top'
  | 'left-middle'
  | 'left-bottom'
  | 'right-top'
  | 'right-middle'
  | 'right-bottom';

export type WorklogSummaryPeriod = 'day' | 'week' | 'month';

export interface WorklogSummaryWidgetSettings {
  enabled: boolean;
  position: WorklogSummaryWidgetPosition;
  periods: WorklogSummaryPeriod[];
  accountScope: 'all' | 'instance';
  instanceId: number | null;
  cacheMinutes: Record<WorklogSummaryPeriod, number>;
}

export interface WorklogSummaryPeriodResult {
  period: WorklogSummaryPeriod;
  start_date: string;
  end_date: string;
  total_seconds: number;
  worklog_count: number;
  issue_count: number;
  collected_at: string;
  next_refresh_at: string;
  from_cache: boolean;
}

export interface WorklogSummaryResponse {
  as_of_date: string;
  scope: 'all' | 'instance';
  instances: Array<{ id: number; name: string; base_url: string }>;
  periods: WorklogSummaryPeriodResult[];
}

export const WORKLOG_SUMMARY_WIDGET_SETTINGS_STORAGE_KEY = 'jiraautoWorklogSummaryWidgetSettings';
export const WORKLOG_SUMMARY_WIDGET_SETTINGS_CHANGED_EVENT = 'worklogSummaryWidgetSettingsChanged';

const POSITIONS: WorklogSummaryWidgetPosition[] = [
  'left-top',
  'left-middle',
  'left-bottom',
  'right-top',
  'right-middle',
  'right-bottom',
];
const PERIODS: WorklogSummaryPeriod[] = ['day', 'week', 'month'];

const DEFAULT_SETTINGS: WorklogSummaryWidgetSettings = {
  enabled: false,
  position: 'left-top',
  periods: ['day'],
  accountScope: 'all',
  instanceId: null,
  cacheMinutes: {
    day: 30,
    week: 120,
    month: 120,
  },
};

const normalizeCacheMinutes = (value: unknown, fallback: number) => {
  const parsed = Number(value);
  if (!Number.isFinite(parsed)) return fallback;
  return Math.min(10080, Math.max(1, Math.round(parsed)));
};

export const loadWorklogSummaryWidgetSettings = (): WorklogSummaryWidgetSettings => {
  try {
    const raw = localStorage.getItem(WORKLOG_SUMMARY_WIDGET_SETTINGS_STORAGE_KEY);
    if (!raw) return DEFAULT_SETTINGS;
    const value = JSON.parse(raw) as Partial<WorklogSummaryWidgetSettings>;
    const periods = Array.isArray(value.periods)
      ? value.periods.filter((period): period is WorklogSummaryPeriod => PERIODS.includes(period as WorklogSummaryPeriod))
      : DEFAULT_SETTINGS.periods;
    return {
      enabled: typeof value.enabled === 'boolean' ? value.enabled : DEFAULT_SETTINGS.enabled,
      position: POSITIONS.includes(value.position as WorklogSummaryWidgetPosition)
        ? value.position as WorklogSummaryWidgetPosition
        : DEFAULT_SETTINGS.position,
      periods: periods.length > 0 ? periods : DEFAULT_SETTINGS.periods,
      accountScope: value.accountScope === 'instance' ? 'instance' : 'all',
      instanceId: typeof value.instanceId === 'number' ? value.instanceId : null,
      cacheMinutes: {
        day: normalizeCacheMinutes(value.cacheMinutes?.day, DEFAULT_SETTINGS.cacheMinutes.day),
        week: normalizeCacheMinutes(value.cacheMinutes?.week, DEFAULT_SETTINGS.cacheMinutes.week),
        month: normalizeCacheMinutes(value.cacheMinutes?.month, DEFAULT_SETTINGS.cacheMinutes.month),
      },
    };
  } catch {
    return DEFAULT_SETTINGS;
  }
};

export const saveWorklogSummaryWidgetSettings = (settings: WorklogSummaryWidgetSettings) => {
  localStorage.setItem(WORKLOG_SUMMARY_WIDGET_SETTINGS_STORAGE_KEY, JSON.stringify(settings));
  window.dispatchEvent(new CustomEvent<WorklogSummaryWidgetSettings>(
    WORKLOG_SUMMARY_WIDGET_SETTINGS_CHANGED_EVENT,
    { detail: settings },
  ));
};
