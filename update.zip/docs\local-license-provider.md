# Local JiraAuto License Provider

The local JiraAuto backend exposes the same frontend-facing endpoints in both modes:

```txt
GET  /api/license/status
POST /api/license/activate
POST /api/license/refresh
POST /api/license/deactivate
```

The implementation is selected with `LICENSE_PROVIDER`.

## Local Development Mode

Default mode:

```env
LICENSE_PROVIDER=local
LICENSE_GATE_ENABLED=Y
```

Accepted development keys:

```txt
JIRAUTO-DEV-2026
JIRAUTO-TRIAL-LOCAL
```

You can override them:

```env
LICENSE_DEV_KEYS=JIRAUTO-DEV-2026,JIRAUTO-TRIAL-LOCAL
```

## Server Mode

Use this when the central Docker license server is available:

```env
LICENSE_PROVIDER=server
LICENSE_SERVER_URL=https://your-license-server.example
LICENSE_SERVER_TIMEOUT=10
LICENSE_SERVER_VERIFY_TLS=Y
JIRAAUTO_APP_VERSION=1.0.0
JIRAAUTO_APP_CHANNEL=stable
```

The local backend maps requests as follows:

```txt
POST /api/license/activate   -> POST {LICENSE_SERVER_URL}/v1/licenses/activate
POST /api/license/refresh    -> POST {LICENSE_SERVER_URL}/v1/licenses/refresh
POST /api/license/deactivate -> POST {LICENSE_SERVER_URL}/v1/licenses/deactivate
```

The local backend sends:

```json
{
  "license_key": "user-entered-key",
  "machine_id_hash": "sha256-hex",
  "device_name": "device name",
  "app_version": "1.0.0",
  "app_channel": "stable"
}
```

The local backend stores the successful server response in SQLite. It does not store the raw license key after activation.

## Gate Controls

Disable the gate only for emergency local troubleshooting:

```env
LICENSE_GATE_ENABLED=N
```

Production builds should keep:

```env
LICENSE_GATE_ENABLED=Y
LICENSE_PROVIDER=server
```

## TLS Verification

TLS verification is enabled by default:

```env
LICENSE_SERVER_VERIFY_TLS=Y
```

If the customer environment uses SSL inspection or a private CA, prefer providing the CA bundle:

```env
LICENSE_SERVER_CA_BUNDLE=C:\path\to\company-ca.pem
```

For controlled enterprise networks where the license endpoint is already protected by a trusted reverse proxy policy, TLS verification can be disabled:

```env
LICENSE_SERVER_VERIFY_TLS=N
```

Disabling TLS verification should be treated as an operational compatibility setting, not the default security posture.
