import { useEffect, useState } from 'react';
import {
  D_DAY_WIDGET_SETTINGS_CHANGED_EVENT,
  getDDayDifference,
  loadDDayWidgetSettings,
  sortDDayItems,
} from '../utils/dDayWidget';
import type { DDayWidgetSettings } from '../utils/dDayWidget';
import { useFloatingWidgetLayout } from '../hooks/useFloatingWidgetLayout';

const parseLocalDate = (value: string) => {
  const [year, month, day] = value.split('-').map(Number);
  return new Date(year, month - 1, day);
};

const getDDayLabel = (targetDate: string) => {
  const difference = getDDayDifference(targetDate);
  if (difference === 0) return 'D-DAY';
  return difference > 0 ? `D-${difference}` : `D+${Math.abs(difference)}`;
};

const getUrgencyClass = (targetDate: string) => {
  const difference = getDDayDifference(targetDate);
  if (difference < 0) return 'expired';
  const days = Math.abs(difference);
  if (days <= 7) return 'within-week';
  if (days <= 14) return 'within-two-weeks';
  if (days <= 30) return 'within-month';
  return 'over-month';
};

const isImminent = (targetDate: string) => {
  const difference = getDDayDifference(targetDate);
  return difference > 0 && difference <= 3;
};

const formatTargetDate = (targetDate: string) => parseLocalDate(targetDate).toLocaleDateString('ko-KR', {
  year: 'numeric',
  month: 'long',
  day: 'numeric',
});

export default function DDayFloatingWidget() {
  const [settings, setSettings] = useState<DDayWidgetSettings>(loadDDayWidgetSettings);
  const [, setCurrentDay] = useState(() => new Date().toDateString());
  const { ref: layoutRef, ...layout } = useFloatingWidgetLayout(
    'd-day',
    settings.position,
    settings.enabled && settings.items.length > 0,
  );

  useEffect(() => {
    const timer = window.setInterval(() => setCurrentDay(new Date().toDateString()), 60000);
    return () => window.clearInterval(timer);
  }, []);

  useEffect(() => {
    const syncSettings = () => setSettings(loadDDayWidgetSettings());
    window.addEventListener(D_DAY_WIDGET_SETTINGS_CHANGED_EVENT, syncSettings);
    window.addEventListener('storage', syncSettings);
    return () => {
      window.removeEventListener(D_DAY_WIDGET_SETTINGS_CHANGED_EVENT, syncSettings);
      window.removeEventListener('storage', syncSettings);
    };
  }, []);

  if (!settings.enabled || settings.items.length === 0) return null;
  const visibleItems = settings.sortMode === 'auto' ? sortDDayItems(settings.items) : settings.items;

  return (
    <section
      ref={layoutRef}
      className={`d-day-floating-widget floating-widget-responsive d-day-widget-position-${settings.position}`}
      data-floating-side={layout.side}
      data-floating-block={layout.block}
      data-floating-stacked={layout.stacked || undefined}
      hidden={layout.hidden}
      aria-hidden={layout.hidden || undefined}
      aria-label={`D-DAY ${settings.items.length}개`}
      style={layout.style}
    >
      <div className="d-day-widget-items">
        {visibleItems.map(item => (
          <div className={`d-day-widget-item ${getUrgencyClass(item.targetDate)}`} key={item.id}>
            <span className="d-day-widget-title">{item.title.trim() || 'D-DAY'}</span>
            <div className="d-day-widget-count">
              <strong>{getDDayLabel(item.targetDate)}</strong>
              {isImminent(item.targetDate) && <small>(임박)</small>}
            </div>
            <time dateTime={item.targetDate}>{formatTargetDate(item.targetDate)}</time>
          </div>
        ))}
      </div>
    </section>
  );
}
