import {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import type { ReactNode } from 'react';
import useFloatingFollowOffset from '../hooks/useFloatingFollowOffset';
import {
  calculateFloatingWidgetStackTops,
  FLOATING_WIDGET_LAYOUT_METRICS,
} from '../utils/floatingWidgetLayout';
import type {
  FloatingWidgetHiddenReason,
  FloatingWidgetKind,
} from '../utils/floatingWidgetLayout';
import {
  FloatingWidgetLayoutContext,
} from './floatingWidgetLayoutContextValue';
import {
  CALENDAR_WIDGET_SETTINGS_CHANGED_EVENT,
  loadCalendarWidgetSettings,
} from '../utils/calendarWidget';
import {
  CLOCK_WIDGET_SETTINGS_CHANGED_EVENT,
  loadClockWidgetSettings,
} from '../utils/clockWidget';
import {
  D_DAY_WIDGET_SETTINGS_CHANGED_EVENT,
  loadDDayWidgetSettings,
} from '../utils/dDayWidget';
import {
  getITCalculatorOccupiedPositions,
  IT_CALCULATOR_WIDGET_SETTINGS_CHANGED_EVENT,
  loadITCalculatorWidgetSettings,
} from '../utils/itCalculatorWidget';
import {
  getNotepadOccupiedPositions,
  loadNotepadWidgetSettings,
  NOTEPAD_WIDGET_SETTINGS_CHANGED_EVENT,
} from '../utils/notepadWidget';
import type {
  FloatingWidgetLayoutContextValue,
  FloatingWidgetGeometry,
  RuntimeHiddenWidget,
} from './floatingWidgetLayoutContextValue';

const WIDGET_LABELS: Record<FloatingWidgetKind, string> = {
  calendar: '달력',
  clock: '시계',
  'd-day': 'D-DAY',
  'it-calculator': 'IT 계산기',
  notepad: '메모장',
  'quick-link': '퀵 링크',
};

const currentViewport = () => ({
  width: typeof window === 'undefined' ? 1920 : window.innerWidth,
  height: typeof window === 'undefined' ? 1080 : window.innerHeight,
});

export function FloatingWidgetLayoutProvider({ children }: { children: ReactNode }) {
  useFloatingFollowOffset();
  const [viewport, setViewport] = useState(currentViewport);
  const [hiddenWidgets, setHiddenWidgets] = useState<Partial<Record<FloatingWidgetKind, RuntimeHiddenWidget>>>({});
  const [widgetGeometries, setWidgetGeometries] = useState<Partial<Record<FloatingWidgetKind, FloatingWidgetGeometry>>>({});
  const [toastVisible, setToastVisible] = useState(false);
  const [occupancyRevision, setOccupancyRevision] = useState(0);
  const notifiedRef = useRef(false);

  useEffect(() => {
    let timer = 0;
    const updateViewport = () => {
      window.clearTimeout(timer);
      timer = window.setTimeout(() => {
        setViewport(currentViewport());
      }, FLOATING_WIDGET_LAYOUT_METRICS.resizeDebounceMs);
    };
    window.addEventListener('resize', updateViewport);
    window.visualViewport?.addEventListener('resize', updateViewport);
    return () => {
      window.clearTimeout(timer);
      window.removeEventListener('resize', updateViewport);
      window.visualViewport?.removeEventListener('resize', updateViewport);
    };
  }, []);

  useEffect(() => {
    let timer = 0;
    const syncOccupancy = () => {
      window.clearTimeout(timer);
      timer = window.setTimeout(() => setOccupancyRevision(value => value + 1), 0);
    };
    const events = [
      CALENDAR_WIDGET_SETTINGS_CHANGED_EVENT,
      CLOCK_WIDGET_SETTINGS_CHANGED_EVENT,
      D_DAY_WIDGET_SETTINGS_CHANGED_EVENT,
      IT_CALCULATOR_WIDGET_SETTINGS_CHANGED_EVENT,
      NOTEPAD_WIDGET_SETTINGS_CHANGED_EVENT,
      'storage',
    ];
    events.forEach(eventName => window.addEventListener(eventName, syncOccupancy));
    return () => {
      window.clearTimeout(timer);
      events.forEach(eventName => window.removeEventListener(eventName, syncOccupancy));
    };
  }, []);

  const constrainToSlots = useMemo<Partial<Record<FloatingWidgetKind, boolean>>>(() => {
    void occupancyRevision;
    const calendar = loadCalendarWidgetSettings();
    const clock = loadClockWidgetSettings();
    const dDay = loadDDayWidgetSettings();
    const calculator = loadITCalculatorWidgetSettings();
    const notepad = loadNotepadWidgetSettings();
    const activeWidgets: Array<{ kind: FloatingWidgetKind; positions: string[] }> = [
      ...(calendar.enabled ? [{ kind: 'calendar' as const, positions: [calendar.position] }] : []),
      ...(clock.enabled ? [{ kind: 'clock' as const, positions: [clock.position] }] : []),
      ...(dDay.enabled && dDay.items.length > 0
        ? [{ kind: 'd-day' as const, positions: [dDay.position] }]
        : []),
      ...(calculator.enabled
        ? [{ kind: 'it-calculator' as const, positions: getITCalculatorOccupiedPositions(calculator.placement) }]
        : []),
      ...(notepad.enabled
        ? [{ kind: 'notepad' as const, positions: getNotepadOccupiedPositions(notepad.placement) }]
        : []),
    ];
    return Object.fromEntries(activeWidgets.map(widget => {
      const side = widget.positions[0]?.split('-')[0];
      const sharesSide = activeWidgets.some(other => (
        other.kind !== widget.kind && other.positions.some(position => position.startsWith(`${side}-`))
      ));
      return [widget.kind, sharesSide];
    }));
  }, [occupancyRevision]);

  const reportHidden = useCallback((
    kind: FloatingWidgetKind,
    hidden: boolean,
    reason?: FloatingWidgetHiddenReason,
  ) => {
    setHiddenWidgets(current => {
      const alreadyHidden = Boolean(current[kind]);
      if (hidden === alreadyHidden && (!hidden || current[kind]?.reason === reason)) return current;
      const next = { ...current };
      if (hidden && reason) next[kind] = { reason };
      else delete next[kind];
      return next;
    });
    if (hidden && !notifiedRef.current) {
      notifiedRef.current = true;
      setToastVisible(true);
    }
  }, []);

  const reportGeometry = useCallback((
    kind: FloatingWidgetKind,
    geometry?: FloatingWidgetGeometry,
  ) => {
    setWidgetGeometries(current => {
      const previous = current[kind];
      if (!geometry) {
        if (!previous) return current;
        const next = { ...current };
        delete next[kind];
        return next;
      }
      if (
        previous
        && previous.side === geometry.side
        && previous.block === geometry.block
        && Math.abs(previous.height - geometry.height) < 0.5
      ) return current;
      return { ...current, [kind]: geometry };
    });
  }, []);

  const stackTopByKind = useMemo<Partial<Record<FloatingWidgetKind, number>>>(() => {
    const widgets = Object.entries(widgetGeometries).flatMap(([kind, geometry]) => (
      geometry ? [{ kind: kind as FloatingWidgetKind, ...geometry }] : []
    ));
    return calculateFloatingWidgetStackTops(viewport.height, widgets);
  }, [viewport.height, widgetGeometries]);

  useEffect(() => {
    if (!toastVisible) return;
    const timer = window.setTimeout(() => setToastVisible(false), 6000);
    return () => window.clearTimeout(timer);
  }, [toastVisible]);

  const value = useMemo<FloatingWidgetLayoutContextValue>(() => ({
    viewportWidth: viewport.width,
    viewportHeight: viewport.height,
    hiddenWidgets,
    constrainToSlots,
    stackTopByKind,
    reportHidden,
    reportGeometry,
  }), [constrainToSlots, hiddenWidgets, reportGeometry, reportHidden, stackTopByKind, viewport.height, viewport.width]);

  const hiddenLabels = Object.keys(hiddenWidgets)
    .map(kind => WIDGET_LABELS[kind as FloatingWidgetKind]);

  return (
    <FloatingWidgetLayoutContext.Provider value={value}>
      {children}
      {toastVisible && hiddenLabels.length > 0 && (
        <button
          type="button"
          className="floating-widget-layout-toast"
          onClick={() => setToastVisible(false)}
        >
          화면 공간이 부족하여 {hiddenLabels.join(', ')} 위젯을 일시적으로 숨겼습니다. 화면을 넓히면 자동으로 복원됩니다.
        </button>
      )}
    </FloatingWidgetLayoutContext.Provider>
  );
}
