# JiraAuto License Server API Contract

This document defines the contract between the local JiraAuto backend and the central license server.

## Goals

- Activate a license key for one machine.
- Enforce plan, expiration, revocation, and device limits.
- Return a signed license token that the local app can verify while offline.
- Support refresh and deactivation without changing JiraAuto frontend routes.

## Base URL

Production:

```txt
https://license.jiraauto.example/v1
```

Local development:

```txt
http://localhost:9000/v1
```

## Authentication

Customer-facing license endpoints do not require a bearer token. They are authenticated by license key plus machine fingerprint.

Admin endpoints require an admin bearer token:

```txt
Authorization: Bearer <admin_api_token>
```

## Common Fields

### Machine ID

The local backend sends a hashed machine identifier.

```json
{
  "machine_id_hash": "sha256-hex"
}
```

The raw fingerprint must never be sent to the server.

### License Status

Allowed values:

```txt
active
not_activated
invalid_key
expired
revoked
device_limit_exceeded
machine_mismatch
offline_grace
server_error
```

### Plan

Initial allowed values:

```txt
trial
personal
team
enterprise
development
```

### Feature Flags

```json
{
  "personal_dashboard": true,
  "bulk_transition": true,
  "team_sync": true,
  "team_board": true,
  "analytics": true,
  "multi_jira_instance": true
}
```

## Customer Endpoints

## POST /licenses/activate

Activates a license key for the current machine.

Request:

```json
{
  "license_key": "JIRAUTO-2026-ABCD-EFGH-IJKL-MNOP",
  "machine_id_hash": "2f5c...e91",
  "device_name": "Office laptop",
  "app_version": "1.0.0",
  "app_channel": "stable"
}
```

Success response, `200 OK`:

```json
{
  "status": "active",
  "licensed": true,
  "license_id": "lic_01HX0000000000000000000000",
  "activation_id": "act_01HX0000000000000000000000",
  "plan": "team",
  "features": {
    "personal_dashboard": true,
    "bulk_transition": true,
    "team_sync": true,
    "team_board": true,
    "analytics": true,
    "multi_jira_instance": true
  },
  "max_devices": 3,
  "expires_at": "2027-05-27T00:00:00Z",
  "refresh_after": "2026-05-28T00:00:00Z",
  "offline_grace_until": "2026-06-10T00:00:00Z",
  "license_token": "signed-token",
  "server_time": "2026-05-27T00:00:00Z"
}
```

Failure response, `400 Bad Request`:

```json
{
  "status": "invalid_key",
  "licensed": false,
  "message": "License key is invalid."
}
```

Failure response, `409 Conflict`:

```json
{
  "status": "device_limit_exceeded",
  "licensed": false,
  "message": "Device limit has been reached.",
  "max_devices": 3,
  "active_devices": 3
}
```

## POST /licenses/refresh

Refreshes a previous activation and returns a new signed token.

Request:

```json
{
  "license_id": "lic_01HX0000000000000000000000",
  "activation_id": "act_01HX0000000000000000000000",
  "machine_id_hash": "2f5c...e91",
  "app_version": "1.0.0",
  "license_token": "previous-signed-token"
}
```

Success response, `200 OK`:

```json
{
  "status": "active",
  "licensed": true,
  "license_id": "lic_01HX0000000000000000000000",
  "activation_id": "act_01HX0000000000000000000000",
  "plan": "team",
  "features": {
    "personal_dashboard": true,
    "bulk_transition": true,
    "team_sync": true,
    "team_board": true,
    "analytics": true,
    "multi_jira_instance": true
  },
  "expires_at": "2027-05-27T00:00:00Z",
  "refresh_after": "2026-05-28T00:00:00Z",
  "offline_grace_until": "2026-06-10T00:00:00Z",
  "license_token": "new-signed-token",
  "server_time": "2026-05-27T00:00:00Z"
}
```

Revoked response, `403 Forbidden`:

```json
{
  "status": "revoked",
  "licensed": false,
  "message": "License has been revoked."
}
```

## POST /licenses/deactivate

Deactivates the current machine.

Request:

```json
{
  "license_id": "lic_01HX0000000000000000000000",
  "activation_id": "act_01HX0000000000000000000000",
  "machine_id_hash": "2f5c...e91"
}
```

Success response, `200 OK`:

```json
{
  "status": "deactivated",
  "licensed": false,
  "message": "Activation has been deactivated."
}
```

## POST /licenses/validate

Validates a token without changing activation state. This is optional for normal local app operation but useful for diagnostics.

Request:

```json
{
  "license_token": "signed-token",
  "machine_id_hash": "2f5c...e91"
}
```

Response, `200 OK`:

```json
{
  "status": "active",
  "licensed": true,
  "license_id": "lic_01HX0000000000000000000000",
  "activation_id": "act_01HX0000000000000000000000",
  "expires_at": "2027-05-27T00:00:00Z"
}
```

## Signed License Token

The license server signs the token. The local JiraAuto backend verifies it with a bundled public key.

Recommended signing algorithms:

- Ed25519
- RS256

Token claims:

```json
{
  "iss": "jiraauto-license-server",
  "aud": "jiraauto-local-app",
  "sub": "lic_01HX0000000000000000000000",
  "activation_id": "act_01HX0000000000000000000000",
  "machine_id_hash": "2f5c...e91",
  "plan": "team",
  "features": {
    "personal_dashboard": true,
    "bulk_transition": true,
    "team_sync": true,
    "team_board": true,
    "analytics": true,
    "multi_jira_instance": true
  },
  "iat": 1780000000,
  "exp": 1811462400,
  "refresh_after": 1780086400,
  "offline_grace_until": 1781209600
}
```

## Local Backend Storage

The local backend should store:

```json
{
  "license_id": "lic_01HX0000000000000000000000",
  "activation_id": "act_01HX0000000000000000000000",
  "license_token": "signed-token",
  "status": "active",
  "plan": "team",
  "features": {},
  "expires_at": "2027-05-27T00:00:00Z",
  "last_online_check_at": "2026-05-27T00:00:00Z",
  "offline_grace_until": "2026-06-10T00:00:00Z"
}
```

The local backend must not store the raw license key after activation.

## Admin Endpoints

## POST /admin/licenses

Creates one or more license keys.

Request:

```json
{
  "customer_email": "buyer@example.com",
  "plan": "team",
  "count": 10,
  "max_devices": 3,
  "expires_at": "2027-05-27T00:00:00Z",
  "features": {
    "personal_dashboard": true,
    "bulk_transition": true,
    "team_sync": true,
    "team_board": true,
    "analytics": true,
    "multi_jira_instance": true
  }
}
```

Response:

```json
{
  "licenses": [
    {
      "license_id": "lic_01HX0000000000000000000000",
      "license_key": "JIRAUTO-2026-ABCD-EFGH-IJKL-MNOP",
      "plan": "team",
      "expires_at": "2027-05-27T00:00:00Z"
    }
  ]
}
```

The server stores only a hash of `license_key`.

## POST /admin/licenses/{license_id}/revoke

Revokes a license.

Response:

```json
{
  "status": "revoked",
  "license_id": "lic_01HX0000000000000000000000"
}
```

## GET /admin/licenses/{license_id}

Returns license metadata and active device list.

Response:

```json
{
  "license_id": "lic_01HX0000000000000000000000",
  "customer_email": "buyer@example.com",
  "plan": "team",
  "status": "active",
  "max_devices": 3,
  "expires_at": "2027-05-27T00:00:00Z",
  "activations": [
    {
      "activation_id": "act_01HX0000000000000000000000",
      "device_name": "Office laptop",
      "machine_id_hash": "2f5c...e91",
      "status": "active",
      "activated_at": "2026-05-27T00:00:00Z",
      "last_seen_at": "2026-05-27T00:00:00Z"
    }
  ]
}
```

## CouchDB Document Model

Use one database initially:

```txt
jiraauto_license_server
```

Document IDs:

```txt
license:<license_id>
activation:<activation_id>
audit:<audit_id>
```

Required indexes:

- `type + license_key_hash`
- `type + license_id`
- `type + license_id + machine_id_hash`
- `type + status`
- `type + created_at`

License document:

```json
{
  "_id": "license:lic_01HX0000000000000000000000",
  "type": "license",
  "license_id": "lic_01HX0000000000000000000000",
  "license_key_hash": "sha256-hex",
  "customer_email": "buyer@example.com",
  "plan": "team",
  "status": "active",
  "max_devices": 3,
  "expires_at": "2027-05-27T00:00:00Z",
  "features": {},
  "created_at": "2026-05-27T00:00:00Z"
}
```

Activation document:

```json
{
  "_id": "activation:act_01HX0000000000000000000000",
  "type": "activation",
  "activation_id": "act_01HX0000000000000000000000",
  "license_id": "lic_01HX0000000000000000000000",
  "machine_id_hash": "2f5c...e91",
  "device_name": "Office laptop",
  "status": "active",
  "app_version": "1.0.0",
  "activated_at": "2026-05-27T00:00:00Z",
  "last_seen_at": "2026-05-27T00:00:00Z"
}
```

## Local App Mapping

Current local endpoints stay stable:

```txt
GET  /api/license/status
POST /api/license/activate
POST /api/license/refresh
POST /api/license/deactivate
```

When the license server is introduced, local `backend/license_service.py` should call the central API internally while preserving these local endpoint names for the frontend.
