import os
import sys
import subprocess
import httpx
import sqlite3
import json
import asyncio
import logging
from datetime import datetime, timedelta
from contextlib import asynccontextmanager
from fastapi import FastAPI, HTTPException, Body, Request
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from dotenv import load_dotenv
from pydantic import BaseModel
from typing import Optional, List, Dict
from license_service import (
    activate_license,
    current_license,
    deactivate_license,
    init_license_store,
    is_license_gate_enabled,
    refresh_license,
)

# 로깅 설정
LOG_FILE = "app.log"
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s',
    handlers=[
        logging.FileHandler(LOG_FILE, encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("JiraDashboard")

load_dotenv()

# 전역 httpx 클라이언트
client = httpx.AsyncClient(
    timeout=httpx.Timeout(30.0, connect=10.0),
    limits=httpx.Limits(max_connections=50, max_keepalive_connections=20)
)

DB_PATH = "jira_cache.db"

class JiraInstance:
    def __init__(self, id: int, base_url: str, token: str):
        self.id = id
        self.base_url = base_url.rstrip("/")
        domain = self.base_url.replace("https://", "").replace("http://", "").split("/")[0]
        parts = domain.split(".")
        self.name = parts[1] if len(parts) >= 2 else parts[0]
        self.headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json"
        }
        self.user_info = None
        self.target_start_id = None
        self.target_end_id = None

instances: Dict[int, JiraInstance] = {}

def load_instances():
    global instances
    instances = {}
    for i in range(1, 11):
        url = os.getenv(f"JIRA_BASE_URL_{i}")
        token = os.getenv(f"JIRA_TOKEN_{i}")
        if url and url.strip() and token and token.strip():
            instances[i] = JiraInstance(i, url, token)
            logger.info(f"Loaded Jira Instance {i}: {url} as '{instances[i].name}'")
    
    legacy_url = os.getenv("JIRA_BASE_URL")
    legacy_token = os.getenv("JIRA_TOKEN")
    if legacy_url and legacy_url.strip() and legacy_token and legacy_token.strip() and 0 not in instances:
        instances[0] = JiraInstance(0, legacy_url, legacy_token)
        logger.info(f"Loaded Legacy Jira Instance: {legacy_url} as '{instances[0].name}'")

async def fetch_user_infos():
    async def fetch_me(inst: JiraInstance):
        try:
            res = await client.get(f"{inst.base_url}/rest/api/2/myself", headers=inst.headers)
            if res.status_code == 200:
                inst.user_info = res.json()
                logger.info(f"Identity confirmed for '{inst.name}': {inst.user_info.get('displayName')}")
        except Exception as e:
            logger.warning(f"Failed to fetch identity for '{inst.name}': {e}")
    
    await asyncio.gather(*(fetch_me(inst) for inst in instances.values()))

async def fetch_custom_fields():
    async def fetch_fields(inst: JiraInstance):
        try:
            res = await client.get(f"{inst.base_url}/rest/api/2/field", headers=inst.headers)
            if res.status_code == 200:
                fields = res.json()
                for f in fields:
                    if f.get("name") == "Target start":
                        inst.target_start_id = f.get("id")
                    elif f.get("name") == "Target end":
                        inst.target_end_id = f.get("id")
                logger.info(f"Custom fields loaded for '{inst.name}' - Target Start: {inst.target_start_id}, Target End: {inst.target_end_id}")
        except Exception as e:
            logger.warning(f"Failed to fetch fields for '{inst.name}': {e}")
    
    await asyncio.gather(*(fetch_fields(inst) for inst in instances.values()))

def init_db():
    try:
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute('PRAGMA journal_mode=WAL')
        
        # 테이블 존재 여부 확인
        c.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='issues'")
        table_exists = c.fetchone()
        
        if table_exists:
            # 기존 테이블이 있으면 복합키 지원을 위해 마이그레이션 필요 여부 확인
            # 간단히 하기 위해, key가 PRIMARY KEY인 경우 재생성 (데이터는 get_issues에서 다시 채워짐)
            c.execute("PRAGMA table_info(issues)")
            columns = c.fetchall()
            is_composite = False
            for col in columns:
                if col[5] > 0: # pk column count
                    is_composite = True
                    break
            
            # 실제 복합키인지 더 정확히 확인하려면 index나 create sql을 봐야하지만, 
            # 여기서는 안전하게 테이블을 드랍하고 다시 만듬 (캐시이므로 무관)
            # 단, 이미 instance_id가 pk에 포함되어 있다면 패스
            c.execute("SELECT sql FROM sqlite_master WHERE name='issues'")
            create_sql = c.fetchone()[0]
            if "PRIMARY KEY(key, instance_id)" not in create_sql.upper() and "PRIMARY KEY (key, instance_id)" not in create_sql.upper():
                logger.info("Migrating issues table to composite primary key (key, instance_id)...")
                c.execute("DROP TABLE issues")
                table_exists = False

        if not table_exists:
            c.execute('''CREATE TABLE issues
                     (key TEXT, instance_id INTEGER, summary TEXT, status TEXT, 
                      assignee_name TEXT, reporter_name TEXT, issuetype TEXT,
                      priority TEXT, components_json TEXT, labels_json TEXT,
                      watchers_json TEXT, created_at TEXT, jira_updated_at TEXT,
                      description TEXT, comments_json TEXT, transitions_json TEXT,
                      changelog_json TEXT, updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                      PRIMARY KEY(key, instance_id))''')

        c.execute('''CREATE TABLE IF NOT EXISTS team_issues
                 (key TEXT, instance_id INTEGER, member_id TEXT, summary TEXT, status TEXT, 
                  assignee_name TEXT, reporter_name TEXT, issuetype TEXT,
                  priority TEXT, created_at TEXT, updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                  raw_json TEXT,
                  PRIMARY KEY(key, instance_id, member_id))''')
        c.execute('''CREATE TABLE IF NOT EXISTS team_notices
                 (id TEXT PRIMARY KEY, author TEXT, content TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, edit_count INTEGER DEFAULT 0)''')
        c.execute('''CREATE TABLE IF NOT EXISTS team_comments
                 (id TEXT PRIMARY KEY, notice_id TEXT, author TEXT, content TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)''')
        c.execute('''CREATE TABLE IF NOT EXISTS team_boards
                 (id TEXT PRIMARY KEY, author TEXT, content TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, edit_count INTEGER DEFAULT 0)''')
        c.execute('''CREATE TABLE IF NOT EXISTS team_board_comments
                 (id TEXT PRIMARY KEY, board_id TEXT, author TEXT, content TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)''')
        c.execute('''CREATE TABLE IF NOT EXISTS team_members
                 (id TEXT PRIMARY KEY, name TEXT, last_sync DATETIME DEFAULT CURRENT_TIMESTAMP)''')
        
        
        try:
            c.execute("ALTER TABLE team_notices ADD COLUMN edit_count INTEGER DEFAULT 0")
        except sqlite3.OperationalError: pass
        try:
            c.execute("ALTER TABLE team_comments ADD COLUMN edit_count INTEGER DEFAULT 0")
        except sqlite3.OperationalError: pass
        try:
            c.execute("ALTER TABLE team_boards ADD COLUMN edit_count INTEGER DEFAULT 0")
        except sqlite3.OperationalError: pass
        try:
            c.execute("ALTER TABLE team_board_comments ADD COLUMN edit_count INTEGER DEFAULT 0")
        except sqlite3.OperationalError: pass
        conn.commit()
        conn.close()
        logger.info("Database initialized successfully.")
    except Exception as e:
        logger.error(f"CRITICAL: DB Init failed: {e}")

@asynccontextmanager
async def lifespan(app: FastAPI):
    load_instances()
    await fetch_user_infos()
    await fetch_custom_fields()
    init_db()
    init_license_store()
    yield
    await client.aclose()
    logger.info("Application shutting down.")

app = FastAPI(lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

LICENSE_PUBLIC_PATHS = (
    "/api/license",
    "/api/health",
)


@app.middleware("http")
async def license_gate(request: Request, call_next):
    if not is_license_gate_enabled():
        return await call_next(request)
    if request.method == "OPTIONS":
        return await call_next(request)
    path = request.url.path
    if not path.startswith("/api"):
        return await call_next(request)
    if any(path.startswith(public_path) for public_path in LICENSE_PUBLIC_PATHS):
        return await call_next(request)
    status = current_license()
    if not status.get("licensed"):
        return JSONResponse(
            status_code=403,
            content={
                "detail": "License activation is required.",
                "license": status,
            },
        )
    return await call_next(request)

class CommentRequest(BaseModel): body: str
class LicenseActivationRequest(BaseModel):
    license_key: str
    device_name: Optional[str] = None


@app.get("/api/license/status")
async def get_license_status():
    return current_license()


@app.post("/api/license/activate")
async def activate_license_route(req: LicenseActivationRequest):
    result = activate_license(req.license_key, req.device_name)
    if not result.get("licensed"):
        raise HTTPException(status_code=400, detail=result)
    return result


@app.post("/api/license/refresh")
async def refresh_license_route():
    return refresh_license()


@app.post("/api/license/deactivate")
async def deactivate_license_route():
    return deactivate_license()


class CreateIssueRequest(BaseModel):
    project_key: str
    summary: str
    description: Optional[str] = ""
    issuetype_name: str
    parent_key: Optional[str] = None
    instance_id: int = 0

MAX_CONCURRENT_REQUESTS = 5
semaphore = asyncio.Semaphore(MAX_CONCURRENT_REQUESTS)
active_tasks = set()

async def fetch_and_cache_details(issue_key: str, instance_id: int, force: bool = False, cache_minutes: int = 5):
    task_id = f"{instance_id}:{issue_key}"
    if task_id in active_tasks: return
    active_tasks.add(task_id)
    try:
        inst = instances.get(instance_id)
        if not inst: return
        if not force:
            try:
                with sqlite3.connect(DB_PATH) as conn:
                    c = conn.cursor()
                    c.execute("SELECT updated_at FROM issues WHERE key = ? AND instance_id = ? AND changelog_json IS NOT NULL", (issue_key, instance_id))
                    row = c.fetchone()
                    if row:
                        updated_at = datetime.strptime(row[0], '%Y-%m-%d %H:%M:%S')
                        if datetime.utcnow() - updated_at < timedelta(minutes=cache_minutes): return
            except Exception: pass
        async with semaphore:
            detail_url = f"{inst.base_url}/rest/api/2/issue/{issue_key}?expand=comments,renderedBody,changelog"
            trans_url = f"{inst.base_url}/rest/api/2/issue/{issue_key}/transitions"
            watch_url = f"{inst.base_url}/rest/api/2/issue/{issue_key}/watchers"
            d_res, t_res, w_res = await asyncio.gather(client.get(detail_url, headers=inst.headers), client.get(trans_url, headers=inst.headers), client.get(watch_url, headers=inst.headers))
            if d_res.status_code == 200:
                detail = d_res.json(); trans = t_res.json() if t_res.status_code == 200 else {"transitions": []}; watch = w_res.json() if w_res.status_code == 200 else {"watchers": []}
                f = detail['fields']; histories = detail.get('changelog', {}).get('histories', [])
                with sqlite3.connect(DB_PATH, timeout=30) as conn:
                    c = conn.cursor()
                    c.execute('''UPDATE issues SET issuetype=?, priority=?, components_json=?, 
                                 labels_json=?, watchers_json=?, created_at=?, jira_updated_at=?, 
                                 description=?, comments_json=?, transitions_json=?, changelog_json=?,
                                 updated_at=CURRENT_TIMESTAMP WHERE key=? AND instance_id=?''', 
                              (f['issuetype']['name'], f['priority']['name'] if f.get('priority') else None,
                               json.dumps([comp['name'] for comp in f.get('components', [])]), json.dumps(f.get('labels', [])),
                               json.dumps([w['displayName'] for w in watch.get('watchers', [])]), f.get('created'), f.get('updated'), f.get('description', ''),
                               json.dumps(f.get('comment', {}).get('comments', [])), json.dumps(trans.get('transitions', [])), json.dumps(histories), issue_key, instance_id))
                    conn.commit()
    finally: active_tasks.discard(task_id)

@app.get("/api/config")
async def get_config():
    first_inst = next(iter(instances.values())) if instances else None
    return {
        "jira_base_url": first_inst.base_url if first_inst else "",
        "instances": [{"id": i.id, "base_url": i.base_url, "name": i.name} for i in instances.values()],
        "tracking_projects": [p.strip() for p in os.environ.get("JIRA_TRACKING_PROJECTS", "").split(",") if p.strip()]
    }

@app.get("/api/users/search")
async def search_users(issue_key: str, query: str):
    with sqlite3.connect(DB_PATH) as conn:
        c = conn.cursor()
        c.execute("SELECT instance_id FROM issues WHERE key = ?", (issue_key,))
        row = c.fetchone()
    instance_id = row[0] if row else next(iter(instances.keys()))
    inst = instances.get(instance_id)
    if not inst: return []
    try:
        response = await client.get(f"{inst.base_url}/rest/api/2/user/search", headers=inst.headers, params={"username": query, "maxResults": 10})
        return response.json() if response.status_code == 200 else []
    except Exception: return []

@app.get("/api/issues")
async def get_issues(start_date: Optional[str] = None, end_date: Optional[str] = None, cache_minutes: int = 5, include_closed: bool = False):
    # JQL 단순화 (오류 방지를 위해 기본 영문 상태만 우선 사용)
    jql_parts = ['(assignee = currentUser() OR comment ~ currentUser() OR reporter = currentUser())']
    if not include_closed:
        jql_parts.insert(0, 'statusCategory != Done')
    jql = ' AND '.join(jql_parts)
    if start_date: jql += f' AND created >= "{start_date}"'
    if end_date: jql += f' AND created <= "{end_date}"'
    jql += ' ORDER BY created DESC'
    
    all_merged_issues = []; all_keys_with_inst = []
    
    async def fetch_from_instance(inst: JiraInstance):
        try:
            # URL에 직접 쿼리 스트링을 넣는 대신 params 파라미터 사용 (자동 인코딩)
            params = {"jql": jql, "maxResults": 100}
            res = await client.get(f"{inst.base_url}/rest/api/2/search", headers=inst.headers, params=params)
            if res.status_code == 200:
                data = res.json()
                for issue in data.get('issues', []):
                    issue['instance_id'] = inst.id
                    all_merged_issues.append(issue); all_keys_with_inst.append((issue['key'], inst.id))
            else:
                logger.error(f"Instance {inst.id} returned {res.status_code}: {res.text}")
        except Exception as e: logger.error(f"Error fetching from instance {inst.id}: {e}")
    await asyncio.gather(*(fetch_from_instance(inst) for inst in instances.values()))
    with sqlite3.connect(DB_PATH, timeout=30) as conn:
        c = conn.cursor()
        # 전체 인스턴스 활성 키 기준 삭제
        if all_keys_with_inst:
            placeholders = ','.join(['(?,?)'] * len(all_keys_with_inst))
            params = [item for sublist in all_keys_with_inst for item in sublist]
            c.execute(f'DELETE FROM issues WHERE (key, instance_id) NOT IN ({placeholders})', params)
        else: c.execute('DELETE FROM issues')
        for issue in all_merged_issues:
            key = issue['key']; f = issue['fields']; iid = issue['instance_id']
            c.execute('''INSERT OR IGNORE INTO issues (key, instance_id, summary, status, assignee_name, reporter_name, jira_updated_at)
                         VALUES (?, ?, ?, ?, ?, ?, ?)''', (key, iid, f['summary'], f['status']['name'], 
                                                    f['assignee']['displayName'] if f['assignee'] else None,
                                                    f['reporter']['displayName'] if f['reporter'] else None, f.get('updated')))
            c.execute('''UPDATE issues SET summary=?, status=?, assignee_name=?, reporter_name=?, jira_updated_at=? 
                         WHERE key=? AND instance_id=?''',
                      (f['summary'], f['status']['name'], f['assignee']['displayName'] if f['assignee'] else None,
                       f['reporter']['displayName'] if f['reporter'] else None, f.get('updated'), key, iid))
        
            
            inst_obj = instances.get(iid)
            inst_name = inst_obj.name if inst_obj else 'Jira'
            
            # /myself 정보에서 정확한 내 이름(디스플레이 네임) 가져오기
            leader_name = 'Team Leader'
            if inst_obj and getattr(inst_obj, 'user_info', None):
                leader_name = inst_obj.user_info.get('displayName', 'Team Leader')
                
            c.execute("INSERT OR IGNORE INTO team_members (id, name) VALUES (?, ?)", (leader_name, leader_name))
            c.execute("UPDATE team_members SET last_sync = CURRENT_TIMESTAMP WHERE id = ?", (leader_name,))
            
            # 프론트엔드가 인식할 수 있게 법인명(team_instance_name) 주입
            issue['team_instance_name'] = inst_name
            if inst_obj:
                issue['team_instance_url'] = inst_obj.base_url
            
            import json
            raw_json = json.dumps(issue)
            
            c.execute('''INSERT OR REPLACE INTO team_issues 
                         (key, instance_id, member_id, summary, status, assignee_name, reporter_name, issuetype, priority, created_at, raw_json) 
                         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                      (key, iid, leader_name, f.get('summary'), f.get('status', {}).get('name'),
                       f.get('assignee', {}).get('displayName') if f.get('assignee') else None,
                       f.get('reporter', {}).get('displayName') if f.get('reporter') else None,
                       f.get('issuetype', {}).get('name') if f.get('issuetype') else None,
                       f.get('priority', {}).get('name') if f.get('priority') else None,
                       f.get('created'),
                       raw_json))
            
        # 이슈 목록 정리(이번에 fetch되지 않은 지난 이슈들은 team_issues에서 삭제)
        conn.commit()
    for key, iid in all_keys_with_inst: asyncio.create_task(fetch_and_cache_details(key, iid, cache_minutes=cache_minutes))
    return {"issues": all_merged_issues}

@app.get("/api/issues/{issue_key}")
async def get_issue_detail(issue_key: str, instance_id: Optional[int] = None):
    # instance_id가 명시되지 않으면 DB에서 첫 번째 매칭 조회
    with sqlite3.connect(DB_PATH) as conn:
        c = conn.cursor()
        if instance_id is not None:
            c.execute("SELECT instance_id FROM issues WHERE key = ? AND instance_id = ?", (issue_key, instance_id))
        else:
            c.execute("SELECT instance_id FROM issues WHERE key = ?", (issue_key,))
        row = c.fetchone()
    iid = row[0] if row else (instance_id if instance_id is not None else 0)
    inst = instances.get(iid)
    try:
        with sqlite3.connect(DB_PATH) as conn:
            c = conn.cursor()
            c.execute('''SELECT description, comments_json, issuetype, priority, components_json, labels_json, watchers_json, 
                                created_at, jira_updated_at, assignee_name, reporter_name, changelog_json 
                         FROM issues WHERE key = ? AND instance_id = ?''', (issue_key, iid))
            row = c.fetchone()
        if row and row[1]:
            return {"key": issue_key, "instance_id": iid, "fields": {"description": row[0], "comment": {"comments": json.loads(row[1])},
                    "issuetype": {"name": row[2]}, "priority": {"name": row[3]}, "components": [{"name": c} for c in json.loads(row[4] or "[]")],
                    "labels": json.loads(row[5] or "[]"), "watchers": json.loads(row[6] or "[]"), "created": row[7], "updated": row[8],
                    "assignee": {"displayName": row[9]}, "reporter": {"displayName": row[10]}}, "changelog": {"histories": json.loads(row[11] or "[]")}}
    except Exception: pass
    if inst:
        res = await client.get(f"{inst.base_url}/rest/api/2/issue/{issue_key}?expand=comments,renderedBody,changelog", headers=inst.headers)
        data = res.json(); data['instance_id'] = iid; return data
    return False, 'Not Found'

@app.get("/api/me")
async def get_myself():
    # 모든 인스턴스의 나 정보를 맵으로 반환
    results = {}
    for iid, inst in instances.items():
        if inst.user_info: results[iid] = inst.user_info
    return results

@app.get("/api/issues/{issue_key}/transitions")
async def get_transitions(issue_key: str, instance_id: Optional[int] = None):
    with sqlite3.connect(DB_PATH) as conn:
        c = conn.cursor()
        if instance_id is not None: c.execute("SELECT instance_id, transitions_json FROM issues WHERE key = ? AND instance_id = ?", (issue_key, instance_id))
        else: c.execute("SELECT instance_id, transitions_json FROM issues WHERE key = ?", (issue_key,))
        row = c.fetchone()
    if row and row[1]: return {"transitions": json.loads(row[1])}
    iid = row[0] if row else (instance_id if instance_id is not None else 0)
    inst = instances.get(iid)
    if inst:
        res = await client.get(f"{inst.base_url}/rest/api/2/issue/{issue_key}/transitions", headers=inst.headers)
        return res.json()
    return {"transitions": []}

def seconds_to_jira_time(seconds: int) -> str:
    """사용자 직관(24시간=1일)에 맞춰 초를 Jira 시간 문자열로 변환"""
    if seconds <= 0:
        return "1m"
    
    # 달력 시간 기준으로 분, 시간, 일 계산
    minutes = seconds // 60
    if minutes == 0: return "1m"
    
    m = minutes % 60
    h_total = minutes // 60
    h = h_total % 24           # 24시간 기준 시간
    calendar_days = h_total // 24 # 24시간 기준 일수
    
    # Jira의 주(week) 단위 표시를 위해 5일=1주 규칙 적용 (Jira 설정 준수)
    d = calendar_days % 5
    w = calendar_days // 5
    
    parts = []
    if w > 0: parts.append(f"{w}w")
    if d > 0: parts.append(f"{d}d")
    if h > 0: parts.append(f"{h}h")
    if m > 0: parts.append(f"{m}m")
    
    return " ".join(parts) if parts else "1m"

from typing import Tuple

async def do_perform_transition(issue_key: str, transition_id: str, instance_id: Optional[int]) -> Tuple[bool, str]:
    with sqlite3.connect(DB_PATH) as conn:
        c = conn.cursor()
        if instance_id is not None: c.execute("SELECT instance_id FROM issues WHERE key = ? AND instance_id = ?", (issue_key, instance_id))
        else: c.execute("SELECT instance_id FROM issues WHERE key = ?", (issue_key,))
        row = c.fetchone()
    iid = row[0] if row else (instance_id if instance_id is not None else 0)
    inst = instances.get(iid)
    if not inst: raise HTTPException(status_code=404)
    
    # 1. 상태 변경 수행
    transition_res = await client.post(f"{inst.base_url}/rest/api/2/issue/{issue_key}/transitions", headers=inst.headers, json={"transition": {"id": transition_id}})
    
    # 2. 시간 추적 자동화 로직
    if transition_res.status_code in [201, 204]:
        try:
            # Jira가 상태를 업데이트할 시간을 잠시 기다림 (안정성 확보)
            await asyncio.sleep(1)
            
            auto_enabled = os.getenv("JIRA_AUTO_TIME_TRACKING") == "Y"
            target_projects = [p.strip().upper() for p in os.getenv("JIRA_TRACKING_PROJECTS", "").split(",") if p.strip()]
            proj_key = issue_key.split("-")[0].upper()
            
            if auto_enabled and proj_key in target_projects:
                # 티켓 상세 정보 및 내 정보 조회
                issue_res = await client.get(f"{inst.base_url}/rest/api/2/issue/{issue_key}", headers=inst.headers)
                me_res = await client.get(f"{inst.base_url}/rest/api/2/myself", headers=inst.headers)
                
                if issue_res.status_code == 200 and me_res.status_code == 200:
                    issue_data = issue_res.json()
                    me_data = me_res.json()
                    fields = issue_data.get("fields", {})
                    
                    # 담당자 확인 (내 계정인 경우만)
                    assignee = fields.get("assignee")
                    if assignee and assignee.get("name") == me_data.get("name"):
                        # 상태 카테고리 확인 (완료 상태인지)
                        status = fields.get("status", {})
                        status_name = status.get("name", "")
                        status_category = status.get("statusCategory", {}).get("key")
                        
                        # 완료(done) 카테고리이거나 명시적으로 완료/닫기 관련 명칭인 경우
                        is_done = (status_category == "done" or 
                                  status_name in ["Done", "Closed", "Resolved", "완료", "닫힘", "닫기", "해결됨"])
                        
                        # 시간 추적이 비어있는지 확인
                        timetracking = fields.get("timetracking", {})
                        if is_done and not timetracking.get("originalEstimate"):
                            # 시간 계산 (생성일 기준)
                            created_str = fields.get("created")
                            if created_str:
                                # 타임존 포함 파싱 시도 (+0900 -> +09:00 형식 보정)
                                fixed_iso = created_str
                                if "+" in fixed_iso and ":" not in fixed_iso.split("+")[-1]:
                                    tz = fixed_iso.split("+")[-1]
                                    fixed_iso = fixed_iso.replace(tz, tz[:2] + ":" + tz[2:])
                                
                                try:
                                    created_dt = datetime.fromisoformat(fixed_iso)
                                    # Aware datetime인 경우 현재 시간도 타임존 포함하여 생성
                                    if created_dt.tzinfo:
                                        now_dt = datetime.now(created_dt.tzinfo)
                                    else:
                                        now_dt = datetime.now()
                                    
                                    diff_seconds = int((now_dt - created_dt).total_seconds())
                                    jira_time = seconds_to_jira_time(diff_seconds)
                                    
                                    # Worklog 등록
                                    await client.post(
                                        f"{inst.base_url}/rest/api/2/issue/{issue_key}/worklog",
                                        headers=inst.headers,
                                        json={"timeSpent": jira_time, "comment": "Automatically logged by Jira Manager"}
                                    )
                                    
                                    update_payload = {
                                        "update": {
                                            "timetracking": [{
                                                "edit": {
                                                    "originalEstimate": jira_time,
                                                    "remainingEstimate": "0m"
                                                }
                                            }]
                                        }
                                    }
                                    
                                    fields_to_update = {}
                                    if getattr(inst, 'target_start_id', None):
                                        fields_to_update[inst.target_start_id] = created_dt.strftime('%Y-%m-%d')
                                    if getattr(inst, 'target_end_id', None):
                                        fields_to_update[inst.target_end_id] = now_dt.strftime('%Y-%m-%d')
                                        
                                    if fields_to_update:
                                        update_payload["fields"] = fields_to_update
                                    
                                    # Time Tracking 및 Target 날짜 업데이트
                                    await client.put(
                                        f"{inst.base_url}/rest/api/2/issue/{issue_key}",
                                        headers=inst.headers,
                                        json=update_payload
                                    )
                                    logger.info(f"Auto-tracked time and target dates for {issue_key}: {jira_time} (Diff: {diff_seconds}s)")
                                except Exception as parse_e:
                                    logger.error(f"Date parsing error for {issue_key}: {parse_e}")

        except Exception as e:
            logger.error(f"Error in auto time tracking for {issue_key}: {e}")

        asyncio.create_task(fetch_and_cache_details(issue_key, iid, force=True))
        return True, ""
    else:
        logger.error(f"Transition failed for {issue_key}: {transition_res.text}")
        return False, transition_res.text

class BulkTransitionRequestItem(BaseModel):
    key: str
    instance_id: Optional[int] = None

class BulkTransitionRequest(BaseModel):
    issues: List[BulkTransitionRequestItem]
    transition_name: str

@app.post("/api/issues/bulk/transitions")
async def bulk_transition_route(req: BulkTransitionRequest):
    results = []
    for issue in req.issues:
        try:
            with sqlite3.connect(DB_PATH) as conn:
                c = conn.cursor()
                if issue.instance_id is not None: c.execute("SELECT instance_id FROM issues WHERE key = ? AND instance_id = ?", (issue.key, issue.instance_id))
                else: c.execute("SELECT instance_id FROM issues WHERE key = ?", (issue.key,))
                row = c.fetchone()
            iid = row[0] if row else (issue.instance_id if issue.instance_id is not None else 0)
            inst = instances.get(iid)
            
            if not inst:
                results.append({"key": issue.key, "success": False, "error": "Instance not found"})
                continue
                
            t_res = await client.get(f"{inst.base_url}/rest/api/2/issue/{issue.key}/transitions", headers=inst.headers)
            if t_res.status_code != 200:
                results.append({"key": issue.key, "success": False, "error": f"Failed to get transitions: {t_res.text}"})
                continue
                
            t_data = t_res.json()
            transitions = t_data.get("transitions", [])
            target_t = next((t for t in transitions if t["name"] == req.transition_name), None)
            
            if not target_t:
                results.append({"key": issue.key, "success": False, "error": f"Transition '{req.transition_name}' not available for this issue."})
                continue
                
            success, error = await do_perform_transition(issue.key, target_t["id"], issue.instance_id)
            results.append({"key": issue.key, "success": success, "error": error})
        except Exception as e:
            results.append({"key": issue.key, "success": False, "error": str(e)})
    return {"results": results}

class TransitionRequest(BaseModel):
    transition_id: str

@app.post("/api/issues/{issue_key}/transitions")
async def perform_transition_route(issue_key: str, req: TransitionRequest, instance_id: Optional[int] = None):
    success, error = await do_perform_transition(issue_key, req.transition_id, instance_id)
    if not success:
        raise HTTPException(status_code=400, detail=error)
    return {"status": "success"}

@app.post("/api/issues/{issue_key}/comments")
async def add_comment(issue_key: str, req: CommentRequest, instance_id: Optional[int] = None):
    with sqlite3.connect(DB_PATH) as conn:
        c = conn.cursor()
        if instance_id is not None: c.execute("SELECT instance_id FROM issues WHERE key = ? AND instance_id = ?", (issue_key, instance_id))
        else: c.execute("SELECT instance_id FROM issues WHERE key = ?", (issue_key,))
        row = c.fetchone()
    iid = row[0] if row else (instance_id if instance_id is not None else 0)
    inst = instances.get(iid)
    if inst:
        await client.post(f"{inst.base_url}/rest/api/2/issue/{issue_key}/comment", headers=inst.headers, json=req.model_dump())
        asyncio.create_task(fetch_and_cache_details(issue_key, iid, force=True)); return {"status": "success"}
    return False, 'Not Found'

@app.put("/api/issues/{issue_key}/comments/{comment_id}")
async def update_comment(issue_key: str, comment_id: str, req: CommentRequest, instance_id: Optional[int] = None):
    with sqlite3.connect(DB_PATH) as conn:
        c = conn.cursor()
        if instance_id is not None: c.execute("SELECT instance_id FROM issues WHERE key = ? AND instance_id = ?", (issue_key, instance_id))
        else: c.execute("SELECT instance_id FROM issues WHERE key = ?", (issue_key,))
        row = c.fetchone()
    iid = row[0] if row else (instance_id if instance_id is not None else 0)
    inst = instances.get(iid)
    if not inst: raise HTTPException(status_code=404)
    res = await client.put(f"{inst.base_url}/rest/api/2/issue/{issue_key}/comment/{comment_id}", headers=inst.headers, json=req.model_dump())
    if res.status_code not in [200, 204]:
        raise HTTPException(status_code=res.status_code, detail=res.text)
    asyncio.create_task(fetch_and_cache_details(issue_key, iid, force=True))
    return {"status": "success"}

@app.delete("/api/issues/{issue_key}/comments/{comment_id}")
async def delete_comment(issue_key: str, comment_id: str, instance_id: Optional[int] = None):
    with sqlite3.connect(DB_PATH) as conn:
        c = conn.cursor()
        if instance_id is not None: c.execute("SELECT instance_id FROM issues WHERE key = ? AND instance_id = ?", (issue_key, instance_id))
        else: c.execute("SELECT instance_id FROM issues WHERE key = ?", (issue_key,))
        row = c.fetchone()
    iid = row[0] if row else (instance_id if instance_id is not None else 0)
    inst = instances.get(iid)
    if not inst: raise HTTPException(status_code=404)
    res = await client.delete(f"{inst.base_url}/rest/api/2/issue/{issue_key}/comment/{comment_id}", headers=inst.headers)
    if res.status_code not in [200, 204]:
        raise HTTPException(status_code=res.status_code, detail=res.text)
    asyncio.create_task(fetch_and_cache_details(issue_key, iid, force=True))
    return {"status": "success"}

@app.post("/api/issues")
async def create_issue(req: CreateIssueRequest):
    inst = instances.get(req.instance_id)
    if not inst: raise HTTPException(status_code=400)
    fields = {"project": {"key": req.project_key}, "summary": req.summary, "description": req.description, "issuetype": {"name": req.issuetype_name}}
    if req.parent_key: fields["parent"] = {"key": req.parent_key}
    response = await client.post(f"{inst.base_url}/rest/api/2/issue", headers=inst.headers, json={"fields": fields})
    if response.status_code != 201: raise HTTPException(status_code=response.status_code, detail=response.text)
    data = response.json(); data['instance_id'] = req.instance_id; return data

@app.get("/api/health")
async def health_check(): return {"status": "healthy", "instances": {iid: inst.name for iid, inst in instances.items()}}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=False)


from fastapi import UploadFile, File
import shutil
import uuid

@app.post("/api/issues/{issue_key}/attachments")
async def add_attachment(issue_key: str, file: UploadFile = File(...), instance_id: Optional[int] = None):
    with sqlite3.connect(DB_PATH) as conn:
        c = conn.cursor()
        if instance_id is not None: c.execute("SELECT instance_id FROM issues WHERE key = ? AND instance_id = ?", (issue_key, instance_id))
        else: c.execute("SELECT instance_id FROM issues WHERE key = ?", (issue_key,))
        row = c.fetchone()
    iid = row[0] if row else (instance_id if instance_id is not None else 0)
    inst = instances.get(iid)
    if not inst: raise HTTPException(status_code=404)
    
    # We will pass the file content directly
    headers = {"X-Atlassian-Token": "no-check"}
    headers.update(inst.headers)
    files = {"file": (file.filename, await file.read(), file.content_type)}
    
    res = await client.post(f"{inst.base_url}/rest/api/2/issue/{issue_key}/attachments", headers=headers, files=files)
    if res.status_code != 200:
        raise HTTPException(status_code=res.status_code, detail=res.text)
    return {"status": "success", "data": res.json()}

class SyncIssuesRequest(BaseModel):
    member_id: str
    issues: List[dict]

@app.post("/api/team/sync")
async def team_sync(req: SyncIssuesRequest):
    with sqlite3.connect(DB_PATH) as conn:
        c = conn.cursor()
        c.execute("INSERT OR IGNORE INTO team_members (id, name) VALUES (?, ?)", (req.member_id, req.member_id))
        c.execute("UPDATE team_members SET last_sync = CURRENT_TIMESTAMP WHERE id = ?", (req.member_id,))
        
        for issue in req.issues:
            c.execute('''INSERT OR REPLACE INTO team_issues 
                (key, instance_id, member_id, summary, status, assignee_name, reporter_name, issuetype, priority, created_at, raw_json)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                (issue.get("key"), issue.get("instance_id", 0), req.member_id, 
                 issue.get("fields", {}).get("summary"), issue.get("fields", {}).get("status", {}).get("name"),
                 issue.get("fields", {}).get("assignee", {}).get("displayName") if issue.get("fields", {}).get("assignee") else None,
                 issue.get("fields", {}).get("reporter", {}).get("displayName") if issue.get("fields", {}).get("reporter") else None,
                 issue.get("fields", {}).get("issuetype", {}).get("name"),
                 issue.get("fields", {}).get("priority", {}).get("name"),
                 issue.get("fields", {}).get("created"), json.dumps(issue)))
        conn.commit()
    return {"status": "success"}

@app.get("/api/team/issues")
async def get_team_issues():
    with sqlite3.connect(DB_PATH) as conn:
        c = conn.cursor()
        c.execute("SELECT raw_json, member_id FROM team_issues ORDER BY updated_at DESC")
        rows = c.fetchall()
        issues = []
        for r in rows:
            iss = json.loads(r[0])
            iss['team_member_id'] = r[1]
            issues.append(iss)
    return {"issues": issues}

@app.get("/api/team/notices")
async def get_team_notices():
    with sqlite3.connect(DB_PATH) as conn:
        c = conn.cursor()
        c.execute("SELECT id, author, content, created_at, edit_count FROM team_notices ORDER BY created_at DESC")
        rows = c.fetchall()
        notices = [{"id": r[0], "author": r[1], "content": r[2], "created_at": r[3], "edit_count": r[4] if len(r)>4 else 0} for r in rows]
    return {"notices": notices}

@app.post("/api/team/notices")
async def add_team_notice(req: dict):
    with sqlite3.connect(DB_PATH) as conn:
        c = conn.cursor()
        nid = str(uuid.uuid4())
        c.execute("INSERT INTO team_notices (id, author, content) VALUES (?, ?, ?)", 
                  (nid, req.get("author", "Team Leader"), req.get("content")))
        conn.commit()
    return {"status": "success", "id": nid}

import socket
import base64

@app.get("/api/team/invite")
async def generate_invite():
    try:
        # Get LAN IP
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        lan_ip = s.getsockname()[0]
        s.close()
    except Exception:
        lan_ip = "127.0.0.1"
    
    # Port is usually 8000 for backend
    port = 8000
    leader_url = f"http://{lan_ip}:{port}"
    
    data = json.dumps({"url": leader_url}).encode('utf-8')
    invite_code = base64.b64encode(data).decode('utf-8')
    
    return {"invite_code": invite_code, "lan_ip": lan_ip, "port": port}


@app.get("/api/team/members")
async def get_team_members():
    with sqlite3.connect(DB_PATH) as conn:
        c = conn.cursor()
        c.execute("SELECT id, name, last_sync FROM team_members ORDER BY last_sync DESC")
        rows = c.fetchall()
        members = [{"id": r[0], "name": r[1], "last_sync": r[2]} for r in rows]
    return {"members": members}

@app.get("/api/team/notices/{notice_id}/comments")
async def get_team_notice_comments(notice_id: str):
    with sqlite3.connect(DB_PATH) as conn:
        c = conn.cursor()
        c.execute("SELECT id, author, content, created_at, edit_count FROM team_comments WHERE notice_id = ? ORDER BY created_at ASC", (notice_id,))
        rows = c.fetchall()
        comments = [{"id": r[0], "author": r[1], "content": r[2], "created_at": r[3], "edit_count": r[4] if len(r)>4 else 0} for r in rows]
    return {"comments": comments}

@app.post("/api/team/notices/{notice_id}/comments")
async def add_team_notice_comment(notice_id: str, req: dict):
    with sqlite3.connect(DB_PATH) as conn:
        c = conn.cursor()
        cid = str(uuid.uuid4())
        c.execute("INSERT INTO team_comments (id, notice_id, author, content) VALUES (?, ?, ?, ?)", 
                  (cid, notice_id, req.get("author", "Team Member"), req.get("content")))
        conn.commit()
    return {"status": "success", "id": cid}

@app.delete("/api/team/notices/comments/{comment_id}")
async def delete_team_comment(comment_id: str):
    with sqlite3.connect(DB_PATH) as conn:
        c = conn.cursor()
        c.execute("DELETE FROM team_comments WHERE id = ?", (comment_id,))
        conn.commit()
    return {"status": "success"}

@app.delete("/api/team/notices/{notice_id}")
async def delete_team_notice(notice_id: str):
    with sqlite3.connect(DB_PATH) as conn:
        c = conn.cursor()
        c.execute("DELETE FROM team_comments WHERE notice_id = ?", (notice_id,))
        c.execute("DELETE FROM team_notices WHERE id = ?", (notice_id,))
        conn.commit()
    return {"status": "success"}
# ==========================================
# TEAM BOARDS
# ==========================================
@app.get("/api/team/boards")
async def get_team_boards():
    with sqlite3.connect(DB_PATH) as conn:
        c = conn.cursor()
        c.execute('''CREATE TABLE IF NOT EXISTS team_boards
                 (id TEXT PRIMARY KEY, author TEXT, content TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, edit_count INTEGER DEFAULT 0)''')
        c.execute('''CREATE TABLE IF NOT EXISTS team_board_comments
                 (id TEXT PRIMARY KEY, board_id TEXT, author TEXT, content TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)''')
        c.execute("SELECT id, author, content, created_at, edit_count FROM team_boards ORDER BY created_at DESC")
        rows = c.fetchall()
        boards = [{"id": r[0], "author": r[1], "content": r[2], "created_at": r[3], "edit_count": r[4] if len(r)>4 else 0} for r in rows]
    return {"boards": boards}

@app.post("/api/team/boards")
async def create_team_board(req: dict):
    author = req.get('author', '익명')
    content = req.get('content', '')
    if not content:
        raise HTTPException(status_code=400, detail="Content is required")
    bid = str(uuid.uuid4())
    with sqlite3.connect(DB_PATH) as conn:
        c = conn.cursor()
        c.execute('''CREATE TABLE IF NOT EXISTS team_boards
                 (id TEXT PRIMARY KEY, author TEXT, content TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, edit_count INTEGER DEFAULT 0)''')
        c.execute("INSERT INTO team_boards (id, author, content) VALUES (?, ?, ?)", 
                  (bid, author, content))
        conn.commit()
    return {"status": "success", "id": bid}

@app.delete("/api/team/boards/{board_id}")
async def delete_team_board(board_id: str):
    with sqlite3.connect(DB_PATH) as conn:
        c = conn.cursor()
        c.execute("DELETE FROM team_board_comments WHERE board_id = ?", (board_id,))
        c.execute("DELETE FROM team_boards WHERE id = ?", (board_id,))
        conn.commit()
    return {"status": "success"}

@app.get("/api/team/boards/{board_id}/comments")
async def get_team_board_comments(board_id: str):
    with sqlite3.connect(DB_PATH) as conn:
        c = conn.cursor()
        c.execute("SELECT id, author, content, created_at, edit_count FROM team_board_comments WHERE board_id = ? ORDER BY created_at ASC", (board_id,))
        rows = c.fetchall()
        comments = [{"id": r[0], "author": r[1], "content": r[2], "created_at": r[3], "edit_count": r[4] if len(r)>4 else 0} for r in rows]
    return {"comments": comments}

@app.post("/api/team/boards/{board_id}/comments")
async def create_team_board_comment(board_id: str, req: dict):
    author = req.get('author', '익명')
    content = req.get('content', '')
    if not content:
        raise HTTPException(status_code=400, detail="Content is required")
    cid = str(uuid.uuid4())
    with sqlite3.connect(DB_PATH) as conn:
        c = conn.cursor()
        c.execute("INSERT INTO team_board_comments (id, board_id, author, content) VALUES (?, ?, ?, ?)", 
                  (cid, board_id, author, content))
        conn.commit()
    return {"status": "success", "id": cid}

@app.delete("/api/team/boards/comments/{comment_id}")
async def delete_team_board_comment(comment_id: str):
    with sqlite3.connect(DB_PATH) as conn:
        c = conn.cursor()
        c.execute("DELETE FROM team_board_comments WHERE id = ?", (comment_id,))
        conn.commit()
    return {"status": "success"}
@app.get("/api/team/notices/recent_comments")
async def get_team_notices_recent_comments():
    with sqlite3.connect(DB_PATH) as conn:
        c = conn.cursor()
        c.execute("SELECT id, notice_id, author, content, created_at FROM team_comments ORDER BY created_at DESC LIMIT 1")
        row = c.fetchone()
        if row:
            comment = {"id": row[0], "post_id": row[1], "author": row[2], "content": row[3], "created_at": row[4]}
            return {"comment": comment}
    return {"comment": None}
@app.get("/api/team/boards/recent_comments")
async def get_team_boards_recent_comments():
    with sqlite3.connect(DB_PATH) as conn:
        c = conn.cursor()
        c.execute("SELECT id, board_id, author, content, created_at FROM team_board_comments ORDER BY created_at DESC LIMIT 1")
        row = c.fetchone()
        if row:
            comment = {"id": row[0], "post_id": row[1], "author": row[2], "content": row[3], "created_at": row[4]}
            return {"comment": comment}
    return {"comment": None}

@app.put("/api/team/notices/{notice_id}")
async def edit_team_notice(notice_id: str, req: dict):
    content = req.get('content', '')
    if not content: raise HTTPException(status_code=400, detail="Content is required")
    with sqlite3.connect(DB_PATH) as conn:
        c = conn.cursor()
        c.execute("UPDATE team_notices SET content = ?, edit_count = edit_count + 1 WHERE id = ?", (content, notice_id))
        conn.commit()
    return {"status": "success"}

@app.put("/api/team/notices/comments/{comment_id}")
async def edit_team_comment(comment_id: str, req: dict):
    content = req.get('content', '')
    if not content: raise HTTPException(status_code=400, detail="Content is required")
    with sqlite3.connect(DB_PATH) as conn:
        c = conn.cursor()
        c.execute("UPDATE team_comments SET content = ?, edit_count = edit_count + 1 WHERE id = ?", (content, comment_id))
        conn.commit()
    return {"status": "success"}

@app.put("/api/team/boards/{board_id}")
async def edit_team_board(board_id: str, req: dict):
    content = req.get('content', '')
    if not content: raise HTTPException(status_code=400, detail="Content is required")
    with sqlite3.connect(DB_PATH) as conn:
        c = conn.cursor()
        c.execute("UPDATE team_boards SET content = ?, edit_count = edit_count + 1 WHERE id = ?", (content, board_id))
        conn.commit()
    return {"status": "success"}

@app.put("/api/team/boards/comments/{comment_id}")
async def edit_team_board_comment(comment_id: str, req: dict):
    content = req.get('content', '')
    if not content: raise HTTPException(status_code=400, detail="Content is required")
    with sqlite3.connect(DB_PATH) as conn:
        c = conn.cursor()
        c.execute("UPDATE team_board_comments SET content = ?, edit_count = edit_count + 1 WHERE id = ?", (content, comment_id))
        conn.commit()
    return {"status": "success"}

@app.get("/api/local-version")
async def get_local_version():
    version_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "version.json"))
    if os.path.exists(version_path):
        with open(version_path, "r", encoding="utf-8") as f:
            try:
                data = json.load(f)
                return {"version": data.get("version", "0.0.0")}
            except:
                pass
    return {"version": "0.0.0"}

@app.post("/api/trigger-update")
async def trigger_update():
    # Run auto_updater.bat in a completely detached console
    CREATE_NEW_CONSOLE = 0x00000010
    cwd = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
    subprocess.Popen(["cmd.exe", "/c", "auto_updater.bat"], creationflags=CREATE_NEW_CONSOLE, cwd=cwd)
    
    # Let the response return to the frontend, then kill the python process
    async def kill_self():
        await asyncio.sleep(1)
        os._exit(0)
    
    asyncio.create_task(kill_self())
    return {"status": "updating"}
