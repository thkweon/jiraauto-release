export type NotepadPlacement =
  | 'left-top'
  | 'left-middle'
  | 'left-bottom'
  | 'right-top'
  | 'right-middle'
  | 'right-bottom'
  | 'left-top-middle'
  | 'left-middle-bottom'
  | 'right-top-middle'
  | 'right-middle-bottom';
export type NotepadOccupiedPosition =
  | 'left-top'
  | 'left-middle'
  | 'left-bottom'
  | 'right-top'
  | 'right-middle'
  | 'right-bottom';

export interface NotepadWidgetSettings {
  enabled: boolean;
  placement: NotepadPlacement;
}

export const NOTEPAD_WIDGET_SETTINGS_STORAGE_KEY = 'jiraautoNotepadWidgetSettings';
export const NOTEPAD_WIDGET_CONTENT_STORAGE_KEY = 'jiraautoNotepadWidgetContent';
export const NOTEPAD_WIDGET_SETTINGS_CHANGED_EVENT = 'notepadWidgetSettingsChanged';

export const NOTEPAD_PLACEMENT_BLOCKS = [
  'top',
  'middle',
  'bottom',
  'top-middle',
  'middle-bottom',
] as const;

export type NotepadPlacementBlock = typeof NOTEPAD_PLACEMENT_BLOCKS[number];

const DEFAULT_SETTINGS: NotepadWidgetSettings = {
  enabled: false,
  placement: 'left-top',
};

export const isNotepadDoublePlacement = (placement: NotepadPlacement) => (
  placement.endsWith('top-middle') || placement.endsWith('middle-bottom')
);

export const getNotepadOccupiedPositions = (placement: NotepadPlacement): NotepadOccupiedPosition[] => {
  const [side, first, second] = placement.split('-');
  return second
    ? [`${side}-${first}` as NotepadOccupiedPosition, `${side}-${second}` as NotepadOccupiedPosition]
    : [`${side}-${first}` as NotepadOccupiedPosition];
};

export const makeNotepadPlacement = (
  side: 'left' | 'right',
  block: NotepadPlacementBlock,
) => `${side}-${block}` as NotepadPlacement;

export const loadNotepadWidgetSettings = (): NotepadWidgetSettings => {
  try {
    const raw = localStorage.getItem(NOTEPAD_WIDGET_SETTINGS_STORAGE_KEY);
    if (!raw) return DEFAULT_SETTINGS;
    const value = JSON.parse(raw) as Partial<NotepadWidgetSettings>;
    const placement = typeof value.placement === 'string'
      && ['left', 'right'].some(side => NOTEPAD_PLACEMENT_BLOCKS.some(block => `${side}-${block}` === value.placement))
      ? value.placement as NotepadPlacement
      : DEFAULT_SETTINGS.placement;
    return {
      enabled: typeof value.enabled === 'boolean' ? value.enabled : DEFAULT_SETTINGS.enabled,
      placement,
    };
  } catch {
    return DEFAULT_SETTINGS;
  }
};

export const saveNotepadWidgetSettings = (settings: NotepadWidgetSettings) => {
  localStorage.setItem(NOTEPAD_WIDGET_SETTINGS_STORAGE_KEY, JSON.stringify(settings));
  window.dispatchEvent(new CustomEvent<NotepadWidgetSettings>(
    NOTEPAD_WIDGET_SETTINGS_CHANGED_EVENT,
    { detail: settings },
  ));
};

export const loadNotepadContent = () => localStorage.getItem(NOTEPAD_WIDGET_CONTENT_STORAGE_KEY) || '';

export const saveNotepadContent = (content: string) => {
  localStorage.setItem(NOTEPAD_WIDGET_CONTENT_STORAGE_KEY, content);
};
