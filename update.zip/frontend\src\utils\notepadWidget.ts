export type NotepadPlacement =
  | 'left-top'
  | 'left-middle'
  | 'left-bottom'
  | 'right-top'
  | 'right-middle'
  | 'right-bottom'
  | 'left-top-middle'
  | 'left-middle-bottom'
  | 'right-top-middle'
  | 'right-middle-bottom';
export type NotepadOccupiedPosition =
  | 'left-top'
  | 'left-middle'
  | 'left-bottom'
  | 'right-top'
  | 'right-middle'
  | 'right-bottom';

export interface NotepadWidgetSettings {
  enabled: boolean;
  placement: NotepadPlacement;
}

export interface NotepadPage {
  id: string;
  content: string;
  lock?: NotepadPageLock;
}

export interface NotepadPagesState {
  pages: NotepadPage[];
  activePageId: string;
}

export const NOTEPAD_WIDGET_SETTINGS_STORAGE_KEY = 'jiraautoNotepadWidgetSettings';
export const NOTEPAD_WIDGET_CONTENT_STORAGE_KEY = 'jiraautoNotepadWidgetContent';
export const NOTEPAD_PAGES_STORAGE_KEY = 'jiraautoNotepadPages';
export const NOTEPAD_WIDGET_SETTINGS_CHANGED_EVENT = 'notepadWidgetSettingsChanged';

export const NOTEPAD_PLACEMENT_BLOCKS = [
  'top',
  'middle',
  'bottom',
  'top-middle',
  'middle-bottom',
] as const;

export type NotepadPlacementBlock = typeof NOTEPAD_PLACEMENT_BLOCKS[number];

const DEFAULT_SETTINGS: NotepadWidgetSettings = {
  enabled: false,
  placement: 'left-top',
};

export const isNotepadDoublePlacement = (placement: NotepadPlacement) => (
  placement.endsWith('top-middle') || placement.endsWith('middle-bottom')
);

export const getNotepadOccupiedPositions = (placement: NotepadPlacement): NotepadOccupiedPosition[] => {
  const [side, first, second] = placement.split('-');
  return second
    ? [`${side}-${first}` as NotepadOccupiedPosition, `${side}-${second}` as NotepadOccupiedPosition]
    : [`${side}-${first}` as NotepadOccupiedPosition];
};

export const makeNotepadPlacement = (
  side: 'left' | 'right',
  block: NotepadPlacementBlock,
) => `${side}-${block}` as NotepadPlacement;

export const loadNotepadWidgetSettings = (): NotepadWidgetSettings => {
  try {
    const raw = localStorage.getItem(NOTEPAD_WIDGET_SETTINGS_STORAGE_KEY);
    if (!raw) return DEFAULT_SETTINGS;
    const value = JSON.parse(raw) as Partial<NotepadWidgetSettings>;
    const placement = typeof value.placement === 'string'
      && ['left', 'right'].some(side => NOTEPAD_PLACEMENT_BLOCKS.some(block => `${side}-${block}` === value.placement))
      ? value.placement as NotepadPlacement
      : DEFAULT_SETTINGS.placement;
    return {
      enabled: typeof value.enabled === 'boolean' ? value.enabled : DEFAULT_SETTINGS.enabled,
      placement,
    };
  } catch {
    return DEFAULT_SETTINGS;
  }
};

export const saveNotepadWidgetSettings = (settings: NotepadWidgetSettings) => {
  localStorage.setItem(NOTEPAD_WIDGET_SETTINGS_STORAGE_KEY, JSON.stringify(settings));
  window.dispatchEvent(new CustomEvent<NotepadWidgetSettings>(
    NOTEPAD_WIDGET_SETTINGS_CHANGED_EVENT,
    { detail: settings },
  ));
};

export const createNotepadPage = (content = ''): NotepadPage => ({
  id: typeof crypto.randomUUID === 'function'
    ? crypto.randomUUID()
    : `notepad-${Date.now()}-${Math.random().toString(36).slice(2)}`,
  content,
});

const createInitialNotepadPagesState = (): NotepadPagesState => {
  const page = createNotepadPage(localStorage.getItem(NOTEPAD_WIDGET_CONTENT_STORAGE_KEY) || '');
  return { pages: [page], activePageId: page.id };
};

export const loadNotepadPagesState = (): NotepadPagesState => {
  try {
    const raw = localStorage.getItem(NOTEPAD_PAGES_STORAGE_KEY);
    if (!raw) return createInitialNotepadPagesState();
    const value = JSON.parse(raw) as Partial<NotepadPagesState>;
    const pages = Array.isArray(value.pages)
      ? value.pages.filter((page): page is NotepadPage => (
        typeof page === 'object'
        && page !== null
        && typeof page.id === 'string'
        && typeof page.content === 'string'
        && (page.lock === undefined || (
          typeof page.lock === 'object'
          && page.lock !== null
          && typeof page.lock.salt === 'string'
          && typeof page.lock.verifier === 'string'
          && typeof page.lock.iv === 'string'
          && typeof page.lock.ciphertext === 'string'
        ))
      ))
      : [];
    if (pages.length === 0) return createInitialNotepadPagesState();
    const activePageId = pages.some(page => page.id === value.activePageId)
      ? value.activePageId as string
      : pages[0].id;
    return { pages, activePageId };
  } catch {
    return createInitialNotepadPagesState();
  }
};

export const saveNotepadPagesState = (state: NotepadPagesState) => {
  localStorage.setItem(NOTEPAD_PAGES_STORAGE_KEY, JSON.stringify(state));
  localStorage.removeItem(NOTEPAD_WIDGET_CONTENT_STORAGE_KEY);
};
import type { NotepadPageLock } from './notepadSecurity';
