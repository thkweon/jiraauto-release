import { useEffect } from 'react';

const API_BASE = 'http://localhost:8000/api';

export function useTeamNotifications() {
  useEffect(() => {
    let cancelled = false;
    let intervalId: ReturnType<typeof setInterval> | undefined;

    const clearPolling = () => {
      if (intervalId !== undefined) {
        clearInterval(intervalId);
        intervalId = undefined;
      }
    };

    const isLicensed = async () => {
      try {
        const res = await fetch(`${API_BASE}/license/status`);
        const data = await res.json();
        return Boolean(data.licensed);
      } catch {
        return false;
      }
    };

    const checkNotifications = async () => {
      if (!(await isLicensed())) return;

      const role = localStorage.getItem('teamRole');
      const leaderUrl = localStorage.getItem('teamLeaderUrl');
      
      // If not in a team, do not poll
      if (!role) return;
      
      const baseUrl = role === 'leader' ? API_BASE : `${leaderUrl}/api`;

      try {
        // 1. Check Notices
        const resNotices = await fetch(`${baseUrl}/team/notices`);
        const dataNotices = await resNotices.json();
        const notices = dataNotices.notices || [];
        
        if (notices.length > 0) {
          const latestNotice = notices[0];
          const lastNoticeId = localStorage.getItem('lastSeenNoticeId');
          
          if (lastNoticeId !== latestNotice.id) {
            // New notice found
            if (lastNoticeId) { // Only alert if we had a previous notice to compare against (skip first load spam)
              const contentSnippet = latestNotice.content.length > 30 
                ? latestNotice.content.substring(0, 30) + '...' 
                : latestNotice.content;
                
              if (Notification.permission === 'granted') {
                new Notification(`팀 공지사항: ${latestNotice.author}`, {
                  body: contentSnippet,
                  icon: '/favicon.svg'
                });
              }
            }
            localStorage.setItem('lastSeenNoticeId', latestNotice.id);
          }
        }

        // 2. Check Boards
        const resBoards = await fetch(`${baseUrl}/team/boards`);
        const dataBoards = await resBoards.json();
        const boards = dataBoards.boards || [];
        
        if (boards.length > 0) {
          const latestBoard = boards[0];
          const lastBoardId = localStorage.getItem('lastSeenBoardId');
          
          if (lastBoardId !== latestBoard.id) {
            // New board post found
            if (lastBoardId) { // Skip first load spam
              const contentSnippet = latestBoard.content.length > 30 
                ? latestBoard.content.substring(0, 30) + '...' 
                : latestBoard.content;
                
              if (Notification.permission === 'granted') {
                new Notification(`팀 게시판: ${latestBoard.author}`, {
                  body: contentSnippet,
                  icon: '/favicon.svg'
                });
              }
            }
            localStorage.setItem('lastSeenBoardId', latestBoard.id);
          }
        }

        // 3. Check Notice Comments
        const resNoticesComments = await fetch(`${baseUrl}/team/notices/recent_comments`);
        const dataNoticesComments = await resNoticesComments.json();
        const noticeComment = dataNoticesComments.comment;
        if (noticeComment) {
          const lastNoticeCommentId = localStorage.getItem('lastSeenNoticeCommentId');
          if (lastNoticeCommentId !== noticeComment.id) {
            if (lastNoticeCommentId) {
              const contentSnippet = noticeComment.content.length > 30 ? noticeComment.content.substring(0, 30) + '...' : noticeComment.content;
              if (Notification.permission === 'granted') {
                new Notification(`공지사항 새 댓글: ${noticeComment.author}`, { body: contentSnippet, icon: '/favicon.svg' });
              }
            }
            localStorage.setItem('lastSeenNoticeCommentId', noticeComment.id);
          }
        }

        // 4. Check Board Comments
        const resBoardsComments = await fetch(`${baseUrl}/team/boards/recent_comments`);
        const dataBoardsComments = await resBoardsComments.json();
        const boardComment = dataBoardsComments.comment;
        if (boardComment) {
          const lastBoardCommentId = localStorage.getItem('lastSeenBoardCommentId');
          if (lastBoardCommentId !== boardComment.id) {
            if (lastBoardCommentId) {
              const contentSnippet = boardComment.content.length > 30 ? boardComment.content.substring(0, 30) + '...' : boardComment.content;
              if (Notification.permission === 'granted') {
                new Notification(`게시판 새 댓글: ${boardComment.author}`, { body: contentSnippet, icon: '/favicon.svg' });
              }
            }
            localStorage.setItem('lastSeenBoardCommentId', boardComment.id);
          }
        }
      } catch {
        // Silently fail if server is down or network issues
      }
    };

    const startPolling = async () => {
      clearPolling();
      if (!(await isLicensed()) || cancelled) return;

      // Only request permission after the app is licensed.
      if (Notification.permission === 'default') {
        Notification.requestPermission();
      }

      const intervalStr = localStorage.getItem('refreshInterval') || '15';
      const intervalMs = parseInt(intervalStr, 10) * 1000;
      intervalId = setInterval(checkNotifications, intervalMs);
      checkNotifications();
    };

    startPolling();

    const handleStorageChange = () => {
      startPolling();
    };

    window.addEventListener('storage', handleStorageChange);
    // Custom event for same-tab updates
    window.addEventListener('refreshIntervalChanged', handleStorageChange);
    window.addEventListener('licenseChanged', handleStorageChange);

    return () => {
      cancelled = true;
      clearPolling();
      window.removeEventListener('storage', handleStorageChange);
      window.removeEventListener('refreshIntervalChanged', handleStorageChange);
      window.removeEventListener('licenseChanged', handleStorageChange);
    };
  }, []);
}
