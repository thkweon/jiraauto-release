type StyleMarker = '*' | '_' | '+' | '-';
type ProtectToken = (html: string) => string;

const STYLE_TAGS: Record<StyleMarker, (content: string) => string> = {
  '*': content => `<strong>${content}</strong>`,
  '_': content => `<em>${content}</em>`,
  '+': content => `<span class="jira-underline">${content}</span>`,
  '-': content => `<span class="jira-strike">${content}</span>`,
};

const STYLE_MARKERS: StyleMarker[] = ['*', '_', '+', '-'];
const TOKEN_PATTERN = /@@JIRA_INLINE_(\d+)@@/g;

const escapeRegExp = (value: string) => value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

export const normalizeJiraWikiMarkers = (value: string): string => value
  .replace(/\{\*\}/g, '*')
  .replace(/\{_\}/g, '_')
  .replace(/\{\+\}/g, '+')
  .replace(/\{-\}/g, '-');

const safeColor = (color: string): string => {
  const trimmed = color.trim();
  if (/^#[0-9a-fA-F]{3}([0-9a-fA-F]{3})?$/.test(trimmed)) return trimmed;
  if (/^rgba?\(\s*\d{1,3}\s*,\s*\d{1,3}\s*,\s*\d{1,3}(?:\s*,\s*(?:0|1|0?\.\d+))?\s*\)$/.test(trimmed)) return trimmed;
  // Jira wiki also allows CSS color names ({color:red}); accept only plain words.
  if (/^[a-zA-Z]{3,20}$/.test(trimmed)) {
    if (typeof CSS !== 'undefined' && typeof CSS.supports === 'function') {
      return CSS.supports('color', trimmed) ? trimmed.toLowerCase() : '';
    }
    return trimmed.toLowerCase();
  }
  return '';
};

const replaceBoundedStyle = (
  value: string,
  marker: StyleMarker,
  render: (content: string) => string,
): string => {
  const escapedMarker = escapeRegExp(marker);
  const contentPattern = marker === '-'
    ? `(?!&gt;)([^${escapedMarker}\\n]+?)`
    : `([^${escapedMarker}\\n]+?)`;
  const pattern = new RegExp(
    `(^|[^\\p{L}\\p{N}_-])${escapedMarker}${contentPattern}${escapedMarker}(?=$|[^\\p{L}\\p{N}_-])`,
    'gu',
  );
  return value.replace(pattern, (_match, prefix, content) => `${prefix}${render(content)}`);
};

/**
 * Apply Jira wiki inline styles to already HTML-escaped text.
 *
 * Content inside every explicit marker (`{*}..{*}`, `{color:red}..{color}`, ...)
 * is processed recursively, so styles nest in any combination, e.g. a red run
 * containing bold and italic parts, or bold text wrapping italics.
 */
export const applyJiraInlineStyles = (input: string, protectToken: ProtectToken): string => {
  const render = (value: string): string => {
    let html = value;

    for (const marker of STYLE_MARKERS) {
      const escaped = escapeRegExp(marker);
      html = html.replace(
        new RegExp(`\\{${escaped}\\}([\\s\\S]+?)\\{${escaped}\\}`, 'g'),
        (_match, content) => protectToken(STYLE_TAGS[marker](render(content))),
      );
    }

    // Colors wrap arbitrary (already styled) content. Resolve the innermost block
    // first so adjacent or nested colors do not swallow each other.
    const colorPattern = /\{color:([^}]+)\}((?:(?!\{color:)[\s\S])*?)\{color\}/g;
    let previous: string;
    do {
      previous = html;
      html = html.replace(colorPattern, (_match, color, content) => {
        const colorValue = safeColor(color);
        const inner = render(content);
        return protectToken(colorValue ? `<span style="color:${colorValue}">${inner}</span>` : inner);
      });
    } while (html !== previous);

    html = normalizeJiraWikiMarkers(html)
      .replace(/\{\}/g, '')
      .replace(/\{\{([^}]+)\}\}/g, (_match, content) => protectToken(`<code>${content}</code>`))
      .replace(/\?\?([^?\n]+)\?\?/g, (_match, content) => protectToken(`<cite>${content}</cite>`));

    for (const marker of STYLE_MARKERS) {
      html = replaceBoundedStyle(html, marker, STYLE_TAGS[marker]);
    }
    return html;
  };

  return render(input);
};

/** Restore protected tokens. Tokens can contain other tokens when styles are nested. */
export const restoreProtectedTokens = (value: string, tokens: string[]): string => {
  let html = value;
  // Bounded depth guards against pathological self-references.
  for (let depth = 0; depth < 32 && TOKEN_PATTERN.test(html); depth += 1) {
    TOKEN_PATTERN.lastIndex = 0;
    html = html.replace(TOKEN_PATTERN, (_match, index) => tokens[Number(index)] ?? '');
  }
  TOKEN_PATTERN.lastIndex = 0;
  return html;
};
