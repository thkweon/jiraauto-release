@echo off
setlocal
chcp 65001 > nul
echo =========================================
echo Jira Dashboard Auto-Updater Bootstrap
echo =========================================

rem Cache-bust GitHub raw CDN so the bootstrap sees the same release the app validated.
set "VERSION_URL=https://raw.githubusercontent.com/thkweon/jiraauto-release/main/version.json?t=%RANDOM%%RANDOM%%RANDOM%"
set "VERSION_FILE=version_remote.json"
set "UPDATER_FILE=remote_update_temp.bat"
set "UPDATE_CHANNEL=%~1"
set "EXPECTED_VERSION=%~2"
set "UPDATER_URL="
set "EXPECTED_UPDATER_HASH="
if /I not "%UPDATE_CHANNEL%"=="beta" set "UPDATE_CHANNEL=stable"

echo [1/5] Preparing downloader...
if exist "downloader.py" del "downloader.py"
(
echo import urllib.request, sys, ssl, json
echo ctx = ssl.create_default_context^(^)
echo ctx.check_hostname = False
echo ctx.verify_mode = ssl.CERT_NONE
echo proxy = urllib.request.ProxyHandler^(^)
echo opener = urllib.request.build_opener^(proxy, urllib.request.HTTPSHandler^(context=ctx^)^)
echo urllib.request.install_opener^(opener^)
echo if len^(sys.argv^) == 4 and sys.argv[1] == "--field":
echo     with open^(sys.argv[2], "r", encoding="utf-8-sig"^) as f: data = json.load^(f^)
echo     value = data.get^(sys.argv[3], ""^)
echo     if isinstance^(value, str^): print^(value.strip^(^)^)
echo     sys.exit^(0^)
echo try:
echo     urllib.request.urlretrieve^(sys.argv[1], sys.argv[2]^)
echo except Exception as e:
echo     print^("Download Error:", e^)
echo     sys.exit^(1^)
) > downloader.py

set "PYTHON_EXE="
if exist "backend\venv\Scripts\python.exe" set "PYTHON_EXE=backend\venv\Scripts\python.exe"
if "%PYTHON_EXE%"=="" (
    where python >nul 2>&1
    if not errorlevel 1 set "PYTHON_EXE=python"
)
if "%PYTHON_EXE%"=="" (
    echo [ERROR] Python is not available. Run run.bat first to rebuild the environment.
    timeout /t 15
    exit
)

echo [2/5] Downloading release metadata...
if exist "%VERSION_FILE%" del "%VERSION_FILE%"
"%PYTHON_EXE%" downloader.py "%VERSION_URL%" "%VERSION_FILE%"
if not exist "%VERSION_FILE%" (
    echo [ERROR] Failed to download version metadata.
    if exist "downloader.py" del "downloader.py"
    timeout /t 15
    exit
)

"%PYTHON_EXE%" downloader.py --field "%VERSION_FILE%" updater_url > updater_url.tmp
if errorlevel 1 goto :MetadataReadFailed
set /p "UPDATER_URL=" < updater_url.tmp
"%PYTHON_EXE%" downloader.py --field "%VERSION_FILE%" updater_sha256 > updater_hash.tmp
if errorlevel 1 goto :MetadataReadFailed
set /p "EXPECTED_UPDATER_HASH=" < updater_hash.tmp
del updater_url.tmp updater_hash.tmp > nul 2>&1

if not defined UPDATER_URL (
    echo [ERROR] updater_url is missing or invalid in version metadata.
    goto :MetadataReadFailed
)
if not defined EXPECTED_UPDATER_HASH (
    echo [ERROR] updater_sha256 is missing from version metadata.
    goto :MetadataReadFailed
)

echo [3/5] Downloading latest updater...
if /I not "%UPDATER_URL:~0,8%"=="https://" (
    echo [ERROR] updater_url must use HTTPS. Value: "%UPDATER_URL%"
    if exist "downloader.py" del "downloader.py"
    timeout /t 15
    exit /b 1
)
rem Bypass stale raw-file CDN entries while preserving the manifest-pinned hash check.
set "UPDATER_URL=%UPDATER_URL%?t=%RANDOM%%RANDOM%%RANDOM%"
if exist "%UPDATER_FILE%" del "%UPDATER_FILE%"
"%PYTHON_EXE%" downloader.py "%UPDATER_URL%" "%UPDATER_FILE%"
if not exist "%UPDATER_FILE%" (
    echo [ERROR] Failed to download latest updater.
    if exist "downloader.py" del "downloader.py"
    timeout /t 15
    exit
)

echo [4/5] Verifying updater integrity...
for /f "delims=" %%H in ('powershell -NoProfile -Command "(Get-FileHash '.\%UPDATER_FILE%' -Algorithm SHA256).Hash"') do set "ACTUAL_UPDATER_HASH=%%H"
if /I not "%EXPECTED_UPDATER_HASH%"=="%ACTUAL_UPDATER_HASH%" (
    echo [ERROR] Updater integrity check failed!
    echo Expected: %EXPECTED_UPDATER_HASH%
    echo Actual  : %ACTUAL_UPDATER_HASH%
    del "%UPDATER_FILE%"
    if exist "downloader.py" del "downloader.py"
    timeout /t 15
    exit
)

echo [5/5] Running latest updater...
call "%UPDATER_FILE%" "%UPDATE_CHANNEL%" "%EXPECTED_VERSION%"
set "UPDATER_EXIT=%ERRORLEVEL%"
if exist "%UPDATER_FILE%" del "%UPDATER_FILE%"
if exist "downloader.py" del "downloader.py"
exit /b %UPDATER_EXIT%

:MetadataReadFailed
if exist "updater_url.tmp" del "updater_url.tmp"
if exist "updater_hash.tmp" del "updater_hash.tmp"
if exist "downloader.py" del "downloader.py"
timeout /t 15
exit /b 1
